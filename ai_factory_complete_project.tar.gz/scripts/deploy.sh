#!/bin/bash

# 识别结果后处理和置信度验证系统部署脚本
# ==========================================
# 
# 作者: MiniMax Agent
# 版本: 1.0.0
# 日期: 2025-11-06

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

check_python() {
    log_step "检查Python版本..."
    
    if ! command -v python3 &> /dev/null; then
        log_error "Python3 未安装，请先安装Python 3.8+"
        exit 1
    fi
    
    python_version=$(python3 --version | cut -d' ' -f2)
    log_info "Python版本: $python_version"
    
    if python3 -c "import sys; exit(0 if sys.version_info >= (3, 8) else 1)"; then
        log_info "Python版本符合要求 (>=3.8)"
    else
        log_error "Python版本过低，需要3.8或更高版本"
        exit 1
    fi
}

check_dependencies() {
    log_step "检查系统依赖..."
    
    if ! command -v pip3 &> /dev/null; then
        log_error "pip3 未安装，请先安装pip"
        exit 1
    fi
    
    log_info "系统依赖检查完成"
}

install_dependencies() {
    log_step "安装Python依赖包..."
    
    cat > requirements.txt << 'REQEOF'
numpy>=1.19.0
pandas>=1.3.0
scikit-learn>=1.0.0
scipy>=1.7.0
networkx>=2.6.0
matplotlib>=3.4.0
seaborn>=0.11.0
pytest>=6.0.0
psutil>=5.8.0
REQEOF
    
    pip3 install -r requirements.txt
    log_info "Python依赖安装完成"
}

create_directories() {
    log_step "创建目录结构..."
    
    directories=(
        "logs"
        "data/input"
        "data/output"
        "data/temp"
        "config"
        "tests"
        "docs"
        "scripts"
        "visualizations"
    )
    
    for dir in "${directories[@]}"; do
        mkdir -p "$dir"
        log_info "创建目录: $dir"
    done
    
    log_info "目录结构创建完成"
}

setup_configs() {
    log_step "设置配置文件..."
    
    if [ ! -f "config/system_config.json" ]; then
        log_info "创建默认配置文件..."
        python3 -c "
from config_system import get_config_by_environment, save_config_to_file
config = get_config_by_environment('production')
save_config_to_file(config, 'config/system_config.json')
print('默认配置文件已创建')
" 2>/dev/null || log_warn "配置文件创建失败，请手动配置"
    fi
    
    log_info "配置文件设置完成"
}

verify_installation() {
    log_step "验证安装..."
    
    python3 -c "
try:
    from result_postprocessing_system import ResultPostprocessingSystem
    from config_system import get_config_by_environment
    config = get_config_by_environment('production')
    system = ResultPostprocessingSystem(config)
    print('✓ 系统组件加载成功')
    print('✓ 系统验证通过')
except Exception as e:
    print(f'✗ 验证失败: {e}')
    exit(1)
" 2>/dev/null || log_warn "系统验证失败，请检查安装"
    
    log_info "安装验证完成"
}

show_usage() {
    echo ""
    echo "=" * 60
    echo "部署完成！使用说明:"
    echo "=" * 60
    echo ""
    echo "1. 启动系统:"
    echo "   python3 scripts/start_system.py"
    echo ""
    echo "2. 运行示例:"
    echo "   python3 code/example_usage.py"
    echo ""
    echo "3. 运行测试:"
    echo "   python3 -m pytest code/test_validation_framework.py -v"
    echo ""
    echo "4. 配置系统:"
    echo "   编辑 config/system_config.json"
    echo ""
    echo "5. 查看文档:"
    echo "   docs/result_postprocessing_validation.md"
    echo ""
}

main() {
    echo "识别结果后处理和置信度验证系统 - 部署脚本"
    echo "=================================================="
    echo ""
    
    check_python
    check_dependencies
    install_dependencies
    create_directories
    setup_configs
    verify_installation
    
    log_info "部署完成！"
    show_usage
}

main "$@"
