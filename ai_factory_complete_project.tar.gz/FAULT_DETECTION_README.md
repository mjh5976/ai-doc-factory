# 故障检测和自动重启机制

一个完整的故障检测和自动重启系统，专为微服务架构设计，包含健康检查、心跳检测、故障分类、自动重启、依赖管理、通知机制和审计日志等功能。

## 🚀 功能特性

### 核心功能
- **健康检查和心跳检测**: 多层级健康检查（进程、端口、HTTP、数据库、缓存、模型服务）
- **故障类型识别和分类**: 智能故障分类和优先级管理
- **自动重启策略和限制**: 指数退避重试机制、熔断器模式、启动保护期
- **服务依赖管理**: 服务依赖图构建、拓扑排序启动、级联重启和隔离
- **故障恢复和通知机制**: 多种通知渠道、故障恢复流程、升级机制
- **日志记录和审计**: 结构化日志记录、故障事件审计、性能指标监控

### 技术特点
- **零依赖集成**: 基于现有技术栈，无需额外依赖
- **生产就绪**: 包含安全配置、错误处理、监控指标
- **可扩展性**: 支持新服务快速接入
- **可观测性**: 完整的监控和告警体系
- **自动化**: 端到端自动化故障处理

## 📋 系统架构

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   演示服务1     │    │   演示服务2     │    │   Redis缓存     │
│  (Flask API)    │    │  (Flask API)    │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 │
         ┌─────────────────────────────────────────────┐
         │            故障检测服务                     │
         │  ┌─────────────┐ ┌─────────────────────┐   │
         │  │ 健康检查器  │ │    故障分类器       │   │
         │  └─────────────┘ └─────────────────────┘   │
         │  ┌─────────────┐ ┌─────────────────────┐   │
         │  │ 重启管理器  │ │    通知管理器       │   │
         │  └─────────────┘ └─────────────────────┘   │
         └─────────────────────────────────────────────┘
                                 │
    ┌────────────────────────────┼────────────────────────────┐
    │                            │                            │
┌─────────────┐        ┌──────────────┐           ┌─────────────┐
│ Prometheus  │        │   Grafana    │           │   Alert     │
│   监控      │        │   可视化     │           │   告警      │
└─────────────┘        └──────────────┘           └─────────────┘
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 │
                    ┌─────────────────────────┐
                    │      Loki日志聚合       │
                    └─────────────────────────┘
```

## 🛠️ 技术栈

- **后端**: Python 3.11, Flask, Prometheus客户端
- **容器化**: Docker, Docker Compose
- **监控**: Prometheus, Grafana, Alertmanager
- **日志**: Loki, Promtail
- **缓存**: Redis
- **通知**: SMTP邮件, 钉钉, 企业微信, Slack

## 🚀 快速开始

### 前置要求

- Docker >= 20.10
- Docker Compose >= 2.0
- curl (用于测试)
- jq (可选，用于JSON格式化)

### 1. 克隆项目

```bash
git clone <repository-url>
cd fault-detection-auto-restart
```

### 2. 配置通知渠道（可选）

编辑 `configs/fault_detection_config.yaml` 文件，配置邮件和Webhook通知：

```yaml
notifications:
  email:
    username: your-email@qq.com
    password: your-app-password
    from_addr: your-email@qq.com
    to_addrs:
      - admin@company.com
  
  webhook:
    dingtalk: https://oapi.dingtalk.com/robot/send?access_token=your-token
    wechat: https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=your-key
```

### 3. 启动系统

```bash
chmod +x *.sh
./start.sh
```

系统将自动：
- 构建所有Docker镜像
- 启动所有服务
- 配置监控和告警
- 显示访问信息

### 4. 验证系统

```bash
# 检查服务状态
./demo.sh status

# 测试健康检查
./demo.sh test-health

# 模拟故障测试
./demo.sh test-crash
```

## 📊 访问地址

启动完成后，可通过以下地址访问：

| 服务 | 地址 | 说明 |
|------|------|------|
| 演示API服务1 | http://localhost:5001 | 第一个演示服务 |
| 演示API服务2 | http://localhost:5002 | 第二个演示服务 |
| 故障检测服务 | http://localhost:8080 | 故障检测API |
| Prometheus | http://localhost:9090 | 指标监控 |
| Grafana | http://localhost:3000 | 可视化面板 (admin/admin123) |
| Alertmanager | http://localhost:9093 | 告警管理 |

## 🧪 演示和测试

### 基本测试

```bash
# 查看系统状态
./demo.sh status

# 测试健康检查
./demo.sh test-health

# 模拟服务崩溃
./demo.sh test-crash

# 模拟错误响应
./demo.sh test-error

# 模拟内存泄漏
./demo.sh test-memory

# 模拟服务挂起
./demo.sh test-hang

# 随机故障模拟
./demo.sh test-random

# 运行所有测试
./demo.sh test-all

# 实时监控系统
./demo.sh monitor

# 查看故障检测日志
./demo.sh logs
```

### 手动测试

```bash
# 查看服务状态
curl http://localhost:5001/health

# 模拟不同类型的故障
curl "http://localhost:5001/simulate-failure?type=crash"     # 进程崩溃
curl "http://localhost:5001/simulate-failure?type=error"     # 错误响应
curl "http://localhost:5001/simulate-failure?type=memory"    # 内存泄漏
curl "http://localhost:5001/simulate-failure?type=hang"      # 服务挂起

# 查看故障检测服务
curl http://localhost:8080/services
curl http://localhost:8080/health

# 手动重启服务
curl -X POST http://localhost:8080/restart/demo-api-1
```

## 🔧 配置说明

### 服务配置

在 `configs/fault_detection_config.yaml` 中配置要监控的服务：

```yaml
services:
  your-service-name:
    container_name: your-container-name
    health_check_url: http://your-service:5000/health
    metrics_url: http://your-service:5000/metrics
    restart_policy: graceful    # graceful/force/scaling
    max_restart_attempts: 3     # 最大重启次数
    restart_delay: 30          # 重启延迟(秒)
    dependencies: []           # 依赖服务列表
    critical: true             # 是否为关键服务
    notification_channels: ["email", "dingtalk"]  # 通知渠道
```

### 故障检测阈值

```yaml
thresholds:
  memory_mb: 500          # 内存使用阈值(MB)
  cpu_percent: 80         # CPU使用率阈值(%)
  error_rate: 0.1         # 错误率阈值
  response_time: 5.0      # 响应时间阈值(秒)
```

### 重启策略

```yaml
restart_policies:
  max_attempts: 3         # 最大重启尝试次数
  delay_seconds: 30       # 重启延迟(秒)
  backoff_multiplier: 2   # 退避倍数
```

## 📈 监控和告警

### Prometheus指标

故障检测服务暴露以下指标：

- `alerts_total`: 告警总数 (按严重程度和服务分组)
- `restarts_total`: 重启总数 (按服务和服务分组)
- `health_checks_total`: 健康检查总数 (按服务和状态分组)
- `fault_detection_latency_seconds`: 故障检测延迟
- `service_status`: 服务状态 (1=健康, 0=不健康)

### Grafana仪表板

访问 http://localhost:3000 查看预配置的仪表板：

- **系统概览**: 所有服务的总体状态
- **故障检测**: 故障事件和重启统计
- **性能监控**: 服务性能指标
- **告警历史**: 告警事件历史

### 告警规则

系统包含以下告警规则：

- **ServiceDown**: 服务不可用
- **HealthCheckFailed**: 健康检查失败
- **HeartbeatLost**: 心跳丢失
- **HighErrorRate**: 错误率过高
- **HighMemoryUsage**: 内存使用率过高
- **HighCPUUsage**: CPU使用率过高
- **TooManyRestarts**: 重启次数过多

## 🔍 日志和审计

### 日志结构

所有日志采用结构化JSON格式，包含以下字段：

- `timestamp`: 时间戳
- `level`: 日志级别 (DEBUG/INFO/WARNING/ERROR)
- `service`: 服务名称
- `message`: 日志消息
- `details`: 详细信息

### 审计日志

审计日志记录所有关键操作：

- 故障检测事件
- 重启尝试记录
- 通知发送记录
- 配置变更记录

审计日志文件位置：`/app/logs/audit.log`

## 🚨 故障处理流程

1. **检测阶段**: 定期执行健康检查
2. **分类阶段**: 根据故障类型和严重程度进行分类
3. **决策阶段**: 根据策略决定是否重启
4. **执行阶段**: 执行重启操作
5. **验证阶段**: 验证重启结果
6. **通知阶段**: 发送通知给相关人员
7. **审计阶段**: 记录所有操作到审计日志

## 🛡️ 安全考虑

- 容器运行使用非root用户
- 网络隔离和服务间通信限制
- 敏感配置信息通过环境变量管理
- 日志脱敏处理
- 访问控制和权限管理

## 🔄 扩展和定制

### 添加新服务

1. 在 `configs/fault_detection_config.yaml` 中添加服务配置
2. 确保服务提供健康检查端点 (`/health`)
3. 重新启动故障检测服务

### 自定义故障类型

继承 `FaultType` 枚举类，添加新的故障类型：

```python
class FaultType(Enum):
    # 现有故障类型...
    CUSTOM_FAULT = "custom_fault"
```

### 添加通知渠道

继承 `NotificationManager` 类，实现新的通知方法：

```python
def _send_custom_notification(self, fault_event, service_config):
    # 实现自定义通知逻辑
    pass
```

## 📚 最佳实践

1. **服务设计**: 确保服务提供可靠的健康检查端点
2. **配置管理**: 使用环境变量管理敏感配置
3. **监控覆盖**: 为所有关键服务配置监控和告警
4. **测试验证**: 定期进行故障演练和恢复测试
5. **文档维护**: 保持配置和流程文档的更新

## 🐛 故障排除

### 常见问题

1. **服务无法启动**
   - 检查Docker镜像是否正确构建
   - 验证配置文件格式
   - 查看容器日志

2. **故障检测不工作**
   - 检查健康检查URL是否可访问
   - 验证Redis连接
   - 查看故障检测服务日志

3. **通知不发送**
   - 检查通知配置
   - 验证网络连接
   - 确认Webhook URL有效性

### 日志查看

```bash
# 查看所有服务日志
docker-compose logs -f

# 查看特定服务日志
docker-compose logs -f fault-detector
docker-compose logs -f demo-api-1

# 查看系统日志
tail -f logs/fault_detector.log
tail -f logs/audit.log
```

## 🤝 贡献指南

1. Fork 项目
2. 创建特性分支
3. 提交更改
4. 推送到分支
5. 创建 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 📞 支持

如有问题或建议，请：

1. 查看文档和FAQ
2. 搜索已存在的问题
3. 创建新的 Issue
4. 联系维护团队

---

**注意**: 这是一个演示系统，生产环境使用前请根据实际需求进行充分测试和配置调整。