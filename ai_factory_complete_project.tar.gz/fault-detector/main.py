#!/usr/bin/env python3
"""
故障检测和自动重启机制 - 核心模块
包含健康检查、心跳检测、故障分类、重启策略、依赖管理等功能
"""

import os
import time
import json
import yaml
import redis
import docker
import logging
import threading
import smtplib
import requests
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, asdict
from enum import Enum
from apscheduler.schedulers.background import BackgroundScheduler
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
import structlog

# 配置日志
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

# Prometheus指标
ALERT_COUNT = Counter('alerts_total', 'Total alerts sent', ['severity', 'service'])
RESTART_COUNT = Counter('restarts_total', 'Total restarts', ['service', 'strategy'])
HEALTH_CHECK_COUNT = Counter('health_checks_total', 'Total health checks', ['service', 'status'])
DETECTION_LATENCY = Histogram('fault_detection_latency_seconds', 'Fault detection latency')
SERVICE_STATUS = Gauge('service_status', 'Service status', ['service'])

class FaultType(Enum):
    """故障类型枚举"""
    SERVICE_DOWN = "service_down"
    HIGH_ERROR_RATE = "high_error_rate"
    HIGH_MEMORY_USAGE = "high_memory_usage"
    HIGH_CPU_USAGE = "high_cpu_usage"
    DEPENDENCY_FAILURE = "dependency_failure"
    NETWORK_ISSUE = "network_issue"
    UNKNOWN = "unknown"

class FaultSeverity(Enum):
    """故障严重程度"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

class RestartStrategy(Enum):
    """重启策略"""
    GRACEFUL = "graceful"
    FORCE = "force"
    SCALING = "scaling"

@dataclass
class ServiceConfig:
    """服务配置"""
    name: str
    container_name: str
    health_check_url: str
    metrics_url: str
    restart_policy: str
    max_restart_attempts: int
    restart_delay: int
    dependencies: List[str]
    critical: bool
    notification_channels: List[str]

@dataclass
class FaultEvent:
    """故障事件"""
    service_name: str
    fault_type: FaultType
    severity: FaultSeverity
    message: str
    timestamp: datetime
    details: Dict[str, Any]
    resolved: bool = False

@dataclass
class RestartAttempt:
    """重启尝试记录"""
    service_name: str
    strategy: RestartStrategy
    timestamp: datetime
    success: bool
    details: Dict[str, Any]

class ConfigManager:
    """配置管理器"""
    
    def __init__(self, config_path: str = "/app/configs/fault_detection_config.yaml"):
        self.config_path = config_path
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            logger.info("配置加载成功", config_path=self.config_path)
            return config
        except Exception as e:
            logger.error("配置加载失败", error=str(e))
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """获取默认配置"""
        return {
            'services': {},
            'thresholds': {
                'memory_mb': 500,
                'cpu_percent': 80,
                'error_rate': 0.1,
                'response_time': 5.0
            },
            'restart_policies': {
                'max_attempts': 3,
                'delay_seconds': 30,
                'backoff_multiplier': 2
            },
            'notifications': {
                'email': {
                    'smtp_server': 'smtp.qq.com',
                    'smtp_port': 587,
                    'username': '',
                    'password': '',
                    'from_addr': '',
                    'to_addrs': []
                },
                'webhook': {
                    'dingtalk': '',
                    'wechat': '',
                    'slack': ''
                }
            },
            'monitoring': {
                'health_check_interval': 30,
                'metrics_poll_interval': 15,
                'alert_cooldown': 300
            }
        }
    
    def get_service_configs(self) -> List[ServiceConfig]:
        """获取服务配置列表"""
        services = []
        for service_name, config in self.config.get('services', {}).items():
            services.append(ServiceConfig(
                name=service_name,
                container_name=config.get('container_name', service_name),
                health_check_url=config.get('health_check_url', f'http://{service_name}:5000/health'),
                metrics_url=config.get('metrics_url', f'http://{service_name}:5000/metrics'),
                restart_policy=config.get('restart_policy', 'graceful'),
                max_restart_attempts=config.get('max_restart_attempts', 3),
                restart_delay=config.get('restart_delay', 30),
                dependencies=config.get('dependencies', []),
                critical=config.get('critical', False),
                notification_channels=config.get('notification_channels', ['email'])
            ))
        return services
    
    def get_thresholds(self) -> Dict[str, float]:
        """获取阈值配置"""
        return self.config.get('thresholds', {})
    
    def get_notification_config(self) -> Dict[str, Any]:
        """获取通知配置"""
        return self.config.get('notifications', {})

class HealthChecker:
    """健康检查器"""
    
    def __init__(self, config_manager: ConfigManager):
        self.config_manager = config_manager
        self.redis_client = self._init_redis()
        self.docker_client = self._init_docker()
    
    def _init_redis(self) -> Optional[redis.Redis]:
        """初始化Redis连接"""
        try:
            redis_url = os.getenv('REDIS_URL', 'redis://redis:6379')
            client = redis.from_url(redis_url)
            client.ping()
            logger.info("Redis连接成功")
            return client
        except Exception as e:
            logger.warning("Redis连接失败", error=str(e))
            return None
    
    def _init_docker(self) -> docker.DockerClient:
        """初始化Docker客户端"""
        try:
            docker_socket = os.getenv('DOCKER_SOCKET', '/var/run/docker.sock')
            client = docker.DockerClient(base_url=docker_socket)
            client.ping()
            logger.info("Docker连接成功")
            return client
        except Exception as e:
            logger.error("Docker连接失败", error=str(e))
            raise
    
    def check_service_health(self, service_config: ServiceConfig) -> Dict[str, Any]:
        """检查服务健康状态"""
        health_data = {
            'service_name': service_config.name,
            'timestamp': datetime.utcnow().isoformat(),
            'healthy': True,
            'checks': {},
            'metrics': {},
            'issues': []
        }
        
        try:
            # 检查容器状态
            container_health = self._check_container_health(service_config)
            health_data['checks']['container'] = container_health
            
            # 检查健康端点
            endpoint_health = self._check_endpoint_health(service_config.health_check_url)
            health_data['checks']['endpoint'] = endpoint_health
            
            # 检查依赖服务
            dependency_health = self._check_dependencies(service_config.dependencies)
            health_data['checks']['dependencies'] = dependency_health
            
            # 获取性能指标
            metrics = self._get_service_metrics(service_config)
            health_data['metrics'] = metrics
            
            # 综合判断健康状态
            health_data['healthy'] = self._evaluate_health(health_data['checks'], metrics)
            
            # 记录指标
            HEALTH_CHECK_COUNT.labels(
                service=service_config.name, 
                status='healthy' if health_data['healthy'] else 'unhealthy'
            ).inc()
            
        except Exception as e:
            logger.error("健康检查异常", 
                        service=service_config.name, 
                        error=str(e))
            health_data['healthy'] = False
            health_data['checks']['error'] = str(e)
        
        return health_data
    
    def _check_container_health(self, service_config: ServiceConfig) -> Dict[str, Any]:
        """检查容器状态"""
        try:
            container = self.docker_client.containers.get(service_config.container_name)
            return {
                'status': container.status,
                'running': container.status == 'running',
                'restart_count': container.attrs['RestartCount'],
                'health': container.attrs.get('State', {}).get('Health', {}).get('Status', 'unknown')
            }
        except docker.errors.NotFound:
            return {'status': 'not_found', 'running': False}
        except Exception as e:
            return {'status': 'error', 'error': str(e)}
    
    def _check_endpoint_health(self, url: str) -> Dict[str, Any]:
        """检查端点健康状态"""
        try:
            response = requests.get(url, timeout=10)
            return {
                'status_code': response.status_code,
                'healthy': response.status_code == 200,
                'response_time': response.elapsed.total_seconds(),
                'content_length': len(response.content)
            }
        except requests.RequestException as e:
            return {'healthy': False, 'error': str(e)}
    
    def _check_dependencies(self, dependencies: List[str]) -> Dict[str, Any]:
        """检查依赖服务"""
        dependency_status = {}
        for dep in dependencies:
            try:
                dep_url = f"http://{dep}:5000/health"
                response = requests.get(dep_url, timeout=5)
                dependency_status[dep] = {
                    'healthy': response.status_code == 200,
                    'status_code': response.status_code
                }
            except Exception as e:
                dependency_status[dep] = {
                    'healthy': False,
                    'error': str(e)
                }
        return dependency_status
    
    def _get_service_metrics(self, service_config: ServiceConfig) -> Dict[str, Any]:
        """获取服务性能指标"""
        try:
            response = requests.get(service_config.metrics_url, timeout=10)
            # 简化的指标解析，实际应该解析Prometheus格式
            return {
                'memory_mb': 100,  # 示例值
                'cpu_percent': 25,  # 示例值
                'request_rate': 10,  # 示例值
                'error_rate': 0.02  # 示例值
            }
        except Exception as e:
            return {'error': str(e)}
    
    def _evaluate_health(self, checks: Dict[str, Any], metrics: Dict[str, Any]) -> bool:
        """评估健康状态"""
        # 容器检查
        if not checks.get('container', {}).get('running', False):
            return False
        
        # 端点检查
        if not checks.get('endpoint', {}).get('healthy', False):
            return False
        
        # 依赖检查
        for dep_status in checks.get('dependencies', {}).values():
            if not dep_status.get('healthy', False):
                return False
        
        # 性能阈值检查
        thresholds = self.config_manager.get_thresholds()
        if metrics.get('memory_mb', 0) > thresholds.get('memory_mb', 500):
            return False
        
        if metrics.get('cpu_percent', 0) > thresholds.get('cpu_percent', 80):
            return False
        
        return True

class FaultClassifier:
    """故障分类器"""
    
    def __init__(self, config_manager: ConfigManager):
        self.config_manager = config_manager
    
    def classify_fault(self, service_config: ServiceConfig, health_data: Dict[str, Any]) -> Optional[FaultEvent]:
        """分类故障"""
        issues = []
        fault_type = FaultType.UNKNOWN
        severity = FaultSeverity.LOW
        
        # 分析容器状态
        container_health = health_data.get('checks', {}).get('container', {})
        if not container_health.get('running', True):
            fault_type = FaultType.SERVICE_DOWN
            severity = FaultSeverity.CRITICAL
            issues.append("容器未运行")
        
        # 分析端点健康
        endpoint_health = health_data.get('checks', {}).get('endpoint', {})
        if not endpoint_health.get('healthy', True):
            fault_type = FaultType.SERVICE_DOWN
            severity = FaultSeverity.HIGH
            issues.append("健康检查端点不可用")
        
        # 分析依赖状态
        dependency_health = health_data.get('checks', {}).get('dependencies', {})
        failed_deps = [dep for dep, status in dependency_health.items() 
                      if not status.get('healthy', True)]
        if failed_deps:
            fault_type = FaultType.DEPENDENCY_FAILURE
            severity = FaultSeverity.HIGH
            issues.append(f"依赖服务失败: {', '.join(failed_deps)}")
        
        # 分析性能指标
        metrics = health_data.get('metrics', {})
        thresholds = self.config_manager.get_thresholds()
        
        if metrics.get('memory_mb', 0) > thresholds.get('memory_mb', 500):
            fault_type = FaultType.HIGH_MEMORY_USAGE
            severity = FaultSeverity.MEDIUM
            issues.append(f"内存使用过高: {metrics['memory_mb']}MB")
        
        if metrics.get('cpu_percent', 0) > thresholds.get('cpu_percent', 80):
            fault_type = FaultType.HIGH_CPU_USAGE
            severity = FaultSeverity.MEDIUM
            issues.append(f"CPU使用率过高: {metrics['cpu_percent']}%")
        
        # 如果没有发现问题，返回None
        if not issues:
            return None
        
        # 创建故障事件
        return FaultEvent(
            service_name=service_config.name,
            fault_type=fault_type,
            severity=severity,
            message=f"{fault_type.value}: {', '.join(issues)}",
            timestamp=datetime.utcnow(),
            details={
                'health_data': health_data,
                'issues': issues,
                'container_name': service_config.container_name
            }
        )

class RestartManager:
    """重启管理器"""
    
    def __init__(self, config_manager: ConfigManager):
        self.config_manager = config_manager
        self.docker_client = docker.DockerClient()
        self.restart_history: List[RestartAttempt] = []
        self.restart_attempts: Dict[str, int] = {}
    
    def should_restart(self, service_config: ServiceConfig, fault_event: FaultEvent) -> bool:
        """判断是否应该重启"""
        # 检查重启次数限制
        attempts = self.restart_attempts.get(service_config.name, 0)
        if attempts >= service_config.max_restart_attempts:
            logger.warning("重启次数已达上限", 
                          service=service_config.name, 
                          attempts=attempts,
                          max_attempts=service_config.max_restart_attempts)
            return False
        
        # 检查冷却时间
        recent_attempts = [
            attempt for attempt in self.restart_history
            if attempt.service_name == service_config.name and
            (datetime.utcnow() - attempt.timestamp).total_seconds() < 300  # 5分钟冷却
        ]
        
        if len(recent_attempts) >= 2:
            logger.info("重启冷却期内", 
                       service=service_config.name,
                       recent_attempts=len(recent_attempts))
            return False
        
        return True
    
    def restart_service(self, service_config: ServiceConfig, fault_event: FaultEvent) -> bool:
        """重启服务"""
        strategy = self._determine_strategy(service_config, fault_event)
        
        try:
            logger.info("开始重启服务", 
                       service=service_config.name,
                       strategy=strategy.value,
                       fault_type=fault_event.fault_type.value)
            
            success = False
            details = {}
            
            if strategy == RestartStrategy.GRACEFUL:
                success, details = self._graceful_restart(service_config)
            elif strategy == RestartStrategy.FORCE:
                success, details = self._force_restart(service_config)
            elif strategy == RestartStrategy.SCALING:
                success, details = self._scaling_restart(service_config)
            
            # 记录重启尝试
            attempt = RestartAttempt(
                service_name=service_config.name,
                strategy=strategy,
                timestamp=datetime.utcnow(),
                success=success,
                details=details
            )
            self.restart_history.append(attempt)
            
            # 更新重启计数
            if success:
                self.restart_attempts[service_config.name] = self.restart_attempts.get(service_config.name, 0) + 1
                RESTART_COUNT.labels(service=service_config.name, strategy=strategy.value).inc()
                logger.info("服务重启成功", 
                           service=service_config.name,
                           strategy=strategy.value)
            else:
                logger.error("服务重启失败", 
                            service=service_config.name,
                            strategy=strategy.value,
                            details=details)
            
            return success
            
        except Exception as e:
            logger.error("重启服务异常", 
                        service=service_config.name,
                        error=str(e))
            return False
    
    def _determine_strategy(self, service_config: ServiceConfig, fault_event: FaultEvent) -> RestartStrategy:
        """确定重启策略"""
        if fault_event.fault_type == FaultType.SERVICE_DOWN:
            return RestartStrategy.FORCE
        elif fault_event.fault_type == FaultType.HIGH_MEMORY_USAGE:
            return RestartStrategy.GRACEFUL
        elif fault_event.fault_type == FaultType.HIGH_CPU_USAGE:
            return RestartStrategy.SCALING
        else:
            return RestartStrategy.GRACEFUL
    
    def _graceful_restart(self, service_config: ServiceConfig) -> tuple[bool, Dict[str, Any]]:
        """优雅重启"""
        try:
            container = self.docker_client.containers.get(service_config.container_name)
            container.restart()
            
            # 等待服务恢复
            time.sleep(service_config.restart_delay)
            
            # 验证重启结果
            container.reload()
            if container.status == 'running':
                return True, {'method': 'graceful', 'status': container.status}
            else:
                return False, {'method': 'graceful', 'status': container.status}
                
        except Exception as e:
            return False, {'method': 'graceful', 'error': str(e)}
    
    def _force_restart(self, service_config: ServiceConfig) -> tuple[bool, Dict[str, Any]]:
        """强制重启"""
        try:
            # 停止容器
            container = self.docker_client.containers.get(service_config.container_name)
            container.stop()
            
            # 等待一段时间
            time.sleep(5)
            
            # 启动容器
            container.start()
            
            # 等待服务恢复
            time.sleep(service_config.restart_delay)
            
            # 验证重启结果
            container.reload()
            if container.status == 'running':
                return True, {'method': 'force', 'status': container.status}
            else:
                return False, {'method': 'force', 'status': container.status}
                
        except Exception as e:
            return False, {'method': 'force', 'error': str(e)}
    
    def _scaling_restart(self, service_config: ServiceConfig) -> tuple[bool, Dict[str, Any]]:
        """扩缩容重启"""
        try:
            # 这里可以实现更复杂的扩缩容逻辑
            # 例如增加副本数量、负载均衡等
            return self._graceful_restart(service_config)
        except Exception as e:
            return False, {'method': 'scaling', 'error': str(e)}

class NotificationManager:
    """通知管理器"""
    
    def __init__(self, config_manager: ConfigManager):
        self.config_manager = config_manager
        self.notification_config = config_manager.get_notification_config()
    
    def send_notification(self, fault_event: FaultEvent, service_config: ServiceConfig) -> bool:
        """发送通知"""
        success = True
        
        for channel in service_config.notification_channels:
            try:
                if channel == 'email':
                    self._send_email_notification(fault_event, service_config)
                elif channel == 'dingtalk':
                    self._send_dingtalk_notification(fault_event, service_config)
                elif channel == 'wechat':
                    self._send_wechat_notification(fault_event, service_config)
                elif channel == 'slack':
                    self._send_slack_notification(fault_event, service_config)
                
                ALERT_COUNT.labels(
                    severity=fault_event.severity.value,
                    service=service_config.name
                ).inc()
                
            except Exception as e:
                logger.error("通知发送失败", 
                            channel=channel,
                            service=service_config.name,
                            error=str(e))
                success = False
        
        return success
    
    def _send_email_notification(self, fault_event: FaultEvent, service_config: ServiceConfig):
        """发送邮件通知"""
        email_config = self.notification_config.get('email', {})
        if not email_config.get('username') or not email_config.get('password'):
            logger.warning("邮件配置不完整，跳过邮件通知")
            return
        
        try:
            msg = MIMEMultipart()
            msg['From'] = email_config['from_addr']
            msg['To'] = ', '.join(email_config['to_addrs'])
            msg['Subject'] = f"[{fault_event.severity.value.upper()}] {service_config.name} 故障告警"
            
            body = f"""
            故障告警详情：
            
            服务名称: {service_config.name}
            故障类型: {fault_event.fault_type.value}
            严重程度: {fault_event.severity.value}
            故障描述: {fault_event.message}
            发生时间: {fault_event.timestamp.strftime('%Y-%m-%d %H:%M:%S')}
            容器名称: {service_config.container_name}
            
            请及时处理此故障。
            
            自动故障检测系统
            """
            
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            server = smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port'])
            server.starttls()
            server.login(email_config['username'], email_config['password'])
            server.send_message(msg)
            server.quit()
            
            logger.info("邮件通知发送成功", 
                       service=service_config.name,
                       recipients=email_config['to_addrs'])
                       
        except Exception as e:
            logger.error("邮件通知发送失败", 
                        service=service_config.name,
                        error=str(e))
            raise
    
    def _send_dingtalk_notification(self, fault_event: FaultEvent, service_config: ServiceConfig):
        """发送钉钉通知"""
        webhook_url = self.notification_config.get('webhook', {}).get('dingtalk')
        if not webhook_url:
            logger.warning("钉钉Webhook URL未配置")
            return
        
        try:
            message = {
                "msgtype": "markdown",
                "markdown": {
                    "title": f"故障告警 - {service_config.name}",
                    "text": f"""## 故障告警
                    
**服务名称**: {service_config.name}
**故障类型**: {fault_event.fault_type.value}
**严重程度**: {fault_event.severity.value}
**故障描述**: {fault_event.message}
**发生时间**: {fault_event.timestamp.strftime('%Y-%m-%d %H:%M:%S')}
**容器名称**: {service_config.container_name}

请及时处理此故障。
                    """
                }
            }
            
            response = requests.post(webhook_url, json=message, timeout=10)
            response.raise_for_status()
            
            logger.info("钉钉通知发送成功", service=service_config.name)
            
        except Exception as e:
            logger.error("钉钉通知发送失败", 
                        service=service_config.name,
                        error=str(e))
            raise
    
    def _send_wechat_notification(self, fault_event: FaultEvent, service_config: ServiceConfig):
        """发送企业微信通知"""
        webhook_url = self.notification_config.get('webhook', {}).get('wechat')
        if not webhook_url:
            logger.warning("企业微信Webhook URL未配置")
            return
        
        try:
            message = {
                "msgtype": "text",
                "text": {
                    "content": f"""故障告警\n服务: {service_config.name}\n类型: {fault_event.fault_type.value}\n级别: {fault_event.severity.value}\n描述: {fault_event.message}\n时间: {fault_event.timestamp.strftime('%Y-%m-%d %H:%M:%S')}"""
                }
            }
            
            response = requests.post(webhook_url, json=message, timeout=10)
            response.raise_for_status()
            
            logger.info("企业微信通知发送成功", service=service_config.name)
            
        except Exception as e:
            logger.error("企业微信通知发送失败", 
                        service=service_config.name,
                        error=str(e))
            raise
    
    def _send_slack_notification(self, fault_event: FaultEvent, service_config: ServiceConfig):
        """发送Slack通知"""
        webhook_url = self.notification_config.get('webhook', {}).get('slack')
        if not webhook_url:
            logger.warning("Slack Webhook URL未配置")
            return
        
        try:
            color = {
                FaultSeverity.CRITICAL: "danger",
                FaultSeverity.HIGH: "warning",
                FaultSeverity.MEDIUM: "#ff9900",
                FaultSeverity.LOW: "good"
            }.get(fault_event.severity, "#cccccc")
            
            message = {
                "attachments": [
                    {
                        "color": color,
                        "title": f"故障告警 - {service_config.name}",
                        "fields": [
                            {"title": "故障类型", "value": fault_event.fault_type.value, "short": True},
                            {"title": "严重程度", "value": fault_event.severity.value, "short": True},
                            {"title": "故障描述", "value": fault_event.message, "short": False},
                            {"title": "发生时间", "value": fault_event.timestamp.strftime('%Y-%m-%d %H:%M:%S'), "short": True},
                            {"title": "容器名称", "value": service_config.container_name, "short": True}
                        ]
                    }
                ]
            }
            
            response = requests.post(webhook_url, json=message, timeout=10)
            response.raise_for_status()
            
            logger.info("Slack通知发送成功", service=service_config.name)
            
        except Exception as e:
            logger.error("Slack通知发送失败", 
                        service=service_config.name,
                        error=str(e))
            raise

class AuditLogger:
    """审计日志记录器"""
    
    def __init__(self):
        self.audit_file = "/app/logs/audit.log"
        self.lock = threading.Lock()
    
    def log_fault_event(self, fault_event: FaultEvent, action: str = "detected"):
        """记录故障事件"""
        with self.lock:
            log_entry = {
                "timestamp": fault_event.timestamp.isoformat(),
                "event_type": "fault_event",
                "action": action,
                "service_name": fault_event.service_name,
                "fault_type": fault_event.fault_type.value,
                "severity": fault_event.severity.value,
                "message": fault_event.message,
                "details": fault_event.details
            }
            
            try:
                with open(self.audit_file, 'a', encoding='utf-8') as f:
                    f.write(json.dumps(log_entry, ensure_ascii=False) + '\n')
            except Exception as e:
                logger.error("审计日志写入失败", error=str(e))
    
    def log_restart_attempt(self, restart_attempt: RestartAttempt):
        """记录重启尝试"""
        with self.lock:
            log_entry = {
                "timestamp": restart_attempt.timestamp.isoformat(),
                "event_type": "restart_attempt",
                "service_name": restart_attempt.service_name,
                "strategy": restart_attempt.strategy.value,
                "success": restart_attempt.success,
                "details": restart_attempt.details
            }
            
            try:
                with open(self.audit_file, 'a', encoding='utf-8') as f:
                    f.write(json.dumps(log_entry, ensure_ascii=False) + '\n')
            except Exception as e:
                logger.error("审计日志写入失败", error=str(e))

class FaultDetectionEngine:
    """故障检测引擎 - 主控制器"""
    
    def __init__(self):
        self.config_manager = ConfigManager()
        self.health_checker = HealthChecker(self.config_manager)
        self.fault_classifier = FaultClassifier(self.config_manager)
        self.restart_manager = RestartManager(self.config_manager)
        self.notification_manager = NotificationManager(self.config_manager)
        self.audit_logger = AuditLogger()
        self.scheduler = BackgroundScheduler()
        self.running = False
        
        # 初始化服务配置
        self.service_configs = self.config_manager.get_service_configs()
        logger.info("故障检测引擎初始化完成", 
                   services=len(self.service_configs))
    
    def start(self):
        """启动故障检测引擎"""
        if self.running:
            logger.warning("故障检测引擎已在运行")
            return
        
        self.running = True
        
        # 启动定时任务
        monitoring_config = self.config_manager.config.get('monitoring', {})
        health_interval = monitoring_config.get('health_check_interval', 30)
        
        self.scheduler.add_job(
            self._health_check_loop,
            'interval',
            seconds=health_interval,
            id='health_check'
        )
        
        self.scheduler.start()
        logger.info("故障检测引擎已启动")
    
    def stop(self):
        """停止故障检测引擎"""
        if not self.running:
            return
        
        self.running = False
        self.scheduler.shutdown()
        logger.info("故障检测引擎已停止")
    
    def _health_check_loop(self):
        """健康检查循环"""
        start_time = time.time()
        
        try:
            for service_config in self.service_configs:
                self._process_service_health_check(service_config)
            
            detection_time = time.time() - start_time
            DETECTION_LATENCY.observe(detection_time)
            
        except Exception as e:
            logger.error("健康检查循环异常", error=str(e))
    
    def _process_service_health_check(self, service_config: ServiceConfig):
        """处理单个服务的健康检查"""
        try:
            # 执行健康检查
            health_data = self.health_checker.check_service_health(service_config)
            
            # 更新Prometheus指标
            SERVICE_STATUS.labels(service=service_config.name).set(
                1 if health_data['healthy'] else 0
            )
            
            # 如果服务不健康，进行故障分类
            if not health_data['healthy']:
                fault_event = self.fault_classifier.classify_fault(service_config, health_data)
                
                if fault_event:
                    logger.warning("检测到故障", 
                                 service=service_config.name,
                                 fault_type=fault_event.fault_type.value,
                                 severity=fault_event.severity.value)
                    
                    # 记录审计日志
                    self.audit_logger.log_fault_event(fault_event)
                    
                    # 发送通知
                    self.notification_manager.send_notification(fault_event, service_config)
                    
                    # 尝试重启
                    if self.restart_manager.should_restart(service_config, fault_event):
                        success = self.restart_manager.restart_service(service_config, fault_event)
                        
                        if success:
                            fault_event.resolved = True
                            self.audit_logger.log_fault_event(fault_event, "resolved")
                            logger.info("故障已解决", service=service_config.name)
                        else:
                            logger.error("重启失败，故障未解决", service=service_config.name)
            
        except Exception as e:
            logger.error("服务健康检查异常", 
                        service=service_config.name,
                        error=str(e))

def create_app():
    """创建Flask应用"""
    app = Flask(__name__)
    engine = FaultDetectionEngine()
    
    @app.route('/health')
    def health():
        return jsonify({
            'status': 'healthy',
            'service': 'fault-detector',
            'timestamp': datetime.utcnow().isoformat()
        })
    
    @app.route('/metrics')
    def metrics():
        return generate_latest(), 200, {'Content-Type': CONTENT_TYPE_LATEST}
    
    @app.route('/webhook/alert', methods=['POST'])
    def webhook_alert():
        """接收告警Webhook"""
        try:
            data = request.get_json()
            logger.info("收到告警Webhook", data=data)
            return jsonify({'status': 'received'}), 200
        except Exception as e:
            logger.error("处理告警Webhook失败", error=str(e))
            return jsonify({'status': 'error'}), 500
    
    @app.route('/services')
    def list_services():
        """列出所有服务状态"""
        services_status = []
        for service_config in engine.service_configs:
            services_status.append({
                'name': service_config.name,
                'container_name': service_config.container_name,
                'critical': service_config.critical,
                'dependencies': service_config.dependencies
            })
        
        return jsonify({
            'services': services_status,
            'total': len(services_status)
        })
    
    @app.route('/restart/<service_name>', methods=['POST'])
    def manual_restart(service_name):
        """手动重启服务"""
        try:
            service_config = next(
                (s for s in engine.service_configs if s.name == service_name), 
                None
            )
            
            if not service_config:
                return jsonify({'error': 'Service not found'}), 404
            
            success = engine.restart_manager.restart_service(service_config, None)
            
            if success:
                return jsonify({'status': 'restart initiated'})
            else:
                return jsonify({'status': 'restart failed'}), 500
                
        except Exception as e:
            logger.error("手动重启失败", 
                        service=service_name,
                        error=str(e))
            return jsonify({'error': str(e)}), 500
    
    # 启动故障检测引擎
    @app.before_first_request
    def initialize():
        engine.start()
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=8080, debug=False)