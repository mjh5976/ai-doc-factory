#!/bin/bash

# 故障检测和自动重启机制 - 启动脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🚀 故障检测和自动重启机制系统启动器${NC}"
echo "=================================="

# 检查Docker和Docker Compose
echo -e "${YELLOW}🔍 检查依赖...${NC}"
if ! command -v docker &> /dev/null; then
    echo -e "${RED}❌ Docker 未安装${NC}"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}❌ Docker Compose 未安装${NC}"
    exit 1
fi

# 创建必要的目录
echo -e "${YELLOW}📁 创建目录结构...${NC}"
mkdir -p logs configs/grafana/{dashboards,datasources}

# 检查配置文件
echo -e "${YELLOW}📋 检查配置文件...${NC}"
if [ ! -f "configs/fault_detection_config.yaml" ]; then
    echo -e "${YELLOW}⚠️  配置文件不存在，使用默认配置${NC}"
fi

# 构建镜像
echo -e "${YELLOW}🔨 构建Docker镜像...${NC}"
chmod +x build.sh
./build.sh

# 启动服务
echo -e "${YELLOW}🚀 启动服务...${NC}"
docker-compose up -d

# 等待服务启动
echo -e "${YELLOW}⏳ 等待服务启动...${NC}"
sleep 30

# 检查服务状态
echo -e "${YELLOW}📊 检查服务状态...${NC}"
docker-compose ps

# 显示访问信息
echo ""
echo -e "${GREEN}🎉 系统启动完成！${NC}"
echo "=================================="
echo -e "${BLUE}📋 服务访问信息:${NC}"
echo -e "  • 演示API服务1: ${YELLOW}http://localhost:5001${NC}"
echo -e "  • 演示API服务2: ${YELLOW}http://localhost:5002${NC}"
echo -e "  • 故障检测服务: ${YELLOW}http://localhost:8080${NC}"
echo -e "  • Prometheus: ${YELLOW}http://localhost:9090${NC}"
echo -e "  • Grafana: ${YELLOW}http://localhost:3000${NC} (admin/admin123)"
echo -e "  • Alertmanager: ${YELLOW}http://localhost:9093${NC}"
echo ""
echo -e "${BLUE}🔧 常用命令:${NC}"
echo -e "  • 查看日志: ${YELLOW}docker-compose logs -f [service_name]${NC}"
echo -e "  • 重启服务: ${YELLOW}docker-compose restart [service_name]${NC}"
echo -e "  • 停止系统: ${YELLOW}docker-compose down${NC}"
echo -e "  • 清理数据: ${YELLOW}docker-compose down -v${NC}"
echo ""
echo -e "${BLUE}🧪 测试命令:${NC}"
echo -e "  • 模拟服务故障: ${YELLOW}curl http://localhost:5001/simulate-failure?type=crash${NC}"
echo -e "  • 查看服务状态: ${YELLOW}curl http://localhost:5001/health${NC}"
echo -e "  • 查看故障检测: ${YELLOW}curl http://localhost:8080/services${NC}"
echo ""
echo -e "${GREEN}✅ 系统已准备就绪！${NC}"