#!/usr/bin/env python3
"""
演示API服务 - 故障检测和自动重启机制示例
包含健康检查、Prometheus指标、故障模拟等功能
"""

import os
import time
import random
import logging
import threading
from datetime import datetime
from flask import Flask, jsonify, request
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
import redis
import psutil
import structlog

# 配置日志
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

# Prometheus指标
REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP requests', ['method', 'endpoint', 'status'])
REQUEST_DURATION = Histogram('http_request_duration_seconds', 'HTTP request duration')
ACTIVE_CONNECTIONS = Gauge('active_connections', 'Active connections')
MEMORY_USAGE = Gauge('process_resident_memory_bytes', 'Process memory usage in bytes')
CPU_USAGE = Gauge('process_cpu_usage_percent', 'Process CPU usage percent')
HEALTH_STATUS = Gauge('health_status', 'Service health status', ['service'])
HEARTBEAT_COUNT = Counter('heartbeat_total', 'Heartbeat count', ['service'])

# 配置
SERVICE_NAME = os.getenv('SERVICE_NAME', 'demo-api')
SERVICE_PORT = int(os.getenv('SERVICE_PORT', 5000))
REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379')
FAILURE_RATE = float(os.getenv('FAILURE_RATE', 0.1))  # 10%失败率模拟故障
HEALTH_CHECK_INTERVAL = int(os.getenv('HEALTH_CHECK_INTERVAL', 30))

# Redis连接
try:
    redis_client = redis.from_url(REDIS_URL)
    redis_client.ping()
    logger.info("Redis连接成功", redis_url=REDIS_URL)
except Exception as e:
    logger.error("Redis连接失败", error=str(e))
    redis_client = None

app = Flask(__name__)

# 全局状态
service_status = {
    'healthy': True,
    'last_heartbeat': time.time(),
    'start_time': time.time(),
    'total_requests': 0,
    'error_count': 0
}

class HealthChecker:
    """健康检查器"""
    
    def __init__(self):
        self.running = False
        self.thread = None
    
    def start(self):
        """启动健康检查"""
        if not self.running:
            self.running = True
            self.thread = threading.Thread(target=self._check_loop, daemon=True)
            self.thread.start()
            logger.info("健康检查器已启动", interval=HEALTH_CHECK_INTERVAL)
    
    def stop(self):
        """停止健康检查"""
        self.running = False
        if self.thread:
            self.thread.join()
    
    def _check_loop(self):
        """健康检查循环"""
        while self.running:
            try:
                self._perform_health_check()
                time.sleep(HEALTH_CHECK_INTERVAL)
            except Exception as e:
                logger.error("健康检查异常", error=str(e))
                time.sleep(5)
    
    def _perform_health_check(self):
        """执行健康检查"""
        current_time = time.time()
        
        # 检查内存使用
        memory_info = psutil.Process().memory_info()
        memory_usage_mb = memory_info.rss / 1024 / 1024
        
        # 检查CPU使用
        cpu_percent = psutil.Process().cpu_percent()
        
        # 检查Redis连接
        redis_healthy = True
        if redis_client:
            try:
                redis_client.ping()
            except Exception:
                redis_healthy = False
        
        # 更新指标
        MEMORY_USAGE.set(memory_info.rss)
        CPU_USAGE.set(cpu_percent)
        
        # 健康状态判断
        is_healthy = (
            memory_usage_mb < 500 and  # 内存小于500MB
            cpu_percent < 80 and       # CPU使用率小于80%
            redis_healthy              # Redis连接正常
        )
        
        service_status['healthy'] = is_healthy
        HEALTH_STATUS.labels(service=SERVICE_NAME).set(1 if is_healthy else 0)
        
        # 记录心跳
        HEARTBEAT_COUNT.labels(service=SERVICE_NAME).inc()
        service_status['last_heartbeat'] = current_time
        
        if is_healthy:
            logger.debug("健康检查通过", 
                        memory_mb=memory_usage_mb, 
                        cpu_percent=cpu_percent,
                        redis_healthy=redis_healthy)
        else:
            logger.warning("健康检查失败", 
                          memory_mb=memory_usage_mb, 
                          cpu_percent=cpu_percent,
                          redis_healthy=redis_healthy)

# 启动健康检查器
health_checker = HealthChecker()

@app.before_first_request
def initialize():
    """初始化"""
    health_checker.start()
    logger.info("服务初始化完成", 
                service_name=SERVICE_NAME,
                port=SERVICE_PORT,
                redis_url=REDIS_URL)

@app.route('/')
def index():
    """首页"""
    return jsonify({
        'service': SERVICE_NAME,
        'status': 'running',
        'timestamp': datetime.utcnow().isoformat(),
        'uptime_seconds': time.time() - service_status['start_time']
    })

@app.route('/health')
def health():
    """健康检查端点"""
    return jsonify({
        'service': SERVICE_NAME,
        'healthy': service_status['healthy'],
        'timestamp': datetime.utcnow().isoformat(),
        'uptime_seconds': time.time() - service_status['start_time'],
        'total_requests': service_status['total_requests'],
        'error_count': service_status['error_count']
    })

@app.route('/metrics')
def metrics():
    """Prometheus指标端点"""
    return generate_latest(), 200, {'Content-Type': CONTENT_TYPE_LATEST}

@app.route('/simulate-failure')
def simulate_failure():
    """模拟故障"""
    failure_type = request.args.get('type', 'random')
    
    if failure_type == 'crash':
        # 模拟进程崩溃
        logger.warning("模拟进程崩溃")
        os._exit(1)
    elif failure_type == 'hang':
        # 模拟挂起
        logger.warning("模拟服务挂起")
        time.sleep(300)  # 挂起5分钟
    elif failure_type == 'error':
        # 模拟错误响应
        logger.warning("模拟错误响应")
        service_status['error_count'] += 1
        return jsonify({'error': 'Simulated error'}), 500
    elif failure_type == 'memory':
        # 模拟内存泄漏
        logger.warning("模拟内存泄漏")
        data = []
        for i in range(100000):
            data.append('x' * 1024)  # 分配1KB数据
        return jsonify({'message': 'Memory allocated'})
    elif failure_type == 'random':
        # 随机故障
        if random.random() < FAILURE_RATE:
            logger.warning("随机故障模拟")
            return jsonify({'error': 'Random failure'}), 500
    
    return jsonify({'message': 'No failure simulated'})

@app.route('/api/data')
def get_data():
    """获取数据API"""
    start_time = time.time()
    
    try:
        # 模拟数据库查询
        if redis_client:
            cached_data = redis_client.get(f'data:{SERVICE_NAME}')
            if cached_data:
                data = eval(cached_data.decode())  # 注意：实际使用中应该使用JSON
            else:
                # 生成模拟数据
                data = {
                    'service': SERVICE_NAME,
                    'timestamp': datetime.utcnow().isoformat(),
                    'items': [{'id': i, 'value': random.randint(1, 100)} for i in range(10)]
                }
                redis_client.setex(f'data:{SERVICE_NAME}', 60, str(data))
        else:
            data = {
                'service': SERVICE_NAME,
                'timestamp': datetime.utcnow().isoformat(),
                'items': [{'id': i, 'value': random.randint(1, 100)} for i in range(10)]
            }
        
        # 记录请求指标
        duration = time.time() - start_time
        REQUEST_COUNT.labels(method='GET', endpoint='/api/data', status='200').inc()
        REQUEST_DURATION.observe(duration)
        service_status['total_requests'] += 1
        
        logger.info("数据获取成功", 
                   service=SERVICE_NAME,
                   duration=duration,
                   items_count=len(data['items']))
        
        return jsonify(data)
        
    except Exception as e:
        # 记录错误
        duration = time.time() - start_time
        REQUEST_COUNT.labels(method='GET', endpoint='/api/data', status='500').inc()
        service_status['total_requests'] += 1
        service_status['error_count'] += 1
        
        logger.error("数据获取失败", 
                    service=SERVICE_NAME,
                    error=str(e),
                    duration=duration)
        
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/api/slow')
def slow_endpoint():
    """慢请求端点（用于测试超时）"""
    delay = float(request.args.get('delay', 2))
    logger.info("慢请求处理", delay=delay)
    time.sleep(delay)
    return jsonify({'message': f'Processed after {delay} seconds'})

@app.route('/status')
def status():
    """详细状态信息"""
    process = psutil.Process()
    
    return jsonify({
        'service': SERVICE_NAME,
        'status': service_status,
        'system': {
            'memory_mb': process.memory_info().rss / 1024 / 1024,
            'cpu_percent': process.cpu_percent(),
            'threads': process.num_threads(),
            'open_files': len(process.open_files()),
            'connections': len(process.connections())
        },
        'redis': {
            'connected': redis_client is not None,
            'ping': redis_client.ping() if redis_client else False
        }
    })

if __name__ == '__main__':
    # 记录启动信息
    logger.info("启动演示API服务", 
                service_name=SERVICE_NAME,
                port=SERVICE_PORT,
                failure_rate=FAILURE_RATE)
    
    # 使用Gunicorn启动生产服务器
    app.run(host='0.0.0.0', port=SERVICE_PORT, debug=False)