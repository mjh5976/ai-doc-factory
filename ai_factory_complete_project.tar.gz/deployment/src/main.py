"""
AI Factory API 主应用
提供模型部署、版本管理、推理服务等API接口
"""

import os
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from starlette.responses import Response
import uvicorn

from src.routers import models, inference, health, metrics
from src.core.config import settings
from src.core.database import init_db
from src.core.logging import setup_logging

# 设置日志
setup_logging()
logger = logging.getLogger(__name__)

# Prometheus指标
REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP requests', ['method', 'endpoint', 'status'])
REQUEST_DURATION = Histogram('http_request_duration_seconds', 'HTTP request duration')

# 启动和关闭事件
@asynccontextmanager
async def lifespan(app: FastAPI):
    # 启动事件
    logger.info("Starting AI Factory API...")
    
    # 初始化数据库
    await init_db()
    
    logger.info("AI Factory API started successfully")
    
    yield
    
    # 关闭事件
    logger.info("Shutting down AI Factory API...")

# 创建FastAPI应用
app = FastAPI(
    title="AI Factory API",
    description="本地模型部署和版本管理系统API",
    version="1.0.0",
    lifespan=lifespan
)

# 添加中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_HOSTS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=settings.ALLOWED_HOSTS
)

# 注册路由
app.include_router(health.router, prefix="/health", tags=["health"])
app.include_router(metrics.router, prefix="/metrics", tags=["metrics"])
app.include_router(models.router, prefix="/api/models", tags=["models"])
app.include_router(inference.router, prefix="/api/inference", tags=["inference"])

@app.get("/")
async def root():
    """根路径，返回API信息"""
    return {
        "service": "AI Factory API",
        "version": "1.0.0",
        "status": "running",
        "documentation": "/docs"
    }

@app.get("/docs")
async def api_docs():
    """API文档"""
    return {"message": "访问 /docs 查看完整的API文档"}

# 错误处理器
@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    logger.error(f"HTTP error: {exc.status_code} - {exc.detail}")
    return {"error": exc.detail, "status_code": exc.status_code}

@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    logger.error(f"Unexpected error: {str(exc)}")
    return {"error": "Internal server error", "status_code": 500}

if __name__ == "__main__":
    uvicorn.run(
        "src.main:app",
        host="0.0.0.0",
        port=5001,
        reload=True,
        log_level="info"
    )