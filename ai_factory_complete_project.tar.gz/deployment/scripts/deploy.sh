#!/bin/bash

# AI Factory 部署脚本
# 用途：自动化部署完整的本地模型部署和版本管理系统

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查依赖
check_dependencies() {
    log_info "检查系统依赖..."
    
    # 检查Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker未安装，请先安装Docker"
        exit 1
    fi
    
    # 检查Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose未安装，请先安装Docker Compose"
        exit 1
    fi
    
    # 检查curl
    if ! command -v curl &> /dev/null; then
        log_error "curl未安装，请先安装curl"
        exit 1
    fi
    
    log_success "依赖检查通过"
}

# 创建目录结构
create_directories() {
    log_info "创建目录结构..."
    
    mkdir -p logs/{api,mlflow,nginx}
    mkdir -p models
    mkdir -p web/dist
    mkdir -p configs/ssl
    mkdir -p backup/{database,artifacts}
    
    log_success "目录结构创建完成"
}

# 生成SSL证书（自签名，用于开发环境）
generate_ssl_cert() {
    log_info "生成SSL证书..."
    
    if [ ! -f configs/ssl/cert.pem ]; then
        openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout configs/ssl/key.pem \
            -out configs/ssl/cert.pem \
            -subj "/C=CN/ST=Beijing/L=Beijing/O=AI Factory/OU=IT/CN=localhost"
        
        log_success "SSL证书生成完成"
    else
        log_info "SSL证书已存在，跳过生成"
    fi
}

# 构建镜像
build_images() {
    log_info "构建Docker镜像..."
    
    # 构建API镜像
    docker build -f Dockerfile.api -t ai-factory-api:latest .
    
    log_success "镜像构建完成"
}

# 启动服务
start_services() {
    log_info "启动AI Factory服务..."
    
    # 启动数据库相关服务
    docker-compose up -d postgres redis
    
    # 等待数据库启动
    log_info "等待数据库启动..."
    sleep 30
    
    # 启动MLflow
    docker-compose up -d mlflow
    
    # 等待MLflow启动
    log_info "等待MLflow启动..."
    sleep 15
    
    # 启动推理服务
    docker-compose up -d vllm ollama
    
    # 启动API服务
    docker-compose up -d api
    
    # 启动前端和反向代理
    docker-compose up -d web nginx
    
    # 启动监控服务
    docker-compose up -d prometheus grafana loki alertmanager promtail
    
    # 启动CI/CD服务（可选）
    # docker-compose up -d jenkins
    
    log_success "所有服务启动完成"
}

# 健康检查
health_check() {
    log_info "执行健康检查..."
    
    # 检查各服务状态
    services=("postgres" "redis" "mlflow" "vllm" "api" "nginx" "prometheus" "grafana")
    
    for service in "${services[@]}"; do
        if docker-compose ps $service | grep -q "Up"; then
            log_success "$service 服务运行正常"
        else
            log_error "$service 服务异常"
        fi
    done
    
    # 检查端口可达性
    ports=("80" "5000" "8000" "9090" "3001")
    for port in "${ports[@]}"; do
        if curl -s http://localhost:$port > /dev/null; then
            log_success "端口 $port 可达"
        else
            log_warning "端口 $port 不可达"
        fi
    done
}

# 初始化数据
initialize_data() {
    log_info "初始化系统数据..."
    
    # 等待MLflow完全启动
    sleep 10
    
    # 创建示例模型（如果需要）
    if [ -f "scripts/create_sample_model.py" ]; then
        docker exec mlflow python /app/scripts/create_sample_model.py
        log_success "示例模型创建完成"
    fi
    
    # 初始化Grafana数据源
    log_info "请手动配置Grafana数据源："
    log_info "1. 访问 http://localhost:3001"
    log_info "2. 使用 admin/admin123 登录"
    log_info "3. 添加 Prometheus 数据源: http://prometheus:9090"
    log_info "4. 添加 Loki 数据源: http://loki:3100"
}

# 显示访问信息
show_access_info() {
    log_success "AI Factory 部署完成！"
    echo
    echo "=== 访问信息 ==="
    echo "前端界面:     http://localhost"
    echo "API文档:      http://localhost/docs"
    echo "MLflow UI:    http://localhost:5000"
    echo "vLLM API:     http://localhost:8000"
    echo "Ollama API:   http://localhost:11434"
    echo "Grafana:      http://localhost:3001 (admin/admin123)"
    echo "Prometheus:   http://localhost:9090"
    echo "Jenkins:      http://localhost:8080 (如果启用)"
    echo
    echo "=== 管理命令 ==="
    echo "查看服务状态: docker-compose ps"
    echo "查看日志:     docker-compose logs -f [service_name]"
    echo "重启服务:     docker-compose restart [service_name]"
    echo "停止所有:     docker-compose down"
    echo "清理数据:     ./scripts/cleanup.sh"
    echo
}

# 主函数
main() {
    echo "========================================"
    echo "  AI Factory 自动化部署脚本"
    echo "========================================"
    echo
    
    check_dependencies
    create_directories
    generate_ssl_cert
    build_images
    start_services
    health_check
    initialize_data
    show_access_info
}

# 执行主函数
main "$@"