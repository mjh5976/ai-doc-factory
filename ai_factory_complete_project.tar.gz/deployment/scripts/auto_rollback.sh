#!/bin/bash

# 自动回滚脚本
# 用途：监控系统状态，自动执行回滚操作

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log_info() { echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $(date '+%Y-%m-%d %H:%M:%S') $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') $1"; }

# 配置参数
MONITOR_INTERVAL=60  # 监控间隔（秒）
ALERT_THRESHOLD_ERROR_RATE=0.05  # 错误率阈值（5%）
ALERT_THRESHOLD_LATENCY=2.0  # 延迟阈值（秒）
ALERT_THRESHOLD_CPU=80  # CPU使用率阈值（%）
ALERT_THRESHOLD_MEMORY=85  # 内存使用率阈值（%）

# 历史记录文件
HISTORY_FILE="/tmp/rollback_history.log"
METRICS_FILE="/tmp/metrics_history.log"

# 初始化
init() {
    # 创建历史记录文件
    touch $HISTORY_FILE
    touch $METRICS_FILE
    
    log_info "自动回滚监控启动"
    log_info "监控间隔: ${MONITOR_INTERVAL}秒"
    log_info "错误率阈值: ${ALERT_THRESHOLD_ERROR_RATE}"
    log_info "延迟阈值: ${ALERT_THRESHOLD_LATENCY}秒"
}

# 获取当前指标
get_metrics() {
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    # API错误率
    local error_rate=$(curl -s "http://localhost:9090/api/v1/query?query=rate(http_requests_total{status=~\"5..\"}[5m])" 2>/dev/null | jq -r '.data.result[0].value[1]' 2>/dev/null || echo "0")
    
    # API延迟（95%分位数）
    local latency=$(curl -s "http://localhost:9090/api/v1/query?query=histogram_quantile(0.95,rate(http_request_duration_seconds_bucket[5m]))" 2>/dev/null | jq -r '.data.result[0].value[1]' 2>/dev/null || echo "0")
    
    # CPU使用率
    local cpu_usage=$(curl -s "http://localhost:9090/api/v1/query?query=100 - (avg by (instance) (rate(node_cpu_seconds_total{mode=\"idle\"}[5m])) * 100)" 2>/dev/null | jq -r '.data.result[0].value[1]' 2>/dev/null || echo "0")
    
    # 内存使用率
    local memory_usage=$(curl -s "http://localhost:9090/api/v1/query?query=(1 - (node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes)) * 100" 2>/dev/null | jq -r '.data.result[0].value[1]' 2>/dev/null || echo "0")
    
    # 模型推理错误率
    local model_error_rate=$(curl -s "http://localhost:9090/api/v1/query?query=rate(model_errors_total[5m]) / rate(model_requests_total[5m])" 2>/dev/null | jq -r '.data.result[0].value[1]' 2>/dev/null || echo "0")
    
    # 记录指标
    echo "$timestamp,error_rate:$error_rate,latency:$latency,cpu:$cpu_usage,memory:$memory_usage,model_error:$model_error_rate" >> $METRICS_FILE
    
    # 返回指标数组
    echo "$error_rate|$latency|$cpu_usage|$memory_usage|$model_error_rate"
}

# 分析指标并判断是否需要回滚
analyze_metrics() {
    local metrics=$1
    IFS='|' read -r error_rate latency cpu_usage memory_usage model_error_rate <<< "$metrics"
    
    # 转换为数字进行比较
    error_rate=$(echo "$error_rate" | bc -l 2>/dev/null || echo "0")
    latency=$(echo "$latency" | bc -l 2>/dev/null || echo "0")
    cpu_usage=$(echo "$cpu_usage" | bc -l 2>/dev/null || echo "0")
    memory_usage=$(echo "$memory_usage" | bc -l 2>/dev/null || echo "0")
    model_error_rate=$(echo "$model_error_rate" | bc -l 2>/dev/null || echo "0")
    
    local should_rollback=false
    local reasons=""
    
    # 检查错误率
    if (( $(echo "$error_rate > $ALERT_THRESHOLD_ERROR_RATE" | bc -l) )); then
        should_rollback=true
        reasons="${reasons}错误率过高($error_rate > $ALERT_THRESHOLD_ERROR_RATE); "
    fi
    
    # 检查延迟
    if (( $(echo "$latency > $ALERT_THRESHOLD_LATENCY" | bc -l) )); then
        should_rollback=true
        reasons="${reasons}延迟过高(${latency}s > ${ALERT_THRESHOLD_LATENCY}s); "
    fi
    
    # 检查CPU使用率
    if (( $(echo "$cpu_usage > $ALERT_THRESHOLD_CPU" | bc -l) )); then
        should_rollback=true
        reasons="${reasons}CPU使用率过高($cpu_usage% > ${ALERT_THRESHOLD_CPU}%); "
    fi
    
    # 检查内存使用率
    if (( $(echo "$memory_usage > $ALERT_THRESHOLD_MEMORY" | bc -l) )); then
        should_rollback=true
        reasons="${reasons}内存使用率过高($memory_usage% > ${ALERT_THRESHOLD_MEMORY}%); "
    fi
    
    # 检查模型错误率
    if (( $(echo "$model_error_rate > 0.1" | bc -l) )); then
        should_rollback=true
        reasons="${reasons}模型错误率过高($model_error_rate > 0.1); "
    fi
    
    # 检查服务可用性
    if ! curl -s -f "http://localhost/health" > /dev/null; then
        should_rollback=true
        reasons="${reasons}服务不可用; "
    fi
    
    if [ "$should_rollback" = true ]; then
        echo "rollback|$reasons"
    else
        echo "normal"
    fi
}

# 执行回滚操作
execute_rollback() {
    local reasons=$1
    
    log_error "检测到异常，开始执行回滚操作"
    log_error "回滚原因: $reasons"
    
    # 记录回滚事件
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "$timestamp,ROLLBACK,$reasons" >> $HISTORY_FILE
    
    # 发送告警
    send_alert "自动回滚触发" "原因: $reasons"
    
    # 执行回滚步骤
    rollback_steps
    
    # 验证回滚结果
    if verify_rollback; then
        log_success "回滚操作成功完成"
        send_alert "回滚成功" "系统已恢复到稳定状态"
    else
        log_error "回滚操作失败，需要人工干预"
        send_alert "回滚失败" "请立即检查系统状态"
    fi
}

# 回滚步骤
rollback_steps() {
    log_info "执行回滚步骤..."
    
    # 步骤1：切换流量到稳定版本
    log_info "步骤1: 切换流量到稳定版本"
    switch_to_stable_version
    
    # 步骤2：停止异常服务
    log_info "步骤2: 停止异常服务"
    stop_failing_services
    
    # 步骤3：重启稳定服务
    log_info "步骤3: 重启稳定服务"
    restart_stable_services
    
    # 步骤4：等待服务恢复
    log_info "步骤4: 等待服务恢复"
    sleep 60
    
    # 步骤5：清理异常资源
    log_info "步骤5: 清理异常资源"
    cleanup_resources
}

# 切换到稳定版本
switch_to_stable_version() {
    # 这里应该调用实际的流量切换API
    # 简化实现
    curl -s -X POST "http://localhost/api/rollback/switch" \
        -H "Content-Type: application/json" \
        -d '{"action": "switch_to_stable"}' > /dev/null
    
    if [ $? -eq 0 ]; then
        log_success "流量切换成功"
    else
        log_error "流量切换失败"
    fi
}

# 停止异常服务
stop_failing_services() {
    # 检查哪些服务异常
    local failing_services=$(docker-compose ps --services --filter "status=running" | grep -E "(api|vllm|ollama)" || true)
    
    for service in $failing_services; do
        if ! curl -s -f "http://localhost:5001/health" > /dev/null 2>&1; then
            log_info "重启异常服务: $service"
            docker-compose restart $service
        fi
    done
}

# 重启稳定服务
restart_stable_services() {
    # 重启关键服务
    local stable_services=("nginx" "redis" "postgres")
    
    for service in "${stable_services[@]}"; do
        log_info "重启稳定服务: $service"
        docker-compose restart $service
    done
}

# 清理资源
cleanup_resources() {
    # 清理异常容器
    docker system prune -f > /dev/null 2>&1 || true
    
    # 清理日志文件
    find /tmp -name "*.log" -mtime +1 -delete 2>/dev/null || true
    
    log_success "资源清理完成"
}

# 验证回滚结果
verify_rollback() {
    log_info "验证回滚结果..."
    
    # 检查服务健康状态
    if ! health_check "API服务"; then
        return 1
    fi
    
    # 检查指标是否恢复正常
    sleep 30
    local metrics=$(get_metrics)
    local status=$(analyze_metrics "$metrics")
    
    if [[ $status == "normal" ]]; then
        log_success "指标恢复正常"
        return 0
    else
        log_error "指标仍然异常"
        return 1
    fi
}

# 健康检查
health_check() {
    local service=$1
    local max_retries=3
    
    for i in $(seq 1 $max_retries); do
        if curl -s -f "http://localhost/health" > /dev/null; then
            return 0
        fi
        
        if [ $i -eq $max_retries ]; then
            return 1
        fi
        
        sleep 10
    done
}

# 发送告警
send_alert() {
    local title=$1
    local message=$2
    
    # 这里应该集成实际的告警系统
    # 例如：邮件、Slack、钉钉等
    log_error "ALERT: $title - $message"
    
    # 示例：写入告警文件
    echo "$(date '+%Y-%m-%d %H:%M:%S') ALERT: $title - $message" >> /tmp/alerts.log
}

# 显示状态
show_status() {
    echo
    echo "=== 自动回滚监控状态 ==="
    echo "监控间隔: ${MONITOR_INTERVAL}秒"
    echo "最后检查: $(tail -1 $METRICS_FILE 2>/dev/null || echo '无数据')"
    echo "历史记录: $(wc -l < $HISTORY_FILE 2>/dev/null || echo '0') 条"
    echo
}

# 主监控循环
main_monitor() {
    log_info "开始主监控循环..."
    
    while true; do
        # 获取当前指标
        local metrics=$(get_metrics)
        
        # 分析指标
        local status=$(analyze_metrics "$metrics")
        
        if [[ $status == rollback* ]]; then
            local reasons=$(echo "$status" | cut -d'|' -f2)
            execute_rollback "$reasons"
            
            # 回滚后等待一段时间再继续监控
            log_info "回滚后等待5分钟..."
            sleep 300
        else
            log_info "系统运行正常"
        fi
        
        show_status
        sleep $MONITOR_INTERVAL
    done
}

# 显示帮助
show_help() {
    echo "用法: $0 [选项]"
    echo
    echo "选项:"
    echo "  --interval SECONDS    监控间隔 (默认: 60)"
    echo "  --error-rate RATE     错误率阈值 (默认: 0.05)"
    echo "  --latency SECONDS     延迟阈值 (默认: 2.0)"
    echo "  --cpu PERCENT         CPU阈值 (默认: 80)"
    echo "  --memory PERCENT      内存阈值 (默认: 85)"
    echo "  --once                单次检查"
    echo "  --help                显示帮助"
}

# 单次检查模式
single_check() {
    log_info "执行单次检查..."
    
    local metrics=$(get_metrics)
    local status=$(analyze_metrics "$metrics")
    
    echo "当前指标: $metrics"
    echo "状态: $status"
    
    if [[ $status == rollback* ]]; then
        local reasons=$(echo "$status" | cut -d'|' -f2)
        log_error "检测到异常，建议执行回滚"
        log_error "原因: $reasons"
        exit 1
    else
        log_success "系统运行正常"
        exit 0
    fi
}

# 主函数
main() {
    # 解析命令行参数
    while [[ $# -gt 0 ]]; do
        case $1 in
            --interval)
                MONITOR_INTERVAL="$2"
                shift 2
                ;;
            --error-rate)
                ALERT_THRESHOLD_ERROR_RATE="$2"
                shift 2
                ;;
            --latency)
                ALERT_THRESHOLD_LATENCY="$2"
                shift 2
                ;;
            --cpu)
                ALERT_THRESHOLD_CPU="$2"
                shift 2
                ;;
            --memory)
                ALERT_THRESHOLD_MEMORY="$2"
                shift 2
                ;;
            --once)
                single_check
                exit 0
                ;;
            --help)
                show_help
                exit 0
                ;;
            *)
                log_error "未知选项: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    init
    main_monitor
}

# 错误处理
trap 'log_error "脚本执行失败，退出码: $?"' ERR

# 执行主函数
main "$@"