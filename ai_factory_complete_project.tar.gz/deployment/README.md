# AI Factory - 本地模型部署和版本管理集成系统

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![Docker](https://img.shields.io/badge/docker-supported-blue.svg)](https://www.docker.com/)
[![MLflow](https://img.shields.io/badge/MLflow-2.8.1-green.svg)](https://mlflow.org/)

## 项目概述

AI Factory 是一个完整的本地模型部署和版本管理系统，专为中小型团队设计，提供端到端的机器学习模型生命周期管理。系统采用开源技术栈，支持模型训练、评估、部署、监控和回滚的全流程自动化。

## 核心特性

### 🚀 模型部署流水线
- 自动化训练到部署的完整流水线
- 支持多种模型格式（PyTorch、TensorFlow、ONNX等）
- 容器化部署，支持Docker和Kubernetes
- 蓝绿部署和灰度发布策略

### 📊 版本管理和标签
- 基于MLflow的模型版本管理
- 灵活的标签和别名管理策略
- 模型比较和选择机制
- 完整的版本历史追踪

### 🔄 蓝绿部署和灰度发布
- 零停机时间的蓝绿部署
- 渐进式灰度发布
- 智能流量切换和路由
- 自动回滚机制

### ⚖️ 负载均衡和流量管理
- Nginx反向代理和负载均衡
- 智能流量路由策略
- 限流和熔断保护
- 多环境支持

### 📈 部署监控和健康检查
- Prometheus指标收集
- Grafana可视化仪表板
- Loki日志聚合和分析
- 实时健康检查和告警

### 🔙 自动回滚和恢复
- 智能异常检测
- 自动回滚触发机制
- 快速恢复策略
- 完整的审计日志

### 🔧 CI/CD系统集成
- GitHub Actions工作流
- Jenkins集成支持
- 自动化测试和部署
- 完整的DevOps流程

## 系统架构

```
┌─────────────────────────────────────────────────────────────┐
│                    用户界面层                                │
├─────────────────────────────────────────────────────────────┤
│  前端界面  │  API文档  │  监控面板  │  管理控制台            │
├─────────────────────────────────────────────────────────────┤
│                    业务逻辑层                                │
├─────────────────────────────────────────────────────────────┤
│  API服务  │  业务编排  │  鉴权管理  │  任务调度              │
├─────────────────────────────────────────────────────────────┤
│                    模型服务层                                │
├─────────────────────────────────────────────────────────────┤
│   vLLM   │  Ollama  │  模型管理  │  推理服务              │
├─────────────────────────────────────────────────────────────┤
│                    数据存储层                                │
├─────────────────────────────────────────────────────────────┤
│ PostgreSQL │  Redis  │  MLflow  │  对象存储              │
├─────────────────────────────────────────────────────────────┤
│                    基础设施层                                │
├─────────────────────────────────────────────────────────────┤
│   Docker  │  Nginx  │ 监控栈  │  CI/CD  │  日志系统         │
└─────────────────────────────────────────────────────────────┘
```

## 技术栈

### 核心组件
- **MLflow 2.8.1**: 模型版本管理和实验追踪
- **vLLM**: 高性能推理服务
- **Ollama**: 轻量级推理服务
- **FastAPI**: 现代API框架
- **PostgreSQL 15**: 关系型数据库
- **Redis 7**: 缓存和会话存储

### 基础设施
- **Docker & Docker Compose**: 容器化部署
- **Nginx**: 反向代理和负载均衡
- **Prometheus**: 指标收集
- **Grafana**: 数据可视化
- **Loki**: 日志聚合
- **Alertmanager**: 告警管理

### CI/CD
- **GitHub Actions**: 自动化工作流
- **Jenkins**: 持续集成
- **Docker Hub/GitHub Container Registry**: 镜像仓库

## 快速开始

### 环境要求
- Docker 20.10+
- Docker Compose 2.0+
- Python 3.9+
- 4GB+ RAM
- 20GB+ 磁盘空间

### 安装步骤

1. **克隆项目**
```bash
git clone https://github.com/your-org/ai-factory.git
cd ai-factory
```

2. **执行自动部署**
```bash
chmod +x deployment/scripts/deploy.sh
./deployment/scripts/deploy.sh
```

3. **访问系统**
- 前端界面: http://localhost
- API文档: http://localhost/docs
- MLflow UI: http://localhost:5000
- Grafana: http://localhost:3001 (admin/admin123)

## 使用指南

### 模型管理

#### 上传模型
```python
import mlflow
import mlflow.pytorch

# 训练模型
model = train_model()
mlflow.pytorch.log_model(model, "model")

# 注册模型
mlflow.register_model(
    "runs:/<run_id>/model",
    "my_model"
)
```

#### 部署模型
```bash
# 灰度发布
./deployment/scripts/gradual_deployment.sh \
    -m my_model \
    -v v2.0 \
    -t 20 \
    -i 600
```

### API调用

#### 推理服务
```bash
# vLLM推理
curl -X POST "http://localhost/v1/chat/completions" \
    -H "Content-Type: application/json" \
    -d '{
        "model": "microsoft/DialoGPT-medium",
        "messages": [{"role": "user", "content": "Hello!"}]
    }'

# Ollama推理
curl -X POST "http://localhost/ollama/api/generate" \
    -H "Content-Type: application/json" \
    -d '{
        "model": "llama2",
        "prompt": "Hello!"
    }'
```

#### 模型管理API
```bash
# 获取模型列表
curl -X GET "http://localhost/api/models"

# 切换模型版本
curl -X POST "http://localhost/api/models/switch" \
    -H "Content-Type: application/json" \
    -d '{"model_name": "my_model", "version": "v2.0"}'
```

### 监控和告警

#### 查看监控指标
访问 Grafana: http://localhost:3001

#### 配置告警
编辑 `deployment/configs/alertmanager/alertmanager.yml`

#### 查看日志
```bash
# 查看服务日志
docker-compose logs -f api

# 查看Loki日志
curl "http://localhost:3100/loki/api/v1/query_range?query={job=\"containerlogs\"}"
```

## 配置说明

### 环境变量

创建 `.env` 文件：
```bash
# 数据库配置
DATABASE_URL=postgresql://mlflow:mlflow123@postgres:5432/mlflow
REDIS_URL=redis://redis:6379/0

# MLflow配置
MLFLOW_TRACKING_URI=http://mlflow:5000
MLFLOW_BACKEND_STORE_URI=postgresql://mlflow:mlflow123@postgres:5432/mlflow

# 推理服务配置
VLLM_HOST=vllm
VLLM_PORT=8000
OLLAMA_HOST=ollama
OLLAMA_PORT=11434

# 监控配置
PROMETHEUS_URL=http://prometheus:9090
GRAFANA_URL=http://grafana:3000
```

### 自定义配置

#### 修改端口
编辑 `deployment/docker-compose.yml` 中的端口映射。

#### 调整资源限制
```yaml
services:
  vllm:
    deploy:
      resources:
        limits:
          cpus: '2'
          memory: 4G
```

#### 添加新的模型
1. 将模型文件放置在 `models/` 目录
2. 更新推理服务配置
3. 重新部署系统

## 高级功能

### 蓝绿部署

```bash
# 切换到绿色环境
curl -X POST "http://localhost/deployment/switch?mode=green" \
    -H "X-Admin-Token: admin_token_123"

# 检查部署状态
curl -X GET "http://localhost/deployment/status"
```

### 自动回滚

```bash
# 启动自动监控
./deployment/scripts/auto_rollback.sh --interval 60

# 手动触发回滚
curl -X POST "http://localhost/api/rollback/switch" \
    -H "Content-Type: application/json" \
    -d '{"action": "switch_to_stable"}'
```

### 性能优化

#### 启用GPU加速
```yaml
services:
  vllm:
    runtime: nvidia
    environment:
      - NVIDIA_VISIBLE_DEVICES=all
```

#### 配置缓存
```yaml
services:
  redis:
    command: redis-server --maxmemory 2gb --maxmemory-policy allkeys-lru
```

## 故障排除

### 常见问题

#### 服务无法启动
```bash
# 检查服务状态
docker-compose ps

# 查看错误日志
docker-compose logs service_name

# 重新启动
docker-compose restart service_name
```

#### 数据库连接失败
```bash
# 检查数据库状态
docker-compose exec postgres pg_isready

# 重置数据库
docker-compose down -v
docker-compose up -d postgres
```

#### 模型推理失败
```bash
# 检查模型服务状态
curl -f http://localhost:8000/v1/models

# 查看模型文件
ls -la models/

# 重新加载模型
docker-compose restart vllm
```

### 日志分析

```bash
# 查看实时日志
docker-compose logs -f

# 搜索特定错误
docker-compose logs api | grep ERROR

# 导出日志
docker-compose logs --no-color api > api.log
```

## 性能基准

### 系统性能
- **API响应时间**: < 100ms (P95)
- **模型推理延迟**: < 2s (P95)
- **并发处理**: 1000+ requests/second
- **系统可用性**: 99.9% uptime

### 资源使用
- **CPU使用率**: < 70% (正常负载)
- **内存使用**: < 80% (正常负载)
- **磁盘IO**: < 80% (正常负载)
- **网络带宽**: 根据模型大小调整

## 安全考虑

### 数据安全
- 本地部署，数据不离开内网
- 支持SSL/TLS加密
- 访问控制和身份验证
- 审计日志记录

### 系统安全
- 容器隔离
- 最小权限原则
- 定期安全更新
- 网络隔离

## 扩展性

### 水平扩展
- 支持多节点部署
- 负载均衡自动扩缩
- 容器编排优化

### 功能扩展
- 插件化架构
- 自定义模型支持
- 多云部署支持
- 边缘计算集成

## 贡献指南

### 开发环境设置
```bash
# 克隆开发分支
git checkout -b feature/new-feature

# 安装开发依赖
pip install -r requirements-dev.txt

# 运行测试
pytest tests/

# 代码格式化
black .
isort .
```

### 提交规范
```
feat: 新功能
fix: 修复bug
docs: 文档更新
style: 代码格式
refactor: 重构
test: 测试相关
chore: 构建过程或辅助工具的变动
```

## 许可证

本项目采用 MIT 许可证。详情请参阅 [LICENSE](LICENSE) 文件。

## 支持和联系

- **文档**: [项目文档](https://ai-factory.readthedocs.io/)
- **问题反馈**: [GitHub Issues](https://github.com/your-org/ai-factory/issues)
- **技术交流**: [Discord 社区](https://discord.gg/ai-factory)
- **邮件支持**: support@ai-factory.com

## 更新日志

### v1.0.0 (2024-12-01)
- 初始版本发布
- 完整的模型部署和版本管理功能
- 支持vLLM和Ollama推理服务
- 集成监控和告警系统
- 蓝绿部署和灰度发布支持

### 计划功能
- [ ] Kubernetes原生支持
- [ ] 多模型并行推理
- [ ] 联邦学习支持
- [ ] 模型压缩和量化
- [ ] 边缘设备部署

## 致谢

感谢以下开源项目的支持：
- [MLflow](https://mlflow.org/) - 模型生命周期管理
- [vLLM](https://vllm.ai/) - 高性能推理服务
- [FastAPI](https://fastapi.tiangolo.com/) - 现代API框架
- [Docker](https://www.docker.com/) - 容器化平台
- [Prometheus](https://prometheus.io/) - 监控系统

---

**AI Factory** - 让AI模型部署变得简单高效 🚀