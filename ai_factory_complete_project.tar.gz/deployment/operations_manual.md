# AI Factory 操作手册

## 概述

AI Factory 是一个完整的本地模型部署和版本管理系统，提供端到端的模型生命周期管理，包括训练、评估、部署、监控和回滚功能。

## 系统架构

系统采用微服务架构，主要组件包括：

- **MLflow**: 模型版本管理和实验追踪
- **vLLM/Ollama**: 模型推理服务
- **API服务**: 业务逻辑和模型编排
- **Nginx**: 反向代理和负载均衡
- **PostgreSQL**: 数据存储
- **Redis**: 缓存和会话存储
- **Prometheus/Grafana**: 监控和可视化
- **Loki/Alertmanager**: 日志收集和告警

## 快速开始

### 1. 环境准备

确保系统已安装：
- Docker 20.10+
- Docker Compose 2.0+
- curl
- OpenSSL（用于生成SSL证书）

### 2. 部署系统

```bash
# 克隆项目
git clone <repository-url>
cd ai-factory

# 执行自动部署
chmod +x deployment/scripts/deploy.sh
./deployment/scripts/deploy.sh
```

### 3. 验证部署

部署完成后，访问以下地址验证系统：

- 前端界面: http://localhost
- API文档: http://localhost/docs
- MLflow UI: http://localhost:5000
- Grafana: http://localhost:3001 (admin/admin123)

## 日常操作

### 模型管理

#### 上传新模型

```bash
# 使用MLflow CLI上传模型
mlflow models serve -m models:/model_name/version \
    --port 8000 \
    --host 0.0.0.0
```

#### 查看模型列表

访问 MLflow UI: http://localhost:5000

#### 版本管理

```bash
# 查看模型版本
curl -X GET "http://localhost:5000/api/2.0/preview/mlflow/experiments/get" \
    -H "Content-Type: application/json"

# 切换模型版本
curl -X POST "http://localhost/api/models/switch" \
    -H "Content-Type: application/json" \
    -d '{"model_name": "model_name", "version": "v2.0"}'
```

### 部署操作

#### 灰度发布

```bash
# 执行灰度发布
chmod +x deployment/scripts/gradual_deployment.sh
./deployment/scripts/gradual_deployment.sh \
    -m recommendation \
    -v v2.1.0 \
    -t 20 \
    -i 600
```

参数说明：
- `-m`: 模型名称
- `-v`: 新版本号
- `-t`: 初始流量百分比（1-50）
- `-i`: 检查间隔（秒）

#### 蓝绿部署

```bash
# 切换到绿色环境
curl -X POST "http://localhost/deployment/switch?mode=green" \
    -H "X-Admin-Token: admin_token_123"

# 验证部署
curl -X GET "http://localhost/deployment/status"
```

### 监控操作

#### 查看监控指标

访问 Grafana: http://localhost:3001

默认仪表板包括：
- API性能指标
- 模型推理指标
- 系统资源使用
- 错误率和延迟

#### 查看日志

```bash
# 查看特定服务日志
docker-compose logs -f api
docker-compose logs -f vllm
docker-compose logs -f nginx

# 查看Loki日志
curl "http://localhost:3100/loki/api/v1/query_range?query={job=\"containerlogs\"}"
```

### 回滚操作

#### 自动回滚监控

```bash
# 启动自动回滚监控
chmod +x deployment/scripts/auto_rollback.sh
./deployment/scripts/auto_rollback.sh --interval 60

# 单次检查
./deployment/scripts/auto_rollback.sh --once
```

#### 手动回滚

```bash
# 切换到稳定版本
curl -X POST "http://localhost/api/rollback/switch" \
    -H "Content-Type: application/json" \
    -d '{"action": "switch_to_stable"}'

# 重启服务
docker-compose restart api vllm
```

## 故障排除

### 常见问题

#### 1. 服务无法启动

```bash
# 检查服务状态
docker-compose ps

# 查看服务日志
docker-compose logs service_name

# 重新启动服务
docker-compose restart service_name
```

#### 2. 数据库连接失败

```bash
# 检查数据库状态
docker-compose exec postgres pg_isready

# 检查连接配置
cat deployment/configs/api/config.py | grep DATABASE_URL
```

#### 3. 模型推理失败

```bash
# 检查模型服务状态
curl -f http://localhost:8000/v1/models

# 查看推理服务日志
docker-compose logs vllm

# 检查模型文件
ls -la models/
```

#### 4. 监控指标异常

```bash
# 检查Prometheus状态
curl -f http://localhost:9090/-/healthy

# 查看告警规则
curl "http://localhost:9090/api/v1/rules"

# 检查Alertmanager状态
curl -f http://localhost:9093/-/healthy
```

### 性能优化

#### 1. 内存使用优化

```bash
# 清理Docker缓存
docker system prune -f

# 清理日志文件
find /var/log -name "*.log" -mtime +7 -delete

# 重启内存密集型服务
docker-compose restart vllm
```

#### 2. 磁盘空间优化

```bash
# 清理未使用的镜像
docker image prune -a

# 清理未使用的数据卷
docker volume prune

# 清理MLflow工件
find /var/lib/docker/volumes -name "*.pkl" -mtime +30 -delete
```

## 备份和恢复

### 数据库备份

```bash
# 备份PostgreSQL
docker-compose exec postgres pg_dump -U mlflow mlflow > backup_$(date +%Y%m%d).sql

# 备份Redis数据
docker-compose exec redis redis-cli BGSAVE
docker cp redis:/data/dump.rdb backup_redis_$(date +%Y%m%d).rdb
```

### 模型文件备份

```bash
# 备份模型文件
tar -czf backup_models_$(date +%Y%m%d).tar.gz models/

# 备份MLflow工件
tar -czf backup_mlflow_artifacts_$(date +%Y%m%d).tar.gz /var/lib/docker/volumes/*_mlflow_artifacts/_data/
```

### 系统恢复

```bash
# 恢复PostgreSQL
docker-compose exec postgres psql -U mlflow -d mlflow < backup_20231201.sql

# 恢复模型文件
tar -xzf backup_models_20231201.tar.gz -C models/

# 重启服务
docker-compose restart
```

## 安全配置

### SSL证书配置

```bash
# 生成自签名证书（开发环境）
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout configs/ssl/key.pem \
    -out configs/ssl/cert.pem \
    -subj "/C=CN/ST=Beijing/L=Beijing/O=AI Factory/OU=IT/CN=localhost"

# 配置Nginx SSL
# 编辑 deployment/configs/nginx/nginx.conf
# 取消注释HTTPS server配置
```

### 访问控制

```bash
# 设置API访问令牌
export API_TOKEN="your-secure-token"

# 配置防火墙规则
iptables -A INPUT -p tcp --dport 80 -j ACCEPT
iptables -A INPUT -p tcp --dport 443 -j ACCEPT
iptables -A INPUT -p tcp --dport 22 -s your-ip -j ACCEPT
```

## 扩展和维护

### 添加新模型

1. 训练模型并保存到MLflow
2. 更新模型配置
3. 重新部署推理服务
4. 更新监控配置

### 性能调优

1. 调整Docker资源限制
2. 优化数据库查询
3. 配置缓存策略
4. 调整监控指标收集频率

### 升级系统

1. 备份现有数据
2. 更新Docker镜像
3. 迁移配置文件
4. 验证系统功能

## 联系方式

- 技术支持: tech-support@ai-factory.com
- 紧急联系: +86-xxx-xxxx-xxxx
- 文档更新: 定期检查项目文档

## 版本历史

- v1.0.0: 初始版本，包含基本功能
- 后续版本将根据需求和反馈进行更新

---

**注意**: 本操作手册基于当前系统版本编写，如有疑问请参考最新文档或联系技术支持团队。