#!/bin/bash

# 故障检测和自动重启机制 - 系统完整性测试
# 用于验证所有必要文件和配置是否完整

set -e

echo "🔍 故障检测和自动重启机制 - 系统完整性测试"
echo "=============================================="

# 检查核心文件
echo "📋 检查核心文件..."

# Docker Compose文件
if [ -f "docker-compose.yml" ]; then
    echo "✅ docker-compose.yml 存在"
else
    echo "❌ docker-compose.yml 缺失"
    exit 1
fi

# 配置文件
config_files=(
    "configs/prometheus.yml"
    "configs/alertmanager.yml"
    "configs/loki-config.yaml"
    "configs/promtail-config.yaml"
    "configs/fault_detection_config.yaml"
    "configs/alert_rules.yml"
    "configs/grafana/datasources/prometheus.yml"
    "configs/grafana/dashboards/dashboard.yml"
)

for file in "${config_files[@]}"; do
    if [ -f "$file" ]; then
        echo "✅ $file 存在"
    else
        echo "❌ $file 缺失"
        exit 1
    fi
done

# 演示应用文件
demo_files=(
    "demo-app/Dockerfile"
    "demo-app/app.py"
    "demo-app/requirements.txt"
)

for file in "${demo_files[@]}"; do
    if [ -f "$file" ]; then
        echo "✅ $file 存在"
    else
        echo "❌ $file 缺失"
        exit 1
    fi
done

# 故障检测服务文件
fault_files=(
    "fault-detector/Dockerfile"
    "fault-detector/main.py"
    "fault-detector/requirements.txt"
)

for file in "${fault_files[@]}"; do
    if [ -f "$file" ]; then
        echo "✅ $file 存在"
    else
        echo "❌ $file 缺失"
        exit 1
    fi
done

# 脚本文件
script_files=(
    "build.sh"
    "start.sh"
    "stop.sh"
    "demo.sh"
    "verify.sh"
)

for file in "${script_files[@]}"; do
    if [ -f "$file" ]; then
        echo "✅ $file 存在"
    else
        echo "❌ $file 缺失"
        exit 1
    fi
done

# 文档文件
doc_files=(
    "docs/fault_detection_auto_restart.md"
    "FAULT_DETECTION_README.md"
)

for file in "${doc_files[@]}"; do
    if [ -f "$file" ]; then
        echo "✅ $file 存在"
    else
        echo "❌ $file 缺失"
        exit 1
    fi
done

# 检查目录结构
echo ""
echo "📁 检查目录结构..."

required_dirs=(
    "configs"
    "configs/grafana"
    "configs/grafana/dashboards"
    "configs/grafana/datasources"
    "demo-app"
    "fault-detector"
    "docs"
    "logs"
)

for dir in "${required_dirs[@]}"; do
    if [ -d "$dir" ]; then
        echo "✅ 目录 $dir 存在"
    else
        echo "❌ 目录 $dir 缺失"
        exit 1
    fi
done

# 验证配置文件语法
echo ""
echo "🔧 验证配置文件语法..."

# 检查YAML文件
yaml_files=(
    "configs/prometheus.yml"
    "configs/alertmanager.yml"
    "configs/loki-config.yaml"
    "configs/promtail-config.yaml"
    "configs/fault_detection_config.yaml"
)

for file in "${yaml_files[@]}"; do
    if python3 -c "import yaml; yaml.safe_load(open('$file'))" 2>/dev/null; then
        echo "✅ $file 语法正确"
    else
        echo "❌ $file 语法错误"
        exit 1
    fi
done

# 检查Python文件语法
python_files=(
    "demo-app/app.py"
    "fault-detector/main.py"
)

for file in "${python_files[@]}"; do
    if python3 -m py_compile "$file" 2>/dev/null; then
        echo "✅ $file 语法正确"
    else
        echo "❌ $file 语法错误"
        exit 1
    fi
done

# 统计信息
echo ""
echo "📊 系统统计信息..."

echo "配置文件数量: $(find configs/ -name "*.yml" -o -name "*.yaml" | wc -l)"
echo "演示应用文件: $(find demo-app/ -type f | wc -l)"
echo "故障检测文件: $(find fault-detector/ -type f | wc -l)"
echo "脚本文件数量: $(find . -maxdepth 1 -name "*.sh" | wc -l)"
echo "文档文件数量: $(find docs/ -name "*.md" | wc -l)"

echo ""
echo "🎉 系统完整性测试通过！"
echo ""
echo "📋 下一步操作:"
echo "1. 配置通知渠道 (编辑 configs/fault_detection_config.yaml)"
echo "2. 运行 ./start.sh 启动系统"
echo "3. 运行 ./demo.sh status 检查系统状态"
echo "4. 运行 ./demo.sh test-crash 测试故障检测"
echo ""
echo "📚 更多信息请查看:"
echo "• 完整文档: docs/fault_detection_auto_restart.md"
echo "• 使用说明: FAULT_DETECTION_README.md"
echo "• 配置示例: configs/ 目录"