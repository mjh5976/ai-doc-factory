#!/bin/bash

# 故障检测和自动重启机制 - 演示脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 服务配置
SERVICE1="http://localhost:5001"
SERVICE2="http://localhost:5002"
FAULT_DETECTOR="http://localhost:8080"

show_help() {
    echo -e "${BLUE}🧪 故障检测和自动重启机制 - 演示脚本${NC}"
    echo "=============================================="
    echo ""
    echo "用法: $0 [命令]"
    echo ""
    echo "命令:"
    echo "  help              显示此帮助信息"
    echo "  status            查看系统状态"
    echo "  test-health       测试健康检查"
    echo "  test-crash        模拟服务崩溃"
    echo "  test-error        模拟错误响应"
    echo "  test-memory       模拟内存泄漏"
    echo "  test-hang         模拟服务挂起"
    echo "  test-random       随机故障模拟"
    echo "  test-all          运行所有测试"
    echo "  monitor           实时监控系统"
    echo "  logs              查看故障检测日志"
    echo ""
    echo -e "${CYAN}示例:${NC}"
    echo "  $0 test-crash     # 模拟服务崩溃"
    echo "  $0 monitor        # 实时监控系统状态"
    echo ""
}

check_services() {
    echo -e "${YELLOW}🔍 检查服务状态...${NC}"
    
    if curl -s -f "$SERVICE1/health" > /dev/null; then
        echo -e "${GREEN}✅ 演示API服务1 正常${NC}"
    else
        echo -e "${RED}❌ 演示API服务1 不可用${NC}"
    fi
    
    if curl -s -f "$SERVICE2/health" > /dev/null; then
        echo -e "${GREEN}✅ 演示API服务2 正常${NC}"
    else
        echo -e "${RED}❌ 演示API服务2 不可用${NC}"
    fi
    
    if curl -s -f "$FAULT_DETECTOR/health" > /dev/null; then
        echo -e "${GREEN}✅ 故障检测服务 正常${NC}"
    else
        echo -e "${RED}❌ 故障检测服务 不可用${NC}"
    fi
}

test_health() {
    echo -e "${CYAN}🏥 测试健康检查功能${NC}"
    echo "========================"
    
    echo -e "${YELLOW}📊 获取服务1状态...${NC}"
    curl -s "$SERVICE1/health" | jq '.' || echo "JSON解析失败"
    
    echo -e "${YELLOW}📊 获取服务2状态...${NC}"
    curl -s "$SERVICE2/health" | jq '.' || echo "JSON解析失败"
    
    echo -e "${YELLOW}📊 获取故障检测服务状态...${NC}"
    curl -s "$FAULT_DETECTOR/services" | jq '.' || echo "JSON解析失败"
}

test_crash() {
    echo -e "${RED}💥 模拟服务崩溃${NC}"
    echo "==================="
    
    echo -e "${YELLOW}⚠️  正在模拟服务1崩溃...${NC}"
    curl -s "$SERVICE1/simulate-failure?type=crash"
    echo ""
    
    echo -e "${YELLOW}⏳ 等待故障检测和重启...${NC}"
    sleep 10
    
    echo -e "${YELLOW}🔍 检查服务恢复情况...${NC}"
    if curl -s -f "$SERVICE1/health" > /dev/null; then
        echo -e "${GREEN}✅ 服务1已自动恢复${NC}"
    else
        echo -e "${RED}❌ 服务1恢复失败${NC}"
    fi
}

test_error() {
    echo -e "${YELLOW}❌ 模拟错误响应${NC}"
    echo "=================="
    
    echo -e "${YELLOW}⚠️  正在模拟服务1错误响应...${NC}"
    response=$(curl -s -w "%{http_code}" -o /tmp/response.txt "$SERVICE1/simulate-failure?type=error")
    echo "响应状态码: $response"
    cat /tmp/response.txt
    echo ""
    
    echo -e "${YELLOW}⏳ 等待故障检测...${NC}"
    sleep 5
    
    echo -e "${YELLOW}📊 检查服务状态...${NC}"
    curl -s "$SERVICE1/health" | jq '.'
}

test_memory() {
    echo -e "${YELLOW}🧠 模拟内存泄漏${NC}"
    echo "=================="
    
    echo -e "${YELLOW}⚠️  正在模拟服务1内存泄漏...${NC}"
    curl -s "$SERVICE1/simulate-failure?type=memory"
    echo ""
    
    echo -e "${YELLOW}⏳ 等待故障检测...${NC}"
    sleep 10
    
    echo -e "${YELLOW}📊 检查服务状态...${NC}"
    curl -s "$SERVICE1/status" | jq '.system.memory_mb'
}

test_hang() {
    echo -e "${YELLOW}⏸️  模拟服务挂起${NC}"
    echo "=================="
    
    echo -e "${YELLOW}⚠️  正在模拟服务2挂起(5秒)...${NC}"
    curl -s "$SERVICE2/simulate-failure?type=hang" &
    
    echo -e "${YELLOW}⏳ 等待故障检测...${NC}"
    sleep 10
    
    echo -e "${YELLOW}📊 检查服务状态...${NC}"
    if curl -s -f "$SERVICE2/health" > /dev/null; then
        echo -e "${GREEN}✅ 服务2已恢复${NC}"
    else
        echo -e "${RED}❌ 服务2仍处于挂起状态${NC}"
    fi
}

test_random() {
    echo -e "${CYAN}🎲 随机故障模拟${NC}"
    echo "=================="
    
    services=("$SERVICE1" "$SERVICE2")
    service_names=("服务1" "服务2")
    
    # 随机选择服务和故障类型
    service_idx=$((RANDOM % 2))
    fault_types=("error" "memory" "hang")
    fault_idx=$((RANDOM % 3))
    
    service=${services[$service_idx]}
    service_name=${service_names[$service_idx]}
    fault_type=${fault_types[$fault_idx]}
    
    echo -e "${YELLOW}⚠️  正在模拟 $service_name 的 $fault_type 故障...${NC}"
    curl -s "$service/simulate-failure?type=$fault_type"
    echo ""
    
    echo -e "${YELLOW}⏳ 等待故障检测和重启...${NC}"
    sleep 15
    
    echo -e "${YELLOW}🔍 检查服务恢复情况...${NC}"
    if curl -s -f "$service/health" > /dev/null; then
        echo -e "${GREEN}✅ $service_name 已自动恢复${NC}"
    else
        echo -e "${RED}❌ $service_name 恢复失败${NC}"
    fi
}

test_all() {
    echo -e "${CYAN}🧪 运行所有测试${NC}"
    echo "=================="
    
    check_services
    echo ""
    
    test_health
    echo ""
    
    read -p "按Enter继续下一个测试..."
    test_crash
    echo ""
    
    read -p "按Enter继续下一个测试..."
    test_error
    echo ""
    
    read -p "按Enter继续下一个测试..."
    test_memory
    echo ""
    
    read -p "按Enter继续下一个测试..."
    test_hang
    echo ""
    
    read -p "按Enter继续下一个测试..."
    test_random
    echo ""
    
    echo -e "${GREEN}🎉 所有测试完成！${NC}"
}

monitor() {
    echo -e "${CYAN}📊 实时监控系统${NC}"
    echo "=================="
    echo "按Ctrl+C退出监控"
    echo ""
    
    while true; do
        clear
        echo -e "${BLUE}📊 系统状态监控 - $(date)${NC}"
        echo "=================================="
        
        # 检查服务状态
        echo -e "${YELLOW}🔍 服务状态:${NC}"
        if curl -s -f "$SERVICE1/health" > /dev/null; then
            echo -e "${GREEN}✅ 服务1: 正常${NC}"
        else
            echo -e "${RED}❌ 服务1: 异常${NC}"
        fi
        
        if curl -s -f "$SERVICE2/health" > /dev/null; then
            echo -e "${GREEN}✅ 服务2: 正常${NC}"
        else
            echo -e "${RED}❌ 服务2: 异常${NC}"
        fi
        
        if curl -s -f "$FAULT_DETECTOR/health" > /dev/null; then
            echo -e "${GREEN}✅ 故障检测: 正常${NC}"
        else
            echo -e "${RED}❌ 故障检测: 异常${NC}"
        fi
        
        echo ""
        echo -e "${YELLOW}📈 性能指标:${NC}"
        
        # 获取服务1的详细状态
        status1=$(curl -s "$SERVICE1/status" 2>/dev/null)
        if [ ! -z "$status1" ]; then
            memory=$(echo "$status1" | jq -r '.system.memory_mb // "N/A"')
            cpu=$(echo "$status1" | jq -r '.system.cpu_percent // "N/A"')
            echo -e "  服务1 - 内存: ${memory}MB, CPU: ${cpu}%"
        fi
        
        status2=$(curl -s "$SERVICE2/status" 2>/dev/null)
        if [ ! -z "$status2" ]; then
            memory=$(echo "$status2" | jq -r '.system.memory_mb // "N/A"')
            cpu=$(echo "$status2" | jq -r '.system.cpu_percent // "N/A"')
            echo -e "  服务2 - 内存: ${memory}MB, CPU: ${cpu}%"
        fi
        
        echo ""
        echo -e "${CYAN}⏰ 下次更新: 5秒后${NC}"
        sleep 5
    done
}

show_logs() {
    echo -e "${CYAN}📋 查看故障检测日志${NC}"
    echo "========================"
    echo "按Ctrl+C退出日志查看"
    echo ""
    
    # 查看故障检测服务日志
    docker-compose logs -f fault-detector
}

# 主逻辑
case "${1:-help}" in
    "help"|"-h"|"--help")
        show_help
        ;;
    "status")
        check_services
        ;;
    "test-health")
        test_health
        ;;
    "test-crash")
        test_crash
        ;;
    "test-error")
        test_error
        ;;
    "test-memory")
        test_memory
        ;;
    "test-hang")
        test_hang
        ;;
    "test-random")
        test_random
        ;;
    "test-all")
        test_all
        ;;
    "monitor")
        monitor
        ;;
    "logs")
        show_logs
        ;;
    *)
        echo -e "${RED}❌ 未知命令: $1${NC}"
        echo ""
        show_help
        exit 1
        ;;
esac