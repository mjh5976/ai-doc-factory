#!/bin/bash

# 故障检测和自动重启机制 - 停止脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🛑 故障检测和自动重启机制系统停止器${NC}"
echo "=================================="

# 询问是否清理数据
echo -e "${YELLOW}❓ 是否清理所有数据？(y/N)${NC}"
read -r response

if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
    echo -e "${YELLOW}🧹 清理所有数据...${NC}"
    docker-compose down -v --remove-orphans
    echo -e "${GREEN}✅ 所有数据已清理${NC}"
else
    echo -e "${YELLOW}⏹️  停止服务...${NC}"
    docker-compose down
    echo -e "${GREEN}✅ 服务已停止${NC}"
fi

# 显示镜像信息
echo -e "${BLUE}📋 保留的镜像:${NC}"
docker images | grep -E "(demo-api|fault-detector)"

echo ""
echo -e "${GREEN}🎉 系统已停止！${NC}"
echo -e "${BLUE}💡 提示:${NC}"
echo -e "  • 如需重新启动: ${YELLOW}./start.sh${NC}"
echo -e "  • 如需重新构建: ${YELLOW}./build.sh${NC}"
echo -e "  • 查看帮助: ${YELLOW}./demo.sh help${NC}"