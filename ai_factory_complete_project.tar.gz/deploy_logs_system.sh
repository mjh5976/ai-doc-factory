#!/bin/bash

# 日志分析和性能监控系统部署脚本
# 作者: MiniMax Agent
# 版本: 1.0

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_debug() {
    echo -e "${BLUE}[DEBUG]${NC} $1"
}

# 检查依赖
check_dependencies() {
    log_info "检查系统依赖..."
    
    # 检查Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker未安装，请先安装Docker"
        exit 1
    fi
    
    # 检查Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose未安装，请先安装Docker Compose"
        exit 1
    fi
    
    # 检查Python
    if ! command -v python3 &> /dev/null; then
        log_error "Python3未安装，请先安装Python3"
        exit 1
    fi
    
    # 检查pip
    if ! command -v pip3 &> /dev/null; then
        log_error "pip3未安装，请先安装pip3"
        exit 1
    fi
    
    log_info "依赖检查完成"
}

# 安装Python依赖
install_python_dependencies() {
    log_info "安装Python依赖包..."
    
    # 创建虚拟环境（可选）
    read -p "是否创建虚拟环境？(y/N): " create_venv
    if [[ $create_venv =~ ^[Yy]$ ]]; then
        python3 -m venv venv
        source venv/bin/activate
        log_info "虚拟环境已激活"
    fi
    
    # 安装依赖
    pip3 install --upgrade pip
    pip3 install redis elasticsearch whoosh scikit-learn pandas numpy matplotlib seaborn schedule psutil boto3 PyYAML requests schedule
    
    log_info "Python依赖安装完成"
}

# 创建目录结构
create_directories() {
    log_info "创建目录结构..."
    
    # 创建必要的目录
    mkdir -p logs
    mkdir -p storage/{hot,warm,cold,archive}
    mkdir -p reports
    mkdir -p indexes
    mkdir -p config/grafana/{provisioning,dashboards,datasources}
    mkdir -p fluentd
    mkdir -p python_apps/{log_collector,log_parser,log_analyzer,metrics_extractor,log_search,log_storage}
    mkdir -p dashboard
    
    # 设置权限
    chmod -R 755 logs storage reports indexes config
    chmod -R 777 storage  # 允许写入
    
    log_info "目录结构创建完成"
}

# 生成配置文件
generate_configs() {
    log_info "生成配置文件..."
    
    # 生成Prometheus配置
    cat > config/prometheus.yml << 'EOF'
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - "alert_rules.yml"

alerting:
  alertmanagers:
    - static_configs:
        - targets:
          - alertmanager:9093

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']
  
  - job_name: 'log_system'
    static_configs:
      - targets: ['log_collector:8000', 'log_analyzer:8000', 'metrics_extractor:8000']
  
  - job_name: 'redis'
    static_configs:
      - targets: ['redis:6379']
  
  - job_name: 'elasticsearch'
    static_configs:
      - targets: ['elasticsearch:9200']
EOF

    # 生成Alertmanager配置
    cat > config/alertmanager.yml << 'EOF'
global:
  smtp_smarthost: 'localhost:587'
  smtp_from: 'logs@company.com'

route:
  group_by: ['alertname']
  group_wait: 10s
  group_interval: 10s
  repeat_interval: 1h
  receiver: 'web.hook'
  routes:
  - match:
      severity: critical
    receiver: 'critical-alerts'

receivers:
- name: 'web.hook'
  webhook_configs:
  - url: 'http://log_analyzer:8080/webhook'
  
- name: 'critical-alerts'
  email_configs:
  - to: 'admin@company.com'
    subject: '[CRITICAL] 日志系统告警'
    body: |
      {{ range .Alerts }}
      告警: {{ .Annotations.summary }}
      描述: {{ .Annotations.description }}
      级别: {{ .Labels.severity }}
      服务: {{ .Labels.service }}
      {{ end }}
EOF

    # 生成Grafana数据源配置
    mkdir -p config/grafana/datasources
    cat > config/grafana/datasources/prometheus.yml << 'EOF'
apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
    editable: true
EOF

    # 生成Fluentd配置
    cat > config/fluentd.conf << 'EOF'
<source>
  @type tail
  @id input_tail
  path /var/log/*.log
  pos_file /fluentd/log/fluentd-docker.log.pos
  tag docker.*
  format /^(?<time>[^ ]* [^ ,]*)[^ ]* (?<container_id>[a-f0-9]{64}) (?<message>.*)$/
  time_format %Y-%m-%dT%H:%M:%S.%NZ
</source>

<source>
  @type udp
  @id input_udp
  port 24224
  tag docker.udp
</source>

<match docker.**>
  @type elasticsearch
  host elasticsearch
  port 9200
  index_name fluentd
  type_name fluentd
  include_tag_key true
  tag_key @log_name
  logstash_format true
  logstash_prefix docker
  logstash_dateformat %Y.%m.%d
  flush_interval 10s
</match>
EOF

    log_info "配置文件生成完成"
}

# 构建Docker镜像
build_images() {
    log_info "构建Docker镜像..."
    
    # 构建Python应用镜像
    for app in log_collector log_parser log_analyzer metrics_extractor log_search log_storage; do
        log_info "构建 $app 镜像..."
        cat > python_apps/$app/Dockerfile << EOF
FROM python:3.9-slim

WORKDIR /app

# 安装系统依赖
RUN apt-get update && apt-get install -y \\
    curl \\
    && rm -rf /var/lib/apt/lists/*

# 复制依赖文件
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# 复制应用代码
COPY . .

# 创建必要目录
RUN mkdir -p logs config reports indexes storage

# 设置环境变量
ENV PYTHONPATH=/app
ENV CONFIG_PATH=/app/config/log_config.yaml

EXPOSE 8000

CMD ["python", "$(basename $app).py"]
EOF

        # 创建requirements.txt
        cat > python_apps/$app/requirements.txt << EOF
redis
elasticsearch
whoosh
scikit-learn
pandas
numpy
matplotlib
seaborn
schedule
psutil
boto3
PyYAML
requests
EOF

        # 构建镜像
        docker build -t $app:latest python_apps/$app/
    done
    
    # 构建Dashboard镜像
    log_info "构建Dashboard镜像..."
    cat > dashboard/Dockerfile << 'EOF'
FROM nginx:alpine

COPY dashboard.html /usr/share/nginx/html/
COPY assets/ /usr/share/nginx/html/assets/

EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
EOF

    # 创建简单的仪表板
    cat > dashboard/dashboard.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>日志分析仪表板</title>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .dashboard { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .widget { border: 1px solid #ddd; padding: 20px; border-radius: 5px; }
        .metric { font-size: 2em; font-weight: bold; color: #333; }
        .chart { width: 100%; height: 300px; }
    </style>
</head>
<body>
    <h1>日志分析和性能监控系统</h1>
    
    <div class="dashboard">
        <div class="widget">
            <h3>日志处理速率</h3>
            <div class="metric" id="processing_rate">0</div>
            <p>条/秒</p>
        </div>
        
        <div class="widget">
            <h3>活跃告警</h3>
            <div class="metric" id="active_alerts">0</div>
            <p>个</p>
        </div>
        
        <div class="widget">
            <h3>存储使用情况</h3>
            <div id="storage_usage">
                <p>热存储: <span id="hot_storage">0</span> GB</p>
                <p>温存储: <span id="warm_storage">0</span> GB</p>
                <p>冷存储: <span id="cold_storage">0</span> GB</p>
            </div>
        </div>
        
        <div class="widget">
            <h3>搜索查询统计</h3>
            <div id="search_stats">
                <p>总查询数: <span id="total_queries">0</span></p>
                <p>平均查询时间: <span id="avg_query_time">0</span> ms</p>
            </div>
        </div>
    </div>
    
    <script>
        // 模拟实时数据更新
        function updateMetrics() {
            document.getElementById('processing_rate').textContent = Math.floor(Math.random() * 1000);
            document.getElementById('active_alerts').textContent = Math.floor(Math.random() * 10);
            document.getElementById('hot_storage').textContent = (Math.random() * 10).toFixed(1);
            document.getElementById('warm_storage').textContent = (Math.random() * 50).toFixed(1);
            document.getElementById('cold_storage').textContent = (Math.random() * 100).toFixed(1);
            document.getElementById('total_queries').textContent = Math.floor(Math.random() * 10000);
            document.getElementById('avg_query_time').textContent = Math.floor(Math.random() * 100);
        }
        
        // 每5秒更新一次
        setInterval(updateMetrics, 5000);
        updateMetrics(); // 初始更新
    </script>
</body>
</html>
EOF

    docker build -t log_dashboard:latest dashboard/
    
    log_info "Docker镜像构建完成"
}

# 启动服务
start_services() {
    log_info "启动日志分析系统服务..."
    
    # 停止现有服务
    docker-compose -f docker-compose.logs.yml down --remove-orphans 2>/dev/null || true
    
    # 启动服务
    docker-compose -f docker-compose.logs.yml up -d
    
    log_info "等待服务启动..."
    sleep 30
    
    # 检查服务状态
    log_info "检查服务状态..."
    docker-compose -f docker-compose.logs.yml ps
    
    log_info "服务启动完成"
}

# 运行健康检查
health_check() {
    log_info "运行健康检查..."
    
    # 检查关键服务
    services=("redis" "elasticsearch" "log_collector" "log_analyzer")
    
    for service in "${services[@]}"; do
        if docker-compose -f docker-compose.logs.yml ps | grep -q "$service"; then
            log_info "$service 运行正常"
        else
            log_error "$service 运行异常"
        fi
    done
    
    # 测试API端点
    log_info "测试API端点..."
    
    # 测试Redis连接
    if docker exec log_redis redis-cli ping | grep -q "PONG"; then
        log_info "Redis连接正常"
    else
        log_error "Redis连接失败"
    fi
    
    # 测试Elasticsearch连接
    if curl -s http://localhost:9200/_cluster/health | grep -q "status"; then
        log_info "Elasticsearch连接正常"
    else
        log_error "Elasticsearch连接失败"
    fi
    
    log_info "健康检查完成"
}

# 显示访问信息
show_access_info() {
    log_info "=========================================="
    log_info "日志分析和性能监控系统部署完成！"
    log_info "=========================================="
    log_info ""
    log_info "访问地址："
    log_info "- 系统仪表板: http://localhost:8081"
    log_info "- Grafana监控: http://localhost:3000 (admin/admin123)"
    log_info "- Kibana日志: http://localhost:5601"
    log_info "- Prometheus: http://localhost:9090"
    log_info "- Alertmanager: http://localhost:9093"
    log_info "- 日志搜索API: http://localhost:8080"
    log_info ""
    log_info "服务管理命令："
    log_info "- 查看服务状态: docker-compose -f docker-compose.logs.yml ps"
    log_info "- 查看日志: docker-compose -f docker-compose.logs.yml logs -f [service_name]"
    log_info "- 重启服务: docker-compose -f docker-compose.logs.yml restart [service_name]"
    log_info "- 停止服务: docker-compose -f docker-compose.logs.yml down"
    log_info ""
    log_info "配置文件位置："
    log_info "- 日志收集配置: config/log_config.yaml"
    log_info "- 分析器配置: config/analyzer_config.yaml"
    log_info "- 存储配置: config/storage_config.yaml"
    log_info "- 搜索配置: config/search_config.yaml"
    log_info ""
    log_info "数据目录："
    log_info "- 日志文件: logs/"
    log_info "- 存储文件: storage/"
    log_info "- 报告文件: reports/"
    log_info "=========================================="
}

# 主函数
main() {
    echo "=========================================="
    echo "日志分析和性能监控系统部署脚本"
    echo "=========================================="
    echo ""
    
    # 检查是否为root用户
    if [[ $EUID -eq 0 ]]; then
        log_warn "建议不要使用root用户运行此脚本"
        read -p "是否继续？(y/N): " continue_as_root
        if [[ ! $continue_as_root =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
    
    # 执行部署步骤
    check_dependencies
    install_python_dependencies
    create_directories
    generate_configs
    build_images
    start_services
    health_check
    show_access_info
    
    log_info "部署完成！"
}

# 错误处理
trap 'log_error "部署过程中发生错误，脚本已退出"; exit 1' ERR

# 运行主函数
main "$@"
