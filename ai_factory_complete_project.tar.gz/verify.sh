#!/bin/bash

# 故障检测和自动重启机制 - 验证脚本
# 用于验证系统是否正确部署和配置

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${BLUE}🔍 故障检测和自动重启机制系统验证${NC}"
echo "======================================"

# 检查必要文件
echo -e "${YELLOW}📋 检查必要文件...${NC}"
required_files=(
    "docker-compose.yml"
    "configs/prometheus.yml"
    "configs/alertmanager.yml"
    "configs/loki-config.yaml"
    "configs/fault_detection_config.yaml"
    "demo-app/Dockerfile"
    "demo-app/app.py"
    "demo-app/requirements.txt"
    "fault-detector/Dockerfile"
    "fault-detector/main.py"
    "fault-detector/requirements.txt"
    "start.sh"
    "demo.sh"
    "stop.sh"
)

missing_files=()
for file in "${required_files[@]}"; do
    if [ ! -f "$file" ]; then
        missing_files+=("$file")
    fi
done

if [ ${#missing_files[@]} -eq 0 ]; then
    echo -e "${GREEN}✅ 所有必要文件都存在${NC}"
else
    echo -e "${RED}❌ 缺少以下文件:${NC}"
    for file in "${missing_files[@]}"; do
        echo -e "  - $file"
    done
    exit 1
fi

# 检查目录结构
echo -e "${YELLOW}📁 检查目录结构...${NC}"
required_dirs=(
    "configs"
    "configs/grafana"
    "configs/grafana/dashboards"
    "configs/grafana/datasources"
    "logs"
    "demo-app"
    "fault-detector"
)

missing_dirs=()
for dir in "${required_dirs[@]}"; do
    if [ ! -d "$dir" ]; then
        missing_dirs+=("$dir")
    fi
done

if [ ${#missing_dirs[@]} -eq 0 ]; then
    echo -e "${GREEN}✅ 目录结构正确${NC}"
else
    echo -e "${RED}❌ 缺少以下目录:${NC}"
    for dir in "${missing_dirs[@]}"; do
        echo -e "  - $dir"
    done
fi

# 检查配置文件格式
echo -e "${YELLOW}📝 检查配置文件格式...${NC}"

# 检查YAML文件格式
yaml_files=(
    "configs/prometheus.yml"
    "configs/alertmanager.yml"
    "configs/loki-config.yaml"
    "configs/fault_detection_config.yaml"
)

for file in "${yaml_files[@]}"; do
    if python3 -c "import yaml; yaml.safe_load(open('$file'))" 2>/dev/null; then
        echo -e "${GREEN}✅ $file 格式正确${NC}"
    else
        echo -e "${RED}❌ $file 格式错误${NC}"
    fi
done

# 检查Python文件语法
echo -e "${YELLOW}🐍 检查Python文件语法...${NC}"
python_files=(
    "demo-app/app.py"
    "fault-detector/main.py"
)

for file in "${python_files[@]}"; do
    if python3 -m py_compile "$file" 2>/dev/null; then
        echo -e "${GREEN}✅ $file 语法正确${NC}"
    else
        echo -e "${RED}❌ $file 语法错误${NC}"
    fi
done

# 检查Docker Compose文件
echo -e "${YELLOW}🐳 检查Docker Compose配置...${NC}"
if docker-compose config > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Docker Compose配置正确${NC}"
else
    echo -e "${RED}❌ Docker Compose配置错误${NC}"
fi

# 检查依赖项
echo -e "${YELLOW}📦 检查依赖项...${NC}"

# 检查Docker
if command -v docker &> /dev/null; then
    echo -e "${GREEN}✅ Docker 已安装${NC}"
else
    echo -e "${RED}❌ Docker 未安装${NC}"
fi

# 检查Docker Compose
if command -v docker-compose &> /dev/null; then
    echo -e "${GREEN}✅ Docker Compose 已安装${NC}"
else
    echo -e "${RED}❌ Docker Compose 未安装${NC}"
fi

# 检查curl
if command -v curl &> /dev/null; then
    echo -e "${GREEN}✅ curl 已安装${NC}"
else
    echo -e "${YELLOW}⚠️  curl 未安装 (可选)${NC}"
fi

# 检查jq
if command -v jq &> /dev/null; then
    echo -e "${GREEN}✅ jq 已安装${NC}"
else
    echo -e "${YELLOW}⚠️  jq 未安装 (可选，用于JSON格式化)${NC}"
fi

# 生成配置摘要
echo -e "${CYAN}📊 配置摘要${NC}"
echo "=================="

# 统计服务数量
service_count=$(grep -c "container_name:" configs/fault_detection_config.yaml 2>/dev/null || echo "0")
echo -e "配置的服务数量: ${YELLOW}$service_count${NC}"

# 统计配置文件大小
total_config_size=$(du -sh configs/ 2>/dev/null | cut -f1 || echo "N/A")
echo -e "配置文件总大小: ${YELLOW}$total_config_size${NC}"

# 检查脚本权限
echo -e "${YELLOW}🔐 检查脚本权限...${NC}"
scripts=("start.sh" "stop.sh" "demo.sh" "build.sh")
for script in "${scripts[@]}"; do
    if [ -f "$script" ]; then
        if [ -x "$script" ]; then
            echo -e "${GREEN}✅ $script 有执行权限${NC}"
        else
            echo -e "${YELLOW}⚠️  $script 没有执行权限 (需要手动添加: chmod +x $script)${NC}"
        fi
    fi
done

# 总结
echo ""
echo -e "${BLUE}🎯 验证总结${NC}"
echo "=============="

if [ ${#missing_files[@]} -eq 0 ] && [ ${#missing_dirs[@]} -eq 0 ]; then
    echo -e "${GREEN}✅ 系统配置验证通过！${NC}"
    echo -e "${CYAN}📋 下一步操作:${NC}"
    echo -e "  1. 配置通知渠道 (编辑 configs/fault_detection_config.yaml)"
    echo -e "  2. 运行 ./start.sh 启动系统"
    echo -e "  3. 运行 ./demo.sh status 检查系统状态"
    echo -e "  4. 运行 ./demo.sh test-crash 测试故障检测"
else
    echo -e "${RED}❌ 系统配置验证失败！${NC}"
    echo -e "${CYAN}🔧 请修复上述问题后重新验证${NC}"
fi

echo ""
echo -e "${BLUE}📚 更多信息请查看:${NC}"
echo -e "  • README文档: ${YELLOW}FAULT_DETECTION_README.md${NC}"
echo -e "  • 配置文件: ${YELLOW}configs/${NC}"
echo -e "  • 示例代码: ${YELLOW}demo-app/ 和 fault-detector/${NC}"