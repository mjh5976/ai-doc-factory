#!/usr/bin/env python3
"""
PDF图纸识别深度学习模型架构图生成器
创建详细的模型架构可视化图表
"""

import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch, ConnectionPatch
import numpy as np

def setup_matplotlib_for_plotting():
    """
    Setup matplotlib and seaborn for plotting with proper configuration.
    Call this function before creating any plots to ensure proper rendering.
    """
    import warnings
    import matplotlib.pyplot as plt
    
    # Ensure warnings are printed
    warnings.filterwarnings('default')  # Show all warnings
    
    # Configure matplotlib for non-interactive mode
    plt.switch_backend("Agg")
    
    # Configure platform-appropriate fonts for cross-platform compatibility
    plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC", "WenQuanYi Zen Hei", "PingFang SC", "Arial Unicode MS", "Hiragino Sans GB"]
    plt.rcParams["axes.unicode_minus"] = False

def create_model_architecture_diagram():
    """创建PDF图纸识别深度学习模型架构图"""
    
    # 设置matplotlib
    setup_matplotlib_for_plotting()
    
    # 创建图形和坐标轴
    fig, ax = plt.subplots(1, 1, figsize=(16, 12))
    ax.set_xlim(0, 20)
    ax.set_ylim(0, 15)
    ax.axis('off')
    
    # 定义颜色方案
    colors = {
        'input': '#E3F2FD',      # 浅蓝色 - 输入层
        'encoder': '#E8F5E8',    # 浅绿色 - 编码器
        'fusion': '#FFF3E0',     # 浅橙色 - 融合层
        'geometry': '#FCE4EC',   # 浅粉色 - 几何理解层
        'task': '#F1F8E9',       # 浅青色 - 任务头部
        'output': '#E0F2F1',     # 浅青色 - 输出层
        'border': '#1976D2',     # 深蓝色 - 边框
        'text': '#424242'        # 深灰色 - 文字
    }
    
    # 绘制输入层
    input_boxes = [
        {'name': 'PDF文档', 'pos': (1, 12), 'size': (2.5, 1)},
        {'name': '矢量解析器', 'pos': (1, 10), 'size': (2.5, 1)},
        {'name': '栅格化处理器', 'pos': (4, 12), 'size': (2.5, 1)},
        {'name': '文本提取器', 'pos': (7, 12), 'size': (2.5, 1)}
    ]
    
    for box in input_boxes:
        fancy_box = FancyBboxPatch(
            box['pos'], box['size'][0], box['size'][1],
            boxstyle="round,pad=0.1",
            facecolor=colors['input'],
            edgecolor=colors['border'],
            linewidth=2
        )
        ax.add_patch(fancy_box)
        ax.text(box['pos'][0] + box['size'][0]/2, box['pos'][1] + box['size'][1]/2,
                box['name'], ha='center', va='center', fontsize=10, fontweight='bold')
    
    # 绘制特征提取层
    encoder_boxes = [
        {'name': '矢量特征编码器', 'pos': (1, 8), 'size': (2.5, 1)},
        {'name': '图像特征编码器', 'pos': (4, 8), 'size': (2.5, 1)},
        {'name': '文本特征编码器', 'pos': (7, 8), 'size': (2.5, 1)}
    ]
    
    for box in encoder_boxes:
        fancy_box = FancyBboxPatch(
            box['pos'], box['size'][0], box['size'][1],
            boxstyle="round,pad=0.1",
            facecolor=colors['encoder'],
            edgecolor=colors['border'],
            linewidth=2
        )
        ax.add_patch(fancy_box)
        ax.text(box['pos'][0] + box['size'][0]/2, box['pos'][1] + box['size'][1]/2,
                box['name'], ha='center', va='center', fontsize=10, fontweight='bold')
    
    # 绘制特征融合层
    fusion_boxes = [
        {'name': '跨模态注意力融合', 'pos': (3, 6), 'size': (3, 1)},
        {'name': 'Transformer融合层', 'pos': (7, 6), 'size': (3, 1)}
    ]
    
    for box in fusion_boxes:
        fancy_box = FancyBboxPatch(
            box['pos'], box['size'][0], box['size'][1],
            boxstyle="round,pad=0.1",
            facecolor=colors['fusion'],
            edgecolor=colors['border'],
            linewidth=2
        )
        ax.add_patch(fancy_box)
        ax.text(box['pos'][0] + box['size'][0]/2, box['pos'][1] + box['size'][1]/2,
                box['name'], ha='center', va='center', fontsize=10, fontweight='bold')
    
    # 绘制几何理解层
    geometry_boxes = [
        {'name': '几何关系网络', 'pos': (3, 4), 'size': (3, 1)},
        {'name': '拓扑分析器', 'pos': (7, 4), 'size': (3, 1)}
    ]
    
    for box in geometry_boxes:
        fancy_box = FancyBboxPatch(
            box['pos'], box['size'][0], box['size'][1],
            boxstyle="round,pad=0.1",
            facecolor=colors['geometry'],
            edgecolor=colors['border'],
            linewidth=2
        )
        ax.add_patch(fancy_box)
        ax.text(box['pos'][0] + box['size'][0]/2, box['pos'][1] + box['size'][1]/2,
                box['name'], ha='center', va='center', fontsize=10, fontweight='bold')
    
    # 绘制任务头部
    task_boxes = [
        {'name': '符号检测头部', 'pos': (1, 2), 'size': (2.5, 1)},
        {'name': '文本检测头部', 'pos': (4, 2), 'size': (2.5, 1)},
        {'name': '尺寸标注头部', 'pos': (7, 2), 'size': (2.5, 1)},
        {'name': '几何分析头部', 'pos': (10, 2), 'size': (2.5, 1)}
    ]
    
    for box in task_boxes:
        fancy_box = FancyBboxPatch(
            box['pos'], box['size'][0], box['size'][1],
            boxstyle="round,pad=0.1",
            facecolor=colors['task'],
            edgecolor=colors['border'],
            linewidth=2
        )
        ax.add_patch(fancy_box)
        ax.text(box['pos'][0] + box['size'][0]/2, box['pos'][1] + box['size'][1]/2,
                box['name'], ha='center', va='center', fontsize=10, fontweight='bold')
    
    # 绘制输出层
    output_box = FancyBboxPatch(
        (4, 0.2), 6, 0.8,
        boxstyle="round,pad=0.1",
        facecolor=colors['output'],
        edgecolor=colors['border'],
        linewidth=2
    )
    ax.add_patch(output_box)
    ax.text(7, 0.6, '结构化输出', ha='center', va='center', fontsize=12, fontweight='bold')
    
    # 绘制连接线
    # 输入到编码器
    for i, encoder_box in enumerate(encoder_boxes):
        if i == 0:  # 矢量特征编码器
            ax.arrow(2.25, 11.8, 0, -2.5, head_width=0.1, head_length=0.1, 
                    fc=colors['border'], ec=colors['border'])
        elif i == 1:  # 图像特征编码器
            ax.arrow(5.25, 11.8, 0, -2.5, head_width=0.1, head_length=0.1, 
                    fc=colors['border'], ec=colors['border'])
        else:  # 文本特征编码器
            ax.arrow(8.25, 11.8, 0, -2.5, head_width=0.1, head_length=0.1, 
                    fc=colors['border'], ec=colors['border'])
    
    # 编码器到融合层
    ax.arrow(2.25, 7.8, 0.75, -0.5, head_width=0.1, head_length=0.1, 
            fc=colors['border'], ec=colors['border'])
    ax.arrow(5.25, 7.8, 0.75, -0.5, head_width=0.1, head_length=0.1, 
            fc=colors['border'], ec=colors['border'])
    ax.arrow(8.25, 7.8, 0.75, -0.5, head_width=0.1, head_length=0.1, 
            fc=colors['border'], ec=colors['border'])
    
    # 融合层内部连接
    ax.arrow(6, 6.5, 0.5, 0, head_width=0.1, head_length=0.1, 
            fc=colors['border'], ec=colors['border'])
    
    # 融合层到几何理解层
    ax.arrow(4.5, 5.8, 0, -0.5, head_width=0.1, head_length=0.1, 
            fc=colors['border'], ec=colors['border'])
    ax.arrow(8.5, 5.8, 0, -0.5, head_width=0.1, head_length=0.1, 
            fc=colors['border'], ec=colors['border'])
    
    # 几何理解层内部连接
    ax.arrow(6, 4.5, 0.5, 0, head_width=0.1, head_length=0.1, 
            fc=colors['border'], ec=colors['border'])
    
    # 几何理解层到任务头部
    ax.arrow(4.5, 3.8, -2.5, -1.5, head_width=0.1, head_length=0.1, 
            fc=colors['border'], ec=colors['border'])
    ax.arrow(4.5, 3.8, -0.5, -1.5, head_width=0.1, head_length=0.1, 
            fc=colors['border'], ec=colors['border'])
    ax.arrow(4.5, 3.8, 1.5, -1.5, head_width=0.1, head_length=0.1, 
            fc=colors['border'], ec=colors['border'])
    ax.arrow(4.5, 3.8, 3.5, -1.5, head_width=0.1, head_length=0.1, 
            fc=colors['border'], ec=colors['border'])
    
    # 任务头部到输出层
    for i, task_box in enumerate(task_boxes):
        center_x = task_box['pos'][0] + task_box['size'][0]/2
        ax.arrow(center_x, 1.8, 0, -0.8, head_width=0.1, head_length=0.1, 
                fc=colors['border'], ec=colors['border'])
    
    # 添加标题
    ax.text(10, 14, 'PDF图纸识别深度学习模型架构', ha='center', va='center', 
            fontsize=16, fontweight='bold', color=colors['text'])
    
    # 添加层标签
    layer_labels = [
        {'text': '输入层', 'pos': (0.5, 12.5), 'color': colors['input']},
        {'text': '特征提取层', 'pos': (0.5, 8.5), 'color': colors['encoder']},
        {'text': '特征融合层', 'pos': (0.5, 6.5), 'color': colors['fusion']},
        {'text': '几何理解层', 'pos': (0.5, 4.5), 'color': colors['geometry']},
        {'text': '任务头部', 'pos': (0.5, 2.5), 'color': colors['task']},
        {'text': '输出层', 'pos': (0.5, 0.6), 'color': colors['output']}
    ]
    
    for label in layer_labels:
        ax.text(label['pos'][0], label['pos'][1], label['text'], 
                ha='center', va='center', fontsize=10, fontweight='bold',
                bbox=dict(boxstyle="round,pad=0.3", facecolor=label['color'], 
                         edgecolor=colors['border'], linewidth=1))
    
    # 添加技术说明
    tech_notes = [
        '• 多模态输入处理\n  - 矢量图形：坐标、线型、线宽\n  - 栅格图像：纹理、边缘、形状\n  - 文本信息：编码、字体、布局',
        '• CNN + Transformer混合架构\n  - CNN：局部特征提取\n  - Transformer：全局上下文建模\n  - 跨模态注意力：特征融合',
        '• 几何理解与拓扑分析\n  - 几何关系网络：空间关系建模\n  - 拓扑分析器：连接关系分析\n  - 规则引擎：几何约束验证',
        '• 多任务学习框架\n  - 符号检测：实例分割 + 分类\n  - 文本检测：序列识别\n  - 尺寸标注：几何测量\n  - 几何分析：形状理解'
    ]
    
    for i, note in enumerate(tech_notes):
        ax.text(13, 13-i*2.5, note, ha='left', va='top', fontsize=9,
                bbox=dict(boxstyle="round,pad=0.5", facecolor='white', 
                         edgecolor=colors['border'], linewidth=1))
    
    plt.tight_layout()
    plt.savefig('/workspace/docs/pdf_model_architecture_diagram.png', 
                dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    
    print("PDF图纸识别深度学习模型架构图已生成：/workspace/docs/pdf_model_architecture_diagram.png")

if __name__ == "__main__":
    create_model_architecture_diagram()
