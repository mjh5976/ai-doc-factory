# PDF解析和图像预处理模块

一个完整的PDF文档解析和图像预处理解决方案，提供高效的批处理能力、错误处理和异常恢复机制。

## 功能特性

### 📄 PDF解析和内容提取
- **矢量图形提取**: 提取线条、矩形、圆形、路径等矢量元素
- **文本提取**: 支持原生PDF文本提取和OCR回退机制
- **图像提取**: 提取嵌入的图像和图表
- **元数据解析**: 获取文档元信息、页面属性等

### 🖼️ 图像预处理和增强
- **去噪处理**: 高斯滤波、双边滤波、非局部均值去噪
- **对比度增强**: 自适应直方图均衡化、伽马校正
- **几何变换**: 缩放、旋转、翻转
- **倾斜校正**: 霍夫变换和图像矩方法
- **线条增强**: 形态学操作和Gabor滤波器
- **二值化**: Otsu、自适应和手动阈值

### 📊 数据格式转换和标准化
- **多格式支持**: JSON、CSV、XML、Excel、Parquet、HDF5
- **数据标准化**: 统一的数据结构和格式
- **文档结构分析**: 自动识别标题、页眉页脚、目录
- **数据验证**: 模式验证和数据质量检查

### ⚡ 批处理和并行处理优化
- **智能批处理**: 自动优化工作线程数和队列大小
- **任务队列**: 优先级队列和任务调度
- **进度跟踪**: 实时进度监控和报告
- **资源管理**: 内存和CPU使用监控
- **缓存机制**: 结果缓存和增量更新

### 🛡️ 错误处理和异常恢复
- **错误分类**: 系统化的错误类型学
- **自动恢复**: 多种恢复策略（重试、回退、跳过、补偿）
- **健康监控**: 系统健康状态实时监控
- **错误模式识别**: 基于模式的错误检测和处理
- **审计追踪**: 完整的错误日志和恢复历史

## 架构设计

```
PDF解析和图像预处理模块
├── pdf_parser.py          # PDF解析器
├── image_preprocessor.py  # 图像预处理器
├── data_converter.py      # 数据转换器
├── batch_processor.py     # 批处理器
├── error_handler.py       # 错误处理器
└── pdf_processing_pipeline.py  # 主流水线
```

## 安装依赖

```bash
pip install -r requirements.txt
```

## 快速开始

### 基本使用

```python
from pdf_processing_pipeline import quick_process_pdf

# 快速处理单个PDF文件
result = quick_process_pdf(
    pdf_path="document.pdf",
    output_dir="output",
    config=None  # 使用默认配置
)

print(f"处理结果: {'成功' if result.success else '失败'}")
print(f"处理时间: {result.processing_time:.2f}秒")
print(f"输出文件: {result.output_files}")
```

### 高级配置

```python
from pdf_processing_pipeline import PDFProcessingPipeline, ProcessingPipelineConfig

# 创建自定义配置
config = ProcessingPipelineConfig(
    pdf_max_workers=4,
    image_resize_factor=1.5,
    image_denoise_method="bilateral",
    data_output_formats=['json', 'csv', 'excel'],
    batch_max_workers=4,
    error_auto_recovery=True
)

# 创建处理流水线
pipeline = PDFProcessingPipeline(config)

# 处理PDF文件
result = pipeline.process_pdf_file(
    pdf_path="document.pdf",
    output_dir="output",
    output_formats=['json', 'csv', 'excel']
)
```

### 批量处理

```python
from pdf_processing_pipeline import batch_process_pdfs

# 批量处理多个PDF文件
pdf_files = ["doc1.pdf", "doc2.pdf", "doc3.pdf"]
results = batch_process_pdfs(
    pdf_paths=pdf_files,
    output_dir="batch_output"
)

# 统计结果
successful = sum(1 for r in results if r.success)
print(f"批量处理完成: {successful}/{len(results)} 成功")
```

## 详细功能说明

### PDF解析器 (pdf_parser.py)

#### 主要功能
- **文本提取**: 支持原生PDF文本提取和多种OCR引擎（Tesseract、PaddleOCR、EasyOCR）
- **矢量图形提取**: 提取路径、线条、矩形、多边形等矢量元素
- **图像提取**: 提取嵌入的图像和图表
- **元数据解析**: 获取文档信息、页面属性等

#### 使用示例
```python
from pdf_parser import PDFParser

# 创建解析器
parser = PDFParser(
    max_workers=4,
    enable_image_extraction=True,
    enable_vector_extraction=True
)

# 解析PDF
page_data_list = parser.parse_pdf("document.pdf")

# 访问结果
for page_data in page_data_list:
    print(f"页面 {page_data.page_number + 1}:")
    print(f"  文本元素: {len(page_data.text_elements)}")
    print(f"  矢量元素: {len(page_data.vector_elements)}")
    print(f"  图像元素: {len(page_data.image_elements)}")
```

### 图像预处理器 (image_preprocessor.py)

#### 主要功能
- **去噪**: 多种去噪算法
- **对比度增强**: 自适应直方图均衡化
- **几何变换**: 缩放、旋转、翻转
- **倾斜校正**: 自动检测和校正倾斜
- **线条增强**: 增强线条和边缘
- **批处理**: 支持批量图像处理

#### 使用示例
```python
from image_preprocessor import BatchImageProcessor, ProcessingConfig

# 创建配置
config = ProcessingConfig(
    resize_factor=1.5,
    denoise_method="bilateral",
    contrast_factor=1.3,
    enable_skew_correction=True,
    enable_line_enhancement=True,
    binarization_method="adaptive"
)

# 创建预处理器
processor = BatchImageProcessor(config, max_workers=4)

# 处理图像
result = processor.preprocessor.preprocess_image(image, config)
print(f"处理步骤: {result.processing_steps}")
print(f"处理时间: {result.processing_time:.2f}秒")
```

### 数据转换器 (data_converter.py)

#### 主要功能
- **格式转换**: 支持多种数据格式
- **数据标准化**: 统一的数据结构
- **文档结构分析**: 自动分析文档结构
- **数据验证**: 模式验证和质量检查

#### 使用示例
```python
from data_converter import DataStandardizer

# 创建转换器
converter = DataStandardizer(version="1.0.0")

# 标准化PDF数据
doc_structure = converter.standardize_pdf_data(pdf_data, "doc_001")

# 转换为不同格式
converter.convert_to_format(doc_structure.to_dict(), 'json', 'output.json')
converter.convert_to_format(doc_structure.to_dict(), 'csv', 'output.csv')
converter.convert_to_format(doc_structure.to_dict(), 'excel', 'output.xlsx')
```

### 批处理器 (batch_processor.py)

#### 主要功能
- **任务队列**: 优先级队列管理
- **智能调度**: 自适应工作线程数
- **进度跟踪**: 实时进度监控
- **缓存机制**: 结果缓存和增量更新
- **资源监控**: 内存和CPU使用监控

#### 使用示例
```python
from batch_processor import SmartBatchProcessor, BatchConfig, Task

# 创建配置
config = BatchConfig(
    max_workers=4,
    max_queue_size=100,
    enable_monitoring=True,
    enable_caching=True
)

# 创建批处理器
processor = SmartBatchProcessor(config)

# 创建任务
task = Task(
    task_id="pdf_parse_001",
    task_type="pdf_parse",
    input_data="document.pdf",
    priority=1
)

# 添加任务
processor.add_task(task)

# 开始处理
processor.start_processing()
result = processor.wait_for_completion()
```

### 错误处理器 (error_handler.py)

#### 主要功能
- **错误分类**: 系统化的错误处理
- **自动恢复**: 多种恢复策略
- **健康监控**: 系统健康状态监控
- **错误模式**: 基于模式的错误处理
- **审计追踪**: 完整的错误日志

#### 使用示例
```python
from error_handler import ErrorRecoverySystem

# 创建错误恢复系统
recovery_system = ErrorRecoverySystem()

# 使用装饰器
@with_error_recovery(recovery_system)
def risky_operation(data):
    # 可能失败的操作
    if np.random.random() < 0.3:
        raise ValueError("模拟操作失败")
    return f"操作成功: {data}"

# 执行操作
result, success = recovery_system.handle_operation(risky_operation, "测试数据")
```

### 主流水线 (pdf_processing_pipeline.py)

#### 主要功能
- **端到端处理**: 完整的PDF处理流水线
- **配置管理**: 灵活的配置系统
- **批处理支持**: 批量处理多个PDF
- **状态监控**: 系统状态监控
- **报告生成**: 详细的处理报告

#### 使用示例
```python
from pdf_processing_pipeline import PDFProcessingPipeline, ProcessingPipelineConfig

# 创建配置
config = ProcessingPipelineConfig(
    pdf_max_workers=4,
    image_resize_factor=1.5,
    data_output_formats=['json', 'csv', 'excel'],
    batch_max_workers=4,
    error_auto_recovery=True
)

# 创建流水线
pipeline = PDFProcessingPipeline(config)

# 处理PDF文件
result = pipeline.process_pdf_file("document.pdf", "output")

# 获取系统状态
status = pipeline.get_system_status()
print(f"系统状态: {status['status']}")

# 导出系统报告
pipeline.export_system_report("system_report.json")
```

## 配置选项

### ProcessingPipelineConfig
```python
config = ProcessingPipelineConfig(
    # PDF解析配置
    pdf_max_workers=4,
    pdf_enable_image_extraction=True,
    pdf_enable_vector_extraction=True,
    
    # 图像预处理配置
    image_resize_factor=1.5,
    image_denoise_method="bilateral",
    image_contrast_factor=1.3,
    image_enable_skew_correction=True,
    image_enable_line_enhancement=True,
    image_binarization_method="adaptive",
    
    # 数据转换配置
    data_output_formats=['json', 'csv', 'excel'],
    data_enable_visualization=True,
    
    # 批处理配置
    batch_max_workers=4,
    batch_max_queue_size=100,
    batch_enable_monitoring=True,
    batch_enable_caching=True,
    
    # 错误处理配置
    error_max_history=1000,
    error_monitoring_interval=30.0,
    error_auto_recovery=True
)
```

## 性能优化

### 内存优化
- **分块处理**: 大文件分块处理
- **缓存管理**: 智能缓存策略
- **垃圾回收**: 自动内存清理

### 并发优化
- **工作线程**: 根据CPU核心数自动调整
- **任务队列**: 优先级队列管理
- **负载均衡**: 智能任务分配

### 错误恢复
- **重试机制**: 指数退避重试
- **降级策略**: 服务降级和回退
- **健康检查**: 实时健康监控

## 监控和调试

### 日志系统
```python
import logging

# 配置日志级别
logging.basicConfig(level=logging.INFO)

# 获取模块日志器
logger = logging.getLogger(__name__)
logger.info("处理开始")
```

### 性能监控
```python
# 获取性能指标
metrics = processor.get_performance_metrics()
print(f"平均执行时间: {metrics['average_execution_time']:.2f}秒")
print(f"成功率: {metrics['completed_tasks']}/{metrics['total_tasks']}")

# 获取健康报告
health_report = monitor.get_health_report()
print(f"CPU使用率: {health_report['statistics']['cpu_usage']['avg']:.1f}%")
```

### 错误分析
```python
# 获取错误统计
error_stats = error_handler.get_error_statistics()
print(f"总错误数: {error_stats['total_errors']}")
print(f"错误类型: {error_stats['error_types']}")

# 获取恢复统计
recovery_stats = recovery_manager.get_recovery_statistics()
print(f"恢复成功率: {recovery_stats['recovery_success_rate']:.1f}%")
```

## 故障排除

### 常见问题

#### 1. OCR引擎初始化失败
```python
# 检查Tesseract安装
import pytesseract
print(pytesseract.get_tesseract_version())

# 检查PaddleOCR模型
from paddleocr import PaddleOCR
ocr = PaddleOCR(use_angle_cls=True, lang='en')
```

#### 2. 内存不足
```python
# 减少批处理大小
config = ProcessingPipelineConfig(
    batch_max_workers=2,
    batch_max_queue_size=50
)

# 启用内存监控
monitor = HealthMonitor(monitoring_interval=10.0)
```

#### 3. 处理速度慢
```python
# 增加工作线程数
config = ProcessingPipelineConfig(
    pdf_max_workers=8,
    batch_max_workers=8
)

# 启用缓存
config.batch_enable_caching = True
```

### 调试模式
```python
# 启用详细日志
logging.basicConfig(level=logging.DEBUG)

# 导出调试信息
pipeline.export_system_report("debug_report.json")
error_system.export_error_report("error_debug.json")
```

## 扩展和定制

### 添加新的OCR引擎
```python
class CustomOCR(OCREngine):
    def extract_text(self, image, bbox=None):
        # 实现自定义OCR逻辑
        pass

# 在流水线中使用
parser = PDFParser(ocr_engines=[CustomOCR()])
```

### 自定义恢复策略
```python
from error_handler import RecoveryStrategy

def custom_recovery(error_info):
    # 自定义恢复逻辑
    return True

strategy = RecoveryStrategy(
    strategy_id="custom_recovery",
    strategy_type="compensate",
    compensation_function=custom_recovery
)

recovery_manager.add_recovery_strategy(strategy)
```

### 添加新的数据格式
```python
def convert_to_custom_format(data, output_path, **kwargs):
    # 实现自定义格式转换
    pass

# 在DataStandardizer中注册
data_converter.convert_to_format = convert_to_custom_format
```

## 最佳实践

### 1. 配置文件管理
```python
# 使用配置文件
import yaml

with open('config.yaml', 'r') as f:
    config_dict = yaml.safe_load(f)

config = ProcessingPipelineConfig(**config_dict)
```

### 2. 错误处理
```python
# 使用装饰器自动处理错误
@with_error_recovery(recovery_system)
def process_document(pdf_path):
    return pipeline.process_pdf_file(pdf_path, "output")
```

### 3. 性能监控
```python
# 定期检查系统状态
def monitor_system():
    status = pipeline.get_system_status()
    if status['status'] != 'healthy':
        # 发送告警
        send_alert(status)

# 设置监控定时器
import threading
timer = threading.Timer(300, monitor_system)  # 5分钟检查一次
timer.start()
```

### 4. 资源管理
```python
# 使用上下文管理器
with PDFProcessingPipeline() as pipeline:
    result = pipeline.process_pdf_file("document.pdf", "output")
```

## 许可证

本项目采用MIT许可证。详见LICENSE文件。

## 贡献

欢迎贡献代码、报告问题或提出改进建议！

## 更新日志

### v1.0.0
- 初始版本发布
- 完整的PDF解析和图像预处理功能
- 批处理和并行处理支持
- 错误处理和异常恢复机制
- 数据格式转换和标准化
- 监控和调试功能

---

如有问题或需要支持，请查看文档或提交issue。
