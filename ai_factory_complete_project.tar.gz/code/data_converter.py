#!/usr/bin/env python3
"""
数据格式转换和标准化模块
提供多种数据格式的转换和标准化功能
"""

import os
import sys
import logging
import json
import csv
import xml.etree.ElementTree as ET
import traceback
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, asdict, field
from pathlib import Path
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor
import threading
import time
import hashlib
from datetime import datetime

import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFont
import pandas as pd
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill
import matplotlib.pyplot as plt
import seaborn as sns

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@dataclass
class StandardizedData:
    """标准化数据类"""
    document_id: str
    page_number: int
    timestamp: str
    processing_version: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self):
        return asdict(self)


@dataclass
class TextData:
    """文本数据类"""
    text_id: str
    content: str
    confidence: float
    bbox: Dict[str, float]  # x, y, width, height
    font_info: Dict[str, Any]  # font_name, font_size, font_style
    language: str = "unknown"
    ocr_engine: str = "unknown"
    position: Dict[str, float] = field(default_factory=dict)  # x, y坐标
    
    def to_dict(self):
        return asdict(self)


@dataclass
class VectorData:
    """矢量数据类"""
    vector_id: str
    element_type: str  # line, rectangle, circle, path, polygon
    points: List[Dict[str, float]]  # [{"x": 1.0, "y": 2.0}, ...]
    style: Dict[str, Any] = field(default_factory=dict)  # stroke_color, fill_color, stroke_width
    layer: str = "default"
    properties: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self):
        return asdict(self)


@dataclass
class ImageData:
    """图像数据类"""
    image_id: str
    bbox: Dict[str, float]  # x, y, width, height
    image_format: str = "png"
    resolution: Tuple[int, int] = (0, 0)
    quality: float = 1.0
    compression_type: str = "lossless"
    file_path: str = ""
    hash_value: str = ""
    
    def to_dict(self):
        return asdict(self)


@dataclass
class LayoutData:
    """布局数据类"""
    layout_id: str
    layout_type: str  # header, footer, body, sidebar, etc.
    bbox: Dict[str, float]
    confidence: float
    children: List[str] = field(default_factory=list)  # 子元素ID列表
    properties: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self):
        return asdict(self)


@dataclass
class DocumentStructure:
    """文档结构数据类"""
    document_id: str
    title: str = ""
    author: str = ""
    subject: str = ""
    creation_date: str = ""
    modification_date: str = ""
    pages: List[Dict[str, Any]] = field(default_factory=list)
    sections: List[Dict[str, Any]] = field(default_factory=list)
    table_of_contents: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self):
        return asdict(self)


class DataConversionError(Exception):
    """数据转换错误"""
    pass


class DataStandardizer:
    """数据标准化器"""
    
    def __init__(self, version: str = "1.0.0"):
        """
        初始化数据标准化器
        
        Args:
            version: 数据格式版本
        """
        self.version = version
        self.supported_formats = ['json', 'csv', 'xml', 'excel', 'parquet', 'hdf5']
        self.data_registry = {}  # 数据注册表
        logger.info(f"数据标准化器初始化完成，版本：{version}")
    
    def standardize_pdf_data(self, pdf_data: Dict[str, Any], 
                           document_id: Optional[str] = None) -> DocumentStructure:
        """
        标准化PDF解析数据
        
        Args:
            pdf_data: PDF解析数据
            document_id: 文档ID，如果为None则自动生成
            
        Returns:
            DocumentStructure: 标准化后的文档结构
        """
        try:
            if document_id is None:
                document_id = self._generate_document_id(pdf_data)
            
            # 创建文档结构
            doc_structure = DocumentStructure(
                document_id=document_id,
                title=pdf_data.get('metadata', {}).get('title', ''),
                author=pdf_data.get('metadata', {}).get('author', ''),
                subject=pdf_data.get('metadata', {}).get('subject', ''),
                creation_date=pdf_data.get('metadata', {}).get('creation_date', ''),
                modification_date=pdf_data.get('metadata', {}).get('modification_date', ''),
                metadata={
                    'source_file': pdf_data.get('file_path', ''),
                    'total_pages': len(pdf_data.get('pages', [])),
                    'processing_timestamp': datetime.now().isoformat(),
                    'version': self.version
                }
            )
            
            # 处理页面数据
            for page_data in pdf_data.get('pages', []):
                page_structure = self._standardize_page_data(page_data, document_id)
                doc_structure.pages.append(page_structure.to_dict())
            
            # 分析文档结构
            doc_structure = self._analyze_document_structure(doc_structure)
            
            logger.info(f"PDF数据标准化完成，文档ID：{document_id}")
            return doc_structure
            
        except Exception as e:
            logger.error(f"PDF数据标准化错误: {e}")
            logger.error(traceback.format_exc())
            raise DataConversionError(f"PDF数据标准化失败: {e}")
    
    def _standardize_page_data(self, page_data: Dict[str, Any], document_id: str) -> StandardizedData:
        """标准化页面数据"""
        try:
            # 标准化文本数据
            text_data_list = []
            for text_elem in page_data.get('text_elements', []):
                text_data = TextData(
                    text_id=self._generate_element_id(document_id, 'text', len(text_data_list)),
                    content=text_elem.get('text', ''),
                    confidence=text_elem.get('confidence', 0.0),
                    bbox=text_elem.get('bbox', {}),
                    font_info=text_elem.get('font_info', {}),
                    language=text_elem.get('language', 'unknown'),
                    ocr_engine=text_elem.get('ocr_engine', 'unknown'),
                    position={'x': text_elem.get('bbox', {}).get('x', 0), 
                             'y': text_elem.get('bbox', {}).get('y', 0)}
                )
                text_data_list.append(text_data)
            
            # 标准化矢量数据
            vector_data_list = []
            for vector_elem in page_data.get('vector_elements', []):
                vector_data = VectorData(
                    vector_id=self._generate_element_id(document_id, 'vector', len(vector_data_list)),
                    element_type=vector_elem.get('element_type', 'unknown'),
                    points=[{'x': p[0], 'y': p[1]} for p in vector_elem.get('points', [])],
                    style=vector_elem.get('style', {}),
                    layer=vector_elem.get('layer', 'default'),
                    properties=vector_elem.get('properties', {})
                )
                vector_data_list.append(vector_data)
            
            # 标准化图像数据
            image_data_list = []
            for image_elem in page_data.get('image_elements', []):
                image_data = ImageData(
                    image_id=self._generate_element_id(document_id, 'image', len(image_data_list)),
                    bbox=image_elem.get('bbox', {}),
                    image_format=image_elem.get('image_format', 'png'),
                    resolution=tuple(image_elem.get('resolution', [0, 0])),
                    quality=image_elem.get('quality', 1.0),
                    compression_type=image_elem.get('compression_type', 'lossless'),
                    file_path=image_elem.get('file_path', ''),
                    hash_value=self._calculate_hash(image_elem.get('image_data', b''))
                )
                image_data_list.append(image_data)
            
            # 创建标准化数据
            standardized_data = StandardizedData(
                document_id=document_id,
                page_number=page_data.get('page_number', 0),
                timestamp=datetime.now().isoformat(),
                processing_version=self.version,
                metadata={
                    'width': page_data.get('width', 0),
                    'height': page_data.get('height', 0),
                    'text_count': len(text_data_list),
                    'vector_count': len(vector_data_list),
                    'image_count': len(image_data_list),
                    'text_data': [td.to_dict() for td in text_data_list],
                    'vector_data': [vd.to_dict() for vd in vector_data_list],
                    'image_data': [id.to_dict() for id in image_data_list]
                }
            )
            
            return standardized_data
            
        except Exception as e:
            logger.error(f"页面数据标准化错误: {e}")
            raise DataConversionError(f"页面数据标准化失败: {e}")
    
    def _analyze_document_structure(self, doc_structure: DocumentStructure) -> DocumentStructure:
        """分析文档结构"""
        try:
            # 分析页面布局
            for page in doc_structure.pages:
                page_metadata = page.get('metadata', {})
                
                # 检测标题
                text_data = page_metadata.get('text_data', [])
                title_candidates = [td for td in text_data if self._is_title_candidate(td)]
                if title_candidates:
                    page['layout_data'] = self._create_layout_data('title', title_candidates[0]['bbox'])
                
                # 检测页眉页脚
                header_footer_regions = self._detect_header_footer_regions(page_metadata)
                if header_footer_regions:
                    page['layout_data'] = header_footer_regions
            
            # 生成目录
            doc_structure.table_of_contents = self._generate_table_of_contents(doc_structure)
            
            logger.info("文档结构分析完成")
            return doc_structure
            
        except Exception as e:
            logger.error(f"文档结构分析错误: {e}")
            return doc_structure
    
    def _is_title_candidate(self, text_data: Dict[str, Any]) -> bool:
        """判断是否为标题候选"""
        try:
            font_info = text_data.get('font_info', {})
            font_size = font_info.get('font_size', 0)
            confidence = text_data.get('confidence', 0.0)
            content = text_data.get('content', '')
            
            # 标题特征：大字体、高置信度、短文本
            return (font_size > 16 and confidence > 0.8 and len(content) < 100)
        except:
            return False
    
    def _detect_header_footer_regions(self, page_metadata: Dict[str, Any]) -> Dict[str, Any]:
        """检测页眉页脚区域"""
        try:
            layout_data = {}
            text_data = page_metadata.get('text_data', [])
            page_height = page_metadata.get('height', 0)
            
            # 页眉：页面顶部区域的文本
            header_texts = [td for td in text_data if td.get('bbox', {}).get('y', 0) < page_height * 0.2]
            if header_texts:
                layout_data['header'] = {
                    'bbox': {'x': 0, 'y': 0, 'width': page_metadata.get('width', 0), 'height': page_height * 0.2},
                    'confidence': 0.8,
                    'text_count': len(header_texts)
                }
            
            # 页脚：页面底部区域的文本
            footer_texts = [td for td in text_data if td.get('bbox', {}).get('y', 0) > page_height * 0.8]
            if footer_texts:
                layout_data['footer'] = {
                    'bbox': {'x': 0, 'y': page_height * 0.8, 'width': page_metadata.get('width', 0), 'height': page_height * 0.2},
                    'confidence': 0.8,
                    'text_count': len(footer_texts)
                }
            
            return layout_data
            
        except Exception as e:
            logger.warning(f"页眉页脚检测错误: {e}")
            return {}
    
    def _create_layout_data(self, layout_type: str, bbox: Dict[str, float]) -> LayoutData:
        """创建布局数据"""
        return LayoutData(
            layout_id=self._generate_element_id('layout', layout_type, 0),
            layout_type=layout_type,
            bbox=bbox,
            confidence=0.8
        )
    
    def _generate_table_of_contents(self, doc_structure: DocumentStructure) -> List[Dict[str, Any]]:
        """生成目录"""
        try:
            toc = []
            page_titles = []
            
            for page in doc_structure.pages:
                page_metadata = page.get('metadata', {})
                text_data = page_metadata.get('text_data', [])
                
                # 查找页面标题
                title_candidates = [td for td in text_data if self._is_title_candidate(td)]
                if title_candidates:
                    title = title_candidates[0]
                    toc.append({
                        'title': title.get('content', ''),
                        'page_number': page.get('page_number', 0) + 1,
                        'confidence': title.get('confidence', 0.0)
                    })
            
            return toc
            
        except Exception as e:
            logger.warning(f"目录生成错误: {e}")
            return []
    
    def convert_to_format(self, data: Any, target_format: str, 
                         output_path: Union[str, Path],
                         **kwargs) -> bool:
        """
        转换数据格式
        
        Args:
            data: 要转换的数据
            target_format: 目标格式
            output_path: 输出路径
            **kwargs: 额外参数
            
        Returns:
            bool: 是否转换成功
        """
        try:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            
            if target_format == 'json':
                return self._convert_to_json(data, output_path, **kwargs)
            elif target_format == 'csv':
                return self._convert_to_csv(data, output_path, **kwargs)
            elif target_format == 'xml':
                return self._convert_to_xml(data, output_path, **kwargs)
            elif target_format == 'excel':
                return self._convert_to_excel(data, output_path, **kwargs)
            elif target_format == 'parquet':
                return self._convert_to_parquet(data, output_path, **kwargs)
            elif target_format == 'hdf5':
                return self._convert_to_hdf5(data, output_path, **kwargs)
            else:
                raise ValueError(f"不支持的格式: {target_format}")
                
        except Exception as e:
            logger.error(f"数据格式转换错误: {e}")
            logger.error(traceback.format_exc())
            return False
    
    def _convert_to_json(self, data: Any, output_path: Path, **kwargs) -> bool:
        """转换为JSON格式"""
        try:
            indent = kwargs.get('indent', 2)
            ensure_ascii = kwargs.get('ensure_ascii', False)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=ensure_ascii, indent=indent, default=str)
            
            logger.info(f"数据已转换为JSON格式: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"JSON转换错误: {e}")
            return False
    
    def _convert_to_csv(self, data: Any, output_path: Path, **kwargs) -> bool:
        """转换为CSV格式"""
        try:
            if isinstance(data, dict):
                # 如果是字典，转换为DataFrame
                df = pd.DataFrame([data])
            elif isinstance(data, list):
                # 如果是列表，转换为DataFrame
                df = pd.DataFrame(data)
            else:
                # 其他类型，转换为单行DataFrame
                df = pd.DataFrame([data])
            
            df.to_csv(output_path, index=False, encoding='utf-8-sig')
            logger.info(f"数据已转换为CSV格式: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"CSV转换错误: {e}")
            return False
    
    def _convert_to_xml(self, data: Any, output_path: Path, **kwargs) -> bool:
        """转换为XML格式"""
        try:
            def dict_to_xml(data_dict, root_name='root'):
                root = ET.Element(root_name)
                
                def add_elements(parent, data):
                    if isinstance(data, dict):
                        for key, value in data.items():
                            if isinstance(value, (dict, list)):
                                child = ET.SubElement(parent, str(key))
                                add_elements(child, value)
                            else:
                                child = ET.SubElement(parent, str(key))
                                child.text = str(value)
                    elif isinstance(data, list):
                        for i, item in enumerate(data):
                            child = ET.SubElement(parent, 'item')
                            if isinstance(item, dict):
                                add_elements(child, item)
                            else:
                                child.text = str(item)
                    else:
                        parent.text = str(data)
                
                add_elements(root, data_dict)
                return root
            
            root = dict_to_xml(data)
            tree = ET.ElementTree(root)
            tree.write(output_path, encoding='utf-8', xml_declaration=True)
            
            logger.info(f"数据已转换为XML格式: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"XML转换错误: {e}")
            return False
    
    def _convert_to_excel(self, data: Any, output_path: Path, **kwargs) -> bool:
        """转换为Excel格式"""
        try:
            if isinstance(data, dict):
                df = pd.DataFrame([data])
            elif isinstance(data, list):
                df = pd.DataFrame(data)
            else:
                df = pd.DataFrame([data])
            
            # 创建Excel工作簿
            with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Data', index=False)
                
                # 获取工作表
                worksheet = writer.sheets['Data']
                
                # 设置样式
                header_font = Font(bold=True)
                header_fill = PatternFill(start_color='366092', end_color='366092', fill_type='solid')
                
                for cell in worksheet[1]:
                    cell.font = Font(bold=True, color='FFFFFF')
                    cell.fill = header_fill
                    cell.alignment = Alignment(horizontal='center')
                
                # 自动调整列宽
                for column in worksheet.columns:
                    max_length = 0
                    column_letter = column[0].column_letter
                    for cell in column:
                        try:
                            if len(str(cell.value)) > max_length:
                                max_length = len(str(cell.value))
                        except:
                            pass
                    adjusted_width = min(max_length + 2, 50)
                    worksheet.column_dimensions[column_letter].width = adjusted_width
            
            logger.info(f"数据已转换为Excel格式: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Excel转换错误: {e}")
            return False
    
    def _convert_to_parquet(self, data: Any, output_path: Path, **kwargs) -> bool:
        """转换为Parquet格式"""
        try:
            if isinstance(data, dict):
                df = pd.DataFrame([data])
            elif isinstance(data, list):
                df = pd.DataFrame(data)
            else:
                df = pd.DataFrame([data])
            
            df.to_parquet(output_path, index=False)
            logger.info(f"数据已转换为Parquet格式: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Parquet转换错误: {e}")
            return False
    
    def _convert_to_hdf5(self, data: Any, output_path: Path, **kwargs) -> bool:
        """转换为HDF5格式"""
        try:
            if isinstance(data, dict):
                df = pd.DataFrame([data])
            elif isinstance(data, list):
                df = pd.DataFrame(data)
            else:
                df = pd.DataFrame([data])
            
            df.to_hdf(output_path, key='data', mode='w', format='table')
            logger.info(f"数据已转换为HDF5格式: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"HDF5转换错误: {e}")
            return False
    
    def validate_data(self, data: Any, schema: Optional[Dict[str, Any]] = None) -> Tuple[bool, List[str]]:
        """
        验证数据格式
        
        Args:
            data: 要验证的数据
            schema: 数据模式（可选）
            
        Returns:
            Tuple[bool, List[str]]: 是否有效，错误信息列表
        """
        errors = []
        
        try:
            # 基本验证
            if data is None:
                errors.append("数据为空")
                return False, errors
            
            # 如果提供了模式，进行模式验证
            if schema:
                errors.extend(self._validate_against_schema(data, schema))
            
            # 特定类型验证
            if isinstance(data, dict):
                errors.extend(self._validate_dict_data(data))
            elif isinstance(data, list):
                errors.extend(self._validate_list_data(data))
            
            return len(errors) == 0, errors
            
        except Exception as e:
            errors.append(f"验证过程错误: {e}")
            return False, errors
    
    def _validate_against_schema(self, data: Any, schema: Dict[str, Any]) -> List[str]:
        """根据模式验证数据"""
        errors = []
        
        try:
            data_type = schema.get('type')
            
            if data_type == 'object':
                if not isinstance(data, dict):
                    errors.append(f"期望对象类型，实际为 {type(data)}")
                else:
                    required_fields = schema.get('required', [])
                    for field in required_fields:
                        if field not in data:
                            errors.append(f"缺少必需字段: {field}")
            
            elif data_type == 'array':
                if not isinstance(data, list):
                    errors.append(f"期望数组类型，实际为 {type(data)}")
            
            elif data_type == 'string':
                if not isinstance(data, str):
                    errors.append(f"期望字符串类型，实际为 {type(data)}")
            
            elif data_type == 'number':
                if not isinstance(data, (int, float)):
                    errors.append(f"期望数字类型，实际为 {type(data)}")
            
        except Exception as e:
            errors.append(f"模式验证错误: {e}")
        
        return errors
    
    def _validate_dict_data(self, data: Dict[str, Any]) -> List[str]:
        """验证字典数据"""
        errors = []
        
        try:
            # 检查是否包含基本字段
            required_fields = ['document_id', 'page_number', 'timestamp']
            for field in required_fields:
                if field not in data:
                    errors.append(f"缺少必需字段: {field}")
            
            # 检查数据类型
            if 'document_id' in data and not isinstance(data['document_id'], str):
                errors.append("document_id 应该是字符串类型")
            
            if 'page_number' in data and not isinstance(data['page_number'], int):
                errors.append("page_number 应该是整数类型")
            
            if 'timestamp' in data and not isinstance(data['timestamp'], str):
                errors.append("timestamp 应该是字符串类型")
            
        except Exception as e:
            errors.append(f"字典数据验证错误: {e}")
        
        return errors
    
    def _validate_list_data(self, data: List[Any]) -> List[str]:
        """验证列表数据"""
        errors = []
        
        try:
            if not data:
                errors.append("列表为空")
                return errors
            
            # 检查列表中元素的类型一致性
            first_type = type(data[0])
            for i, item in enumerate(data[1:], 1):
                if type(item) != first_type:
                    errors.append(f"列表元素类型不一致: 索引 {i}")
                    break
            
        except Exception as e:
            errors.append(f"列表数据验证错误: {e}")
        
        return errors
    
    def _generate_document_id(self, pdf_data: Dict[str, Any]) -> str:
        """生成文档ID"""
        try:
            # 基于文件路径或内容生成哈希
            file_path = pdf_data.get('file_path', '')
            if file_path:
                hash_object = hashlib.md5(file_path.encode())
                return f"doc_{hash_object.hexdigest()[:8]}"
            else:
                # 基于内容生成
                content_str = json.dumps(pdf_data, sort_keys=True)
                hash_object = hashlib.md5(content_str.encode())
                return f"doc_{hash_object.hexdigest()[:8]}"
        except:
            return f"doc_{int(time.time())}"
    
    def _generate_element_id(self, document_id: str, element_type: str, index: int) -> str:
        """生成元素ID"""
        return f"{document_id}_{element_type}_{index:04d}"
    
    def _calculate_hash(self, data: bytes) -> str:
        """计算数据哈希"""
        try:
            return hashlib.md5(data).hexdigest()
        except:
            return ""


class BatchDataProcessor:
    """批处理数据处理器"""
    
    def __init__(self, standardizer: DataStandardizer, max_workers: int = 4):
        """
        初始化批处理器
        
        Args:
            standardizer: 数据标准化器
            max_workers: 最大工作线程数
        """
        self.standardizer = standardizer
        self.max_workers = max_workers
        logger.info(f"批处理数据处理器初始化完成，最大工作线程数：{max_workers}")
    
    def process_batch(self, data_list: List[Any], 
                     output_dir: Union[str, Path],
                     formats: List[str] = None,
                     **kwargs) -> Dict[str, bool]:
        """
        批处理数据
        
        Args:
            data_list: 数据列表
            output_dir: 输出目录
            formats: 输出格式列表
            **kwargs: 额外参数
            
        Returns:
            Dict[str, bool]: 处理结果
        """
        if not data_list:
            return {}
        
        if formats is None:
            formats = ['json', 'csv']
        
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        results = {}
        
        try:
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = []
                
                for i, data in enumerate(data_list):
                    for format_type in formats:
                        future = executor.submit(self._process_single_data, data, output_dir, format_type, i, **kwargs)
                        futures.append((future, format_type, i))
                
                # 收集结果
                for future, format_type, index in futures:
                    try:
                        success = future.result()
                        key = f"{format_type}_page_{index}"
                        results[key] = success
                    except Exception as e:
                        logger.error(f"数据处理错误 {format_type} page {index}: {e}")
                        results[f"{format_type}_page_{index}"] = False
            
            logger.info(f"批处理完成，处理了 {len(results)} 个文件")
            return results
            
        except Exception as e:
            logger.error(f"批处理错误: {e}")
            logger.error(traceback.format_exc())
            return results
    
    def _process_single_data(self, data: Any, output_dir: Path, format_type: str, index: int, **kwargs) -> bool:
        """处理单条数据"""
        try:
            output_file = output_dir / f"page_{index:04d}.{format_type}"
            return self.standardizer.convert_to_format(data, format_type, output_file, **kwargs)
        except Exception as e:
            logger.error(f"单条数据处理错误: {e}")
            return False
    
    def process_directory(self, input_dir: Union[str, Path],
                         output_dir: Union[str, Path],
                         file_patterns: List[str] = None,
                         formats: List[str] = None) -> Dict[str, bool]:
        """
        处理目录中的所有文件
        
        Args:
            input_dir: 输入目录
            output_dir: 输出目录
            file_patterns: 文件模式列表
            formats: 输出格式列表
            
        Returns:
            Dict[str, bool]: 处理结果
        """
        input_dir = Path(input_dir)
        output_dir = Path(output_dir)
        
        if file_patterns is None:
            file_patterns = ['*.json', '*.csv', '*.xml']
        
        if formats is None:
            formats = ['json', 'csv', 'excel']
        
        # 收集文件
        data_files = []
        for pattern in file_patterns:
            data_files.extend(input_dir.glob(pattern))
        
        if not data_files:
            logger.warning(f"在目录 {input_dir} 中未找到匹配的文件")
            return {}
        
        logger.info(f"找到 {len(data_files)} 个数据文件")
        
        # 加载数据
        data_list = []
        valid_files = []
        
        for data_file in data_files:
            try:
                with open(data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    data_list.append(data)
                    valid_files.append(data_file)
            except Exception as e:
                logger.error(f"读取数据文件错误 {data_file}: {e}")
        
        if not data_list:
            logger.error("没有有效的数据文件")
            return {}
        
        # 批处理
        return self.process_batch(data_list, output_dir, formats)


class DataVisualizer:
    """数据可视化器"""
    
    @staticmethod
    def setup_matplotlib_for_plotting():
        """
        Setup matplotlib and seaborn for plotting with proper configuration.
        Call this function before creating any plots to ensure proper rendering.
        """
        import warnings
        import matplotlib.pyplot as plt
        import seaborn as sns

        # Ensure warnings are printed
        warnings.filterwarnings('default')  # Show all warnings

        # Configure matplotlib for non-interactive mode
        plt.switch_backend("Agg")

        # Set chart style
        plt.style.use("seaborn-v0_8")
        sns.set_palette("husl")

        # Configure platform-appropriate fonts for cross-platform compatibility
        # Must be set after style.use, otherwise will be overridden by style configuration
        plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC", "WenQuanYi Zen Hei", "PingFang SC", "Arial Unicode MS", "Hiragino Sans GB"]
        plt.rcParams["axes.unicode_minus"] = False
    
    @staticmethod
    def visualize_document_structure(doc_structure: DocumentStructure, 
                                   output_path: Union[str, Path]) -> bool:
        """
        可视化文档结构
        
        Args:
            doc_structure: 文档结构
            output_path: 输出路径
            
        Returns:
            bool: 是否成功
        """
        try:
            DataVisualizer.setup_matplotlib_for_plotting()
            
            output_path = Path(output_path)
            
            # 创建图表
            fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 12))
            fig.suptitle(f'文档结构分析: {doc_structure.document_id}', fontsize=16)
            
            # 1. 页面文本分布
            page_text_counts = [len(page.get('metadata', {}).get('text_data', [])) for page in doc_structure.pages]
            ax1.bar(range(len(page_text_counts)), page_text_counts, color='skyblue')
            ax1.set_title('每页文本元素数量')
            ax1.set_xlabel('页面编号')
            ax1.set_ylabel('文本元素数量')
            
            # 2. 页面矢量元素分布
            page_vector_counts = [len(page.get('metadata', {}).get('vector_data', [])) for page in doc_structure.pages]
            ax2.bar(range(len(page_vector_counts)), page_vector_counts, color='lightgreen')
            ax2.set_title('每页矢量元素数量')
            ax2.set_xlabel('页面编号')
            ax2.set_ylabel('矢量元素数量')
            
            # 3. 页面图像元素分布
            page_image_counts = [len(page.get('metadata', {}).get('image_data', [])) for page in doc_structure.pages]
            ax3.bar(range(len(page_image_counts)), page_image_counts, color='lightcoral')
            ax3.set_title('每页图像元素数量')
            ax3.set_xlabel('页面编号')
            ax3.set_ylabel('图像元素数量')
            
            # 4. 文档元数据
            metadata = doc_structure.metadata
            ax4.axis('off')
            metadata_text = f"""
文档信息:
- 标题: {doc_structure.title or '未知'}
- 作者: {doc_structure.author or '未知'}
- 总页数: {len(doc_structure.pages)}
- 总文本元素: {sum(page_text_counts)}
- 总矢量元素: {sum(page_vector_counts)}
- 总图像元素: {sum(page_image_counts)}
- 处理时间: {metadata.get('processing_timestamp', '未知')}
- 版本: {metadata.get('version', '未知')}
            """
            ax4.text(0.1, 0.9, metadata_text, transform=ax4.transAxes, fontsize=10,
                    verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
            
            plt.tight_layout()
            plt.savefig(output_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info(f"文档结构可视化已保存: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"文档结构可视化错误: {e}")
            return False
    
    @staticmethod
    def create_data_quality_report(data: Any, output_path: Union[str, Path]) -> bool:
        """
        创建数据质量报告
        
        Args:
            data: 数据
            output_path: 输出路径
            
        Returns:
            bool: 是否成功
        """
        try:
            DataVisualizer.setup_matplotlib_for_plotting()
            
            output_path = Path(output_path)
            
            fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 12))
            fig.suptitle('数据质量报告', fontsize=16)
            
            # 1. 数据类型分布
            if isinstance(data, dict):
                data_types = {}
                for key, value in data.items():
                    data_types[type(value).__name__] = data_types.get(type(value).__name__, 0) + 1
                
                ax1.pie(data_types.values(), labels=data_types.keys(), autopct='%1.1f%%')
                ax1.set_title('数据类型分布')
            
            # 2. 数据完整性
            completeness = []
            labels = []
            if isinstance(data, dict):
                for key, value in data.items():
                    if value is not None:
                        completeness.append(100)
                    else:
                        completeness.append(0)
                    labels.append(key[:10])  # 截断长标签
            
            if completeness:
                ax2.barh(labels, completeness, color='lightblue')
                ax2.set_title('数据完整性')
                ax2.set_xlabel('完整性 (%)')
            
            # 3. 数据长度分布（如果是列表）
            if isinstance(data, list):
                lengths = [len(str(item)) for item in data if isinstance(item, (str, list, dict))]
                if lengths:
                    ax3.hist(lengths, bins=20, color='lightgreen', alpha=0.7)
                    ax3.set_title('数据长度分布')
                    ax3.set_xlabel('长度')
                    ax3.set_ylabel('频次')
            
            # 4. 数据质量指标
            ax4.axis('off')
            quality_metrics = DataVisualizer._calculate_quality_metrics(data)
            metrics_text = "\n".join([f"{k}: {v}" for k, v in quality_metrics.items()])
            ax4.text(0.1, 0.9, f"数据质量指标:\n{metrics_text}", transform=ax4.transAxes, fontsize=12,
                    verticalalignment='top', bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.5))
            
            plt.tight_layout()
            plt.savefig(output_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info(f"数据质量报告已保存: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"数据质量报告错误: {e}")
            return False
    
    @staticmethod
    def _calculate_quality_metrics(data: Any) -> Dict[str, Any]:
        """计算数据质量指标"""
        try:
            metrics = {}
            
            if isinstance(data, dict):
                total_fields = len(data)
                non_null_fields = sum(1 for v in data.values() if v is not None)
                metrics['完整性'] = f"{(non_null_fields/total_fields*100):.1f}%" if total_fields > 0 else "0%"
                metrics['字段总数'] = total_fields
                metrics['非空字段数'] = non_null_fields
                
            elif isinstance(data, list):
                total_items = len(data)
                non_null_items = sum(1 for item in data if item is not None)
                metrics['完整性'] = f"{(non_null_items/total_items*100):.1f}%" if total_items > 0 else "0%"
                metrics['元素总数'] = total_items
                metrics['非空元素数'] = non_null_items
                
                # 计算平均长度
                if data:
                    avg_length = np.mean([len(str(item)) for item in data if item is not None])
                    metrics['平均长度'] = f"{avg_length:.1f}"
            
            return metrics
            
        except Exception as e:
            logger.warning(f"质量指标计算错误: {e}")
            return {}


# 使用示例
if __name__ == "__main__":
    # 创建数据标准化器
    standardizer = DataStandardizer(version="1.0.0")
    
    # 示例PDF数据
    pdf_data = {
        'file_path': 'example.pdf',
        'pages': [
            {
                'page_number': 0,
                'width': 800,
                'height': 600,
                'text_elements': [
                    {
                        'text': 'Sample Title',
                        'confidence': 0.95,
                        'bbox': {'x': 100, 'y': 50, 'width': 200, 'height': 30},
                        'font_info': {'font_size': 18, 'font_name': 'Arial'},
                        'ocr_engine': 'tesseract'
                    }
                ],
                'vector_elements': [
                    {
                        'element_type': 'line',
                        'points': [(100, 100), (700, 100)],
                        'style': {'stroke_color': [0, 0, 0], 'stroke_width': 2}
                    }
                ],
                'image_elements': [
                    {
                        'bbox': {'x': 200, 'y': 200, 'width': 400, 'height': 300},
                        'image_format': 'png',
                        'resolution': [800, 600]
                    }
                ]
            }
        ]
    }
    
    # 标准化数据
    try:
        doc_structure = standardizer.standardize_pdf_data(pdf_data, "example_doc_001")
        
        # 转换为多种格式
        output_dir = Path("output")
        output_dir.mkdir(exist_ok=True)
        
        # JSON格式
        standardizer.convert_to_format(doc_structure.to_dict(), 'json', 
                                     output_dir / "document_structure.json", indent=2)
        
        # CSV格式
        standardizer.convert_to_format(doc_structure.to_dict(), 'csv', 
                                     output_dir / "document_structure.csv")
        
        # Excel格式
        standardizer.convert_to_format(doc_structure.to_dict(), 'excel', 
                                     output_dir / "document_structure.xlsx")
        
        # XML格式
        standardizer.convert_to_format(doc_structure.to_dict(), 'xml', 
                                     output_dir / "document_structure.xml")
        
        # 验证数据
        is_valid, errors = standardizer.validate_data(doc_structure.to_dict())
        print(f"数据验证结果: {'有效' if is_valid else '无效'}")
        if errors:
            print(f"错误信息: {errors}")
        
        # 创建可视化
        DataVisualizer.visualize_document_structure(doc_structure, 
                                                   output_dir / "document_structure.png")
        
        DataVisualizer.create_data_quality_report(doc_structure.to_dict(), 
                                                 output_dir / "data_quality.png")
        
        print("数据转换和标准化完成")
        
    except Exception as e:
        logger.error(f"示例执行错误: {e}")
        logger.error(traceback.format_exc())
