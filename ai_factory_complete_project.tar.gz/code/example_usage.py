#!/usr/bin/env python3
"""
PDF解析和图像预处理模块使用示例
演示各种功能的使用方法
"""

import os
import sys
import time
import logging
from pathlib import Path
import numpy as np
import cv2

# 导入模块
from pdf_processing_pipeline import (
    PDFProcessingPipeline, 
    ProcessingPipelineConfig,
    quick_process_pdf,
    batch_process_pdfs
)
from pdf_parser import PDFParser, ProcessingConfig
from image_preprocessor import BatchImageProcessor, ProcessingConfig as ImageConfig
from data_converter import DataStandardizer, DataVisualizer
from batch_processor import SmartBatchProcessor, BatchConfig, Task
from error_handler import ErrorRecoverySystem, with_error_recovery

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def create_sample_pdf():
    """创建示例PDF文件用于测试"""
    try:
        # 创建一个简单的示例图像作为PDF内容
        img = np.ones((800, 600, 3), dtype=np.uint8) * 255
        
        # 添加一些文本
        cv2.putText(img, "Sample Document", (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 0), 3)
        cv2.putText(img, "Page 1 of 1", (50, 200), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
        
        # 添加一些图形
        cv2.rectangle(img, (100, 250), (500, 400), (0, 0, 0), 2)
        cv2.circle(img, (300, 325), 50, (0, 0, 0), 2)
        
        # 添加一些线条
        cv2.line(img, (100, 450), (500, 450), (0, 0, 0), 2)
        
        # 保存为图像文件（模拟PDF内容）
        cv2.imwrite("sample_document.png", img)
        logger.info("示例文档已创建: sample_document.png")
        
        return "sample_document.png"
        
    except Exception as e:
        logger.error(f"创建示例PDF失败: {e}")
        return None


def example_1_basic_usage():
    """示例1: 基本使用"""
    logger.info("=== 示例1: 基本使用 ===")
    
    try:
        # 创建示例文档
        sample_file = create_sample_pdf()
        if not sample_file:
            logger.warning("跳过示例1：无法创建示例文档")
            return
        
        # 使用快速处理函数
        result = quick_process_pdf(
            pdf_path=sample_file,
            output_dir="output_example1"
        )
        
        print(f"处理结果: {'成功' if result.success else '失败'}")
        print(f"处理时间: {result.processing_time:.2f}秒")
        print(f"输出文件: {result.output_files}")
        
        if result.success:
            print("✅ 基本使用示例完成")
        else:
            print("❌ 基本使用示例失败")
            
    except Exception as e:
        logger.error(f"示例1执行错误: {e}")


def example_2_custom_config():
    """示例2: 自定义配置"""
    logger.info("=== 示例2: 自定义配置 ===")
    
    try:
        # 创建自定义配置
        config = ProcessingPipelineConfig(
            pdf_max_workers=2,
            image_resize_factor=2.0,
            image_denoise_method="gaussian",
            image_contrast_factor=1.5,
            data_output_formats=['json', 'csv'],
            batch_max_workers=2,
            error_auto_recovery=True
        )
        
        # 创建示例文档
        sample_file = create_sample_pdf()
        if not sample_file:
            logger.warning("跳过示例2：无法创建示例文档")
            return
        
        # 创建流水线
        pipeline = PDFProcessingPipeline(config)
        
        # 处理文档
        result = pipeline.process_pdf_file(
            pdf_path=sample_file,
            output_dir="output_example2"
        )
        
        print(f"处理结果: {'成功' if result.success else '失败'}")
        print(f"处理时间: {result.processing_time:.2f}秒")
        print(f"配置使用: 自定义配置")
        
        if result.success:
            print("✅ 自定义配置示例完成")
        else:
            print("❌ 自定义配置示例失败")
            
    except Exception as e:
        logger.error(f"示例2执行错误: {e}")


def example_3_batch_processing():
    """示例3: 批量处理"""
    logger.info("=== 示例3: 批量处理 ===")
    
    try:
        # 创建多个示例文档
        sample_files = []
        for i in range(3):
            img = np.ones((400, 300, 3), dtype=np.uint8) * 255
            cv2.putText(img, f"Document {i+1}", (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
            cv2.putText(img, f"Page 1 of 1", (20, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 1)
            
            filename = f"sample_document_{i+1}.png"
            cv2.imwrite(filename, img)
            sample_files.append(filename)
        
        # 批量处理
        results = batch_process_pdfs(
            pdf_paths=sample_files,
            output_dir="output_example3"
        )
        
        successful = sum(1 for r in results if r.success)
        print(f"批量处理结果: {successful}/{len(results)} 成功")
        
        for i, result in enumerate(results):
            print(f"  文档 {i+1}: {'成功' if result.success else '失败'} "
                  f"({result.processing_time:.2f}秒)")
        
        if successful > 0:
            print("✅ 批量处理示例完成")
        else:
            print("❌ 批量处理示例失败")
            
    except Exception as e:
        logger.error(f"示例3执行错误: {e}")


def example_4_error_handling():
    """示例4: 错误处理"""
    logger.info("=== 示例4: 错误处理 ===")
    
    try:
        # 创建错误恢复系统
        recovery_system = ErrorRecoverySystem()
        
        # 使用装饰器
        @with_error_recovery(recovery_system)
        def risky_operation(data):
            # 模拟可能失败的操作
            import random
            if random.random() < 0.7:  # 70%概率失败
                raise ValueError("模拟操作失败")
            return f"操作成功处理: {data}"
        
        # 执行多个操作
        test_data = ["数据1", "数据2", "数据3", "数据4", "数据5"]
        results = []
        
        for data in test_data:
            result, success = recovery_system.handle_operation(risky_operation, data)
            results.append(success)
            print(f"操作 '{data}': {'成功' if success else '失败'}")
        
        successful = sum(results)
        print(f"错误处理结果: {successful}/{len(results)} 成功")
        
        # 获取系统状态
        status = recovery_system.get_system_status()
        print(f"系统状态: {status['system_status']}")
        
        if successful > 0:
            print("✅ 错误处理示例完成")
        else:
            print("❌ 错误处理示例失败")
            
    except Exception as e:
        logger.error(f"示例4执行错误: {e}")


def example_5_individual_components():
    """示例5: 独立组件使用"""
    logger.info("=== 示例5: 独立组件使用 ===")
    
    try:
        # 1. 图像预处理器示例
        logger.info("  5.1: 图像预处理器")
        
        # 创建示例图像
        img = np.random.randint(0, 255, (400, 300, 3), dtype=np.uint8)
        
        # 创建预处理器
        image_config = ImageConfig(
            resize_factor=1.5,
            denoise_method="bilateral",
            contrast_factor=1.3,
            enable_skew_correction=True
        )
        
        preprocessor = BatchImageProcessor(image_config)
        result = preprocessor.preprocessor.preprocess_image(img, image_config)
        
        print(f"    图像处理步骤: {len(result.processing_steps)}")
        print(f"    处理时间: {result.processing_time:.2f}秒")
        
        # 2. 数据转换器示例
        logger.info("  5.2: 数据转换器")
        
        # 创建示例数据
        sample_data = {
            'document_id': 'example_001',
            'title': '示例文档',
            'pages': [
                {
                    'page_number': 1,
                    'text_elements': [
                        {'text': '示例文本', 'confidence': 0.95}
                    ]
                }
            ]
        }
        
        converter = DataStandardizer()
        
        # 转换为不同格式
        formats = ['json', 'csv', 'xml']
        for fmt in formats:
            output_file = f"output_example5/data.{fmt}"
            success = converter.convert_to_format(sample_data, fmt, output_file)
            print(f"    {fmt.upper()}转换: {'成功' if success else '失败'}")
        
        # 3. 批处理器示例
        logger.info("  5.3: 批处理器")
        
        # 创建任务
        tasks = []
        for i in range(3):
            task = Task(
                task_id=f"task_{i+1}",
                task_type="data_convert",
                input_data={'data': f'test_data_{i+1}'},
                priority=1,
                metadata={'output_format': 'json'}
            )
            tasks.append(task)
        
        batch_config = BatchConfig(max_workers=2, max_queue_size=10)
        batch_processor = SmartBatchProcessor(batch_config)
        
        # 添加任务
        added_count = batch_processor.batch_processor.add_batch_tasks(tasks)
        print(f"    任务添加: {added_count}/{len(tasks)}")
        
        print("✅ 独立组件示例完成")
        
    except Exception as e:
        logger.error(f"示例5执行错误: {e}")


def example_6_performance_monitoring():
    """示例6: 性能监控"""
    logger.info("=== 示例6: 性能监控 ===")
    
    try:
        # 创建示例文档
        sample_file = create_sample_pdf()
        if not sample_file:
            logger.warning("跳过示例6：无法创建示例文档")
            return
        
        # 创建配置
        config = ProcessingPipelineConfig(
            pdf_max_workers=4,
            batch_max_workers=4,
            batch_enable_monitoring=True,
            error_monitoring_interval=5.0
        )
        
        # 创建流水线
        pipeline = PDFProcessingPipeline(config)
        
        # 开始监控
        pipeline.error_system.start_monitoring()
        
        # 处理文档
        result = pipeline.process_pdf_file(
            pdf_path=sample_file,
            output_dir="output_example6"
        )
        
        # 获取性能指标
        performance_metrics = pipeline.batch_processor.get_performance_metrics()
        print(f"性能指标:")
        print(f"  总任务数: {performance_metrics['total_tasks']}")
        print(f"  完成任务: {performance_metrics['completed_tasks']}")
        print(f"  失败任务: {performance_metrics['failed_tasks']}")
        print(f"  平均执行时间: {performance_metrics['average_execution_time']:.2f}秒")
        
        # 获取系统状态
        system_status = pipeline.get_system_status()
        print(f"系统状态: {system_status['status']}")
        
        # 获取优化报告
        optimization_report = pipeline.batch_processor.get_optimization_report()
        print(f"效率指标:")
        print(f"  成功率: {optimization_report['efficiency_indicators']['success_rate']}")
        print(f"  吞吐量: {optimization_report['efficiency_indicators']['throughput']}")
        
        # 停止监控
        pipeline.error_system.stop_monitoring()
        
        print("✅ 性能监控示例完成")
        
    except Exception as e:
        logger.error(f"示例6执行错误: {e}")


def example_7_data_visualization():
    """示例7: 数据可视化"""
    logger.info("=== 示例7: 数据可视化 ===")
    
    try:
        # 创建示例文档结构
        from data_converter import DocumentStructure
        
        doc_structure = DocumentStructure(
            document_id="example_visualization",
            title="可视化示例文档",
            author="示例作者",
            pages=[
                {
                    'page_number': 1,
                    'metadata': {
                        'text_data': [
                            {'text': '标题文本', 'confidence': 0.95},
                            {'text': '正文文本1', 'confidence': 0.88},
                            {'text': '正文文本2', 'confidence': 0.92}
                        ],
                        'vector_data': [
                            {'element_type': 'line', 'points': [(100, 100), (200, 100)]},
                            {'element_type': 'rectangle', 'points': [(150, 150), (250, 200)]}
                        ],
                        'image_data': [
                            {'bbox': {'x': 300, 'y': 100, 'width': 100, 'height': 100}}
                        ]
                    }
                }
            ]
        )
        
        # 创建可视化
        visualizer = DataVisualizer()
        
        # 文档结构可视化
        success1 = visualizer.visualize_document_structure(
            doc_structure, 
            "output_example7/document_structure.png"
        )
        print(f"文档结构可视化: {'成功' if success1 else '失败'}")
        
        # 数据质量报告
        success2 = visualizer.create_data_quality_report(
            doc_structure.to_dict(),
            "output_example7/data_quality.png"
        )
        print(f"数据质量报告: {'成功' if success2 else '失败'}")
        
        print("✅ 数据可视化示例完成")
        
    except Exception as e:
        logger.error(f"示例7执行错误: {e}")


def cleanup_example_files():
    """清理示例文件"""
    try:
        # 清理示例文档
        example_files = [
            "sample_document.png",
            "sample_document_1.png",
            "sample_document_2.png", 
            "sample_document_3.png"
        ]
        
        for file in example_files:
            if os.path.exists(file):
                os.remove(file)
                logger.info(f"清理文件: {file}")
        
        # 清理输出目录
        output_dirs = [
            "output_example1", "output_example2", "output_example3",
            "output_example5", "output_example6", "output_example7"
        ]
        
        for dir_path in output_dirs:
            if os.path.exists(dir_path):
                import shutil
                shutil.rmtree(dir_path)
                logger.info(f"清理目录: {dir_path}")
        
        logger.info("示例文件清理完成")
        
    except Exception as e:
        logger.warning(f"清理示例文件时出错: {e}")


def main():
    """主函数"""
    logger.info("开始运行PDF解析和图像预处理模块示例")
    
    try:
        # 创建输出目录
        for i in range(1, 8):
            output_dir = Path(f"output_example{i}")
            output_dir.mkdir(exist_ok=True)
        
        # 运行示例
        examples = [
            example_1_basic_usage,
            example_2_custom_config,
            example_3_batch_processing,
            example_4_error_handling,
            example_5_individual_components,
            example_6_performance_monitoring,
            example_7_data_visualization
        ]
        
        successful_examples = 0
        
        for i, example_func in enumerate(examples, 1):
            try:
                logger.info(f"运行示例 {i}/{len(examples)}")
                example_func()
                successful_examples += 1
                time.sleep(1)  # 短暂延迟
            except Exception as e:
                logger.error(f"示例 {i} 执行失败: {e}")
        
        # 总结
        logger.info("=== 示例运行总结 ===")
        print(f"成功运行的示例: {successful_examples}/{len(examples)}")
        
        if successful_examples == len(examples):
            print("🎉 所有示例都成功运行！")
        elif successful_examples > 0:
            print(f"⚠️  有 {len(examples) - successful_examples} 个示例失败")
        else:
            print("❌ 所有示例都失败了")
        
        print("\n📁 输出文件位置:")
        for i in range(1, 8):
            output_dir = Path(f"output_example{i}")
            if output_dir.exists():
                files = list(output_dir.glob("*"))
                if files:
                    print(f"  output_example{i}/ ({len(files)} 个文件)")
        
    except Exception as e:
        logger.error(f"主函数执行错误: {e}")
    
    finally:
        # 询问是否清理示例文件
        try:
            response = input("\n是否清理示例文件？(y/N): ").lower().strip()
            if response in ['y', 'yes']:
                cleanup_example_files()
            else:
                print("保留示例文件")
        except KeyboardInterrupt:
            print("\n用户取消")
        except:
            print("\n保留示例文件")


if __name__ == "__main__":
    main()
