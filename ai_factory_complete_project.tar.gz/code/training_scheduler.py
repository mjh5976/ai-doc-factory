#!/usr/bin/env python3
"""
训练调度和资源管理模块
自动训练任务调度和资源管理
"""

import os
import json
import time
import logging
import asyncio
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Union
from dataclasses import dataclass, asdict
from enum import Enum
import yaml
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.distributed as dist
from torch.utils.data import DataLoader
import mlflow
import mlflow.pytorch
import docker
import kubernetes.client
from kubernetes.client.rest import ApiException
import celery
from celery import Celery
import psutil
import GPUtil
from prometheus_client import Gauge, Counter, Histogram, start_http_server
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger(__name__)

class TrainingStatus(Enum):
    """训练状态枚举"""
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class ResourceType(Enum):
    """资源类型枚举"""
    CPU = "cpu"
    GPU = "gpu"
    MEMORY = "memory"
    STORAGE = "storage"

@dataclass
class TrainingJob:
    """训练任务数据类"""
    job_id: str
    model_version: str
    trigger_id: str
    config: Dict
    status: TrainingStatus
    created_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    progress: float = 0.0
    metrics: Dict = None
    resource_usage: Dict = None
    error_message: Optional[str] = None

@dataclass
class ResourceAllocation:
    """资源分配数据类"""
    job_id: str
    cpu_cores: int
    memory_gb: float
    gpu_count: int
    gpu_memory_gb: float
    storage_gb: float
    estimated_duration_hours: float
    priority: int = 1

class TrainingScheduler:
    """训练调度器"""
    
    def __init__(self, config_path: str = "config/training_scheduler_config.yaml"):
        """初始化训练调度器"""
        self.config = self._load_config(config_path)
        self.setup_logging()
        self.setup_monitoring()
        self.setup_kubernetes()
        self.setup_celery()
        self.setup_docker()
        self.setup_mlflow()
        
        # 任务队列
        self.job_queue = []
        self.running_jobs = {}
        self.completed_jobs = {}
        self.failed_jobs = {}
        
        # 资源管理
        self.available_resources = self._initialize_resources()
        self.resource_allocations = {}
        
        # 监控指标
        self.jobs_gauge = Gauge('training_jobs_total', 'Total training jobs', ['status'])
        self.resource_gauge = Gauge('resource_usage', 'Resource usage', ['type'])
        self.job_duration = Histogram('job_duration_seconds', 'Job duration in seconds')
        
        logger.info("训练调度器初始化完成")
    
    def _load_config(self, config_path: str) -> Dict:
        """加载配置文件"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            logger.info(f"训练调度器配置文件加载成功: {config_path}")
            return config
        except Exception as e:
            logger.error(f"训练调度器配置文件加载失败: {e}")
            raise
    
    def setup_logging(self):
        """设置日志"""
        log_config = self.config.get('logging', {})
        log_dir = Path(log_config.get('directory', 'logs'))
        log_dir.mkdir(exist_ok=True)
        
        # 配置日志格式
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        file_handler = logging.FileHandler(log_dir / 'training_scheduler.log')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logging.INFO)
        
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)
        
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
    
    def setup_monitoring(self):
        """设置监控系统"""
        monitor_config = self.config['monitoring']
        
        # 启动Prometheus指标服务器
        if monitor_config.get('prometheus', {}).get('enabled', True):
            port = monitor_config.get('prometheus', {}).get('port', 8001)
            start_http_server(port)
            logger.info(f"训练调度器Prometheus指标服务器启动在端口: {port}")
    
    def setup_kubernetes(self):
        """设置Kubernetes客户端"""
        try:
            self.k8s_client = kubernetes.client.ApiClient()
            self.apps_v1 = kubernetes.client.AppsV1Api(self.k8s_client)
            self.core_v1 = kubernetes.client.CoreV1Api(self.k8s_client)
            self.batch_v1 = kubernetes.client.BatchV1Api(self.k8s_client)
            logger.info("Kubernetes客户端设置完成")
        except Exception as e:
            logger.warning(f"Kubernetes设置失败: {e}")
            self.k8s_client = None
    
    def setup_celery(self):
        """设置Celery任务队列"""
        celery_config = self.config['celery']
        
        self.celery_app = Celery(
            'training_scheduler',
            broker=celery_config['broker_url'],
            backend=celery_config['result_backend']
        )
        
        self.celery_app.conf.update(celery_config['config'])
        logger.info("Celery任务队列设置完成")
    
    def setup_docker(self):
        """设置Docker客户端"""
        try:
            self.docker_client = docker.from_env()
            logger.info("Docker客户端设置完成")
        except Exception as e:
            logger.warning(f"Docker客户端设置失败: {e}")
            self.docker_client = None
    
    def setup_mlflow(self):
        """设置MLflow"""
        mlflow_config = self.config['mlflow']
        
        mlflow.set_tracking_uri(mlflow_config['tracking_uri'])
        mlflow.set_experiment(mlflow_config['experiment_name'])
        
        logger.info("MLflow设置完成")
    
    def _initialize_resources(self) -> Dict:
        """初始化可用资源"""
        resource_config = self.config['resources']
        
        # 获取系统资源
        cpu_count = psutil.cpu_count()
        memory_gb = psutil.virtual_memory().total / (1024**3)
        
        # 获取GPU资源
        gpu_count = 0
        gpu_memory_gb = 0
        try:
            gpus = GPUtil.getGPUs()
            gpu_count = len(gpus)
            if gpus:
                gpu_memory_gb = sum([gpu.memoryTotal for gpu in gpus]) / 1024
        except:
            pass
        
        # 获取存储资源
        storage_gb = psutil.disk_usage('/').free / (1024**3)
        
        return {
            'cpu_cores': min(cpu_count, resource_config.get('max_cpu_cores', cpu_count)),
            'memory_gb': min(memory_gb, resource_config.get('max_memory_gb', memory_gb)),
            'gpu_count': min(gpu_count, resource_config.get('max_gpu_count', gpu_count)),
            'gpu_memory_gb': min(gpu_memory_gb, resource_config.get('max_gpu_memory_gb', gpu_memory_gb)),
            'storage_gb': min(storage_gb, resource_config.get('max_storage_gb', storage_gb))
        }
    
    def submit_training_job(self, training_config: Dict) -> str:
        """提交训练任务"""
        logger.info("提交训练任务...")
        
        try:
            # 生成任务ID
            job_id = f"job_{int(time.time())}_{np.random.randint(1000, 9999)}"
            
            # 创建训练任务
            job = TrainingJob(
                job_id=job_id,
                model_version=training_config['model_version'],
                trigger_id=training_config['trigger_id'],
                config=training_config,
                status=TrainingStatus.PENDING,
                created_at=datetime.now(),
                metrics={},
                resource_usage={}
            )
            
            # 估算资源需求
            resource_allocation = self._estimate_resource_requirements(job)
            
            # 检查资源可用性
            if self._check_resource_availability(resource_allocation):
                # 资源可用，直接排队
                job.status = TrainingStatus.QUEUED
                self.job_queue.append(job)
                self.resource_allocations[job_id] = resource_allocation
                
                logger.info(f"训练任务已提交: {job_id}, 状态: {job.status.value}")
                
                # 立即尝试启动任务
                self._try_start_next_job()
                
            else:
                # 资源不足，加入队列等待
                job.status = TrainingStatus.PENDING
                self.job_queue.append(job)
                self.resource_allocations[job_id] = resource_allocation
                
                logger.info(f"训练任务已提交但等待资源: {job_id}")
            
            return job_id
            
        except Exception as e:
            logger.error(f"提交训练任务失败: {e}")
            raise
    
    def _estimate_resource_requirements(self, job: TrainingJob) -> ResourceAllocation:
        """估算资源需求"""
        config = job.config
        training_config = config.get('config', {})
        
        # 基于模型大小和训练配置估算资源需求
        model_size_mb = training_config.get('model_size_mb', 100)
        batch_size = training_config.get('batch_size', 32)
        epochs = training_config.get('epochs', 10)
        data_size_gb = training_config.get('data_size_gb', 1)
        
        # CPU需求（基于batch size和数据大小）
        cpu_cores = max(1, min(8, int(batch_size / 8) + 2))
        
        # 内存需求（基于模型大小和数据大小）
        memory_gb = max(2, model_size_mb / 100 + data_size_gb * 2)
        
        # GPU需求（基于batch size）
        gpu_count = 1 if batch_size >= 16 else 0
        gpu_memory_gb = max(1, model_size_mb / 200 + batch_size / 32)
        
        # 存储需求（基于数据大小）
        storage_gb = data_size_gb * 3  # 原始数据 + 增强数据 + 模型检查点
        
        # 估算训练时长（小时）
        base_time_per_epoch = 0.5  # 基础时间
        time_multiplier = max(1, batch_size / 32)
        estimated_duration_hours = epochs * base_time_per_epoch * time_multiplier
        
        # 计算优先级（基于触发类型和严重程度）
        priority_map = {
            'performance_degradation': 3,
            'data_drift': 2,
            'scheduled': 1,
            'manual': 2
        }
        priority = priority_map.get(config.get('trigger_type', 'manual'), 1)
        
        return ResourceAllocation(
            job_id=job.job_id,
            cpu_cores=cpu_cores,
            memory_gb=memory_gb,
            gpu_count=gpu_count,
            gpu_memory_gb=gpu_memory_gb,
            storage_gb=storage_gb,
            estimated_duration_hours=estimated_duration_hours,
            priority=priority
        )
    
    def _check_resource_availability(self, resource_allocation: ResourceAllocation) -> bool:
        """检查资源可用性"""
        resources = self.available_resources
        
        # 检查CPU
        if resource_allocation.cpu_cores > resources['cpu_cores']:
            return False
        
        # 检查内存
        if resource_allocation.memory_gb > resources['memory_gb']:
            return False
        
        # 检查GPU
        if resource_allocation.gpu_count > resources['gpu_count']:
            return False
        
        # 检查GPU内存
        if resource_allocation.gpu_memory_gb > resources['gpu_memory_gb']:
            return False
        
        # 检查存储
        if resource_allocation.storage_gb > resources['storage_gb']:
            return False
        
        return True
    
    def _try_start_next_job(self):
        """尝试启动下一个任务"""
        logger.info("尝试启动下一个训练任务...")
        
        # 按优先级排序队列
        self.job_queue.sort(key=lambda x: self.resource_allocations[x.job_id].priority, reverse=True)
        
        for job in self.job_queue[:]:
            if job.status == TrainingStatus.QUEUED:
                resource_allocation = self.resource_allocations[job.job_id]
                
                if self._check_resource_availability(resource_allocation):
                    # 启动任务
                    self._start_training_job(job)
                    break
    
    def _start_training_job(self, job: TrainingJob):
        """启动训练任务"""
        logger.info(f"启动训练任务: {job.job_id}")
        
        try:
            # 更新任务状态
            job.status = TrainingStatus.RUNNING
            job.started_at = datetime.now()
            
            # 分配资源
            resource_allocation = self.resource_allocations[job.job_id]
            self._allocate_resources(resource_allocation)
            
            # 移动到运行队列
            self.running_jobs[job.job_id] = job
            
            # 从等待队列移除
            self.job_queue = [j for j in self.job_queue if j.job_id != job.job_id]
            
            # 提交训练任务到Celery
            self.celery_app.send_task(
                'training_scheduler.execute_training_job',
                args=[job.job_id, job.config]
            )
            
            logger.info(f"训练任务已启动: {job.job_id}")
            
        except Exception as e:
            logger.error(f"启动训练任务失败 {job.job_id}: {e}")
            job.status = TrainingStatus.FAILED
            job.error_message = str(e)
            self.failed_jobs[job.job_id] = job
    
    def _allocate_resources(self, resource_allocation: ResourceAllocation):
        """分配资源"""
        # 更新可用资源
        self.available_resources['cpu_cores'] -= resource_allocation.cpu_cores
        self.available_resources['memory_gb'] -= resource_allocation.memory_gb
        self.available_resources['gpu_count'] -= resource_allocation.gpu_count
        self.available_resources['gpu_memory_gb'] -= resource_allocation.gpu_memory_gb
        self.available_resources['storage_gb'] -= resource_allocation.storage_gb
        
        # 更新监控指标
        self.resource_gauge.labels(type='cpu').set(
            (self.available_resources['cpu_cores'] + resource_allocation.cpu_cores) - self.available_resources['cpu_cores']
        )
        self.resource_gauge.labels(type='memory').set(
            (self.available_resources['memory_gb'] + resource_allocation.memory_gb) - self.available_resources['memory_gb']
        )
        self.resource_gauge.labels(type='gpu').set(
            (self.available_resources['gpu_count'] + resource_allocation.gpu_count) - self.available_resources['gpu_count']
        )
    
    def _release_resources(self, resource_allocation: ResourceAllocation):
        """释放资源"""
        # 释放资源
        self.available_resources['cpu_cores'] += resource_allocation.cpu_cores
        self.available_resources['memory_gb'] += resource_allocation.memory_gb
        self.available_resources['gpu_count'] += resource_allocation.gpu_count
        self.available_resources['gpu_memory_gb'] += resource_allocation.gpu_memory_gb
        self.available_resources['storage_gb'] += resource_allocation.storage_gb
        
        # 更新监控指标
        self.resource_gauge.labels(type='cpu').set(self.available_resources['cpu_cores'])
        self.resource_gauge.labels(type='memory').set(self.available_resources['memory_gb'])
        self.resource_gauge.labels(type='gpu').set(self.available_resources['gpu_count'])
    
    def update_job_status(self, job_id: str, status: TrainingStatus, metrics: Dict = None, error_message: str = None):
        """更新任务状态"""
        logger.info(f"更新任务状态: {job_id} -> {status.value}")
        
        try:
            if job_id in self.running_jobs:
                job = self.running_jobs[job_id]
                job.status = status
                
                if metrics:
                    job.metrics.update(metrics)
                
                if error_message:
                    job.error_message = error_message
                
                if status in [TrainingStatus.COMPLETED, TrainingStatus.FAILED, TrainingStatus.CANCELLED]:
                    job.completed_at = datetime.now()
                    
                    # 释放资源
                    resource_allocation = self.resource_allocations[job_id]
                    self._release_resources(resource_allocation)
                    
                    # 移动到完成队列
                    if status == TrainingStatus.COMPLETED:
                        self.completed_jobs[job_id] = job
                    else:
                        self.failed_jobs[job_id] = job
                    
                    # 从运行队列移除
                    del self.running_jobs[job_id]
                    
                    # 更新监控指标
                    duration = (job.completed_at - job.started_at).total_seconds()
                    self.job_duration.observe(duration)
                    
                    # 尝试启动下一个任务
                    self._try_start_next_job()
                
                # 更新Prometheus指标
                self._update_prometheus_metrics()
                
        except Exception as e:
            logger.error(f"更新任务状态失败 {job_id}: {e}")
    
    def _update_prometheus_metrics(self):
        """更新Prometheus指标"""
        self.jobs_gauge.labels(status='pending').set(
            len([j for j in self.job_queue if j.status == TrainingStatus.PENDING])
        )
        self.jobs_gauge.labels(status='queued').set(
            len([j for j in self.job_queue if j.status == TrainingStatus.QUEUED])
        )
        self.jobs_gauge.labels(status='running').set(len(self.running_jobs))
        self.jobs_gauge.labels(status='completed').set(len(self.completed_jobs))
        self.jobs_gauge.labels(status='failed').set(len(self.failed_jobs))
    
    def get_job_status(self, job_id: str) -> Optional[Dict]:
        """获取任务状态"""
        # 检查所有队列
        for queue in [self.job_queue, self.running_jobs, self.completed_jobs, self.failed_jobs]:
            if isinstance(queue, dict):
                if job_id in queue:
                    job = queue[job_id]
                    return asdict(job)
            else:
                for job in queue:
                    if job.job_id == job_id:
                        return asdict(job)
        
        return None
    
    def get_queue_status(self) -> Dict:
        """获取队列状态"""
        return {
            'pending_jobs': len([j for j in self.job_queue if j.status == TrainingStatus.PENDING]),
            'queued_jobs': len([j for j in self.job_queue if j.status == TrainingStatus.QUEUED]),
            'running_jobs': len(self.running_jobs),
            'completed_jobs': len(self.completed_jobs),
            'failed_jobs': len(self.failed_jobs),
            'available_resources': self.available_resources
        }
    
    def cancel_job(self, job_id: str) -> bool:
        """取消任务"""
        logger.info(f"取消任务: {job_id}")
        
        try:
            # 查找任务
            job = None
            for queue in [self.job_queue, self.running_jobs]:
                if isinstance(queue, dict):
                    if job_id in queue:
                        job = queue[job_id]
                        break
                else:
                    for j in queue:
                        if j.job_id == job_id:
                            job = j
                            break
            
            if not job:
                logger.warning(f"任务不存在: {job_id}")
                return False
            
            # 更新状态
            job.status = TrainingStatus.CANCELLED
            job.completed_at = datetime.now()
            
            # 释放资源
            resource_allocation = self.resource_allocations[job_id]
            self._release_resources(resource_allocation)
            
            # 移动到失败队列
            self.failed_jobs[job_id] = job
            
            # 从原队列移除
            if job in self.job_queue:
                self.job_queue.remove(job)
            elif job_id in self.running_jobs:
                del self.running_jobs[job_id]
            
            # 尝试启动下一个任务
            self._try_start_next_job()
            
            logger.info(f"任务已取消: {job_id}")
            return True
            
        except Exception as e:
            logger.error(f"取消任务失败 {job_id}: {e}")
            return False
    
    def cleanup_completed_jobs(self, max_age_hours: int = 24):
        """清理已完成的任务"""
        logger.info("清理已完成的任务...")
        
        cutoff_time = datetime.now() - timedelta(hours=max_age_hours)
        
        # 清理已完成的任务
        completed_to_remove = []
        for job_id, job in self.completed_jobs.items():
            if job.completed_at and job.completed_at < cutoff_time:
                completed_to_remove.append(job_id)
        
        for job_id in completed_to_remove:
            del self.completed_jobs[job_id]
        
        # 清理失败的任务
        failed_to_remove = []
        for job_id, job in self.failed_jobs.items():
            if job.completed_at and job.completed_at < cutoff_time:
                failed_to_remove.append(job_id)
        
        for job_id in failed_to_remove:
            del self.failed_jobs[job_id]
        
        logger.info(f"清理完成: 移除 {len(completed_to_remove)} 个已完成任务, {len(failed_to_remove)} 个失败任务")
    
    def generate_scheduler_report(self) -> Dict:
        """生成调度器报告"""
        logger.info("生成调度器报告...")
        
        try:
            report = {
                'timestamp': datetime.now().isoformat(),
                'queue_status': self.get_queue_status(),
                'resource_utilization': self._calculate_resource_utilization(),
                'job_statistics': self._calculate_job_statistics(),
                'performance_metrics': self._calculate_performance_metrics()
            }
            
            # 生成报告图表
            self._generate_scheduler_charts(report)
            
            # 保存报告
            report_path = Path('reports') / f'scheduler_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
            report_path.parent.mkdir(exist_ok=True)
            
            with open(report_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False, default=str)
            
            logger.info(f"调度器报告已生成: {report_path}")
            return report
            
        except Exception as e:
            logger.error(f"生成调度器报告失败: {e}")
            return {}
    
    def _calculate_resource_utilization(self) -> Dict:
        """计算资源利用率"""
        total_resources = self._initialize_resources()
        available_resources = self.available_resources
        
        utilization = {}
        for resource_type in ['cpu_cores', 'memory_gb', 'gpu_count', 'gpu_memory_gb', 'storage_gb']:
            total = total_resources[resource_type]
            available = available_resources[resource_type]
            used = total - available
            utilization[resource_type] = {
                'total': total,
                'used': used,
                'available': available,
                'utilization_rate': used / total if total > 0 else 0
            }
        
        return utilization
    
    def _calculate_job_statistics(self) -> Dict:
        """计算任务统计"""
        all_jobs = list(self.completed_jobs.values()) + list(self.failed_jobs.values())
        
        if not all_jobs:
            return {}
        
        # 计算平均执行时间
        completed_jobs = [j for j in all_jobs if j.status == TrainingStatus.COMPLETED]
        if completed_jobs:
            durations = [(j.completed_at - j.started_at).total_seconds() for j in completed_jobs if j.started_at and j.completed_at]
            avg_duration = np.mean(durations) if durations else 0
        else:
            avg_duration = 0
        
        # 计算成功率
        success_rate = len(completed_jobs) / len(all_jobs) if all_jobs else 0
        
        # 按触发类型统计
        trigger_stats = {}
        for job in all_jobs:
            trigger_type = job.config.get('trigger_type', 'unknown')
            if trigger_type not in trigger_stats:
                trigger_stats[trigger_type] = {'total': 0, 'completed': 0, 'failed': 0}
            
            trigger_stats[trigger_type]['total'] += 1
            if job.status == TrainingStatus.COMPLETED:
                trigger_stats[trigger_type]['completed'] += 1
            else:
                trigger_stats[trigger_type]['failed'] += 1
        
        return {
            'total_jobs': len(all_jobs),
            'completed_jobs': len(completed_jobs),
            'failed_jobs': len(all_jobs) - len(completed_jobs),
            'success_rate': success_rate,
            'average_duration_seconds': avg_duration,
            'trigger_statistics': trigger_stats
        }
    
    def _calculate_performance_metrics(self) -> Dict:
        """计算性能指标"""
        # 计算任务吞吐量（每小时完成的任务数）
        recent_jobs = []
        cutoff_time = datetime.now() - timedelta(hours=1)
        
        for job in self.completed_jobs.values():
            if job.completed_at and job.completed_at > cutoff_time:
                recent_jobs.append(job)
        
        throughput = len(recent_jobs)  # jobs per hour
        
        # 计算平均等待时间
        waiting_times = []
        for job in self.job_queue:
            if job.created_at:
                waiting_time = (datetime.now() - job.created_at).total_seconds()
                waiting_times.append(waiting_time)
        
        avg_waiting_time = np.mean(waiting_times) if waiting_times else 0
        
        # 计算资源效率
        resource_efficiency = 1 - (sum(self.available_resources.values()) / sum(self._initialize_resources().values()))
        
        return {
            'throughput_jobs_per_hour': throughput,
            'average_waiting_time_seconds': avg_waiting_time,
            'resource_efficiency': resource_efficiency
        }
    
    def _generate_scheduler_charts(self, report: Dict):
        """生成调度器图表"""
        try:
            charts_dir = Path('reports') / 'charts'
            charts_dir.mkdir(parents=True, exist_ok=True)
            
            # 设置中文字体
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False
            
            # 资源利用率图表
            fig, axes = plt.subplots(2, 2, figsize=(15, 10))
            fig.suptitle('训练调度器性能分析', fontsize=16)
            
            # 资源利用率
            utilization = report['resource_utilization']
            resources = list(utilization.keys())
            rates = [utilization[r]['utilization_rate'] for r in resources]
            
            axes[0, 0].bar(resources, rates, color='skyblue')
            axes[0, 0].set_title('资源利用率')
            axes[0, 0].set_ylabel('利用率')
            axes[0, 0].tick_params(axis='x', rotation=45)
            
            # 任务状态分布
            queue_status = report['queue_status']
            statuses = ['pending', 'queued', 'running', 'completed', 'failed']
            counts = [queue_status.get(f'{s}_jobs', 0) for s in statuses]
            
            axes[0, 1].pie(counts, labels=statuses, autopct='%1.1f%%')
            axes[0, 1].set_title('任务状态分布')
            
            # 触发类型统计
            trigger_stats = report['job_statistics']['trigger_statistics']
            if trigger_stats:
                triggers = list(trigger_stats.keys())
                totals = [trigger_stats[t]['total'] for t in triggers]
                
                axes[1, 0].bar(triggers, totals, color='lightgreen')
                axes[1, 0].set_title('触发类型统计')
                axes[1, 0].set_ylabel('任务数量')
                axes[1, 0].tick_params(axis='x', rotation=45)
            
            # 性能指标
            perf_metrics = report['performance_metrics']
            metrics_names = ['吞吐量', '平均等待时间', '资源效率']
            metrics_values = [
                perf_metrics['throughput_jobs_per_hour'],
                perf_metrics['average_waiting_time_seconds'] / 60,  # 转换为分钟
                perf_metrics['resource_efficiency'] * 100  # 转换为百分比
            ]
            
            axes[1, 1].bar(metrics_names, metrics_values, color='orange')
            axes[1, 1].set_title('性能指标')
            axes[1, 1].set_ylabel('数值')
            axes[1, 1].tick_params(axis='x', rotation=45)
            
            plt.tight_layout()
            
            # 保存图表
            chart_path = charts_dir / 'scheduler_performance.png'
            plt.savefig(chart_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info(f"调度器性能图表已生成: {chart_path}")
            
        except Exception as e:
            logger.error(f"生成调度器图表失败: {e}")
    
    def start_scheduler_loop(self):
        """启动调度器循环"""
        logger.info("启动训练调度器循环...")
        
        def scheduler_task():
            while True:
                try:
                    # 尝试启动下一个任务
                    self._try_start_next_job()
                    
                    # 清理已完成的任务
                    self.cleanup_completed_jobs()
                    
                    # 更新监控指标
                    self._update_prometheus_metrics()
                    
                    # 等待下一个调度周期
                    interval = self.config.get('scheduler_interval', 30)  # 30秒
                    time.sleep(interval)
                    
                except Exception as e:
                    logger.error(f"调度器循环错误: {e}")
                    time.sleep(60)  # 错误时等待1分钟
        
        # 启动后台线程
        scheduler_thread = threading.Thread(target=scheduler_task, daemon=True)
        scheduler_thread.start()
        
        logger.info("训练调度器循环已启动")

# Celery任务定义
@celery_app.task
def execute_training_job(job_id: str, config: Dict):
    """执行训练任务的Celery任务"""
    logger.info(f"开始执行训练任务: {job_id}")
    
    try:
        # 导入训练器
        from auto_retraining_system import AutoRetrainingSystem
        
        # 创建训练系统实例
        training_system = AutoRetrainingSystem()
        
        # 更新任务状态为运行中
        training_system._update_trigger_status(job_id, 'processing')
        
        # 执行训练
        # 这里应该调用实际的训练逻辑
        # training_system._execute_training_job(job_id, config)
        
        # 模拟训练过程
        time.sleep(10)  # 模拟训练时间
        
        # 更新任务状态为完成
        training_system._update_trigger_status(job_id, 'completed')
        
        logger.info(f"训练任务执行完成: {job_id}")
        
    except Exception as e:
        logger.error(f"训练任务执行失败 {job_id}: {e}")
        # 更新任务状态为失败
        # training_system._update_trigger_status(job_id, 'failed')

def main():
    """主函数"""
    try:
        # 创建训练调度器
        scheduler = TrainingScheduler()
        
        # 启动调度器循环
        scheduler.start_scheduler_loop()
        
        # 保持主线程运行
        while True:
            time.sleep(60)
            
    except KeyboardInterrupt:
        logger.info("训练调度器停止")
    except Exception as e:
        logger.error(f"训练调度器运行错误: {e}")
        raise

if __name__ == "__main__":
    main()