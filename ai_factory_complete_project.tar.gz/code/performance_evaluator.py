"""
PDF图纸识别性能评估工具
提供准确率、召回率、F1-score等指标的计算和评估功能
"""

import json
import time
import logging
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass, asdict
from datetime import datetime
import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.metrics import roc_auc_score, precision_recall_curve, roc_curve
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import pandas as pd


@dataclass
class EvaluationResult:
    """评估结果"""
    timestamp: str
    blueprint_type: str
    model_version: str
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    confusion_matrix: List[List[int]]
    classification_report: Dict[str, Any]
    processing_time: float
    memory_usage: float
    cpu_usage: float
    sample_count: int
    error_count: int
    ab_test_group: Optional[str] = None
    confidence_interval: Optional[float] = None
    statistical_significance: Optional[bool] = None


@dataclass
class BlueprintEvaluationConfig:
    """图纸评估配置"""
    # 权重配置
    accuracy_weight: float = 0.25
    recall_weight: float = 0.25
    f1_score_weight: float = 0.25
    processing_time_weight: float = 0.15
    memory_efficiency_weight: float = 0.10
    
    # 阈值配置
    accuracy_threshold: float = 0.85
    recall_threshold: float = 0.80
    f1_score_threshold: float = 0.82
    processing_time_threshold: float = 30.0
    memory_threshold: float = 2048.0  # MB
    
    # 置信区间
    confidence_level: float = 0.95
    
    # 评估类型权重
    blueprint_weights: Dict[str, float] = None
    
    def __post_init__(self):
        if self.blueprint_weights is None:
            self.blueprint_weights = {
                'architectural': 0.30,
                'mechanical': 0.25,
                'electrical': 0.25,
                'pid': 0.20
            }


class PDFBlueprintEvaluator:
    """PDF图纸识别性能评估器"""
    
    def __init__(self, config: BlueprintEvaluationConfig = None):
        self.config = config or BlueprintEvaluationConfig()
        self.logger = logging.getLogger(__name__)
        self.evaluation_history = []
        
        # 设置matplotlib中文字体
        plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False
    
    def evaluate_model_performance(self,
                                 predictions: List[Any],
                                 ground_truth: List[Any],
                                 blueprint_type: str,
                                 model_version: str,
                                 processing_time: float = 0,
                                 memory_usage: float = 0,
                                 cpu_usage: float = 0,
                                 ab_test_group: Optional[str] = None) -> EvaluationResult:
        """评估模型性能"""
        try:
            start_time = time.time()
            
            # 计算基础指标
            accuracy = accuracy_score(ground_truth, predictions)
            precision = precision_score(ground_truth, predictions, average='weighted', zero_division=0)
            recall = recall_score(ground_truth, predictions, average='weighted', zero_division=0)
            f1 = f1_score(ground_truth, predictions, average='weighted', zero_division=0)
            
            # 计算混淆矩阵
            cm = confusion_matrix(ground_truth, predictions)
            
            # 生成分类报告
            from sklearn.metrics import classification_report
            report = classification_report(ground_truth, predictions, output_dict=True, zero_division=0)
            
            # 计算置信区间
            confidence_interval = self._calculate_confidence_interval(accuracy, len(ground_truth))
            
            # 创建评估结果
            result = EvaluationResult(
                timestamp=datetime.now().isoformat(),
                blueprint_type=blueprint_type,
                model_version=model_version,
                accuracy=accuracy,
                precision=precision,
                recall=recall,
                f1_score=f1,
                confusion_matrix=cm.tolist(),
                classification_report=report,
                processing_time=processing_time,
                memory_usage=memory_usage,
                cpu_usage=cpu_usage,
                sample_count=len(ground_truth),
                error_count=len(ground_truth) - sum(1 for p, g in zip(predictions, ground_truth) if p == g),
                ab_test_group=ab_test_group,
                confidence_interval=confidence_interval
            )
            
            # 添加到历史记录
            self.evaluation_history.append(result)
            
            self.logger.info(f"模型评估完成 - {blueprint_type}: 准确率={accuracy:.3f}, F1={f1:.3f}")
            
            return result
            
        except Exception as e:
            self.logger.error(f"模型评估失败: {e}")
            raise
    
    def _calculate_confidence_interval(self, accuracy: float, sample_size: int, confidence_level: float = 0.95) -> float:
        """计算准确率的置信区间"""
        try:
            from scipy import stats
            z_score = stats.norm.ppf((1 + confidence_level) / 2)
            margin_of_error = z_score * np.sqrt(accuracy * (1 - accuracy) / sample_size)
            return margin_of_error
        except ImportError:
            # 简化版本的置信区间计算
            return 1.96 * np.sqrt(accuracy * (1 - accuracy) / sample_size)
    
    def calculate_composite_score(self, result: EvaluationResult) -> float:
        """计算综合评分"""
        try:
            # 归一化处理
            accuracy_score = min(result.accuracy / self.config.accuracy_threshold, 1.0)
            recall_score = min(result.recall / self.config.recall_threshold, 1.0)
            f1_score_norm = min(result.f1_score / self.config.f1_score_threshold, 1.0)
            processing_time_score = max(1.0 - (result.processing_time / self.config.processing_time_threshold), 0)
            memory_efficiency_score = max(1.0 - (result.memory_usage / self.config.memory_threshold), 0)
            
            # 计算加权平均
            composite_score = (
                accuracy_score * self.config.accuracy_weight +
                recall_score * self.config.recall_weight +
                f1_score_norm * self.config.f1_score_weight +
                processing_time_score * self.config.processing_time_weight +
                memory_efficiency_score * self.config.memory_efficiency_weight
            )
            
            return min(composite_score, 1.0)
            
        except Exception as e:
            self.logger.error(f"计算综合评分失败: {e}")
            return 0.0
    
    def compare_models(self, 
                      results_a: EvaluationResult, 
                      results_b: EvaluationResult,
                      significance_level: float = 0.05) -> Dict[str, Any]:
        """比较两个模型性能"""
        try:
            # 计算综合评分
            score_a = self.calculate_composite_score(results_a)
            score_b = self.calculate_composite_score(results_b)
            
            # 进行统计显著性检验
            statistical_significance = self._statistical_significance_test(
                results_a, results_b, significance_level
            )
            
            comparison = {
                'model_a': {
                    'version': results_a.model_version,
                    'accuracy': results_a.accuracy,
                    'f1_score': results_a.f1_score,
                    'composite_score': score_a,
                    'sample_count': results_a.sample_count
                },
                'model_b': {
                    'version': results_b.model_version,
                    'accuracy': results_b.accuracy,
                    'f1_score': results_b.f1_score,
                    'composite_score': score_b,
                    'sample_count': results_b.sample_count
                },
                'improvement': {
                    'accuracy_improvement': results_b.accuracy - results_a.accuracy,
                    'f1_improvement': results_b.f1_score - results_a.f1_score,
                    'composite_improvement': score_b - score_a,
                    'relative_improvement': (score_b - score_a) / score_a if score_a > 0 else 0
                },
                'statistical_significance': statistical_significance,
                'recommendation': self._generate_recommendation(score_a, score_b, statistical_significance)
            }
            
            return comparison
            
        except Exception as e:
            self.logger.error(f"模型比较失败: {e}")
            raise
    
    def _statistical_significance_test(self, 
                                     results_a: EvaluationResult, 
                                     results_b: EvaluationResult,
                                     alpha: float = 0.05) -> bool:
        """统计显著性检验"""
        try:
            from scipy.stats import ttest_ind
            
            # 假设我们有原始预测结果（这里简化处理）
            # 在实际应用中，需要保存原始预测结果进行检验
            n_a, n_b = results_a.sample_count, results_b.sample_count
            
            # 使用二项分布近似
            # 这里简化处理，实际应该使用原始预测数据
            p_value = 0.05  # 简化处理
            
            return p_value < alpha
            
        except ImportError:
            # 简化版本：基于置信区间判断
            if results_a.confidence_interval and results_b.confidence_interval:
                return abs(results_a.accuracy - results_b.accuracy) > max(
                    results_a.confidence_interval, results_b.confidence_interval
                )
            return False
    
    def _generate_recommendation(self, score_a: float, score_b: float, significant: bool) -> str:
        """生成推荐建议"""
        if significant:
            if score_b > score_a:
                return "建议采用模型B，性能显著提升"
            else:
                return "建议采用模型A，性能显著提升"
        else:
            if abs(score_b - score_a) < 0.05:
                return "两模型性能相近，可根据其他因素（如部署成本、推理速度）选择"
            else:
                return "性能差异不显著，建议进一步测试"
    
    def generate_evaluation_report(self, 
                                 results: List[EvaluationResult],
                                 output_path: str,
                                 include_plots: bool = True) -> str:
        """生成评估报告"""
        try:
            # 创建输出目录
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            
            # 生成报告内容
            report_data = {
                'evaluation_summary': self._generate_summary(results),
                'detailed_results': [asdict(result) for result in results],
                'comparisons': self._generate_comparisons(results),
                'recommendations': self._generate_recommendations(results),
                'timestamp': datetime.now().isoformat()
            }
            
            # 保存JSON报告
            json_path = f"{output_path}.json"
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, ensure_ascii=False, indent=2)
            
            # 生成可视化图表
            if include_plots:
                self._generate_evaluation_plots(results, output_path)
            
            self.logger.info(f"评估报告已生成: {json_path}")
            return json_path
            
        except Exception as e:
            self.logger.error(f"生成评估报告失败: {e}")
            raise
    
    def _generate_summary(self, results: List[EvaluationResult]) -> Dict[str, Any]:
        """生成评估摘要"""
        if not results:
            return {}
        
        # 按图纸类型分组
        by_blueprint = {}
        for result in results:
            blueprint_type = result.blueprint_type
            if blueprint_type not in by_blueprint:
                by_blueprint[blueprint_type] = []
            by_blueprint[blueprint_type].append(result)
        
        summary = {
            'total_evaluations': len(results),
            'blueprint_types': list(by_blueprint.keys()),
            'overall_performance': {},
            'best_performing_model': None,
            'performance_trends': {}
        }
        
        # 计算整体性能
        all_accuracies = [r.accuracy for r in results]
        all_f1_scores = [r.f1_score for r in results]
        
        summary['overall_performance'] = {
            'mean_accuracy': np.mean(all_accuracies),
            'mean_f1_score': np.mean(all_f1_scores),
            'std_accuracy': np.std(all_accuracies),
            'std_f1_score': np.std(all_f1_scores)
        }
        
        # 找出最佳模型
        best_result = max(results, key=lambda r: self.calculate_composite_score(r))
        summary['best_performing_model'] = {
            'version': best_result.model_version,
            'blueprint_type': best_result.blueprint_type,
            'accuracy': best_result.accuracy,
            'f1_score': best_result.f1_score,
            'composite_score': self.calculate_composite_score(best_result)
        }
        
        return summary
    
    def _generate_comparisons(self, results: List[EvaluationResult]) -> List[Dict[str, Any]]:
        """生成模型比较"""
        comparisons = []
        
        # 按模型版本分组
        by_model = {}
        for result in results:
            version = result.model_version
            if version not in by_model:
                by_model[version] = []
            by_model[version].append(result)
        
        # 比较不同版本
        versions = list(by_model.keys())
        for i in range(len(versions)):
            for j in range(i + 1, len(versions)):
                version_a, version_b = versions[i], versions[j]
                
                # 计算平均性能
                avg_a = np.mean([self.calculate_composite_score(r) for r in by_model[version_a]])
                avg_b = np.mean([self.calculate_composite_score(r) for r in by_model[version_b]])
                
                comparison = {
                    'model_a': version_a,
                    'model_b': version_b,
                    'performance_a': avg_a,
                    'performance_b': avg_b,
                    'improvement': avg_b - avg_a,
                    'relative_improvement': (avg_b - avg_a) / avg_a if avg_a > 0 else 0
                }
                comparisons.append(comparison)
        
        return comparisons
    
    def _generate_recommendations(self, results: List[EvaluationResult]) -> List[str]:
        """生成建议"""
        recommendations = []
        
        if not results:
            return ["没有评估数据可供分析"]
        
        # 分析整体性能
        avg_accuracy = np.mean([r.accuracy for r in results])
        avg_f1 = np.mean([r.f1_score for r in results])
        
        if avg_accuracy < self.config.accuracy_threshold:
            recommendations.append(f"整体准确率({avg_accuracy:.3f})低于阈值({self.config.accuracy_threshold})，建议优化模型")
        
        if avg_f1 < self.config.f1_score_threshold:
            recommendations.append(f"整体F1-score({avg_f1:.3f})低于阈值({self.config.f1_score_threshold})，建议改进特征工程")
        
        # 分析处理时间
        avg_processing_time = np.mean([r.processing_time for r in results])
        if avg_processing_time > self.config.processing_time_threshold:
            recommendations.append(f"平均处理时间({avg_processing_time:.2f}秒)较长，建议优化算法效率")
        
        # 分析内存使用
        avg_memory = np.mean([r.memory_usage for r in results])
        if avg_memory > self.config.memory_threshold:
            recommendations.append(f"平均内存使用({avg_memory:.0f}MB)较高，建议优化内存管理")
        
        # 找出需要改进的图纸类型
        by_blueprint = {}
        for result in results:
            blueprint_type = result.blueprint_type
            if blueprint_type not in by_blueprint:
                by_blueprint[blueprint_type] = []
            by_blueprint[blueprint_type].append(result)
        
        for blueprint_type, type_results in by_blueprint.items():
            avg_score = np.mean([self.calculate_composite_score(r) for r in type_results])
            if avg_score < 0.8:
                recommendations.append(f"{blueprint_type}图纸识别性能较低(综合评分{avg_score:.3f})，建议针对性优化")
        
        return recommendations
    
    def _generate_evaluation_plots(self, results: List[EvaluationResult], output_path: str):
        """生成评估图表"""
        try:
            # 创建图表
            fig, axes = plt.subplots(2, 2, figsize=(15, 12))
            fig.suptitle('PDF图纸识别性能评估报告', fontsize=16)
            
            # 1. 准确率对比
            ax1 = axes[0, 0]
            blueprint_types = list(set(r.blueprint_type for r in results))
            model_versions = list(set(r.model_version for r in results))
            
            data_for_plot = []
            labels = []
            for result in results:
                data_for_plot.append(result.accuracy)
                labels.append(f"{result.blueprint_type}\n{result.model_version}")
            
            ax1.bar(range(len(data_for_plot)), data_for_plot)
            ax1.set_title('各模型准确率对比')
            ax1.set_ylabel('准确率')
            ax1.set_xticks(range(len(labels)))
            ax1.set_xticklabels(labels, rotation=45, ha='right')
            
            # 2. F1-score对比
            ax2 = axes[0, 1]
            f1_scores = [r.f1_score for r in results]
            ax2.bar(range(len(f1_scores)), f1_scores)
            ax2.set_title('各模型F1-score对比')
            ax2.set_ylabel('F1-score')
            ax2.set_xticks(range(len(labels)))
            ax2.set_xticklabels(labels, rotation=45, ha='right')
            
            # 3. 处理时间分布
            ax3 = axes[1, 0]
            processing_times = [r.processing_time for r in results]
            ax3.hist(processing_times, bins=10, alpha=0.7)
            ax3.set_title('处理时间分布')
            ax3.set_xlabel('处理时间(秒)')
            ax3.set_ylabel('频次')
            
            # 4. 综合评分趋势
            ax4 = axes[1, 1]
            composite_scores = [self.calculate_composite_score(r) for r in results]
            timestamps = [r.timestamp for r in results]
            
            ax4.plot(range(len(composite_scores)), composite_scores, marker='o')
            ax4.set_title('综合评分趋势')
            ax4.set_ylabel('综合评分')
            ax4.set_xlabel('评估序号')
            ax4.grid(True)
            
            plt.tight_layout()
            
            # 保存图表
            plot_path = f"{output_path}_plots.png"
            plt.savefig(plot_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            self.logger.info(f"评估图表已生成: {plot_path}")
            
        except Exception as e:
            self.logger.error(f"生成评估图表失败: {e}")


# 使用示例
if __name__ == "__main__":
    # 创建评估器
    evaluator = PDFBlueprintEvaluator()
    
    # 模拟评估数据
    np.random.seed(42)
    
    # 模拟预测结果和真实标签
    predictions_a = np.random.choice([0, 1], size=1000, p=[0.2, 0.8])
    ground_truth = np.random.choice([0, 1], size=1000, p=[0.15, 0.85])
    
    predictions_b = np.random.choice([0, 1], size=1000, p=[0.18, 0.82])
    
    # 评估模型A
    result_a = evaluator.evaluate_model_performance(
        predictions=predictions_a,
        ground_truth=ground_truth,
        blueprint_type="architectural",
        model_version="v1.0",
        processing_time=25.5,
        memory_usage=2048,
        cpu_usage=65
    )
    
    # 评估模型B
    result_b = evaluator.evaluate_model_performance(
        predictions=predictions_b,
        ground_truth=ground_truth,
        blueprint_type="architectural",
        model_version="v1.1",
        processing_time=22.3,
        memory_usage=1856,
        cpu_usage=58
    )
    
    # 比较模型
    comparison = evaluator.compare_models(result_a, result_b)
    print("模型比较结果:")
    print(json.dumps(comparison, indent=2, ensure_ascii=False))
    
    # 生成评估报告
    report_path = evaluator.generate_evaluation_report(
        results=[result_a, result_b],
        output_path="reports/evaluation_report"
    )
    
    print(f"评估报告已生成: {report_path}")