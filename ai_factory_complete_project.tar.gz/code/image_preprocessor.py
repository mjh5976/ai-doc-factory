#!/usr/bin/env python3
"""
图像预处理和增强模块
提供多种图像处理算法来改善PDF解析质量
"""

import os
import sys
import logging
import json
import traceback
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, asdict
from pathlib import Path
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import threading
import time

import numpy as np
import cv2
from PIL import Image, ImageEnhance, ImageFilter
import skimage
from skimage import restoration, morphology, segmentation, measure, filters
from skimage.transform import hough_line, hough_line_peaks
from skimage.feature import canny
import torch
import torchvision.transforms as transforms
from torchvision.models import resnet50
import torch.nn.functional as F

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@dataclass
class ProcessingConfig:
    """图像处理配置"""
    # 基础处理
    resize_factor: float = 1.0
    rotate_angle: float = 0.0
    flip_horizontal: bool = False
    flip_vertical: bool = False
    
    # 去噪参数
    denoise_method: str = "gaussian"  # gaussian, bilateral, non_local_means
    denoise_strength: float = 1.0
    
    # 对比度增强
    contrast_factor: float = 1.2
    brightness_factor: float = 1.0
    gamma_correction: float = 1.0
    
    # 二值化
    binarization_method: str = "adaptive"  # otsu, adaptive, manual
    threshold_value: int = 128
    
    # 边缘检测
    edge_detection_method: str = "canny"  # canny, sobel, laplacian
    edge_threshold_low: float = 0.1
    edge_threshold_high: float = 0.3
    
    # 形态学操作
    morphological_kernel_size: int = 3
    morphological_operation: str = "opening"  # opening, closing, erosion, dilation
    
    # 倾斜校正
    enable_skew_correction: bool = True
    skew_detection_method: str = "hough"  # hough, moments
    
    # 线条增强
    enable_line_enhancement: bool = True
    line_detection_method: str = "morphological"  # morphological, hough, gabor
    
    def to_dict(self):
        return asdict(self)


@dataclass
class ProcessingResult:
    """图像处理结果"""
    original_image: np.ndarray
    processed_image: np.ndarray
    processing_steps: List[str]
    processing_time: float
    config: ProcessingConfig
    metadata: Dict[str, Any]
    
    def to_dict(self):
        return {
            'processing_steps': self.processing_steps,
            'processing_time': self.processing_time,
            'config': self.config.to_dict(),
            'metadata': self.metadata,
            'image_shape': self.processed_image.shape
        }


class ImageProcessingError(Exception):
    """图像处理错误"""
    pass


class ImagePreprocessor:
    """图像预处理器主类"""
    
    def __init__(self, config: Optional[ProcessingConfig] = None):
        """
        初始化图像预处理器
        
        Args:
            config: 处理配置，如果为None则使用默认配置
        """
        self.config = config or ProcessingConfig()
        logger.info("图像预处理器初始化完成")
    
    def preprocess_image(self, image: np.ndarray, config: Optional[ProcessingConfig] = None) -> ProcessingResult:
        """
        预处理图像
        
        Args:
            image: 输入图像 (BGR格式)
            config: 处理配置
            
        Returns:
            ProcessingResult: 处理结果
        """
        if config:
            self.config = config
        
        start_time = time.time()
        processing_steps = []
        metadata = {}
        
        try:
            # 验证输入
            if image is None or image.size == 0:
                raise ImageProcessingError("输入图像为空")
            
            # 转换为BGR格式（如果需要）
            if len(image.shape) == 3 and image.shape[2] == 3:
                # 确保是BGR格式
                if image.dtype == np.uint8 and np.max(image) <= 255:
                    pass  # 已经是BGR格式
                else:
                    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            
            original_image = image.copy()
            processed_image = image.copy()
            
            # 1. 基础几何变换
            processed_image, steps = self._apply_geometric_transforms(processed_image)
            processing_steps.extend(steps)
            
            # 2. 去噪
            processed_image, steps = self._apply_denoising(processed_image)
            processing_steps.extend(steps)
            
            # 3. 对比度增强
            processed_image, steps = self._apply_contrast_enhancement(processed_image)
            processing_steps.extend(steps)
            
            # 4. 倾斜校正
            if self.config.enable_skew_correction:
                processed_image, steps = self._apply_skew_correction(processed_image)
                processing_steps.extend(steps)
            
            # 5. 边缘检测和线条增强
            if self.config.enable_line_enhancement:
                processed_image, steps = self._apply_line_enhancement(processed_image)
                processing_steps.extend(steps)
            
            # 6. 形态学操作
            processed_image, steps = self._apply_morphological_operations(processed_image)
            processing_steps.extend(steps)
            
            # 7. 二值化
            processed_image, steps = self._apply_binarization(processed_image)
            processing_steps.extend(steps)
            
            processing_time = time.time() - start_time
            
            # 收集元数据
            metadata = {
                'original_shape': original_image.shape,
                'processed_shape': processed_image.shape,
                'processing_steps_count': len(processing_steps)
            }
            
            result = ProcessingResult(
                original_image=original_image,
                processed_image=processed_image,
                processing_steps=processing_steps,
                processing_time=processing_time,
                config=self.config,
                metadata=metadata
            )
            
            logger.info(f"图像预处理完成，耗时: {processing_time:.2f}秒，步骤: {len(processing_steps)}")
            return result
            
        except Exception as e:
            logger.error(f"图像预处理错误: {e}")
            logger.error(traceback.format_exc())
            raise ImageProcessingError(f"图像预处理失败: {e}")
    
    def _apply_geometric_transforms(self, image: np.ndarray) -> Tuple[np.ndarray, List[str]]:
        """应用几何变换"""
        steps = []
        processed_image = image.copy()
        
        try:
            # 缩放
            if abs(self.config.resize_factor - 1.0) > 0.01:
                new_width = int(processed_image.shape[1] * self.config.resize_factor)
                new_height = int(processed_image.shape[0] * self.config.resize_factor)
                processed_image = cv2.resize(processed_image, (new_width, new_height), 
                                           interpolation=cv2.INTER_CUBIC)
                steps.append(f"resize_{self.config.resize_factor}")
            
            # 旋转
            if abs(self.config.rotate_angle) > 0.1:
                center = (processed_image.shape[1] // 2, processed_image.shape[0] // 2)
                rotation_matrix = cv2.getRotationMatrix2D(center, self.config.rotate_angle, 1.0)
                processed_image = cv2.warpAffine(processed_image, rotation_matrix, 
                                               (processed_image.shape[1], processed_image.shape[0]))
                steps.append(f"rotate_{self.config.rotate_angle}")
            
            # 翻转
            if self.config.flip_horizontal:
                processed_image = cv2.flip(processed_image, 1)
                steps.append("flip_horizontal")
            
            if self.config.flip_vertical:
                processed_image = cv2.flip(processed_image, 0)
                steps.append("flip_vertical")
            
        except Exception as e:
            logger.warning(f"几何变换错误: {e}")
        
        return processed_image, steps
    
    def _apply_denoising(self, image: np.ndarray) -> Tuple[np.ndarray, List[str]]:
        """应用去噪"""
        steps = []
        processed_image = image.copy()
        
        try:
            if self.config.denoise_method == "gaussian":
                if self.config.denoise_strength > 0:
                    kernel_size = int(self.config.denoise_strength * 3) | 1  # 确保是奇数
                    processed_image = cv2.GaussianBlur(processed_image, (kernel_size, kernel_size), 0)
                    steps.append(f"gaussian_denoise_{kernel_size}")
            
            elif self.config.denoise_method == "bilateral":
                if self.config.denoise_strength > 0:
                    d = int(self.config.denoise_strength * 9) + 1
                    sigma_color = int(self.config.denoise_strength * 75)
                    sigma_space = int(self.config.denoise_strength * 75)
                    processed_image = cv2.bilateralFilter(processed_image, d, sigma_color, sigma_space)
                    steps.append(f"bilateral_denoise_{d}")
            
            elif self.config.denoise_method == "non_local_means":
                if self.config.denoise_strength > 0:
                    h = int(self.config.denoise_strength * 10)
                    template_window_size = 7
                    search_window_size = 21
                    processed_image = cv2.fastNlMeansDenoisingColored(processed_image, None, h, h, 
                                                                     templateWindowSize=template_window_size, 
                                                                     searchWindowSize=search_window_size)
                    steps.append(f"nlm_denoise_{h}")
            
        except Exception as e:
            logger.warning(f"去噪错误: {e}")
        
        return processed_image, steps
    
    def _apply_contrast_enhancement(self, image: np.ndarray) -> Tuple[np.ndarray, List[str]]:
        """应用对比度增强"""
        steps = []
        processed_image = image.copy()
        
        try:
            # 对比度增强
            if abs(self.config.contrast_factor - 1.0) > 0.01:
                processed_image = cv2.convertScaleAbs(processed_image, alpha=self.config.contrast_factor, beta=0)
                steps.append(f"contrast_{self.config.contrast_factor}")
            
            # 亮度调整
            if abs(self.config.brightness_factor - 1.0) > 0.01:
                beta = (self.config.brightness_factor - 1.0) * 50
                processed_image = cv2.convertScaleAbs(processed_image, alpha=1.0, beta=beta)
                steps.append(f"brightness_{self.config.brightness_factor}")
            
            # 伽马校正
            if abs(self.config.gamma_correction - 1.0) > 0.01:
                # 构建伽马校正查找表
                inv_gamma = 1.0 / self.config.gamma_correction
                table = np.array([((i / 255.0) ** inv_gamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
                processed_image = cv2.LUT(processed_image, table)
                steps.append(f"gamma_{self.config.gamma_correction}")
            
            # 自适应直方图均衡化
            if len(processed_image.shape) == 3:
                lab = cv2.cvtColor(processed_image, cv2.COLOR_BGR2LAB)
                l, a, b = cv2.split(lab)
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                l = clahe.apply(l)
                lab = cv2.merge([l, a, b])
                processed_image = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
                steps.append("clahe")
            
        except Exception as e:
            logger.warning(f"对比度增强错误: {e}")
        
        return processed_image, steps
    
    def _apply_skew_correction(self, image: np.ndarray) -> Tuple[np.ndarray, List[str]]:
        """应用倾斜校正"""
        steps = []
        processed_image = image.copy()
        
        try:
            if self.config.skew_detection_method == "hough":
                # 使用霍夫变换检测倾斜角度
                gray = cv2.cvtColor(processed_image, cv2.COLOR_BGR2GRAY)
                edges = cv2.Canny(gray, 50, 150, apertureSize=3)
                
                # 霍夫线变换
                lines = cv2.HoughLines(edges, 1, np.pi/180, threshold=100)
                
                if lines is not None:
                    angles = []
                    for rho, theta in lines[:, 0]:
                        angle = np.degrees(theta) - 90
                        angles.append(angle)
                    
                    # 计算主要倾斜角度
                    if angles:
                        median_angle = np.median(angles)
                        
                        # 旋转校正
                        if abs(median_angle) > 0.5:  # 只有当倾斜角度足够大时才校正
                            center = (processed_image.shape[1] // 2, processed_image.shape[0] // 2)
                            rotation_matrix = cv2.getRotationMatrix2D(center, median_angle, 1.0)
                            processed_image = cv2.warpAffine(processed_image, rotation_matrix, 
                                                           (processed_image.shape[1], processed_image.shape[0]))
                            steps.append(f"skew_correction_{median_angle:.2f}")
            
            elif self.config.skew_detection_method == "moments":
                # 使用图像矩检测倾斜
                gray = cv2.cvtColor(processed_image, cv2.COLOR_BGR2GRAY)
                _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
                
                # 计算图像矩
                moments = cv2.moments(binary)
                if moments['mu02'] != 0:
                    skew = moments['mu11'] / moments['mu02']
                    angle = np.degrees(np.arctan(skew))
                    
                    if abs(angle) > 0.5:
                        center = (processed_image.shape[1] // 2, processed_image.shape[0] // 2)
                        rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
                        processed_image = cv2.warpAffine(processed_image, rotation_matrix, 
                                                       (processed_image.shape[1], processed_image.shape[0]))
                        steps.append(f"skew_correction_{angle:.2f}")
            
        except Exception as e:
            logger.warning(f"倾斜校正错误: {e}")
        
        return processed_image, steps
    
    def _apply_line_enhancement(self, image: np.ndarray) -> Tuple[np.ndarray, List[str]]:
        """应用线条增强"""
        steps = []
        processed_image = image.copy()
        
        try:
            if self.config.line_detection_method == "morphological":
                # 形态学线条增强
                gray = cv2.cvtColor(processed_image, cv2.COLOR_BGR2GRAY)
                
                # 创建线条检测核
                kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 15))
                
                # 顶帽变换突出亮线条
                tophat = cv2.morphologyEx(gray, cv2.MORPH_TOPHAT, kernel)
                
                # 黑帽变换突出暗线条
                blackhat = cv2.morphologyEx(gray, cv2.MORPH_BLACKHAT, kernel)
                
                # 合并结果
                enhanced = cv2.add(gray, tophat)
                enhanced = cv2.subtract(enhanced, blackhat)
                
                # 转回BGR
                processed_image = cv2.cvtColor(enhanced, cv2.COLOR_GRAY2BGR)
                steps.append("morphological_line_enhancement")
            
            elif self.config.line_detection_method == "gabor":
                # Gabor滤波器增强
                gray = cv2.cvtColor(processed_image, cv2.COLOR_BGR2GRAY)
                
                # Gabor滤波器参数
                kernels = []
                for theta in np.arange(0, np.pi, np.pi / 4):
                    kernel = cv2.getGaborKernel((21, 21), 5, theta, 2*np.pi, 0.5, 0, ktype=cv2.CV_32F)
                    kernels.append(kernel)
                
                # 应用Gabor滤波器
                enhanced = np.zeros_like(gray)
                for kernel in kernels:
                    filtered = cv2.filter2D(gray, cv2.CV_8UC3, kernel)
                    enhanced = cv2.max(enhanced, filtered)
                
                # 转回BGR
                processed_image = cv2.cvtColor(enhanced, cv2.COLOR_GRAY2BGR)
                steps.append("gabor_line_enhancement")
            
        except Exception as e:
            logger.warning(f"线条增强错误: {e}")
        
        return processed_image, steps
    
    def _apply_morphological_operations(self, image: np.ndarray) -> Tuple[np.ndarray, List[str]]:
        """应用形态学操作"""
        steps = []
        processed_image = image.copy()
        
        try:
            kernel_size = self.config.morphological_kernel_size
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_size, kernel_size))
            
            if self.config.morphological_operation == "opening":
                processed_image = cv2.morphologyEx(processed_image, cv2.MORPH_OPEN, kernel)
                steps.append(f"opening_{kernel_size}")
            
            elif self.config.morphological_operation == "closing":
                processed_image = cv2.morphologyEx(processed_image, cv2.MORPH_CLOSE, kernel)
                steps.append(f"closing_{kernel_size}")
            
            elif self.config.morphological_operation == "erosion":
                processed_image = cv2.erode(processed_image, kernel, iterations=1)
                steps.append(f"erosion_{kernel_size}")
            
            elif self.config.morphological_operation == "dilation":
                processed_image = cv2.dilate(processed_image, kernel, iterations=1)
                steps.append(f"dilation_{kernel_size}")
            
        except Exception as e:
            logger.warning(f"形态学操作错误: {e}")
        
        return processed_image, steps
    
    def _apply_binarization(self, image: np.ndarray) -> Tuple[np.ndarray, List[str]]:
        """应用二值化"""
        steps = []
        processed_image = image.copy()
        
        try:
            gray = cv2.cvtColor(processed_image, cv2.COLOR_BGR2GRAY)
            
            if self.config.binarization_method == "otsu":
                _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
                steps.append("otsu_binarization")
            
            elif self.config.binarization_method == "adaptive":
                binary = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                             cv2.THRESH_BINARY, 11, 2)
                steps.append("adaptive_binarization")
            
            elif self.config.binarization_method == "manual":
                _, binary = cv2.threshold(gray, self.config.threshold_value, 255, cv2.THRESH_BINARY)
                steps.append(f"manual_binarization_{self.config.threshold_value}")
            
            # 转回BGR
            processed_image = cv2.cvtColor(binary, cv2.COLOR_GRAY2BGR)
            
        except Exception as e:
            logger.warning(f"二值化错误: {e}")
        
        return processed_image, steps


class BatchImageProcessor:
    """批处理图像处理器"""
    
    def __init__(self, config: Optional[ProcessingConfig] = None, max_workers: int = 4):
        """
        初始化批处理器
        
        Args:
            config: 默认处理配置
            max_workers: 最大工作线程数
        """
        self.config = config or ProcessingConfig()
        self.max_workers = max_workers
        self.preprocessor = ImagePreprocessor(config)
        logger.info(f"批处理图像处理器初始化完成，最大工作线程数：{max_workers}")
    
    def process_batch(self, images: List[np.ndarray], 
                     configs: Optional[List[ProcessingConfig]] = None) -> List[ProcessingResult]:
        """
        批处理图像
        
        Args:
            images: 图像列表
            configs: 对应的处理配置列表
            
        Returns:
            List[ProcessingResult]: 处理结果列表
        """
        if not images:
            return []
        
        if configs is None:
            configs = [self.config] * len(images)
        elif len(configs) != len(images):
            raise ValueError("配置列表长度与图像列表长度不匹配")
        
        results = []
        
        try:
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = []
                
                for i, (image, config) in enumerate(zip(images, configs)):
                    future = executor.submit(self._process_single_image, image, config, i)
                    futures.append(future)
                
                # 收集结果
                for future in concurrent.futures.as_completed(futures):
                    try:
                        result = future.result()
                        results.append(result)
                    except Exception as e:
                        logger.error(f"图像处理错误: {e}")
                        logger.error(traceback.format_exc())
            
            # 按原始顺序排序
            results.sort(key=lambda x: x.metadata.get('image_index', 0))
            
            logger.info(f"批处理完成，处理了 {len(results)} 张图像")
            return results
            
        except Exception as e:
            logger.error(f"批处理错误: {e}")
            logger.error(traceback.format_exc())
            raise
    
    def _process_single_image(self, image: np.ndarray, config: ProcessingConfig, index: int) -> ProcessingResult:
        """处理单张图像"""
        try:
            result = self.preprocessor.preprocess_image(image, config)
            result.metadata['image_index'] = index
            return result
        except Exception as e:
            logger.error(f"图像 {index} 处理错误: {e}")
            raise
    
    def process_directory(self, input_dir: Union[str, Path], 
                         output_dir: Union[str, Path],
                         file_patterns: List[str] = None) -> List[ProcessingResult]:
        """
        处理目录中的所有图像文件
        
        Args:
            input_dir: 输入目录
            output_dir: 输出目录
            file_patterns: 文件模式列表，如 ['*.jpg', '*.png']
            
        Returns:
            List[ProcessingResult]: 处理结果列表
        """
        input_dir = Path(input_dir)
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        if file_patterns is None:
            file_patterns = ['*.jpg', '*.jpeg', '*.png', '*.bmp', '*.tiff']
        
        # 收集图像文件
        image_files = []
        for pattern in file_patterns:
            image_files.extend(input_dir.glob(pattern))
        
        if not image_files:
            logger.warning(f"在目录 {input_dir} 中未找到匹配的文件")
            return []
        
        logger.info(f"找到 {len(image_files)} 个图像文件")
        
        # 加载图像
        images = []
        valid_files = []
        
        for image_file in image_files:
            try:
                image = cv2.imread(str(image_file))
                if image is not None:
                    images.append(image)
                    valid_files.append(image_file)
                else:
                    logger.warning(f"无法读取图像文件: {image_file}")
            except Exception as e:
                logger.error(f"读取图像文件错误 {image_file}: {e}")
        
        if not images:
            logger.error("没有有效的图像文件")
            return []
        
        # 处理图像
        results = self.process_batch(images)
        
        # 保存处理后的图像
        for i, (result, image_file) in enumerate(zip(results, valid_files)):
            try:
                output_file = output_dir / f"processed_{image_file.name}"
                cv2.imwrite(str(output_file), result.processed_image)
                
                # 保存处理信息
                info_file = output_dir / f"{image_file.stem}_info.json"
                with open(info_file, 'w', encoding='utf-8') as f:
                    json.dump(result.to_dict(), f, ensure_ascii=False, indent=2)
                
                logger.info(f"保存处理结果: {output_file}")
                
            except Exception as e:
                logger.error(f"保存结果错误 {image_file}: {e}")
        
        return results


class AdvancedImageProcessor:
    """高级图像处理器"""
    
    @staticmethod
    def enhance_document_quality(image: np.ndarray) -> np.ndarray:
        """增强文档质量"""
        try:
            # 转换为灰度图
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
            
            # 1. 去噪
            denoised = cv2.fastNlMeansDenoising(gray, None, 10, 7, 21)
            
            # 2. 对比度增强
            clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
            enhanced = clahe.apply(denoised)
            
            # 3. 锐化
            kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
            sharpened = cv2.filter2D(enhanced, -1, kernel)
            
            # 4. 形态学操作去除小噪点
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
            cleaned = cv2.morphologyEx(sharpened, cv2.MORPH_OPEN, kernel)
            
            return cleaned
            
        except Exception as e:
            logger.error(f"文档质量增强错误: {e}")
            return image
    
    @staticmethod
    def detect_and_correct_skew(image: np.ndarray) -> Tuple[np.ndarray, float]:
        """检测并校正倾斜"""
        try:
            # 转换为灰度图
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
            
            # 二值化
            _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # 边缘检测
            edges = cv2.Canny(binary, 50, 150, apertureSize=3)
            
            # 霍夫线变换
            lines = cv2.HoughLines(edges, 1, np.pi/180, threshold=100)
            
            if lines is not None:
                angles = []
                for rho, theta in lines[:, 0]:
                    angle = np.degrees(theta) - 90
                    angles.append(angle)
                
                # 计算主要倾斜角度
                if angles:
                    median_angle = np.median(angles)
                    
                    # 旋转校正
                    if abs(median_angle) > 0.5:
                        center = (image.shape[1] // 2, image.shape[0] // 2)
                        rotation_matrix = cv2.getRotationMatrix2D(center, median_angle, 1.0)
                        corrected = cv2.warpAffine(image, rotation_matrix, 
                                                 (image.shape[1], image.shape[0]))
                        return corrected, median_angle
            
            return image, 0.0
            
        except Exception as e:
            logger.error(f"倾斜校正错误: {e}")
            return image, 0.0
    
    @staticmethod
    def extract_text_regions(image: np.ndarray) -> List[Tuple[int, int, int, int]]:
        """提取文本区域"""
        try:
            # 转换为灰度图
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
            
            # 二值化
            _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # 查找轮廓
            contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            text_regions = []
            for contour in contours:
                x, y, w, h = cv2.boundingRect(contour)
                
                # 过滤太小的区域
                if w > 20 and h > 20:
                    # 计算宽高比，过滤掉非文本区域
                    aspect_ratio = w / h
                    area = w * h
                    
                    # 文本区域通常有特定的宽高比和面积
                    if 0.1 < aspect_ratio < 10 and area > 100:
                        text_regions.append((x, y, w, h))
            
            return text_regions
            
        except Exception as e:
            logger.error(f"文本区域提取错误: {e}")
            return []
    
    @staticmethod
    def enhance_lines_and_edges(image: np.ndarray) -> np.ndarray:
        """增强线条和边缘"""
        try:
            # 转换为灰度图
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
            
            # 1. 高斯模糊减少噪声
            blurred = cv2.GaussianBlur(gray, (3, 3), 0)
            
            # 2. Sobel边缘检测
            sobel_x = cv2.Sobel(blurred, cv2.CV_64F, 1, 0, ksize=3)
            sobel_y = cv2.Sobel(blurred, cv2.CV_64F, 0, 1, ksize=3)
            
            # 3. 计算梯度幅值
            magnitude = np.sqrt(sobel_x**2 + sobel_y**2)
            magnitude = np.uint8(magnitude / magnitude.max() * 255)
            
            # 4. 阈值化
            _, edges = cv2.threshold(magnitude, 50, 255, cv2.THRESH_BINARY)
            
            # 5. 形态学操作连接断开的线条
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
            enhanced = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)
            
            return enhanced
            
        except Exception as e:
            logger.error(f"线条增强错误: {e}")
            return image


# 使用示例
if __name__ == "__main__":
    # 创建批处理器
    config = ProcessingConfig(
        resize_factor=1.5,
        denoise_method="bilateral",
        contrast_factor=1.3,
        enable_skew_correction=True,
        enable_line_enhancement=True,
        binarization_method="adaptive"
    )
    
    processor = BatchImageProcessor(config, max_workers=4)
    
    # 处理单张图像
    test_image = cv2.imread("test_image.jpg")
    if test_image is not None:
        result = processor.preprocessor.preprocess_image(test_image, config)
        print(f"处理步骤: {result.processing_steps}")
        print(f"处理时间: {result.processing_time:.2f}秒")
        
        # 保存结果
        cv2.imwrite("processed_image.jpg", result.processed_image)
        
        # 保存处理信息
        with open("processing_info.json", 'w', encoding='utf-8') as f:
            json.dump(result.to_dict(), f, ensure_ascii=False, indent=2)
    else:
        print("测试图像不存在")
