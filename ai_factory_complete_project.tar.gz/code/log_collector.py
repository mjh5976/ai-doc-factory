#!/usr/bin/env python3
"""
日志收集器 - 统一日志收集和聚合系统
支持多种日志源：文件、网络、数据库、API等
"""

import os
import sys
import time
import json
import logging
import threading
import queue
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, asdict
from concurrent.futures import ThreadPoolExecutor, as_completed
import socket
import socketio
import redis
import requests
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import yaml

@dataclass
class LogEntry:
    """标准化日志条目"""
    timestamp: str
    level: str
    source: str
    service: str
    message: str
    metadata: Dict[str, Any]
    trace_id: Optional[str] = None
    span_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

class LogCollector:
    """统一日志收集器"""
    
    def __init__(self, config_path: str = "config/log_config.yaml"):
        self.config = self._load_config(config_path)
        self.logger = logging.getLogger(__name__)
        self.log_queue = queue.Queue(maxsize=10000)
        self.processors = []
        self.running = False
        self.redis_client = None
        
        # 初始化Redis连接
        if self.config.get('redis'):
            self.redis_client = redis.Redis(
                host=self.config['redis']['host'],
                port=self.config['redis']['port'],
                decode_responses=True
            )
        
        # 设置日志格式
        self._setup_logging()
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载配置文件"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            print(f"配置文件加载失败: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """默认配置"""
        return {
            'collectors': {
                'file': {
                    'enabled': True,
                    'sources': [
                        {'path': '/var/log/app/*.log', 'service': 'app'},
                        {'path': '/var/log/nginx/*.log', 'service': 'nginx'},
                        {'path': '/var/log/database/*.log', 'service': 'database'}
                    ]
                },
                'network': {
                    'enabled': True,
                    'port': 514,
                    'protocol': 'udp'
                },
                'api': {
                    'enabled': False,
                    'endpoints': []
                }
            },
            'redis': {
                'host': 'localhost',
                'port': 6379
            },
            'processing': {
                'max_workers': 4,
                'batch_size': 100,
                'flush_interval': 5
            },
            'output': {
                'elasticsearch': {
                    'enabled': True,
                    'hosts': ['localhost:9200'],
                    'index_prefix': 'logs'
                },
                'kafka': {
                    'enabled': False,
                    'brokers': ['localhost:9092'],
                    'topic': 'logs'
                }
            }
        }
    
    def _setup_logging(self):
        """设置日志配置"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('/var/log/log_collector.log'),
                logging.StreamHandler(sys.stdout)
            ]
        )
    
    def add_processor(self, processor: Callable[[LogEntry], LogEntry]):
        """添加日志处理器"""
        self.processors.append(processor)
    
    def start(self):
        """启动日志收集器"""
        self.running = True
        self.logger.info("启动日志收集器...")
        
        # 启动文件监控
        if self.config['collectors']['file']['enabled']:
            self._start_file_collector()
        
        # 启动网络监听
        if self.config['collectors']['network']['enabled']:
            self._start_network_collector()
        
        # 启动处理线程
        self._start_processors()
        
        # 启动输出线程
        self._start_output_thread()
    
    def stop(self):
        """停止日志收集器"""
        self.running = False
        self.logger.info("停止日志收集器...")
    
    def _start_file_collector(self):
        """启动文件日志收集"""
        for source_config in self.config['collectors']['file']['sources']:
            watcher = FileLogWatcher(
                source_config['path'],
                source_config['service'],
                self.log_queue
            )
            observer = Observer()
            observer.schedule(watcher, os.path.dirname(source_config['path']), recursive=True)
            observer.start()
            self.logger.info(f"开始监控文件: {source_config['path']}")
    
    def _start_network_collector(self):
        """启动网络日志收集"""
        network_config = self.config['collectors']['network']
        collector = NetworkLogCollector(
            network_config['port'],
            network_config['protocol'],
            self.log_queue
        )
        collector.start()
    
    def _start_processors(self):
        """启动日志处理线程"""
        def process_logs():
            while self.running:
                try:
                    # 批量处理日志
                    batch = []
                    for _ in range(self.config['processing']['batch_size']):
                        try:
                            log_entry = self.log_queue.get(timeout=1)
                            batch.append(log_entry)
                        except queue.Empty:
                            break
                    
                    if batch:
                        self._process_batch(batch)
                
                except Exception as e:
                    self.logger.error(f"日志处理错误: {e}")
                    time.sleep(1)
        
        for i in range(self.config['processing']['max_workers']):
            thread = threading.Thread(target=process_logs, daemon=True)
            thread.start()
    
    def _process_batch(self, batch: List[LogEntry]):
        """批量处理日志"""
        for log_entry in batch:
            try:
                # 应用处理器链
                for processor in self.processors:
                    log_entry = processor(log_entry)
                
                # 发送到输出
                self._send_to_output(log_entry)
                
            except Exception as e:
                self.logger.error(f"处理日志条目失败: {e}")
    
    def _send_to_output(self, log_entry: LogEntry):
        """发送日志到输出端"""
        # 发送到Elasticsearch
        if self.config['output']['elasticsearch']['enabled']:
            self._send_to_elasticsearch(log_entry)
        
        # 发送到Kafka
        if self.config['output']['kafka']['enabled']:
            self._send_to_kafka(log_entry)
        
        # 发送到Redis
        if self.redis_client:
            self._send_to_redis(log_entry)
    
    def _send_to_elasticsearch(self, log_entry: LogEntry):
        """发送到Elasticsearch"""
        try:
            # 这里应该使用elasticsearch客户端
            # 为简化示例，直接打印
            self.logger.debug(f"发送到ES: {log_entry.to_dict()}")
        except Exception as e:
            self.logger.error(f"发送到ES失败: {e}")
    
    def _send_to_kafka(self, log_entry: LogEntry):
        """发送到Kafka"""
        try:
            # 这里应该使用kafka客户端
            # 为简化示例，直接打印
            self.logger.debug(f"发送到Kafka: {log_entry.to_dict()}")
        except Exception as e:
            self.logger.error(f"发送到Kafka失败: {e}")
    
    def _send_to_redis(self, log_entry: LogEntry):
        """发送到Redis"""
        try:
            if self.redis_client:
                # 使用时间戳作为key
                key = f"logs:{log_entry.timestamp}"
                self.redis_client.lpush(key, json.dumps(log_entry.to_dict()))
                # 设置过期时间（24小时）
                self.redis_client.expire(key, 86400)
        except Exception as e:
            self.logger.error(f"发送到Redis失败: {e}")

class FileLogWatcher(FileSystemEventHandler):
    """文件日志监控器"""
    
    def __init__(self, file_pattern: str, service: str, log_queue: queue.Queue):
        self.file_pattern = re.compile(file_pattern.replace('*', '.*'))
        self.service = service
        self.log_queue = log_queue
        self.file_positions = {}
    
    def on_modified(self, event):
        if event.is_directory:
            return
        
        if self.file_pattern.match(event.src_path):
            self._process_file(event.src_path)
    
    def _process_file(self, file_path: str):
        """处理文件日志"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                # 获取文件位置
                position = self.file_positions.get(file_path, 0)
                f.seek(position)
                
                for line in f:
                    log_entry = self._parse_log_line(line.strip(), file_path)
                    if log_entry:
                        self.log_queue.put(log_entry)
                
                # 更新文件位置
                self.file_positions[file_path] = f.tell()
        
        except Exception as e:
            logging.error(f"处理文件 {file_path} 失败: {e}")
    
    def _parse_log_line(self, line: str, file_path: str) -> Optional[LogEntry]:
        """解析日志行"""
        # 简单的日志解析模式
        patterns = [
            # 2024-01-01 12:00:00 [INFO] service: message
            r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\s+\[(\w+)\]\s+(\w+):\s+(.+)',
            # ISO format with level
            r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z)\s+(\w+)\s+(.+?):\s+(.+)'
        ]
        
        for pattern in patterns:
            match = re.match(pattern, line)
            if match:
                groups = match.groups()
                if len(groups) == 4:
                    timestamp, level, service, message = groups
                    return LogEntry(
                        timestamp=timestamp,
                        level=level.upper(),
                        source=file_path,
                        service=service,
                        message=message,
                        metadata={'file': file_path}
                    )
        
        # 默认解析
        return LogEntry(
            timestamp=datetime.now().isoformat(),
            level='INFO',
            source=file_path,
            service=self.service,
            message=line,
            metadata={'file': file_path}
        )

class NetworkLogCollector:
    """网络日志收集器"""
    
    def __init__(self, port: int, protocol: str, log_queue: queue.Queue):
        self.port = port
        self.protocol = protocol.lower()
        self.log_queue = log_queue
        self.running = False
        self.socket = None
    
    def start(self):
        """启动网络监听"""
        self.running = True
        
        if self.protocol == 'udp':
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        else:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        self.socket.bind(('0.0.0.0', self.port))
        
        if self.protocol == 'tcp':
            self.socket.listen(5)
        
        threading.Thread(target=self._listen_loop, daemon=True).start()
        logging.info(f"网络日志收集器启动，端口: {self.port}, 协议: {self.protocol}")
    
    def _listen_loop(self):
        """监听循环"""
        while self.running:
            try:
                if self.protocol == 'udp':
                    data, addr = self.socket.recvfrom(4096)
                    self._process_network_data(data.decode('utf-8'), addr)
                else:
                    conn, addr = self.socket.accept()
                    threading.Thread(target=self._handle_tcp_connection, 
                                   args=(conn, addr), daemon=True).start()
            except Exception as e:
                logging.error(f"网络监听错误: {e}")
                time.sleep(1)
    
    def _handle_tcp_connection(self, conn, addr):
        """处理TCP连接"""
        try:
            while self.running:
                data = conn.recv(4096)
                if not data:
                    break
                self._process_network_data(data.decode('utf-8'), addr)
        except Exception as e:
            logging.error(f"TCP连接处理错误: {e}")
        finally:
            conn.close()
    
    def _process_network_data(self, data: str, addr):
        """处理网络数据"""
        try:
            # 解析网络日志数据
            log_entry = LogEntry(
                timestamp=datetime.now().isoformat(),
                level='INFO',
                source=f"network:{addr[0]}:{addr[1]}",
                service='network',
                message=data.strip(),
                metadata={'source_ip': addr[0], 'source_port': addr[1]}
            )
            self.log_queue.put(log_entry)
        except Exception as e:
            logging.error(f"处理网络数据失败: {e}")

def main():
    """主函数"""
    # 创建日志收集器
    collector = LogCollector()
    
    # 添加日志处理器
    collector.add_processor(add_trace_context)
    collector.add_processor(enrich_with_host_info)
    collector.add_processor(validate_log_entry)
    
    try:
        collector.start()
        
        # 保持运行
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        logging.info("接收到停止信号")
        collector.stop()

def add_trace_context(log_entry: LogEntry) -> LogEntry:
    """添加追踪上下文"""
    # 从消息中提取trace_id和span_id
    message = log_entry.message
    trace_match = re.search(r'trace_id:([a-zA-Z0-9-]+)', message)
    span_match = re.search(r'span_id:([a-zA-Z0-9-]+)', message)
    
    if trace_match:
        log_entry.trace_id = trace_match.group(1)
    if span_match:
        log_entry.span_id = span_match.group(1)
    
    return log_entry

def enrich_with_host_info(log_entry: LogEntry) -> LogEntry:
    """丰富主机信息"""
    log_entry.metadata.update({
        'hostname': socket.gethostname(),
        'ip_address': socket.gethostbyname(socket.gethostname()),
        'pid': os.getpid()
    })
    return log_entry

def validate_log_entry(log_entry: LogEntry) -> LogEntry:
    """验证日志条目"""
    # 确保必需字段不为空
    if not log_entry.timestamp:
        log_entry.timestamp = datetime.now().isoformat()
    if not log_entry.level:
        log_entry.level = 'INFO'
    if not log_entry.service:
        log_entry.service = 'unknown'
    
    return log_entry

if __name__ == "__main__":
    main()
