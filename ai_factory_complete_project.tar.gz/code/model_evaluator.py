#!/usr/bin/env python3
"""
模型验证和评估模块
自动模型验证、性能评估和A/B测试
"""

import os
import json
import time
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Union
from dataclasses import dataclass, asdict
from enum import Enum
import yaml
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
import mlflow
import mlflow.pytorch
import mlflow.sklearn
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, precision_recall_curve,
    confusion_matrix, classification_report,
    mean_absolute_error, mean_squared_error, r2_score
)
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger(__name__)

class EvaluationType(Enum):
    """评估类型枚举"""
    CLASSIFICATION = "classification"
    REGRESSION = "regression"
    CLUSTERING = "clustering"
    RANKING = "ranking"

class TestType(Enum):
    """测试类型枚举"""
    A_B_TEST = "a_b_test"
    REGRESSION_TEST = "regression_test"
    PERFORMANCE_TEST = "performance_test"
    STRESS_TEST = "stress_test"

@dataclass
class EvaluationResult:
    """评估结果数据类"""
    model_version: str
    evaluation_type: EvaluationType
    metrics: Dict[str, float]
    confusion_matrix: Optional[np.ndarray] = None
    roc_curve: Optional[Tuple[np.ndarray, np.ndarray, np.ndarray]] = None
    precision_recall_curve: Optional[Tuple[np.ndarray, np.ndarray, np.ndarray]] = None
    feature_importance: Optional[Dict[str, float]] = None
    execution_time: float = 0.0
    timestamp: datetime = None

@dataclass
class ABTestResult:
    """A/B测试结果数据类"""
    test_id: str
    control_model: str
    treatment_model: str
    control_metrics: Dict[str, float]
    treatment_metrics: Dict[str, float]
    statistical_significance: Dict[str, float]
    recommendation: str
    confidence_level: float
    sample_size: int
    test_duration_hours: float
    start_time: datetime
    end_time: datetime

class ModelEvaluator:
    """模型评估器"""
    
    def __init__(self, config_path: str = "config/model_evaluator_config.yaml"):
        """初始化模型评估器"""
        self.config = self._load_config(config_path)
        self.setup_logging()
        self.setup_mlflow()
        self.setup_storage()
        
        # 评估缓存
        self.evaluation_cache = {}
        
        logger.info("模型评估器初始化完成")
    
    def _load_config(self, config_path: str) -> Dict:
        """加载配置文件"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            logger.info(f"模型评估器配置文件加载成功: {config_path}")
            return config
        except Exception as e:
            logger.error(f"模型评估器配置文件加载失败: {e}")
            raise
    
    def setup_logging(self):
        """设置日志"""
        log_config = self.config.get('logging', {})
        log_dir = Path(log_config.get('directory', 'logs'))
        log_dir.mkdir(exist_ok=True)
        
        # 配置日志格式
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        file_handler = logging.FileHandler(log_dir / 'model_evaluator.log')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logging.INFO)
        
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)
        
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
    
    def setup_mlflow(self):
        """设置MLflow"""
        mlflow_config = self.config['mlflow']
        
        mlflow.set_tracking_uri(mlflow_config['tracking_uri'])
        mlflow.set_experiment(mlflow_config['experiment_name'])
        
        logger.info("MLflow设置完成")
    
    def setup_storage(self):
        """设置存储"""
        storage_config = self.config['storage']
        
        # 创建存储目录
        for dir_path in ['evaluations', 'reports', 'charts']:
            Path(storage_config['base_path'] / dir_path).mkdir(parents=True, exist_ok=True)
        
        self.storage_config = storage_config
    
    def evaluate_model(self, model, X_test, y_test, model_version: str, 
                      evaluation_type: EvaluationType = EvaluationType.CLASSIFICATION) -> EvaluationResult:
        """评估模型"""
        logger.info(f"开始评估模型: {model_version}")
        
        start_time = time.time()
        
        try:
            # 根据评估类型选择评估方法
            if evaluation_type == EvaluationType.CLASSIFICATION:
                result = self._evaluate_classification_model(model, X_test, y_test, model_version)
            elif evaluation_type == EvaluationType.REGRESSION:
                result = self._evaluate_regression_model(model, X_test, y_test, model_version)
            elif evaluation_type == EvaluationType.CLUSTERING:
                result = self._evaluate_clustering_model(model, X_test, y_test, model_version)
            elif evaluation_type == EvaluationType.RANKING:
                result = self._evaluate_ranking_model(model, X_test, y_test, model_version)
            else:
                raise ValueError(f"不支持的评估类型: {evaluation_type}")
            
            # 设置执行时间
            result.execution_time = time.time() - start_time
            result.timestamp = datetime.now()
            
            # 保存评估结果
            self._save_evaluation_result(result)
            
            # 记录到MLflow
            self._log_evaluation_to_mlflow(result)
            
            logger.info(f"模型评估完成: {model_version}, 执行时间: {result.execution_time:.2f}秒")
            return result
            
        except Exception as e:
            logger.error(f"模型评估失败 {model_version}: {e}")
            raise
    
    def _evaluate_classification_model(self, model, X_test, y_test, model_version: str) -> EvaluationResult:
        """评估分类模型"""
        logger.info("评估分类模型...")
        
        # 预测
        y_pred = model.predict(X_test)
        y_pred_proba = None
        
        # 如果模型支持概率预测
        if hasattr(model, 'predict_proba'):
            y_pred_proba = model.predict_proba(X_test)
        elif hasattr(model, 'decision_function'):
            y_pred_proba = model.decision_function(X_test)
        
        # 计算指标
        metrics = {
            'accuracy': accuracy_score(y_test, y_pred),
            'precision': precision_score(y_test, y_pred, average='weighted', zero_division=0),
            'recall': recall_score(y_test, y_pred, average='weighted', zero_division=0),
            'f1_score': f1_score(y_test, y_pred, average='weighted', zero_division=0)
        }
        
        # 如果有概率预测，计算AUC
        if y_pred_proba is not None:
            try:
                if len(np.unique(y_test)) == 2:  # 二分类
                    if y_pred_proba.shape[1] == 2:
                        metrics['auc'] = roc_auc_score(y_test, y_pred_proba[:, 1])
                    else:
                        metrics['auc'] = roc_auc_score(y_test, y_pred_proba)
                else:  # 多分类
                    metrics['auc'] = roc_auc_score(y_test, y_pred_proba, multi_class='ovr', average='weighted')
            except Exception as e:
                logger.warning(f"计算AUC失败: {e}")
                metrics['auc'] = 0.0
        
        # 生成混淆矩阵
        cm = confusion_matrix(y_test, y_pred)
        
        # 生成ROC曲线
        roc_curve_data = None
        if y_pred_proba is not None and len(np.unique(y_test)) == 2:
            try:
                fpr, tpr, thresholds = roc_curve(y_test, y_pred_proba[:, 1] if y_pred_proba.shape[1] == 2 else y_pred_proba)
                roc_curve_data = (fpr, tpr, thresholds)
            except Exception as e:
                logger.warning(f"生成ROC曲线失败: {e}")
        
        # 生成Precision-Recall曲线
        pr_curve_data = None
        if y_pred_proba is not None and len(np.unique(y_test)) == 2:
            try:
                precision, recall, thresholds = precision_recall_curve(y_test, y_pred_proba[:, 1] if y_pred_proba.shape[1] == 2 else y_pred_proba)
                pr_curve_data = (precision, recall, thresholds)
            except Exception as e:
                logger.warning(f"生成Precision-Recall曲线失败: {e}")
        
        # 生成评估图表
        self._generate_classification_charts(model_version, y_test, y_pred, y_pred_proba, cm, roc_curve_data, pr_curve_data)
        
        return EvaluationResult(
            model_version=model_version,
            evaluation_type=EvaluationType.CLASSIFICATION,
            metrics=metrics,
            confusion_matrix=cm,
            roc_curve=roc_curve_data,
            precision_recall_curve=pr_curve_data
        )
    
    def _evaluate_regression_model(self, model, X_test, y_test, model_version: str) -> EvaluationResult:
        """评估回归模型"""
        logger.info("评估回归模型...")
        
        # 预测
        y_pred = model.predict(X_test)
        
        # 计算指标
        metrics = {
            'mae': mean_absolute_error(y_test, y_pred),
            'mse': mean_squared_error(y_test, y_pred),
            'rmse': np.sqrt(mean_squared_error(y_test, y_pred)),
            'r2_score': r2_score(y_test, y_pred)
        }
        
        # 生成回归图表
        self._generate_regression_charts(model_version, y_test, y_pred)
        
        return EvaluationResult(
            model_version=model_version,
            evaluation_type=EvaluationType.REGRESSION,
            metrics=metrics
        )
    
    def _evaluate_clustering_model(self, model, X_test, y_test, model_version: str) -> EvaluationResult:
        """评估聚类模型"""
        logger.info("评估聚类模型...")
        
        # 预测聚类标签
        y_pred = model.predict(X_test)
        
        # 计算聚类指标
        from sklearn.metrics import adjusted_rand_score, silhouette_score, calinski_harabasz_score
        
        metrics = {
            'adjusted_rand_score': adjusted_rand_score(y_test, y_pred),
            'silhouette_score': silhouette_score(X_test, y_pred),
            'calinski_harabasz_score': calinski_harabasz_score(X_test, y_pred)
        }
        
        # 生成聚类图表
        self._generate_clustering_charts(model_version, X_test, y_pred)
        
        return EvaluationResult(
            model_version=model_version,
            evaluation_type=EvaluationType.CLUSTERING,
            metrics=metrics
        )
    
    def _evaluate_ranking_model(self, model, X_test, y_test, model_version: str) -> EvaluationResult:
        """评估排序模型"""
        logger.info("评估排序模型...")
        
        # 预测
        y_pred = model.predict(X_test)
        
        # 计算排序指标
        from sklearn.metrics import ndcg_score
        
        # 假设y_test是相关性分数，y_pred是预测分数
        try:
            # 将数据转换为正确的格式
            y_true_2d = y_test.values.reshape(1, -1) if hasattr(y_test, 'values') else np.array(y_test).reshape(1, -1)
            y_score_2d = y_pred.reshape(1, -1)
            
            metrics = {
                'ndcg_score': ndcg_score(y_true_2d, y_score_2d)
            }
        except Exception as e:
            logger.warning(f"计算NDCG分数失败: {e}")
            metrics = {'ndcg_score': 0.0}
        
        # 生成排序图表
        self._generate_ranking_charts(model_version, y_test, y_pred)
        
        return EvaluationResult(
            model_version=model_version,
            evaluation_type=EvaluationType.RANKING,
            metrics=metrics
        )
    
    def _generate_classification_charts(self, model_version: str, y_test, y_pred, y_pred_proba, 
                                      cm, roc_curve_data, pr_curve_data):
        """生成分类评估图表"""
        try:
            charts_dir = Path(self.storage_config['base_path']) / 'charts'
            charts_dir.mkdir(parents=True, exist_ok=True)
            
            # 设置中文字体
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False
            
            fig, axes = plt.subplots(2, 2, figsize=(15, 10))
            fig.suptitle(f'模型 {model_version} 分类评估', fontsize=16)
            
            # 混淆矩阵
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[0, 0])
            axes[0, 0].set_title('混淆矩阵')
            axes[0, 0].set_xlabel('预测标签')
            axes[0, 0].set_ylabel('真实标签')
            
            # ROC曲线
            if roc_curve_data:
                fpr, tpr, _ = roc_curve_data
                axes[0, 1].plot(fpr, tpr, label='ROC曲线')
                axes[0, 1].plot([0, 1], [0, 1], 'k--', label='随机分类器')
                axes[0, 1].set_xlabel('假正率 (FPR)')
                axes[0, 1].set_ylabel('真正率 (TPR)')
                axes[0, 1].set_title('ROC曲线')
                axes[0, 1].legend()
            else:
                axes[0, 1].text(0.5, 0.5, 'ROC曲线不可用', ha='center', va='center', transform=axes[0, 1].transAxes)
                axes[0, 1].set_title('ROC曲线')
            
            # Precision-Recall曲线
            if pr_curve_data:
                precision, recall, _ = pr_curve_data
                axes[1, 0].plot(recall, precision, label='Precision-Recall曲线')
                axes[1, 0].set_xlabel('召回率 (Recall)')
                axes[1, 0].set_ylabel('精确率 (Precision)')
                axes[1, 0].set_title('Precision-Recall曲线')
                axes[1, 0].legend()
            else:
                axes[1, 0].text(0.5, 0.5, 'Precision-Recall曲线不可用', ha='center', va='center', transform=axes[1, 0].transAxes)
                axes[1, 0].set_title('Precision-Recall曲线')
            
            # 预测分布
            if y_pred_proba is not None:
                if y_pred_proba.shape[1] == 2:  # 二分类
                    proba = y_pred_proba[:, 1]
                else:  # 多分类
                    proba = np.max(y_pred_proba, axis=1)
                
                axes[1, 1].hist(proba, bins=30, alpha=0.7, color='skyblue')
                axes[1, 1].set_xlabel('预测概率')
                axes[1, 1].set_ylabel('频次')
                axes[1, 1].set_title('预测概率分布')
            else:
                # 显示预测标签分布
                unique, counts = np.unique(y_pred, return_counts=True)
                axes[1, 1].bar(unique, counts, color='lightgreen')
                axes[1, 1].set_xlabel('预测标签')
                axes[1, 1].set_ylabel('数量')
                axes[1, 1].set_title('预测标签分布')
            
            plt.tight_layout()
            
            # 保存图表
            chart_path = charts_dir / f'{model_version}_classification_evaluation.png'
            plt.savefig(chart_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info(f"分类评估图表已生成: {chart_path}")
            
        except Exception as e:
            logger.error(f"生成分类评估图表失败: {e}")
    
    def _generate_regression_charts(self, model_version: str, y_test, y_pred):
        """生成回归评估图表"""
        try:
            charts_dir = Path(self.storage_config['base_path']) / 'charts'
            charts_dir.mkdir(parents=True, exist_ok=True)
            
            # 设置中文字体
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False
            
            fig, axes = plt.subplots(2, 2, figsize=(15, 10))
            fig.suptitle(f'模型 {model_version} 回归评估', fontsize=16)
            
            # 预测 vs 真实值散点图
            axes[0, 0].scatter(y_test, y_pred, alpha=0.6)
            min_val = min(min(y_test), min(y_pred))
            max_val = max(max(y_test), max(y_pred))
            axes[0, 0].plot([min_val, max_val], [min_val, max_val], 'r--', lw=2)
            axes[0, 0].set_xlabel('真实值')
            axes[0, 0].set_ylabel('预测值')
            axes[0, 0].set_title('预测值 vs 真实值')
            
            # 残差图
            residuals = y_test - y_pred
            axes[0, 1].scatter(y_pred, residuals, alpha=0.6)
            axes[0, 1].axhline(y=0, color='r', linestyle='--')
            axes[0, 1].set_xlabel('预测值')
            axes[0, 1].set_ylabel('残差')
            axes[0, 1].set_title('残差图')
            
            # 残差直方图
            axes[1, 0].hist(residuals, bins=30, alpha=0.7, color='skyblue')
            axes[1, 0].set_xlabel('残差')
            axes[1, 0].set_ylabel('频次')
            axes[1, 0].set_title('残差分布')
            
            # Q-Q图
            from scipy.stats import probplot
            probplot(residuals, dist="norm", plot=axes[1, 1])
            axes[1, 1].set_title('Q-Q图')
            
            plt.tight_layout()
            
            # 保存图表
            chart_path = charts_dir / f'{model_version}_regression_evaluation.png'
            plt.savefig(chart_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info(f"回归评估图表已生成: {chart_path}")
            
        except Exception as e:
            logger.error(f"生成回归评估图表失败: {e}")
    
    def _generate_clustering_charts(self, model_version: str, X_test, y_pred):
        """生成聚类评估图表"""
        try:
            charts_dir = Path(self.storage_config['base_path']) / 'charts'
            charts_dir.mkdir(parents=True, exist_ok=True)
            
            # 设置中文字体
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False
            
            # 如果数据维度太高，先降维
            if X_test.shape[1] > 2:
                from sklearn.decomposition import PCA
                pca = PCA(n_components=2)
                X_2d = pca.fit_transform(X_test)
            else:
                X_2d = X_test
            
            fig, axes = plt.subplots(1, 2, figsize=(15, 6))
            fig.suptitle(f'模型 {model_version} 聚类评估', fontsize=16)
            
            # 聚类结果
            scatter = axes[0].scatter(X_2d[:, 0], X_2d[:, 1], c=y_pred, cmap='viridis', alpha=0.6)
            axes[0].set_title('聚类结果')
            axes[0].set_xlabel('主成分1')
            axes[0].set_ylabel('主成分2')
            plt.colorbar(scatter, ax=axes[0])
            
            # 聚类大小分布
            unique, counts = np.unique(y_pred, return_counts=True)
            axes[1].bar(unique, counts, color='lightgreen')
            axes[1].set_xlabel('聚类标签')
            axes[1].set_ylabel('样本数量')
            axes[1].set_title('聚类大小分布')
            
            plt.tight_layout()
            
            # 保存图表
            chart_path = charts_dir / f'{model_version}_clustering_evaluation.png'
            plt.savefig(chart_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info(f"聚类评估图表已生成: {chart_path}")
            
        except Exception as e:
            logger.error(f"生成聚类评估图表失败: {e}")
    
    def _generate_ranking_charts(self, model_version: str, y_test, y_pred):
        """生成排序评估图表"""
        try:
            charts_dir = Path(self.storage_config['base_path']) / 'charts'
            charts_dir.mkdir(parents=True, exist_ok=True)
            
            # 设置中文字体
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False
            
            fig, axes = plt.subplots(1, 2, figsize=(15, 6))
            fig.suptitle(f'模型 {model_version} 排序评估', fontsize=16)
            
            # 预测分数分布
            axes[0].hist(y_pred, bins=30, alpha=0.7, color='skyblue')
            axes[0].set_xlabel('预测分数')
            axes[0].set_ylabel('频次')
            axes[0].set_title('预测分数分布')
            
            # 真实相关性分布
            axes[1].hist(y_test, bins=30, alpha=0.7, color='lightgreen')
            axes[1].set_xlabel('真实相关性')
            axes[1].set_ylabel('频次')
            axes[1].set_title('真实相关性分布')
            
            plt.tight_layout()
            
            # 保存图表
            chart_path = charts_dir / f'{model_version}_ranking_evaluation.png'
            plt.savefig(chart_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info(f"排序评估图表已生成: {chart_path}")
            
        except Exception as e:
            logger.error(f"生成排序评估图表失败: {e}")
    
    def _save_evaluation_result(self, result: EvaluationResult):
        """保存评估结果"""
        try:
            # 保存到文件
            eval_dir = Path(self.storage_config['base_path']) / 'evaluations'
            eval_dir.mkdir(parents=True, exist_ok=True)
            
            result_file = eval_dir / f'{result.model_version}_evaluation_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
            
            # 转换结果为可序列化的格式
            result_dict = asdict(result)
            result_dict['timestamp'] = result.timestamp.isoformat() if result.timestamp else None
            
            # 处理numpy数组
            if result_dict['confusion_matrix'] is not None:
                result_dict['confusion_matrix'] = result_dict['confusion_matrix'].tolist()
            
            if result_dict['roc_curve'] is not None:
                result_dict['roc_curve'] = [
                    result_dict['roc_curve'][0].tolist(),
                    result_dict['roc_curve'][1].tolist(),
                    result_dict['roc_curve'][2].tolist()
                ]
            
            if result_dict['precision_recall_curve'] is not None:
                result_dict['precision_recall_curve'] = [
                    result_dict['precision_recall_curve'][0].tolist(),
                    result_dict['precision_recall_curve'][1].tolist(),
                    result_dict['precision_recall_curve'][2].tolist()
                ]
            
            with open(result_file, 'w', encoding='utf-8') as f:
                json.dump(result_dict, f, indent=2, ensure_ascii=False, default=str)
            
            logger.info(f"评估结果已保存: {result_file}")
            
        except Exception as e:
            logger.error(f"保存评估结果失败: {e}")
    
    def _log_evaluation_to_mlflow(self, result: EvaluationResult):
        """记录评估结果到MLflow"""
        try:
            with mlflow.start_run():
                # 记录指标
                for metric_name, metric_value in result.metrics.items():
                    mlflow.log_metric(f"eval_{metric_name}", metric_value)
                
                # 记录执行时间
                mlflow.log_metric("eval_execution_time", result.execution_time)
                
                # 记录评估类型
                mlflow.log_param("evaluation_type", result.evaluation_type.value)
                
                # 记录图表文件
                chart_files = list(Path(self.storage_config['base_path'] / 'charts').glob(f'{result.model_version}_*.png'))
                for chart_file in chart_files:
                    mlflow.log_artifact(str(chart_file))
                
        except Exception as e:
            logger.error(f"记录评估结果到MLflow失败: {e}")
    
    def run_ab_test(self, control_model, treatment_model, X_test, y_test, 
                   test_config: Dict) -> ABTestResult:
        """运行A/B测试"""
        logger.info("开始A/B测试...")
        
        try:
            test_id = f"ab_test_{int(time.time())}"
            start_time = datetime.now()
            
            # 获取测试配置
            confidence_level = test_config.get('confidence_level', 0.95)
            min_sample_size = test_config.get('min_sample_size', 100)
            test_duration_hours = test_config.get('test_duration_hours', 24)
            
            # 评估控制模型
            control_result = self.evaluate_model(control_model, X_test, y_test, "control_model")
            control_metrics = control_result.metrics
            
            # 评估实验模型
            treatment_result = self.evaluate_model(treatment_model, X_test, y_test, "treatment_model")
            treatment_metrics = treatment_result.metrics
            
            # 统计显著性检验
            statistical_significance = self._perform_statistical_tests(
                control_metrics, treatment_metrics, confidence_level
            )
            
            # 生成推荐
            recommendation = self._generate_ab_test_recommendation(
                control_metrics, treatment_metrics, statistical_significance
            )
            
            end_time = datetime.now()
            
            result = ABTestResult(
                test_id=test_id,
                control_model="control_model",
                treatment_model="treatment_model",
                control_metrics=control_metrics,
                treatment_metrics=treatment_metrics,
                statistical_significance=statistical_significance,
                recommendation=recommendation,
                confidence_level=confidence_level,
                sample_size=len(X_test),
                test_duration_hours=(end_time - start_time).total_seconds() / 3600,
                start_time=start_time,
                end_time=end_time
            )
            
            # 保存A/B测试结果
            self._save_ab_test_result(result)
            
            # 记录到MLflow
            self._log_ab_test_to_mlflow(result)
            
            logger.info(f"A/B测试完成: {test_id}")
            return result
            
        except Exception as e:
            logger.error(f"A/B测试失败: {e}")
            raise
    
    def _perform_statistical_tests(self, control_metrics: Dict, treatment_metrics: Dict, 
                                 confidence_level: float) -> Dict[str, float]:
        """执行统计显著性检验"""
        significance = {}
        
        try:
            alpha = 1 - confidence_level
            
            # 对每个指标进行t检验
            for metric_name in control_metrics.keys():
                if metric_name in treatment_metrics:
                    control_value = control_metrics[metric_name]
                    treatment_value = treatment_metrics[metric_name]
                    
                    # 模拟样本数据进行t检验
                    # 在实际应用中，需要使用原始预测结果
                    np.random.seed(42)  # 为了可重现性
                    control_samples = np.random.normal(control_value, 0.1, 100)
                    treatment_samples = np.random.normal(treatment_value, 0.1, 100)
                    
                    # 执行t检验
                    t_stat, p_value = stats.ttest_ind(control_samples, treatment_samples)
                    
                    significance[f"{metric_name}_p_value"] = p_value
                    significance[f"{metric_name}_significant"] = p_value < alpha
                    significance[f"{metric_name}_effect_size"] = abs(treatment_value - control_value)
            
        except Exception as e:
            logger.error(f"统计显著性检验失败: {e}")
        
        return significance
    
    def _generate_ab_test_recommendation(self, control_metrics: Dict, treatment_metrics: Dict,
                                       statistical_significance: Dict) -> str:
        """生成A/B测试推荐"""
        try:
            # 计算总体改善
            improvements = []
            significant_improvements = 0
            
            for metric_name, control_value in control_metrics.items():
                if metric_name in treatment_metrics:
                    treatment_value = treatment_metrics[metric_name]
                    
                    # 对于准确率、F1等指标，值越高越好
                    if metric_name in ['accuracy', 'precision', 'recall', 'f1_score', 'auc', 'r2_score']:
                        improvement = (treatment_value - control_value) / control_value if control_value != 0 else 0
                    else:  # 对于错误率、损失等指标，值越低越好
                        improvement = (control_value - treatment_value) / control_value if control_value != 0 else 0
                    
                    improvements.append(improvement)
                    
                    # 检查是否显著改善
                    sig_key = f"{metric_name}_significant"
                    if sig_key in statistical_significance and statistical_significance[sig_key]:
                        significant_improvements += 1
            
            avg_improvement = np.mean(improvements) if improvements else 0
            
            # 生成推荐
            if significant_improvements > 0 and avg_improvement > 0.01:  # 1%改善
                return "推荐采用实验模型，显著改善了关键指标"
            elif significant_improvements > 0 and avg_improvement < -0.01:
                return "推荐保持控制模型，实验模型显著降低了性能"
            elif avg_improvement > 0.005:  # 0.5%改善
                return "实验模型略有改善，但统计显著性不足，建议延长测试时间"
            elif avg_improvement < -0.005:
                return "实验模型略有下降，但统计显著性不足，建议调查原因"
            else:
                return "两个模型性能相当，无明显差异"
                
        except Exception as e:
            logger.error(f"生成A/B测试推荐失败: {e}")
            return "无法生成推荐，需要进一步分析"
    
    def _save_ab_test_result(self, result: ABTestResult):
        """保存A/B测试结果"""
        try:
            reports_dir = Path(self.storage_config['base_path']) / 'reports'
            reports_dir.mkdir(parents=True, exist_ok=True)
            
            result_file = reports_dir / f'{result.test_id}_ab_test_result.json'
            
            # 转换结果为可序列化的格式
            result_dict = asdict(result)
            result_dict['start_time'] = result.start_time.isoformat()
            result_dict['end_time'] = result.end_time.isoformat()
            
            with open(result_file, 'w', encoding='utf-8') as f:
                json.dump(result_dict, f, indent=2, ensure_ascii=False, default=str)
            
            logger.info(f"A/B测试结果已保存: {result_file}")
            
        except Exception as e:
            logger.error(f"保存A/B测试结果失败: {e}")
    
    def _log_ab_test_to_mlflow(self, result: ABTestResult):
        """记录A/B测试结果到MLflow"""
        try:
            with mlflow.start_run():
                # 记录测试配置
                mlflow.log_param("test_id", result.test_id)
                mlflow.log_param("confidence_level", result.confidence_level)
                mlflow.log_param("sample_size", result.sample_size)
                mlflow.log_param("test_duration_hours", result.test_duration_hours)
                
                # 记录控制模型指标
                for metric_name, metric_value in result.control_metrics.items():
                    mlflow.log_metric(f"control_{metric_name}", metric_value)
                
                # 记录实验模型指标
                for metric_name, metric_value in result.treatment_metrics.items():
                    mlflow.log_metric(f"treatment_{metric_name}", metric_value)
                
                # 记录统计显著性
                for sig_name, sig_value in result.statistical_significance.items():
                    mlflow.log_metric(f"sig_{sig_name}", sig_value)
                
                # 记录推荐
                mlflow.log_param("recommendation", result.recommendation)
                
        except Exception as e:
            logger.error(f"记录A/B测试结果到MLflow失败: {e}")
    
    def run_regression_test(self, model, baseline_metrics: Dict, current_metrics: Dict,
                          tolerance: float = 0.05) -> Dict:
        """运行回归测试"""
        logger.info("运行回归测试...")
        
        try:
            regression_results = {}
            
            for metric_name, baseline_value in baseline_metrics.items():
                if metric_name in current_metrics:
                    current_value = current_metrics[metric_name]
                    
                    # 计算退化程度
                    if baseline_value != 0:
                        degradation = (baseline_value - current_value) / baseline_value
                    else:
                        degradation = 0
                    
                    # 判断是否回归
                    is_regression = degradation > tolerance
                    
                    regression_results[metric_name] = {
                        'baseline_value': baseline_value,
                        'current_value': current_value,
                        'degradation': degradation,
                        'tolerance': tolerance,
                        'is_regression': is_regression,
                        'status': 'REGRESSION' if is_regression else 'PASS'
                    }
            
            # 生成回归测试报告
            self._generate_regression_test_report(regression_results)
            
            # 记录到MLflow
            self._log_regression_test_to_mlflow(regression_results)
            
            logger.info("回归测试完成")
            return regression_results
            
        except Exception as e:
            logger.error(f"回归测试失败: {e}")
            raise
    
    def _generate_regression_test_report(self, regression_results: Dict):
        """生成回归测试报告"""
        try:
            reports_dir = Path(self.storage_config['base_path']) / 'reports'
            reports_dir.mkdir(parents=True, exist_ok=True)
            
            report_file = reports_dir / f'regression_test_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
            
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(regression_results, f, indent=2, ensure_ascii=False, default=str)
            
            logger.info(f"回归测试报告已生成: {report_file}")
            
        except Exception as e:
            logger.error(f"生成回归测试报告失败: {e}")
    
    def _log_regression_test_to_mlflow(self, regression_results: Dict):
        """记录回归测试结果到MLflow"""
        try:
            with mlflow.start_run():
                for metric_name, result in regression_results.items():
                    mlflow.log_metric(f"regression_{metric_name}_degradation", result['degradation'])
                    mlflow.log_param(f"regression_{metric_name}_status", result['status'])
                    
        except Exception as e:
            logger.error(f"记录回归测试结果到MLflow失败: {e}")
    
    def generate_evaluation_report(self, model_version: str, evaluation_results: List[EvaluationResult]) -> Dict:
        """生成评估报告"""
        logger.info(f"生成模型 {model_version} 的评估报告...")
        
        try:
            report = {
                'model_version': model_version,
                'timestamp': datetime.now().isoformat(),
                'evaluation_count': len(evaluation_results),
                'latest_evaluation': asdict(evaluation_results[-1]) if evaluation_results else None,
                'performance_summary': self._generate_performance_summary(evaluation_results),
                'recommendations': self._generate_evaluation_recommendations(evaluation_results)
            }
            
            # 保存报告
            report_path = Path(self.storage_config['base_path']) / 'reports' / f'{model_version}_evaluation_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
            report_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(report_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False, default=str)
            
            logger.info(f"评估报告已生成: {report_path}")
            return report
            
        except Exception as e:
            logger.error(f"生成评估报告失败: {e}")
            return {}
    
    def _generate_performance_summary(self, evaluation_results: List[EvaluationResult]) -> Dict:
        """生成性能摘要"""
        if not evaluation_results:
            return {}
        
        # 按评估类型分组
        by_type = {}
        for result in evaluation_results:
            eval_type = result.evaluation_type.value
            if eval_type not in by_type:
                by_type[eval_type] = []
            by_type[eval_type].append(result.metrics)
        
        summary = {}
        for eval_type, metrics_list in by_type.items():
            # 计算平均值
            avg_metrics = {}
            for metric_name in metrics_list[0].keys():
                values = [m[metric_name] for m in metrics_list if metric_name in m]
                avg_metrics[metric_name] = np.mean(values) if values else 0
            
            summary[eval_type] = {
                'average_metrics': avg_metrics,
                'evaluation_count': len(metrics_list)
            }
        
        return summary
    
    def _generate_evaluation_recommendations(self, evaluation_results: List[EvaluationResult]) -> List[str]:
        """生成评估建议"""
        recommendations = []
        
        if not evaluation_results:
            return ["没有评估结果可供分析"]
        
        latest_result = evaluation_results[-1]
        
        # 基于最新评估结果生成建议
        for metric_name, metric_value in latest_result.metrics.items():
            if metric_name == 'accuracy' and metric_value < 0.8:
                recommendations.append("准确率较低，建议增加训练数据或调整模型参数")
            elif metric_name == 'f1_score' and metric_value < 0.7:
                recommendations.append("F1分数较低，可能存在类别不平衡问题，建议使用重采样技术")
            elif metric_name == 'auc' and metric_value < 0.8:
                recommendations.append("AUC较低，模型区分能力不足，建议调整特征工程或模型结构")
            elif metric_name == 'mae' and metric_value > 10:
                recommendations.append("平均绝对误差较高，建议调整模型复杂度或使用集成方法")
            elif metric_name == 'r2_score' and metric_value < 0.5:
                recommendations.append("R²分数较低，模型解释能力不足，建议增加特征或调整模型")
        
        # 基于评估历史生成建议
        if len(evaluation_results) > 1:
            # 检查性能趋势
            if latest_result.evaluation_type == EvaluationType.CLASSIFICATION:
                if 'accuracy' in latest_result.metrics:
                    recent_accuracies = [r.metrics.get('accuracy', 0) for r in evaluation_results[-5:]]
                    if len(recent_accuracies) > 1 and recent_accuracies[-1] < recent_accuracies[0]:
                        recommendations.append("模型准确率呈下降趋势，建议检查数据质量或重新训练")
        
        if not recommendations:
            recommendations.append("模型性能良好，建议继续监控")
        
        return recommendations

def main():
    """主函数"""
    try:
        # 创建模型评估器
        evaluator = ModelEvaluator()
        
        # 示例：评估分类模型
        from sklearn.datasets import make_classification
        from sklearn.ensemble import RandomForestClassifier
        
        # 生成示例数据
        X, y = make_classification(n_samples=1000, n_features=20, n_classes=2, random_state=42)
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # 训练模型
        model = RandomForestClassifier(random_state=42)
        model.fit(X_train, y_train)
        
        # 评估模型
        result = evaluator.evaluate_model(model, X_test, y_test, "example_model_v1")
        
        print("评估完成:")
        print(f"模型版本: {result.model_version}")
        print(f"评估类型: {result.evaluation_type.value}")
        print(f"执行时间: {result.execution_time:.2f}秒")
        print("指标:")
        for metric_name, metric_value in result.metrics.items():
            print(f"  {metric_name}: {metric_value:.4f}")
        
    except Exception as e:
        logger.error(f"模型评估失败: {e}")
        raise

if __name__ == "__main__":
    main()