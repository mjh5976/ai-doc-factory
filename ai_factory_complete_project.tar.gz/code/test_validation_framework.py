"""
识别结果后处理和置信度验证系统测试框架
=========================================

包含单元测试、集成测试、性能测试和验证框架

作者: MiniMax Agent
版本: 1.0.0
日期: 2025-11-06
"""

import unittest
import pytest
import numpy as np
import json
import time
from typing import List, Dict, Any
from unittest.mock import Mock, patch
import tempfile
import os

# 导入主系统模块
from result_postprocessing_system import (
    ResultPostprocessingSystem, RecognitionResult, ResultType, 
    ErrorType, QualityLevel, ValidationResult, ConsistencyCheck,
    create_sample_results
)


class TestRecognitionResult(unittest.TestCase):
    """识别结果数据类测试"""
    
    def test_creation(self):
        """测试识别结果创建"""
        result = RecognitionResult(
            id="test_001",
            type=ResultType.TEXT,
            content={"text": "测试文本"},
            confidence=0.9,
            bbox=(10, 20, 30, 40)
        )
        
        self.assertEqual(result.id, "test_001")
        self.assertEqual(result.type, ResultType.TEXT)
        self.assertEqual(result.confidence, 0.9)
        self.assertEqual(result.bbox, (10, 20, 30, 40))
    
    def test_to_dict(self):
        """测试转换为字典"""
        result = RecognitionResult(
            id="test_001",
            type=ResultType.TEXT,
            content={"text": "测试文本"},
            confidence=0.9
        )
        
        result_dict = result.to_dict()
        
        self.assertIsInstance(result_dict, dict)
        self.assertEqual(result_dict['id'], "test_001")
        self.assertEqual(result_dict['type'], "text")
        self.assertEqual(result_dict['confidence'], 0.9)


class TestConfidenceCalculator(unittest.TestCase):
    """置信度计算器测试"""
    
    def setUp(self):
        """测试设置"""
        from result_postprocessing_system import ConfidenceCalculator
        self.config = {'confidence': {}}
        self.calculator = ConfidenceCalculator(self.config['confidence'])
    
    def test_extract_features(self):
        """测试特征提取"""
        result = RecognitionResult(
            id="test_001",
            type=ResultType.TEXT,
            content={"text": "测试文本", "font_size": 12},
            confidence=0.9,
            bbox=(10, 20, 30, 40)
        )
        
        features = self.calculator._extract_features(result)
        
        self.assertIsInstance(features, list)
        self.assertEqual(len(features), 20)  # 固定长度
        self.assertEqual(features[0], 0.9)  # 置信度
    
    def test_calculate_confidence_without_training(self):
        """测试未训练时的置信度计算"""
        result = RecognitionResult(
            id="test_001",
            type=ResultType.TEXT,
            content={"text": "测试文本"},
            confidence=0.8
        )
        
        confidence = self.calculator.calculate_confidence(result)
        self.assertEqual(confidence, 0.8)  # 应该返回原始置信度


class TestConsistencyChecker(unittest.TestCase):
    """一致性检查器测试"""
    
    def setUp(self):
        """测试设置"""
        from result_postprocessing_system import ConsistencyChecker
        self.config = {'consistency': {'tolerance': 0.02}}
        self.checker = ConsistencyChecker(self.config['consistency'])
    
    def test_geometric_consistency(self):
        """测试几何一致性检查"""
        results = [
            RecognitionResult(
                id="geom_001",
                type=ResultType.GEOMETRY,
                content={"shape": "rectangle"},
                confidence=0.9,
                bbox=(10, 10, 50, 30)
            ),
            RecognitionResult(
                id="geom_002",
                type=ResultType.GEOMETRY,
                content={"shape": "rectangle"},
                confidence=0.8,
                bbox=(15, 15, 50, 30)  # 重叠的几何形状
            )
        ]
        
        consistency = self.checker.check_consistency(results)
        
        self.assertIsInstance(consistency, ConsistencyCheck)
        self.assertGreaterEqual(consistency.geometric_consistency, 0.0)
        self.assertLessEqual(consistency.geometric_consistency, 1.0)
    
    def test_semantic_consistency(self):
        """测试语义一致性检查"""
        results = [
            RecognitionResult(
                id="text_001",
                type=ResultType.TEXT,
                content={"text": "标题"},
                confidence=0.9
            ),
            RecognitionResult(
                id="text_002",
                type=ResultType.TEXT,
                content={"text": "标题"},  # 重复文本
                confidence=0.8
            )
        ]
        
        consistency = self.checker.check_consistency(results)
        
        self.assertIsInstance(consistency, ConsistencyCheck)
        self.assertLess(consistency.semantic_consistency, 1.0)  # 应该有重复惩罚


class TestAnomalyDetector(unittest.TestCase):
    """异常检测器测试"""
    
    def setUp(self):
        """测试设置"""
        from result_postprocessing_system import AnomalyDetector
        self.config = {'anomaly': {'contamination': 0.1}}
        self.detector = AnomalyDetector(self.config['anomaly'])
    
    def test_extract_features(self):
        """测试异常检测特征提取"""
        result = RecognitionResult(
            id="test_001",
            type=ResultType.TEXT,
            content={"text": "测试文本"},
            confidence=0.9,
            processing_time=1.5
        )
        
        features = self.detector._extract_features(result)
        
        self.assertIsInstance(features, list)
        self.assertEqual(len(features), 10)  # 固定长度
        self.assertEqual(features[0], 0.9)  # 置信度
        self.assertEqual(features[1], 1.5)  # 处理时间
    
    def test_detect_anomalies_without_training(self):
        """测试未训练时的异常检测"""
        results = create_sample_results()
        
        anomaly_results = self.detector.detect_anomalies(results)
        
        self.assertIsInstance(anomaly_results, dict)
        self.assertIn('anomalies', anomaly_results)
        self.assertIn('normal', anomaly_results)
        self.assertEqual(len(anomaly_results['anomalies']), 0)  # 未训练时不应检测到异常


class TestResultOptimizer(unittest.TestCase):
    """结果优化器测试"""
    
    def setUp(self):
        """测试设置"""
        from result_postprocessing_system import ResultOptimizer
        self.config = {'optimization': {}}
        self.optimizer = ResultOptimizer(self.config['optimization'])
    
    def test_remove_duplicates(self):
        """测试去重功能"""
        results = [
            RecognitionResult(
                id="text_001",
                type=ResultType.TEXT,
                content={"text": "测试文本"},
                confidence=0.9
            ),
            RecognitionResult(
                id="text_002",
                type=ResultType.TEXT,
                content={"text": "测试文本"},  # 相同内容
                confidence=0.8
            )
        ]
        
        unique_results = self.optimizer._remove_duplicates(results)
        
        self.assertEqual(len(unique_results), 1)
    
    def test_are_overlapping(self):
        """测试重叠检测"""
        result1 = RecognitionResult(
            id="geom_001",
            type=ResultType.GEOMETRY,
            content={"shape": "rectangle"},
            confidence=0.9,
            bbox=(10, 10, 50, 30)
        )
        
        result2 = RecognitionResult(
            id="geom_002",
            type=ResultType.GEOMETRY,
            content={"shape": "rectangle"},
            confidence=0.8,
            bbox=(20, 20, 50, 30)  # 重叠
        )
        
        result3 = RecognitionResult(
            id="geom_003",
            type=ResultType.GEOMETRY,
            content={"shape": "rectangle"},
            confidence=0.8,
            bbox=(100, 100, 50, 30)  # 不重叠
        )
        
        self.assertTrue(self.optimizer._are_overlapping(result1, result2))
        self.assertFalse(self.optimizer._are_overlapping(result1, result3))


class TestQualityAssessor(unittest.TestCase):
    """质量评估器测试"""
    
    def setUp(self):
        """测试设置"""
        from result_postprocessing_system import QualityAssessor
        self.config = {'quality': {}}
        self.assessor = QualityAssessor(self.config['quality'])
    
    def test_assess_completeness(self):
        """测试完整性评估"""
        results = create_sample_results()
        
        completeness = self.assessor._assess_completeness(results)
        
        self.assertGreaterEqual(completeness, 0.0)
        self.assertLessEqual(completeness, 1.0)
    
    def test_assess_quality(self):
        """测试质量评估"""
        results = create_sample_results()
        validation_result = ValidationResult(
            is_valid=True,
            confidence=0.85,
            errors=[],
            warnings=[],
            quality_score=0.8
        )
        consistency_check = ConsistencyCheck(
            geometric_consistency=0.9,
            semantic_consistency=0.85,
            topological_consistency=0.8,
            dimensional_consistency=0.9,
            overall_score=0.86
        )
        
        quality_level = self.assessor.assess_quality(
            results, validation_result, consistency_check
        )
        
        self.assertIsInstance(quality_level, QualityLevel)
        self.assertIn(quality_level, [QualityLevel.HIGH, QualityLevel.MEDIUM, 
                                     QualityLevel.LOW, QualityLevel.FAILED])


class TestResultFormatter(unittest.TestCase):
    """结果格式化器测试"""
    
    def setUp(self):
        """测试设置"""
        from result_postprocessing_system import ResultFormatter
        self.config = {'formatting': {}}
        self.formatter = ResultFormatter(self.config['formatting'])
    
    def test_generate_audit_trail(self):
        """测试审计追踪生成"""
        results = create_sample_results()
        validation_result = ValidationResult(
            is_valid=True,
            confidence=0.85,
            errors=[],
            warnings=[]
        )
        
        audit_trail = self.formatter._generate_audit_trail(results, validation_result)
        
        self.assertIsInstance(audit_trail, list)
        self.assertGreater(len(audit_trail), 0)
    
    def test_export_to_json(self):
        """测试JSON导出"""
        results = create_sample_results()
        validation_result = ValidationResult(
            is_valid=True,
            confidence=0.85,
            errors=[],
            warnings=[]
        )
        consistency_check = ConsistencyCheck()
        quality_level = QualityLevel.MEDIUM
        quality_report = {}
        
        formatted_output = self.formatter.format_results(
            results, validation_result, consistency_check,
            quality_level, quality_report
        )
        
        json_output = self.formatter.export_to_format(formatted_output, 'json')
        
        self.assertIsInstance(json_output, str)
        # 验证JSON格式
        parsed = json.loads(json_output)
        self.assertIn('metadata', parsed)
        self.assertIn('results', parsed)


class TestIntegration(unittest.TestCase):
    """集成测试"""
    
    def setUp(self):
        """测试设置"""
        self.config = {
            'confidence': {},
            'consistency': {'tolerance': 0.02},
            'anomaly': {'contamination': 0.1},
            'quality': {},
            'formatting': {}
        }
        self.system = ResultPostprocessingSystem(self.config)
    
    def test_end_to_end_processing(self):
        """端到端处理测试"""
        # 创建测试数据
        results = create_sample_results()
        training_data = results[:2]
        
        # 处理结果
        start_time = time.time()
        formatted_output = self.system.process_results(results, training_data)
        end_time = time.time()
        
        # 验证结果
        self.assertIsInstance(formatted_output, dict)
        self.assertIn('metadata', formatted_output)
        self.assertIn('results', formatted_output)
        self.assertIn('validation', formatted_output)
        self.assertIn('consistency', formatted_output)
        self.assertIn('quality_report', formatted_output)
        
        # 验证处理时间
        processing_time = end_time - start_time
        self.assertLess(processing_time, 10.0)  # 应该在10秒内完成
        
        # 验证结果数量
        self.assertGreater(len(formatted_output['results']), 0)
    
    def test_system_status(self):
        """测试系统状态获取"""
        status = self.system.get_system_status()
        
        self.assertIsInstance(status, dict)
        self.assertIn('system_name', status)
        self.assertIn('components', status)
        self.assertIn('config_summary', status)


class TestPerformance(unittest.TestCase):
    """性能测试"""
    
    def setUp(self):
        """测试设置"""
        self.config = {
            'confidence': {},
            'consistency': {'tolerance': 0.02},
            'anomaly': {'contamination': 0.1},
            'quality': {},
            'formatting': {}
        }
        self.system = ResultPostprocessingSystem(self.config)
    
    def test_large_dataset_performance(self):
        """大数据集性能测试"""
        # 创建大量测试数据
        results = []
        for i in range(100):
            result = RecognitionResult(
                id=f"test_{i:03d}",
                type=ResultType.TEXT,
                content={"text": f"测试文本 {i}"},
                confidence=np.random.uniform(0.5, 1.0),
                bbox=(i*10, i*5, 30, 20)
            )
            results.append(result)
        
        training_data = results[:20]
        
        # 性能测试
        start_time = time.time()
        formatted_output = self.system.process_results(results, training_data)
        end_time = time.time()
        
        processing_time = end_time - start_time
        
        # 性能要求
        self.assertLess(processing_time, 30.0)  # 应该在30秒内完成100个结果
        self.assertEqual(len(formatted_output['results']), 100)
    
    def test_memory_usage(self):
        """内存使用测试"""
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss
        
        # 创建大量数据
        results = []
        for i in range(50):
            result = RecognitionResult(
                id=f"test_{i:03d}",
                type=ResultType.GEOMETRY,
                content={"shape": "rectangle", "area": i*100},
                confidence=0.9,
                bbox=(i*20, i*10, 50, 30)
            )
            results.append(result)
        
        # 处理数据
        training_data = results[:10]
        formatted_output = self.system.process_results(results, training_data)
        
        final_memory = process.memory_info().rss
        memory_increase = final_memory - initial_memory
        
        # 内存增长应该在合理范围内（少于500MB）
        self.assertLess(memory_increase, 500 * 1024 * 1024)


class TestErrorHandling(unittest.TestCase):
    """错误处理测试"""
    
    def setUp(self):
        """测试设置"""
        self.config = {
            'confidence': {},
            'consistency': {'tolerance': 0.02},
            'anomaly': {'contamination': 0.1},
            'quality': {},
            'formatting': {}
        }
        self.system = ResultPostprocessingSystem(self.config)
    
    def test_empty_results(self):
        """测试空结果处理"""
        results = []
        training_data = []
        
        # 应该能正常处理空结果
        formatted_output = self.system.process_results(results, training_data)
        
        self.assertIsInstance(formatted_output, dict)
        self.assertEqual(len(formatted_output['results']), 0)
    
    def test_invalid_result_data(self):
        """测试无效结果数据"""
        # 创建包含无效数据的测试结果
        results = [
            RecognitionResult(
                id="invalid_001",
                type=ResultType.TEXT,
                content={},  # 空内容
                confidence=1.5,  # 无效置信度
                bbox=None
            )
        ]
        
        # 应该能正常处理并标记为错误
        formatted_output = self.system.process_results(results)
        
        self.assertIsInstance(formatted_output, dict)
        self.assertGreater(len(formatted_output['validation']['errors']), 0)


class TestValidationFramework:
    """验证框架类"""
    
    def __init__(self):
        self.test_results = []
        self.performance_metrics = {}
    
    def run_validation_suite(self) -> Dict[str, Any]:
        """运行完整验证套件"""
        print("开始运行验证套件...")
        
        # 运行所有测试
        test_classes = [
            TestRecognitionResult,
            TestConfidenceCalculator,
            TestConsistencyChecker,
            TestAnomalyDetector,
            TestResultOptimizer,
            TestQualityAssessor,
            TestResultFormatter,
            TestIntegration,
            TestPerformance,
            TestErrorHandling
        ]
        
        total_tests = 0
        passed_tests = 0
        failed_tests = []
        
        for test_class in test_classes:
            print(f"运行测试类: {test_class.__name__}")
            
            suite = unittest.TestLoader().loadTestsFromTestCase(test_class)
            runner = unittest.TextTestRunner(verbosity=0, stream=open(os.devnull, 'w'))
            result = runner.run(suite)
            
            total_tests += result.testsRun
            passed_tests += result.testsRun - len(result.failures) - len(result.errors)
            
            if result.failures:
                failed_tests.extend([(test_class.__name__, str(f[0])) for f in result.failures])
            if result.errors:
                failed_tests.extend([(test_class.__name__, str(e[0])) for e in result.errors])
        
        # 生成验证报告
        validation_report = {
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'summary': {
                'total_tests': total_tests,
                'passed_tests': passed_tests,
                'failed_tests': len(failed_tests),
                'success_rate': passed_tests / total_tests if total_tests > 0 else 0
            },
            'failed_tests': failed_tests,
            'performance_metrics': self.performance_metrics,
            'overall_status': 'PASSED' if len(failed_tests) == 0 else 'FAILED'
        }
        
        print(f"验证完成: {passed_tests}/{total_tests} 测试通过")
        return validation_report
    
    def benchmark_performance(self, system: ResultPostprocessingSystem) -> Dict[str, Any]:
        """性能基准测试"""
        print("开始性能基准测试...")
        
        # 测试不同数据量
        data_sizes = [10, 50, 100]
        benchmark_results = {}
        
        for size in data_sizes:
            # 创建测试数据
            results = []
            for i in range(size):
                result = RecognitionResult(
                    id=f"bench_{i:03d}",
                    type=ResultType.TEXT,
                    content={"text": f"基准测试文本 {i}"},
                    confidence=0.9,
                    bbox=(i*10, i*5, 30, 20)
                )
                results.append(result)
            
            training_data = results[:min(10, size//2)]
            
            # 性能测试
            start_time = time.time()
            formatted_output = system.process_results(results, training_data)
            end_time = time.time()
            
            processing_time = end_time - start_time
            throughput = size / processing_time
            
            benchmark_results[f'size_{size}'] = {
                'processing_time': processing_time,
                'throughput': throughput,
                'memory_usage': self._estimate_memory_usage(results)
            }
        
        self.performance_metrics = benchmark_results
        return benchmark_results
    
    def _estimate_memory_usage(self, results: List[RecognitionResult]) -> int:
        """估算内存使用量"""
        import sys
        total_size = 0
        for result in results:
            total_size += sys.getsizeof(result)
            total_size += sys.getsizeof(result.content)
        return total_size
    
    def validate_output_format(self, formatted_output: Dict[str, Any]) -> Dict[str, Any]:
        """验证输出格式"""
        validation_results = {
            'format_valid': True,
            'required_fields': [],
            'optional_fields': [],
            'errors': []
        }
        
        # 检查必需字段
        required_fields = ['metadata', 'results', 'validation', 'consistency', 'quality_report']
        for field in required_fields:
            if field not in formatted_output:
                validation_results['required_fields'].append(field)
                validation_results['format_valid'] = False
        
        # 检查数据类型
        if 'results' in formatted_output:
            if not isinstance(formatted_output['results'], list):
                validation_results['errors'].append("results字段应该是列表类型")
                validation_results['format_valid'] = False
        
        if 'validation' in formatted_output:
            if not isinstance(formatted_output['validation'], dict):
                validation_results['errors'].append("validation字段应该是字典类型")
                validation_results['format_valid'] = False
        
        return validation_results


def run_comprehensive_validation():
    """运行综合验证"""
    print("=" * 60)
    print("识别结果后处理和置信度验证系统 - 综合验证")
    print("=" * 60)
    
    # 初始化验证框架
    validator = TestValidationFramework()
    
    # 创建系统实例
    config = {
        'confidence': {},
        'consistency': {'tolerance': 0.02},
        'anomaly': {'contamination': 0.1},
        'quality': {},
        'formatting': {}
    }
    system = ResultPostprocessingSystem(config)
    
    # 1. 运行验证套件
    print("\n1. 运行验证套件...")
    validation_report = validator.run_validation_suite()
    
    # 2. 性能基准测试
    print("\n2. 性能基准测试...")
    performance_results = validator.benchmark_performance(system)
    
    # 3. 功能验证
    print("\n3. 功能验证...")
    sample_results = create_sample_results()
    formatted_output = system.process_results(sample_results)
    
    format_validation = validator.validate_output_format(formatted_output)
    
    # 4. 生成综合报告
    print("\n4. 生成综合报告...")
    comprehensive_report = {
        'system_info': {
            'name': '识别结果后处理和置信度验证系统',
            'version': '1.0.0',
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
        },
        'validation_results': validation_report,
        'performance_results': performance_results,
        'format_validation': format_validation,
        'overall_assessment': {
            'validation_status': validation_report['overall_status'],
            'performance_acceptable': all(
                result['processing_time'] < 10.0 
                for result in performance_results.values()
            ),
            'format_valid': format_validation['format_valid'],
            'system_ready': (
                validation_report['overall_status'] == 'PASSED' and
                format_validation['format_valid']
            )
        }
    }
    
    # 保存报告
    with open('validation_report.json', 'w', encoding='utf-8') as f:
        json.dump(comprehensive_report, f, indent=2, ensure_ascii=False)
    
    print("\n" + "=" * 60)
    print("验证结果摘要")
    print("=" * 60)
    print(f"验证状态: {validation_report['overall_status']}")
    print(f"测试通过率: {validation_report['summary']['success_rate']:.2%}")
    print(f"性能测试: {'通过' if comprehensive_report['overall_assessment']['performance_acceptable'] else '失败'}")
    print(f"格式验证: {'通过' if format_validation['format_valid'] else '失败'}")
    print(f"系统就绪: {'是' if comprehensive_report['overall_assessment']['system_ready'] else '否'}")
    print(f"详细报告已保存到: validation_report.json")
    
    return comprehensive_report


if __name__ == "__main__":
    # 运行综合验证
    report = run_comprehensive_validation()
