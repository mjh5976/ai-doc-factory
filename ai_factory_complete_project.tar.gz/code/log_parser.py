#!/usr/bin/env python3
"""
日志解析和结构化处理器
将原始日志转换为结构化数据，支持多种日志格式
"""

import re
import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional, Union, Tuple
from dataclasses import dataclass, field
from enum import Enum
import yaml
import jsonschema
from pathlib import Path

class LogLevel(Enum):
    """日志级别枚举"""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARN = "WARN"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"
    FATAL = "FATAL"

@dataclass
class ParsedLogEntry:
    """解析后的日志条目"""
    timestamp: datetime
    level: LogLevel
    service: str
    host: str
    pid: Optional[int] = None
    thread: Optional[str] = None
    logger_name: Optional[str] = None
    message: str = ""
    exception: Optional[str] = None
    stack_trace: Optional[str] = None
    custom_fields: Dict[str, Any] = field(default_factory=dict)
    location: Optional[str] = None
    source_file: Optional[str] = None
    source_line: Optional[int] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        result = {
            'timestamp': self.timestamp.isoformat(),
            'level': self.level.value,
            'service': self.service,
            'host': self.host,
            'message': self.message
        }
        
        # 添加可选字段
        if self.pid is not None:
            result['pid'] = self.pid
        if self.thread is not None:
            result['thread'] = self.thread
        if self.logger_name is not None:
            result['logger_name'] = self.logger_name
        if self.exception is not None:
            result['exception'] = self.exception
        if self.stack_trace is not None:
            result['stack_trace'] = self.stack_trace
        if self.location is not None:
            result['location'] = self.location
        if self.source_file is not None:
            result['source_file'] = self.source_file
        if self.source_line is not None:
            result['source_line'] = self.source_line
        if self.custom_fields:
            result.update(self.custom_fields)
        
        return result

class LogParser:
    """日志解析器"""
    
    def __init__(self, config_path: str = "config/parser_config.yaml"):
        self.config = self._load_config(config_path)
        self.logger = logging.getLogger(__name__)
        self.patterns = self._compile_patterns()
        self.schema_validator = self._setup_schema_validator()
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载解析配置"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            self.logger.warning(f"解析配置文件加载失败: {e}，使用默认配置")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """默认解析配置"""
        return {
            'patterns': {
                'apache_combined': r'(?P<host>\S+) \S+ \S+ \[(?P<time>[^\]]+)\] "(?P<method>\S+) (?P<path>\S+) (?P<protocol>\S+)" (?P<status>\d{3}) (?P<size>\S+) "(?P<referer>[^"]*)" "(?P<user_agent>[^"]*)"',
                'nginx_access': r'(?P<remote_addr>\S+) - (?P<remote_user>\S+) \[(?P<time_local>[^\]]+)\] "(?P<method>\S+) (?P<request>\S+) (?P<protocol>\S+)" (?P<status>\d{3}) (?P<body_bytes_sent>\d+) "(?P<http_referer>[^"]*)" "(?P<http_user_agent>[^"]*)"',
                'syslog': r'(?P<month>\w+)\s+(?P<day>\d+)\s+(?P<time>\d{2}:\d{2}:\d{2})\s+(?P<host>\S+)\s+(?P<program>[^:]+):\s+(?P<message>.*)',
                'json_log': r'^\{.*\}$',
                'log4j': r'(?P<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})\s+\[(?P<level>\w+)\]\s+(?P<logger>[^:]+):\s+(?P<message>.*)',
                'python_logging': r'(?P<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})\s+(?P<level>\w+)\s+(?P<module>[^:]+):(?P<line>\d+)\s+-\s+(?P<message>.*)',
                'spring_boot': r'(?P<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3})\s+(?P<level>\w+)\s+\[(?P<thread>[^\]]+)\]\s+(?P<logger>[^:]+)\s*:\s+(?P<message>.*)',
                'nodejs': r'(?P<timestamp>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z)\s+(?P<level>\w+)\s+(?P<module>[^:]+):(?P<line>\d+)\s+-\s+(?P<message>.*)',
                'java_spring': r'(?P<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})\s+(?P<level>\w+)\s+\[(?P<thread>[^\]]+)\]\s+(?P<logger>[^:]+)\s*:\s+(?P<message>.*)'
            },
            'timestamp_formats': [
                '%Y-%m-%d %H:%M:%S',
                '%Y-%m-%d %H:%M:%S.%f',
                '%d/%b/%Y:%H:%M:%S %z',
                '%Y-%m-%dT%H:%M:%S.%fZ',
                '%Y-%m-%dT%H:%M:%S%z'
            ],
            'default_service': 'unknown',
            'default_host': 'localhost',
            'field_mappings': {
                'service': ['service', 'app', 'application', 'service_name'],
                'host': ['host', 'hostname', 'machine'],
                'pid': ['pid', 'process_id'],
                'thread': ['thread', 'thread_name'],
                'logger': ['logger', 'logger_name', 'category']
            }
        }
    
    def _compile_patterns(self) -> Dict[str, re.Pattern]:
        """编译正则表达式模式"""
        patterns = {}
        for name, pattern in self.config['patterns'].items():
            try:
                patterns[name] = re.compile(pattern)
            except re.error as e:
                self.logger.error(f"编译正则表达式模式 '{name}' 失败: {e}")
        return patterns
    
    def _setup_schema_validator(self) -> Optional[jsonschema.Draft7Validator]:
        """设置JSON Schema验证器"""
        try:
            schema = {
                "type": "object",
                "properties": {
                    "timestamp": {"type": "string"},
                    "level": {"type": "string"},
                    "service": {"type": "string"},
                    "host": {"type": "string"},
                    "message": {"type": "string"}
                },
                "required": ["timestamp", "level", "service", "host", "message"]
            }
            return jsonschema.Draft7Validator(schema)
        except Exception as e:
            self.logger.warning(f"设置Schema验证器失败: {e}")
            return None
    
    def parse(self, log_line: str, source_file: Optional[str] = None) -> Optional[ParsedLogEntry]:
        """解析单行日志"""
        if not log_line.strip():
            return None
        
        # 尝试不同的解析模式
        for pattern_name, pattern in self.patterns.items():
            try:
                match = pattern.match(log_line.strip())
                if match:
                    return self._create_parsed_entry(match, pattern_name, source_file)
            except Exception as e:
                self.logger.debug(f"模式 '{pattern_name}' 解析失败: {e}")
                continue
        
        # 如果所有模式都失败，使用通用解析
        return self._fallback_parse(log_line, source_file)
    
    def _create_parsed_entry(self, match: re.Match, pattern_name: str, source_file: Optional[str]) -> ParsedLogEntry:
        """根据匹配结果创建解析条目"""
        groups = match.groupdict()
        
        # 解析时间戳
        timestamp = self._parse_timestamp(groups.get('timestamp'))
        
        # 解析日志级别
        level = self._parse_level(groups.get('level'))
        
        # 提取字段
        service = self._extract_field(groups, 'service') or self.config['default_service']
        host = self._extract_field(groups, 'host') or self.config['default_host']
        pid = self._extract_int_field(groups, 'pid')
        thread = self._extract_field(groups, 'thread')
        logger_name = self._extract_field(groups, 'logger')
        message = groups.get('message', '')
        
        # 处理特殊模式
        if pattern_name == 'json_log':
            return self._parse_json_log(message, source_file)
        
        # 处理异常信息
        exception, stack_trace = self._extract_exception_info(message)
        
        # 创建解析条目
        entry = ParsedLogEntry(
            timestamp=timestamp,
            level=level,
            service=service,
            host=host,
            pid=pid,
            thread=thread,
            logger_name=logger_name,
            message=message,
            exception=exception,
            stack_trace=stack_trace,
            source_file=source_file,
            source_line=self._extract_int_field(groups, 'line')
        )
        
        # 添加自定义字段
        entry.custom_fields = self._extract_custom_fields(groups, pattern_name)
        
        return entry
    
    def _parse_json_log(self, json_str: str, source_file: Optional[str]) -> ParsedLogEntry:
        """解析JSON格式日志"""
        try:
            data = json.loads(json_str)
            
            # 提取基本字段
            timestamp = self._parse_timestamp(data.get('timestamp'))
            level = self._parse_level(data.get('level'))
            service = data.get('service', self.config['default_service'])
            host = data.get('host', self.config['default_host'])
            message = data.get('message', json_str)
            
            # 提取可选字段
            pid = data.get('pid')
            thread = data.get('thread')
            logger_name = data.get('logger')
            exception = data.get('exception')
            stack_trace = data.get('stack_trace')
            
            entry = ParsedLogEntry(
                timestamp=timestamp,
                level=level,
                service=service,
                host=host,
                pid=pid,
                thread=thread,
                logger_name=logger_name,
                message=message,
                exception=exception,
                stack_trace=stack_trace,
                source_file=source_file
            )
            
            # 添加JSON中的其他字段作为自定义字段
            entry.custom_fields = {k: v for k, v in data.items() 
                                 if k not in ['timestamp', 'level', 'service', 'host', 'message', 
                                            'pid', 'thread', 'logger', 'exception', 'stack_trace']}
            
            return entry
            
        except json.JSONDecodeError:
            self.logger.warning(f"JSON解析失败: {json_str}")
            return self._fallback_parse(json_str, source_file)
    
    def _fallback_parse(self, log_line: str, source_file: Optional[str]) -> ParsedLogEntry:
        """回退解析方法"""
        # 尝试从消息中提取时间戳
        timestamp_match = re.search(r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}', log_line)
        timestamp = self._parse_timestamp(timestamp_match.group() if timestamp_match else None)
        
        # 尝试从消息中提取级别
        level_match = re.search(r'\b(DEBUG|INFO|WARN|WARNING|ERROR|CRITICAL|FATAL)\b', log_line, re.IGNORECASE)
        level = self._parse_level(level_match.group() if level_match else None)
        
        return ParsedLogEntry(
            timestamp=timestamp,
            level=level,
            service=self.config['default_service'],
            host=self.config['default_host'],
            message=log_line,
            source_file=source_file
        )
    
    def _parse_timestamp(self, timestamp_str: Optional[str]) -> datetime:
        """解析时间戳"""
        if not timestamp_str:
            return datetime.now()
        
        for fmt in self.config['timestamp_formats']:
            try:
                return datetime.strptime(timestamp_str, fmt)
            except ValueError:
                continue
        
        # 如果所有格式都失败，尝试ISO格式
        try:
            return datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
        except ValueError:
            self.logger.warning(f"无法解析时间戳: {timestamp_str}")
            return datetime.now()
    
    def _parse_level(self, level_str: Optional[str]) -> LogLevel:
        """解析日志级别"""
        if not level_str:
            return LogLevel.INFO
        
        level_str = level_str.upper()
        try:
            return LogLevel(level_str)
        except ValueError:
            # 处理特殊情况
            if level_str in ['WARN', 'WARNING']:
                return LogLevel.WARNING
            elif level_str in ['FATAL']:
                return LogLevel.CRITICAL
            else:
                self.logger.warning(f"未知的日志级别: {level_str}")
                return LogLevel.INFO
    
    def _extract_field(self, groups: Dict[str, str], field_name: str) -> Optional[str]:
        """提取字段值"""
        # 检查映射
        mappings = self.config['field_mappings'].get(field_name, [])
        for mapped_name in mappings:
            if mapped_name in groups and groups[mapped_name]:
                return groups[mapped_name]
        
        # 直接检查字段名
        if field_name in groups and groups[field_name]:
            return groups[field_name]
        
        return None
    
    def _extract_int_field(self, groups: Dict[str, str], field_name: str) -> Optional[int]:
        """提取整数字段"""
        value = self._extract_field(groups, field_name)
        if value:
            try:
                return int(value)
            except ValueError:
                pass
        return None
    
    def _extract_exception_info(self, message: str) -> Tuple[Optional[str], Optional[str]]:
        """提取异常信息"""
        exception_pattern = r'([A-Za-z0-9_]+Exception|Error|Exception):\s*(.+)'
        match = re.search(exception_pattern, message)
        
        if match:
            exception_type = match.group(1)
            exception_msg = match.group(2)
            
            # 查找堆栈跟踪
            stack_trace = None
            if 'stack' in message.lower() or 'trace' in message.lower():
                stack_match = re.search(r'stack.*?:\s*(.*)', message, re.DOTALL)
                if stack_match:
                    stack_trace = stack_match.group(1).strip()
            
            return exception_type, stack_trace
        
        return None, None
    
    def _extract_custom_fields(self, groups: Dict[str, str], pattern_name: str) -> Dict[str, Any]:
        """提取自定义字段"""
        custom_fields = {}
        
        # 根据模式添加特定字段
        if pattern_name == 'apache_combined':
            custom_fields.update({
                'method': groups.get('method'),
                'path': groups.get('path'),
                'status': groups.get('status'),
                'size': groups.get('size'),
                'referer': groups.get('referer'),
                'user_agent': groups.get('user_agent')
            })
        elif pattern_name == 'nginx_access':
            custom_fields.update({
                'remote_addr': groups.get('remote_addr'),
                'remote_user': groups.get('remote_user'),
                'method': groups.get('method'),
                'request': groups.get('request'),
                'status': groups.get('status'),
                'body_bytes_sent': groups.get('body_bytes_sent'),
                'http_referer': groups.get('http_referer'),
                'http_user_agent': groups.get('http_user_agent')
            })
        
        # 移除空值
        return {k: v for k, v in custom_fields.items() if v is not None}
    
    def validate_entry(self, entry: ParsedLogEntry) -> bool:
        """验证解析条目"""
        if not self.schema_validator:
            return True
        
        try:
            self.schema_validator.validate(entry.to_dict())
            return True
        except jsonschema.ValidationError as e:
            self.logger.warning(f"日志条目验证失败: {e}")
            return False
    
    def batch_parse(self, log_lines: List[str], source_file: Optional[str] = None) -> List[ParsedLogEntry]:
        """批量解析日志"""
        results = []
        for line in log_lines:
            entry = self.parse(line, source_file)
            if entry and self.validate_entry(entry):
                results.append(entry)
        return results
    
    def parse_file(self, file_path: str, encoding: str = 'utf-8') -> List[ParsedLogEntry]:
        """解析日志文件"""
        entries = []
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                for line_num, line in enumerate(f, 1):
                    try:
                        entry = self.parse(line.strip(), file_path)
                        if entry:
                            entry.source_line = line_num
                            if self.validate_entry(entry):
                                entries.append(entry)
                    except Exception as e:
                        self.logger.warning(f"解析文件 {file_path} 第 {line_num} 行失败: {e}")
                        continue
        except Exception as e:
            self.logger.error(f"读取文件 {file_path} 失败: {e}")
        
        return entries

class LogEnricher:
    """日志丰富器 - 添加额外信息"""
    
    def __init__(self, config_path: str = "config/enricher_config.yaml"):
        self.config = self._load_config(config_path)
        self.logger = logging.getLogger(__name__)
        self.geoip_db = None
        self.user_agent_parser = None
        self._setup_enrichers()
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载丰富器配置"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            self.logger.warning(f"丰富器配置文件加载失败: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """默认丰富器配置"""
        return {
            'geoip': {
                'enabled': False,
                'db_path': '/usr/share/GeoIP/GeoLite2-City.mmdb'
            },
            'user_agent': {
                'enabled': False
            },
            'threat_intelligence': {
                'enabled': False,
                'api_key': None
            },
            'custom_enrichers': []
        }
    
    def _setup_enrichers(self):
        """设置丰富器"""
        # 设置GeoIP
        if self.config['geoip']['enabled']:
            try:
                import geoip2.database
                self.geoip_db = geoip2.database.Reader(self.config['geoip']['db_path'])
            except ImportError:
                self.logger.warning("geoip2库未安装，GeoIP丰富功能不可用")
            except Exception as e:
                self.logger.warning(f"GeoIP数据库加载失败: {e}")
        
        # 设置User-Agent解析器
        if self.config['user_agent']['enabled']:
            try:
                import user_agents
                self.user_agent_parser = user_agents
            except ImportError:
                self.logger.warning("user-agents库未安装，User-Agent解析功能不可用")
    
    def enrich(self, entry: ParsedLogEntry) -> ParsedLogEntry:
        """丰富日志条目"""
        # GeoIP丰富
        if self.geoip_db and 'ip' in entry.custom_fields:
            entry = self._enrich_geoip(entry)
        
        # User-Agent丰富
        if self.user_agent_parser and 'user_agent' in entry.custom_fields:
            entry = self._enrich_user_agent(entry)
        
        # 威胁情报丰富
        if self.config['threat_intelligence']['enabled']:
            entry = self._enrich_threat_intel(entry)
        
        # 自定义丰富器
        for enricher_config in self.config['custom_enrichers']:
            entry = self._apply_custom_enricher(entry, enricher_config)
        
        return entry
    
    def _enrich_geoip(self, entry: ParsedLogEntry) -> ParsedLogEntry:
        """GeoIP丰富"""
        try:
            ip = entry.custom_fields.get('ip') or entry.custom_fields.get('remote_addr')
            if ip:
                response = self.geoip_db.city(ip)
                entry.custom_fields.update({
                    'geoip.country': response.country.name,
                    'geoip.country_code': response.country.iso_code,
                    'geoip.city': response.city.name,
                    'geoip.latitude': float(response.location.latitude) if response.location.latitude else None,
                    'geoip.longitude': float(response.location.longitude) if response.location.longitude else None,
                    'geoip.timezone': response.location.time_zone
                })
        except Exception as e:
            self.logger.debug(f"GeoIP丰富失败: {e}")
        
        return entry
    
    def _enrich_user_agent(self, entry: ParsedLogEntry) -> ParsedLogEntry:
        """User-Agent丰富"""
        try:
            user_agent_str = entry.custom_fields.get('user_agent') or entry.custom_fields.get('http_user_agent')
            if user_agent_str:
                ua = self.user_agent_parser.parse(user_agent_str)
                entry.custom_fields.update({
                    'ua.browser': str(ua.browser.family) if ua.browser.family else None,
                    'ua.browser_version': str(ua.browser.version_string) if ua.browser.version_string else None,
                    'ua.os': str(ua.os.family) if ua.os.family else None,
                    'ua.os_version': str(ua.os.version_string) if ua.os.version_string else None,
                    'ua.device': str(ua.device.family) if ua.device.family else None,
                    'ua.is_mobile': ua.is_mobile,
                    'ua.is_tablet': ua.is_tablet,
                    'ua.is_pc': ua.is_pc,
                    'ua.is_bot': ua.is_bot
                })
        except Exception as e:
            self.logger.debug(f"User-Agent丰富失败: {e}")
        
        return entry
    
    def _enrich_threat_intel(self, entry: ParsedLogEntry) -> ParsedLogEntry:
        """威胁情报丰富"""
        try:
            ip = entry.custom_fields.get('ip') or entry.custom_fields.get('remote_addr')
            if ip and self.config['threat_intelligence']['api_key']:
                # 这里可以集成威胁情报API
                # 例如VirusTotal、AlienVault OTX等
                pass
        except Exception as e:
            self.logger.debug(f"威胁情报丰富失败: {e}")
        
        return entry
    
    def _apply_custom_enricher(self, entry: ParsedLogEntry, enricher_config: Dict[str, Any]) -> ParsedLogEntry:
        """应用自定义丰富器"""
        try:
            enricher_type = enricher_config.get('type')
            
            if enricher_type == 'lookup':
                # 查找表丰富
                lookup_table = enricher_config.get('lookup_table', {})
                field = enricher_config.get('field')
                if field and field in entry.custom_fields:
                    key = entry.custom_fields[field]
                    if key in lookup_table:
                        entry.custom_fields.update(lookup_table[key])
            
            elif enricher_type == 'script':
                # 脚本丰富（需要实现）
                pass
            
        except Exception as e:
            self.logger.debug(f"自定义丰富器应用失败: {e}")
        
        return entry

def main():
    """主函数 - 测试解析器"""
    parser = LogParser()
    enricher = LogEnricher()
    
    # 测试日志行
    test_logs = [
        "2024-01-01 12:00:00 [INFO] app: User login successful",
        '{"timestamp": "2024-01-01T12:00:00Z", "level": "ERROR", "service": "api", "message": "Database connection failed"}',
        "127.0.0.1 - - [01/Jan/2024:12:00:00 +0000] \"GET /api/users HTTP/1.1\" 200 1234",
        "2024-01-01 12:00:00,123 [ERROR] com.example.Service: Database connection failed"
    ]
    
    for log_line in test_logs:
        print(f"\n原始日志: {log_line}")
        
        # 解析
        entry = parser.parse(log_line)
        if entry:
            print(f"解析结果: {entry.to_dict()}")
            
            # 丰富
            enriched_entry = enricher.enrich(entry)
            print(f"丰富后: {enriched_entry.to_dict()}")

if __name__ == "__main__":
    main()
