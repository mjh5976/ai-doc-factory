#!/usr/bin/env python3
"""
日志存储和归档策略系统
提供高效的日志存储管理、数据生命周期管理和归档策略
"""

import os
import sys
import time
import json
import logging
import shutil
import gzip
import pickle
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Union, Callable
from dataclasses import dataclass, field, asdict
from collections import defaultdict, deque
from enum import Enum
import yaml
import sqlite3
import redis
import boto3
from pathlib import Path
import threading
from concurrent.futures import ThreadPoolExecutor
import psutil
import schedule

class StorageTier(Enum):
    """存储层级"""
    HOT = "HOT"        # 热存储 - 最近数据，快速访问
    WARM = "WARM"      # 温存储 - 中期数据，中等访问速度
    COLD = "COLD"      # 冷存储 - 长期数据，慢速访问
    ARCHIVE = "ARCHIVE" # 归档 - 极长期数据，压缩存储

class CompressionType(Enum):
    """压缩类型"""
    NONE = "NONE"
    GZIP = "GZIP"
    BZ2 = "BZ2"
    LZMA = "LZMA"

@dataclass
class StorageConfig:
    """存储配置"""
    tier: StorageTier
    retention_days: int
    compression: CompressionType
    max_size_mb: int
    index_enabled: bool
    backup_enabled: bool
    backup_frequency: str  # cron表达式
    location: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'tier': self.tier.value,
            'retention_days': self.retention_days,
            'compression': self.compression.value,
            'max_size_mb': self.max_size_mb,
            'index_enabled': self.index_enabled,
            'backup_enabled': self.backup_enabled,
            'backup_frequency': self.backup_frequency,
            'location': self.location
        }

@dataclass
class LogFile:
    """日志文件对象"""
    file_id: str
    file_path: str
    size_bytes: int
    created_at: datetime
    last_accessed: datetime
    access_count: int
    tier: StorageTier
    compressed: bool
    indexed: bool
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'file_id': self.file_id,
            'file_path': self.file_path,
            'size_bytes': self.size_bytes,
            'created_at': self.created_at.isoformat(),
            'last_accessed': self.last_accessed.isoformat(),
            'access_count': self.access_count,
            'tier': self.tier.value,
            'compressed': self.compressed,
            'indexed': self.indexed,
            'metadata': self.metadata
        }

class LogStorageManager:
    """日志存储管理器"""
    
    def __init__(self, config_path: str = "config/storage_config.yaml"):
        self.config = self._load_config(config_path)
        self.logger = logging.getLogger(__name__)
        self.redis_client = None
        self.s3_client = None
        self.storage_tiers = {}
        self.file_registry = {}
        self.compression_handlers = {
            CompressionType.GZIP: self._compress_gzip,
            CompressionType.BZ2: self._compress_bz2,
            CompressionType.LZMA: self._compress_lzma
        }
        
        # 初始化Redis连接
        if self.config.get('redis'):
            self.redis_client = redis.Redis(
                host=self.config['redis']['host'],
                port=self.config['redis']['port'],
                decode_responses=True
            )
        
        # 初始化S3客户端
        if self.config.get('s3'):
            self.s3_client = boto3.client(
                's3',
                aws_access_key_id=self.config['s3'].get('access_key'),
                aws_secret_access_key=self.config['s3'].get('secret_key'),
                region_name=self.config['s3'].get('region', 'us-east-1')
            )
        
        # 初始化存储层级
        self._setup_storage_tiers()
        
        # 启动后台任务
        self._start_background_tasks()
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载存储配置"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            self.logger.warning(f"存储配置文件加载失败: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """默认存储配置"""
        return {
            'redis': {
                'host': 'localhost',
                'port': 6379
            },
            's3': {
                'enabled': False,
                'bucket': 'logs-archive',
                'region': 'us-east-1'
            },
            'storage_tiers': {
                'hot': {
                    'retention_days': 7,
                    'compression': 'NONE',
                    'max_size_mb': 10240,  # 10GB
                    'index_enabled': True,
                    'backup_enabled': True,
                    'backup_frequency': '0 2 * * *',  # 每天2点
                    'location': '/var/log/storage/hot'
                },
                'warm': {
                    'retention_days': 30,
                    'compression': 'GZIP',
                    'max_size_mb': 51200,  # 50GB
                    'index_enabled': True,
                    'backup_enabled': True,
                    'backup_frequency': '0 3 * * *',
                    'location': '/var/log/storage/warm'
                },
                'cold': {
                    'retention_days': 90,
                    'compression': 'GZIP',
                    'max_size_mb': 102400,  # 100GB
                    'index_enabled': False,
                    'backup_enabled': True,
                    'backup_frequency': '0 4 * * *',
                    'location': '/var/log/storage/cold'
                },
                'archive': {
                    'retention_days': 365,
                    'compression': 'BZ2',
                    'max_size_mb': 204800,  # 200GB
                    'index_enabled': False,
                    'backup_enabled': True,
                    'backup_frequency': '0 5 1 * *',  # 每月1号5点
                    'location': '/var/log/storage/archive'
                }
            },
            'cleanup': {
                'enabled': True,
                'schedule': '0 1 * * *',  # 每天1点
                'dry_run': False
            },
            'monitoring': {
                'enabled': True,
                'disk_usage_threshold': 85,
                'alert_on_full': True
            }
        }
    
    def _setup_storage_tiers(self):
        """设置存储层级"""
        for tier_name, tier_config in self.config['storage_tiers'].items():
            storage_config = StorageConfig(
                tier=StorageTier(tier_name.upper()),
                retention_days=tier_config['retention_days'],
                compression=CompressionType(tier_config['compression']),
                max_size_mb=tier_config['max_size_mb'],
                index_enabled=tier_config['index_enabled'],
                backup_enabled=tier_config['backup_enabled'],
                backup_frequency=tier_config['backup_frequency'],
                location=tier_config['location']
            )
            
            self.storage_tiers[storage_config.tier] = storage_config
            
            # 创建存储目录
            os.makedirs(storage_config.location, exist_ok=True)
            
            self.logger.info(f"设置存储层级: {tier_name} -> {storage_config.location}")
    
    def _start_background_tasks(self):
        """启动后台任务"""
        # 启动清理任务
        if self.config['cleanup']['enabled']:
            schedule.every().day.at("01:00").do(self._cleanup_expired_logs)
        
        # 启动监控任务
        if self.config['monitoring']['enabled']:
            schedule.every(30).minutes.do(self._monitor_storage_usage)
        
        # 启动备份任务
        for tier_config in self.storage_tiers.values():
            if tier_config.backup_enabled:
                schedule.every().day.at("02:00").do(self._backup_tier, tier_config.tier)
        
        # 启动调度器线程
        def run_scheduler():
            while True:
                schedule.run_pending()
                time.sleep(60)
        
        scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
        scheduler_thread.start()
    
    def store_log_file(self, file_path: str, tier: StorageTier = None) -> str:
        """存储日志文件"""
        if tier is None:
            tier = self._determine_tier(file_path)
        
        storage_config = self.storage_tiers[tier]
        
        try:
            # 生成文件ID
            file_id = self._generate_file_id()
            
            # 目标路径
            target_path = os.path.join(storage_config.location, f"{file_id}.log")
            
            # 复制文件
            shutil.copy2(file_path, target_path)
            
            # 压缩文件
            compressed = False
            if storage_config.compression != CompressionType.NONE:
                target_path = self._compress_file(target_path, storage_config.compression)
                compressed = True
            
            # 创建日志文件对象
            log_file = LogFile(
                file_id=file_id,
                file_path=target_path,
                size_bytes=os.path.getsize(target_path),
                created_at=datetime.now(),
                last_accessed=datetime.now(),
                access_count=0,
                tier=tier,
                compressed=compressed,
                indexed=storage_config.index_enabled
            )
            
            # 注册文件
            self._register_log_file(log_file)
            
            # 存储元数据
            self._store_file_metadata(log_file)
            
            self.logger.info(f"日志文件已存储: {file_id} -> {target_path}")
            return file_id
            
        except Exception as e:
            self.logger.error(f"存储日志文件失败: {e}")
            raise
    
    def retrieve_log_file(self, file_id: str) -> Optional[str]:
        """检索日志文件"""
        try:
            # 获取文件信息
            log_file = self._get_log_file(file_id)
            if not log_file:
                return None
            
            # 更新访问信息
            self._update_file_access(file_id)
            
            # 解压文件（如果需要）
            if log_file.compressed:
                decompressed_path = self._decompress_file(log_file.file_path)
                return decompressed_path
            else:
                return log_file.file_path
                
        except Exception as e:
            self.logger.error(f"检索日志文件失败: {e}")
            return None
    
    def move_log_file(self, file_id: str, target_tier: StorageTier) -> bool:
        """移动日志文件到不同层级"""
        try:
            log_file = self._get_log_file(file_id)
            if not log_file:
                return False
            
            if log_file.tier == target_tier:
                return True
            
            source_config = self.storage_tiers[log_file.tier]
            target_config = self.storage_tiers[target_tier]
            
            # 目标路径
            target_path = os.path.join(target_config.location, f"{file_id}.log")
            
            # 移动文件
            shutil.move(log_file.file_path, target_path)
            
            # 更新文件信息
            log_file.file_path = target_path
            log_file.tier = target_tier
            
            # 重新压缩（如果需要）
            if target_config.compression != source_config.compression:
                if target_config.compression != CompressionType.NONE:
                    target_path = self._compress_file(target_path, target_config.compression)
                    log_file.file_path = target_path
                    log_file.compressed = True
                else:
                    log_file.compressed = False
            
            # 更新注册信息
            self._update_log_file(log_file)
            
            self.logger.info(f"日志文件已移动: {file_id} {log_file.tier.value} -> {target_tier.value}")
            return True
            
        except Exception as e:
            self.logger.error(f"移动日志文件失败: {e}")
            return False
    
    def delete_log_file(self, file_id: str) -> bool:
        """删除日志文件"""
        try:
            log_file = self._get_log_file(file_id)
            if not log_file:
                return False
            
            # 删除物理文件
            if os.path.exists(log_file.file_path):
                os.remove(log_file.file_path)
            
            # 从注册中删除
            self._unregister_log_file(file_id)
            
            # 删除元数据
            self._delete_file_metadata(file_id)
            
            self.logger.info(f"日志文件已删除: {file_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"删除日志文件失败: {e}")
            return False
    
    def get_storage_stats(self) -> Dict[str, Any]:
        """获取存储统计"""
        stats = {
            'total_files': len(self.file_registry),
            'total_size_bytes': 0,
            'by_tier': defaultdict(lambda: {'count': 0, 'size_bytes': 0}),
            'compression_ratio': 0.0,
            'disk_usage': {}
        }
        
        total_original_size = 0
        total_compressed_size = 0
        
        for file_id, log_file in self.file_registry.items():
            stats['total_size_bytes'] += log_file.size_bytes
            stats['by_tier'][log_file.tier.value]['count'] += 1
            stats['by_tier'][log_file.tier.value]['size_bytes'] += log_file.size_bytes
            
            if log_file.compressed:
                total_compressed_size += log_file.size_bytes
            else:
                total_original_size += log_file.size_bytes
        
        # 计算压缩比
        if total_original_size > 0:
            stats['compression_ratio'] = total_compressed_size / total_original_size
        
        # 磁盘使用情况
        for tier, config in self.storage_tiers.items():
            try:
                usage = shutil.disk_usage(config.location)
                stats['disk_usage'][tier.value] = {
                    'total': usage.total,
                    'used': usage.used,
                    'free': usage.free,
                    'usage_percent': (usage.used / usage.total) * 100
                }
            except Exception as e:
                self.logger.debug(f"获取磁盘使用情况失败: {e}")
        
        return dict(stats)
    
    def _determine_tier(self, file_path: str) -> StorageTier:
        """确定文件应该存储在哪个层级"""
        # 基于文件大小和修改时间决定存储层级
        file_stat = os.stat(file_path)
        file_size = file_stat.st_size
        file_age = datetime.now() - datetime.fromtimestamp(file_stat.st_mtime)
        
        # 最近的、大文件 -> 热存储
        if file_age.days < 1 and file_size > 100 * 1024 * 1024:  # 100MB
            return StorageTier.HOT
        
        # 中等大小文件 -> 温存储
        if file_age.days < 7 and file_size > 10 * 1024 * 1024:  # 10MB
            return StorageTier.WARM
        
        # 旧文件 -> 冷存储
        if file_age.days < 30:
            return StorageTier.COLD
        
        # 极旧文件 -> 归档
        return StorageTier.ARCHIVE
    
    def _generate_file_id(self) -> str:
        """生成文件ID"""
        timestamp = int(time.time() * 1000)
        random_suffix = str(hash(str(timestamp)))[-6:]
        return f"log_{timestamp}_{random_suffix}"
    
    def _compress_file(self, file_path: str, compression_type: CompressionType) -> str:
        """压缩文件"""
        if compression_type not in self.compression_handlers:
            return file_path
        
        return self.compression_handlers[compression_type](file_path)
    
    def _compress_gzip(self, file_path: str) -> str:
        """GZIP压缩"""
        compressed_path = file_path + '.gz'
        with open(file_path, 'rb') as f_in:
            with gzip.open(compressed_path, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        os.remove(file_path)
        return compressed_path
    
    def _compress_bz2(self, file_path: str) -> str:
        """BZ2压缩"""
        import bz2
        compressed_path = file_path + '.bz2'
        with open(file_path, 'rb') as f_in:
            with bz2.open(compressed_path, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        os.remove(file_path)
        return compressed_path
    
    def _compress_lzma(self, file_path: str) -> str:
        """LZMA压缩"""
        import lzma
        compressed_path = file_path + '.xz'
        with open(file_path, 'rb') as f_in:
            with lzma.open(compressed_path, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        os.remove(file_path)
        return compressed_path
    
    def _decompress_file(self, file_path: str) -> str:
        """解压文件"""
        if file_path.endswith('.gz'):
            return self._decompress_gzip(file_path)
        elif file_path.endswith('.bz2'):
            return self._decompress_bz2(file_path)
        elif file_path.endswith('.xz'):
            return self._decompress_lzma(file_path)
        else:
            return file_path
    
    def _decompress_gzip(self, file_path: str) -> str:
        """GZIP解压"""
        decompressed_path = file_path[:-3]
        with gzip.open(file_path, 'rb') as f_in:
            with open(decompressed_path, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        return decompressed_path
    
    def _decompress_bz2(self, file_path: str) -> str:
        """BZ2解压"""
        import bz2
        decompressed_path = file_path[:-4]
        with bz2.open(file_path, 'rb') as f_in:
            with open(decompressed_path, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        return decompressed_path
    
    def _decompress_lzma(self, file_path: str) -> str:
        """LZMA解压"""
        import lzma
        decompressed_path = file_path[:-3]
        with lzma.open(file_path, 'rb') as f_in:
            with open(decompressed_path, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        return decompressed_path
    
    def _register_log_file(self, log_file: LogFile):
        """注册日志文件"""
        self.file_registry[log_file.file_id] = log_file
        
        # 存储到Redis
        if self.redis_client:
            try:
                registry_key = f"log_file:{log_file.file_id}"
                self.redis_client.hset(registry_key, mapping={
                    'file_id': log_file.file_id,
                    'file_path': log_file.file_path,
                    'size_bytes': log_file.size_bytes,
                    'created_at': log_file.created_at.isoformat(),
                    'last_accessed': log_file.last_accessed.isoformat(),
                    'access_count': log_file.access_count,
                    'tier': log_file.tier.value,
                    'compressed': str(log_file.compressed),
                    'indexed': str(log_file.indexed)
                })
                self.redis_client.expire(registry_key, 86400 * 30)  # 30天过期
            except Exception as e:
                self.logger.error(f"注册日志文件到Redis失败: {e}")
    
    def _unregister_log_file(self, file_id: str):
        """注销日志文件"""
        if file_id in self.file_registry:
            del self.file_registry[file_id]
        
        # 从Redis删除
        if self.redis_client:
            try:
                self.redis_client.delete(f"log_file:{file_id}")
            except Exception as e:
                self.logger.error(f"从Redis删除日志文件失败: {e}")
    
    def _get_log_file(self, file_id: str) -> Optional[LogFile]:
        """获取日志文件信息"""
        if file_id in self.file_registry:
            return self.file_registry[file_id]
        
        # 从Redis获取
        if self.redis_client:
            try:
                registry_key = f"log_file:{file_id}"
                data = self.redis_client.hgetall(registry_key)
                if data:
                    log_file = LogFile(
                        file_id=data['file_id'],
                        file_path=data['file_path'],
                        size_bytes=int(data['size_bytes']),
                        created_at=datetime.fromisoformat(data['created_at']),
                        last_accessed=datetime.fromisoformat(data['last_accessed']),
                        access_count=int(data['access_count']),
                        tier=StorageTier(data['tier']),
                        compressed=data['compressed'] == 'True',
                        indexed=data['indexed'] == 'True'
                    )
                    self.file_registry[file_id] = log_file
                    return log_file
            except Exception as e:
                self.logger.error(f"从Redis获取日志文件失败: {e}")
        
        return None
    
    def _update_log_file(self, log_file: LogFile):
        """更新日志文件信息"""
        self.file_registry[log_file.file_id] = log_file
        self._store_file_metadata(log_file)
    
    def _update_file_access(self, file_id: str):
        """更新文件访问信息"""
        log_file = self._get_log_file(file_id)
        if log_file:
            log_file.last_accessed = datetime.now()
            log_file.access_count += 1
            self._update_log_file(log_file)
    
    def _store_file_metadata(self, log_file: LogFile):
        """存储文件元数据"""
        if self.redis_client:
            try:
                metadata_key = f"log_metadata:{log_file.file_id}"
                metadata = {
                    'file_id': log_file.file_id,
                    'created_at': log_file.created_at.isoformat(),
                    'last_accessed': log_file.last_accessed.isoformat(),
                    'access_count': log_file.access_count,
                    'tier': log_file.tier.value,
                    'metadata': json.dumps(log_file.metadata)
                }
                self.redis_client.hset(metadata_key, mapping=metadata)
                self.redis_client.expire(metadata_key, 86400 * 365)  # 1年过期
            except Exception as e:
                self.logger.error(f"存储文件元数据失败: {e}")
    
    def _delete_file_metadata(self, file_id: str):
        """删除文件元数据"""
        if self.redis_client:
            try:
                self.redis_client.delete(f"log_file:{file_id}")
                self.redis_client.delete(f"log_metadata:{file_id}")
            except Exception as e:
                self.logger.error(f"删除文件元数据失败: {e}")
    
    def _cleanup_expired_logs(self):
        """清理过期日志"""
        self.logger.info("开始清理过期日志...")
        
        current_time = datetime.now()
        expired_files = []
        
        for file_id, log_file in self.file_registry.items():
            storage_config = self.storage_tiers[log_file.tier]
            expiry_time = log_file.created_at + timedelta(days=storage_config.retention_days)
            
            if current_time > expiry_time:
                expired_files.append(file_id)
        
        # 删除过期文件
        for file_id in expired_files:
            if not self.config['cleanup']['dry_run']:
                self.delete_log_file(file_id)
            self.logger.info(f"清理过期文件: {file_id}")
        
        self.logger.info(f"清理完成，删除了 {len(expired_files)} 个过期文件")
    
    def _monitor_storage_usage(self):
        """监控存储使用情况"""
        threshold = self.config['monitoring']['disk_usage_threshold']
        
        for tier, config in self.storage_tiers.items():
            try:
                usage = shutil.disk_usage(config.location)
                usage_percent = (usage.used / usage.total) * 100
                
                if usage_percent > threshold:
                    self.logger.warning(f"存储层级 {tier.value} 使用率过高: {usage_percent:.1f}%")
                    
                    if self.config['monitoring']['alert_on_full']:
                        self._trigger_storage_alert(tier, usage_percent)
                        
            except Exception as e:
                self.logger.error(f"监控存储使用情况失败: {e}")
    
    def _trigger_storage_alert(self, tier: StorageTier, usage_percent: float):
        """触发存储告警"""
        # 这里可以集成告警系统
        self.logger.critical(f"存储层级 {tier.value} 即将满载: {usage_percent:.1f}%")
    
    def _backup_tier(self, tier: StorageTier):
        """备份存储层级"""
        config = self.storage_tiers[tier]
        
        if not config.backup_enabled:
            return
        
        try:
            backup_path = f"{config.location}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            shutil.copytree(config.location, backup_path)
            
            # 上传到S3（如果配置了）
            if self.s3_client and self.config['s3']['enabled']:
                self._upload_to_s3(backup_path, tier)
            
            self.logger.info(f"存储层级 {tier.value} 备份完成: {backup_path}")
            
        except Exception as e:
            self.logger.error(f"备份存储层级 {tier.value} 失败: {e}")
    
    def _upload_to_s3(self, backup_path: str, tier: StorageTier):
        """上传备份到S3"""
        try:
            bucket = self.config['s3']['bucket']
            s3_key = f"backups/{tier.value.lower()}/{os.path.basename(backup_path)}.tar.gz"
            
            # 创建tar.gz压缩包
            import tarfile
            tar_path = f"{backup_path}.tar.gz"
            with tarfile.open(tar_path, "w:gz") as tar:
                tar.add(backup_path, arcname=os.path.basename(backup_path))
            
            # 上传到S3
            self.s3_client.upload_file(tar_path, bucket, s3_key)
            
            # 清理本地备份
            shutil.rmtree(backup_path)
            os.remove(tar_path)
            
            self.logger.info(f"备份已上传到S3: s3://{bucket}/{s3_key}")
            
        except Exception as e:
            self.logger.error(f"上传备份到S3失败: {e}")

class LogArchiver:
    """日志归档器"""
    
    def __init__(self, storage_manager: LogStorageManager):
        self.storage_manager = storage_manager
        self.logger = logging.getLogger(__name__)
        self.archive_queue = deque()
        self.archive_thread = None
        self.running = False
    
    def start(self):
        """启动归档器"""
        self.running = True
        self.archive_thread = threading.Thread(target=self._archive_worker, daemon=True)
        self.archive_thread.start()
        self.logger.info("日志归档器已启动")
    
    def stop(self):
        """停止归档器"""
        self.running = False
        if self.archive_thread:
            self.archive_thread.join()
        self.logger.info("日志归档器已停止")
    
    def archive_logs(self, file_ids: List[str], target_tier: StorageTier):
        """归档日志文件"""
        for file_id in file_ids:
            self.archive_queue.append((file_id, target_tier))
    
    def _archive_worker(self):
        """归档工作线程"""
        while self.running:
            try:
                if self.archive_queue:
                    file_id, target_tier = self.archive_queue.popleft()
                    success = self.storage_manager.move_log_file(file_id, target_tier)
                    if success:
                        self.logger.debug(f"日志文件已归档: {file_id} -> {target_tier.value}")
                    else:
                        self.logger.warning(f"日志文件归档失败: {file_id}")
                else:
                    time.sleep(1)
            except Exception as e:
                self.logger.error(f"归档工作线程错误: {e}")
                time.sleep(5)

def main():
    """主函数 - 测试存储管理器"""
    # 创建存储管理器
    storage_manager = LogStorageManager()
    
    # 创建归档器
    archiver = LogArchiver(storage_manager)
    archiver.start()
    
    # 创建测试日志文件
    test_file_path = "/tmp/test.log"
    with open(test_file_path, 'w') as f:
        for i in range(1000):
            f.write(f"Test log entry {i}\n")
    
    # 存储日志文件
    file_id = storage_manager.store_log_file(test_file_path)
    print(f"日志文件已存储: {file_id}")
    
    # 检索日志文件
    retrieved_path = storage_manager.retrieve_log_file(file_id)
    print(f"日志文件已检索: {retrieved_path}")
    
    # 获取存储统计
    stats = storage_manager.get_storage_stats()
    print(f"存储统计: {stats}")
    
    # 归档文件
    archiver.archive_logs([file_id], StorageTier.COLD)
    time.sleep(2)  # 等待归档完成
    
    # 停止归档器
    archiver.stop()
    
    # 清理测试文件
    os.remove(test_file_path)
    if retrieved_path and os.path.exists(retrieved_path):
        os.remove(retrieved_path)

if __name__ == "__main__":
    main()
