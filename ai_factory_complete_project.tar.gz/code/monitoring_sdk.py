"""
PDF图纸识别监控数据采集SDK
提供指标收集、监控数据上报等功能
"""

import time
import json
import logging
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass, asdict
from datetime import datetime
from prometheus_client import Counter, Histogram, Gauge, start_http_server
import threading
import queue
import requests


@dataclass
class MonitoringConfig:
    """监控配置"""
    prometheus_endpoint: str = "http://localhost:9090"
    pushgateway_endpoint: str = "http://localhost:9091"
    service_name: str = "pdf-blueprint-recognition"
    service_version: str = "1.0.0"
    environment: str = "production"
    sample_rate: float = 1.0
    buffer_size: int = 1000
    flush_interval: int = 10


@dataclass
class PerformanceMetrics:
    """性能指标数据"""
    timestamp: str
    service_name: str
    blueprint_type: str
    model_version: str
    accuracy: float
    recall: float
    f1_score: float
    precision: float
    processing_time: float
    memory_usage: float
    cpu_usage: float
    error_count: int
    total_requests: int
    success_rate: float
    ab_test_group: Optional[str] = None
    confidence_interval: Optional[float] = None


class PDFRecognitionMonitor:
    """PDF识别监控器"""
    
    def __init__(self, config: MonitoringConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.metrics_buffer = queue.Queue(maxsize=config.buffer_size)
        self.running = False
        self.thread = None
        
        # Prometheus指标定义
        self._init_prometheus_metrics()
        
        # 启动HTTP服务器暴露指标
        self._start_metrics_server()
    
    def _init_prometheus_metrics(self):
        """初始化Prometheus指标"""
        try:
            from prometheus_client import Counter, Histogram, Gauge, CollectorRegistry, CONTENT_TYPE_LATEST
            
            # 识别性能指标
            self.recognition_accuracy = Gauge(
                'pdf_blueprint_recognition_accuracy',
                'PDF识别准确率',
                ['service_name', 'blueprint_type', 'model_version']
            )
            
            self.recognition_recall = Gauge(
                'pdf_blueprint_recognition_recall',
                'PDF识别召回率',
                ['service_name', 'blueprint_type', 'model_version']
            )
            
            self.recognition_f1_score = Gauge(
                'pdf_blueprint_recognition_f1_score',
                'PDF识别F1-score',
                ['service_name', 'blueprint_type', 'model_version']
            )
            
            self.recognition_precision = Gauge(
                'pdf_blueprint_recognition_precision',
                'PDF识别精确率',
                ['service_name', 'blueprint_type', 'model_version']
            )
            
            # 处理时间指标
            self.processing_time = Histogram(
                'pdf_blueprint_recognition_processing_time_seconds',
                'PDF识别处理时间',
                ['service_name', 'blueprint_type', 'model_version']
            )
            
            # 错误和请求指标
            self.total_requests = Counter(
                'pdf_blueprint_recognition_total',
                'PDF识别总请求数',
                ['service_name', 'blueprint_type', 'model_version']
            )
            
            self.recognition_errors = Counter(
                'pdf_blueprint_recognition_errors_total',
                'PDF识别错误总数',
                ['service_name', 'blueprint_type', 'model_version', 'error_type']
            )
            
            # 系统资源指标
            self.memory_usage = Gauge(
                'pdf_model_memory_usage_bytes',
                '模型内存使用量',
                ['service_name', 'model_version']
            )
            
            self.cpu_usage = Gauge(
                'pdf_model_cpu_usage_percent',
                '模型CPU使用率',
                ['service_name', 'model_version']
            )
            
            # A/B测试指标
            self.ab_test_accuracy = Gauge(
                'pdf_ab_test_accuracy',
                'A/B测试准确率',
                ['service_name', 'model_version', 'test_group']
            )
            
            self.ab_test_samples = Counter(
                'pdf_ab_test_samples_total',
                'A/B测试样本总数',
                ['service_name', 'model_version', 'test_group']
            )
            
            self.logger.info("Prometheus指标初始化完成")
            
        except ImportError:
            self.logger.warning("prometheus_client未安装，将使用模拟指标")
            self._init_mock_metrics()
    
    def _init_mock_metrics(self):
        """初始化模拟指标（用于测试）"""
        self.metrics_data = {
            'accuracy': [],
            'recall': [],
            'f1_score': [],
            'precision': [],
            'processing_time': [],
            'total_requests': 0,
            'errors': 0,
            'memory_usage': 0,
            'cpu_usage': 0
        }
    
    def _start_metrics_server(self):
        """启动指标暴露服务器"""
        try:
            start_http_server(8000)
            self.logger.info("指标服务器启动在端口8000")
        except Exception as e:
            self.logger.error(f"启动指标服务器失败: {e}")
    
    def start(self):
        """启动监控"""
        if not self.running:
            self.running = True
            self.thread = threading.Thread(target=self._flush_worker, daemon=True)
            self.thread.start()
            self.logger.info("PDF识别监控器已启动")
    
    def stop(self):
        """停止监控"""
        if self.running:
            self.running = False
            if self.thread:
                self.thread.join(timeout=5)
            self.logger.info("PDF识别监控器已停止")
    
    def _flush_worker(self):
        """指标缓冲刷新工作线程"""
        while self.running:
            try:
                self._flush_metrics()
                time.sleep(self.config.flush_interval)
            except Exception as e:
                self.logger.error(f"刷新指标时出错: {e}")
    
    def _flush_metrics(self):
        """刷新指标到监控系统"""
        while not self.metrics_buffer.empty():
            try:
                metrics = self.metrics_buffer.get_nowait()
                self._push_to_prometheus(metrics)
            except queue.Empty:
                break
            except Exception as e:
                self.logger.error(f"推送指标失败: {e}")
    
    def _push_to_prometheus(self, metrics: PerformanceMetrics):
        """推送指标到Prometheus"""
        try:
            # 设置指标值
            labels = {
                'service_name': metrics.service_name,
                'blueprint_type': metrics.blueprint_type,
                'model_version': metrics.model_version
            }
            
            self.recognition_accuracy.labels(**labels).set(metrics.accuracy)
            self.recognition_recall.labels(**labels).set(metrics.recall)
            self.recognition_f1_score.labels(**labels).set(metrics.f1_score)
            self.recognition_precision.labels(**labels).set(metrics.precision)
            
            # 记录处理时间
            self.processing_time.labels(**labels).observe(metrics.processing_time)
            
            # 更新计数器
            self.total_requests.labels(**labels).inc(metrics.total_requests)
            self.recognition_errors.labels(
                **labels, error_type='general'
            ).inc(metrics.error_count)
            
            # 系统资源
            self.memory_usage.labels(
                service_name=metrics.service_name,
                model_version=metrics.model_version
            ).set(metrics.memory_usage)
            
            self.cpu_usage.labels(
                service_name=metrics.service_name,
                model_version=metrics.model_version
            ).set(metrics.cpu_usage)
            
            # A/B测试指标
            if metrics.ab_test_group:
                ab_labels = {
                    'service_name': metrics.service_name,
                    'model_version': metrics.model_version,
                    'test_group': metrics.ab_test_group
                }
                self.ab_test_accuracy.labels(**ab_labels).set(metrics.accuracy)
                self.ab_test_samples.labels(**ab_labels).inc(metrics.total_requests)
            
        except Exception as e:
            self.logger.error(f"设置Prometheus指标失败: {e}")
    
    def record_performance(self, metrics: PerformanceMetrics):
        """记录性能指标"""
        try:
            if self.config.sample_rate < 1.0:
                import random
                if random.random() > self.config.sample_rate:
                    return
            
            self.metrics_buffer.put(metrics, timeout=1)
        except queue.Full:
            self.logger.warning("指标缓冲区已满，丢弃指标")
        except Exception as e:
            self.logger.error(f"记录指标失败: {e}")
    
    def record_recognition_result(self, 
                                blueprint_type: str,
                                model_version: str,
                                accuracy: float,
                                recall: float,
                                f1_score: float,
                                precision: float,
                                processing_time: float,
                                memory_usage: float = 0,
                                cpu_usage: float = 0,
                                error_count: int = 0,
                                total_requests: int = 1,
                                success_rate: float = 1.0,
                                ab_test_group: Optional[str] = None):
        """记录识别结果"""
        metrics = PerformanceMetrics(
            timestamp=datetime.now().isoformat(),
            service_name=self.config.service_name,
            blueprint_type=blueprint_type,
            model_version=model_version,
            accuracy=accuracy,
            recall=recall,
            f1_score=f1_score,
            precision=precision,
            processing_time=processing_time,
            memory_usage=memory_usage,
            cpu_usage=cpu_usage,
            error_count=error_count,
            total_requests=total_requests,
            success_rate=success_rate,
            ab_test_group=ab_test_group
        )
        
        self.record_performance(metrics)
    
    def record_ab_test_result(self,
                            model_version: str,
                            group_a_accuracy: float,
                            group_b_accuracy: float,
                            group_a_samples: int,
                            group_b_samples: int):
        """记录A/B测试结果"""
        # 记录A组结果
        self.record_recognition_result(
            blueprint_type="ab_test",
            model_version=model_version,
            accuracy=group_a_accuracy,
            recall=0,  # 简化处理
            f1_score=0,  # 简化处理
            precision=0,  # 简化处理
            processing_time=0,  # 简化处理
            total_requests=group_a_samples,
            ab_test_group="A"
        )
        
        # 记录B组结果
        self.record_recognition_result(
            blueprint_type="ab_test",
            model_version=model_version,
            accuracy=group_b_accuracy,
            recall=0,  # 简化处理
            f1_score=0,  # 简化处理
            precision=0,  # 简化处理
            processing_time=0,  # 简化处理
            total_requests=group_b_samples,
            ab_test_group="B"
        )
    
    def get_current_metrics(self) -> Dict[str, Any]:
        """获取当前指标（用于测试）"""
        if hasattr(self, 'metrics_data'):
            return self.metrics_data.copy()
        return {}


# 使用示例
if __name__ == "__main__":
    # 配置监控
    config = MonitoringConfig(
        service_name="pdf-blueprint-recognition",
        environment="development",
        sample_rate=1.0
    )
    
    # 创建监控器
    monitor = PDFRecognitionMonitor(config)
    monitor.start()
    
    try:
        # 模拟记录一些指标
        for i in range(10):
            monitor.record_recognition_result(
                blueprint_type="architectural",
                model_version="v1.0",
                accuracy=0.85 + i * 0.01,
                recall=0.80 + i * 0.01,
                f1_score=0.82 + i * 0.01,
                precision=0.83 + i * 0.01,
                processing_time=2.5 + i * 0.1,
                memory_usage=1024 + i * 100,
                cpu_usage=45 + i * 2
            )
            time.sleep(1)
        
        # 记录A/B测试结果
        monitor.record_ab_test_result(
            model_version="v1.0",
            group_a_accuracy=0.85,
            group_b_accuracy=0.87,
            group_a_samples=1000,
            group_b_samples=1000
        )
        
        print("监控数据记录完成，请查看 http://localhost:8000/metrics")
        time.sleep(30)  # 等待30秒
        
    finally:
        monitor.stop()