"""
识别结果后处理和置信度验证系统
=====================================

完整的PDF图纸识别结果后处理和置信度验证系统，包括：
1. 识别结果后处理和优化
2. 置信度计算和评估
3. 结果一致性检查和验证
4. 异常检测和错误纠正
5. 结果格式化和输出
6. 质量评估和反馈机制

作者: MiniMax Agent
版本: 1.0.0
日期: 2025-11-06
"""

import json
import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
from enum import Enum
import warnings
from collections import defaultdict, Counter
from datetime import datetime
import hashlib

# 第三方库
try:
    from sklearn.metrics import accuracy_score, precision_recall_fscore_support
    from sklearn.preprocessing import StandardScaler
    from sklearn.ensemble import IsolationForest
    from sklearn.cluster import DBSCAN
    import networkx as nx
    from scipy.spatial.distance import cdist
    from scipy.optimize import minimize
    import matplotlib.pyplot as plt
    import seaborn as sns
    from scipy.stats import chi2_contingency, ks_2samp
    from scipy.spatial import KDTree
    from scipy.sparse import csr_matrix
    import cv2
except ImportError as e:
    warnings.warn(f"部分依赖库未安装: {e}")

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ResultType(Enum):
    """识别结果类型枚举"""
    TEXT = "text"
    SYMBOL = "symbol"
    LINE = "line"
    GEOMETRY = "geometry"
    DIMENSION = "dimension"
    ANNOTATION = "annotation"


class ErrorType(Enum):
    """错误类型枚举"""
    GEOMETRIC = "geometric"
    SEMANTIC = "semantic"
    TOPOLOGICAL = "topological"
    DIMENSIONAL = "dimensional"
    CONSISTENCY = "consistency"


class QualityLevel(Enum):
    """质量等级枚举"""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    FAILED = "failed"


@dataclass
class RecognitionResult:
    """识别结果数据类"""
    id: str
    type: ResultType
    content: Dict[str, Any]
    confidence: float
    bbox: Optional[Tuple[float, float, float, float]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    processing_time: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            'id': self.id,
            'type': self.type.value,
            'content': self.content,
            'confidence': self.confidence,
            'bbox': self.bbox,
            'metadata': self.metadata,
            'processing_time': self.processing_time,
            'timestamp': self.timestamp.isoformat()
        }


@dataclass
class ValidationResult:
    """验证结果数据类"""
    is_valid: bool
    confidence: float
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    quality_score: float = 0.0
    suggestions: List[str] = field(default_factory=list)


@dataclass
class ConsistencyCheck:
    """一致性检查结果"""
    geometric_consistency: float = 1.0
    semantic_consistency: float = 1.0
    topological_consistency: float = 1.0
    dimensional_consistency: float = 1.0
    overall_score: float = 1.0
    violations: List[str] = field(default_factory=list)


class ConfidenceCalculator:
    """置信度计算器"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.scaler = StandardScaler()
        self.is_fitted = False
        
    def fit(self, training_data: List[RecognitionResult]):
        """使用训练数据拟合置信度计算器"""
        features = []
        for result in training_data:
            feature_vector = self._extract_features(result)
            features.append(feature_vector)
        
        if features:
            self.scaler.fit(np.array(features))
            self.is_fitted = True
            logger.info("置信度计算器训练完成")
    
    def _extract_features(self, result: RecognitionResult) -> List[float]:
        """提取特征向量"""
        features = []
        
        # 基础特征
        features.append(result.confidence)
        features.append(result.processing_time)
        
        # 内容特征
        if result.type == ResultType.TEXT:
            content = result.content
            features.append(len(content.get('text', '')))
            features.append(content.get('font_size', 0))
            features.append(content.get('font_weight', 0))
        elif result.type == ResultType.SYMBOL:
            content = result.content
            features.append(content.get('symbol_size', 0))
            features.append(content.get('complexity_score', 0))
        elif result.type == ResultType.GEOMETRY:
            content = result.content
            features.append(content.get('area', 0))
            features.append(content.get('perimeter', 0))
            features.append(content.get('aspect_ratio', 0))
        
        # 空间特征
        if result.bbox:
            x, y, w, h = result.bbox
            features.append(w * h)  # 面积
            features.append(w / (h + 1e-8))  # 宽高比
            features.append(x + y)  # 位置特征
        
        # 填充到固定长度
        while len(features) < 20:
            features.append(0.0)
        
        return features[:20]
    
    def calculate_confidence(self, result: RecognitionResult) -> float:
        """计算增强置信度"""
        if not self.is_fitted:
            return result.confidence
        
        features = self._extract_features(result)
        features = np.array(features).reshape(1, -1)
        features = self.scaler.transform(features)
        
        # 使用简单的线性组合计算置信度
        weights = np.array([0.3, 0.1, 0.2, 0.1, 0.1, 0.1, 0.1])  # 可学习权重
        if len(features[0]) >= len(weights):
            enhanced_confidence = np.dot(features[0][:len(weights)], weights)
            return np.clip(enhanced_confidence, 0, 1)
        
        return result.confidence


class ConsistencyChecker:
    """结果一致性检查器"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.tolerance = config.get('tolerance', 0.02)
        
    def check_consistency(self, results: List[RecognitionResult]) -> ConsistencyCheck:
        """检查结果一致性"""
        violations = []
        
        # 几何一致性检查
        geometric_score = self._check_geometric_consistency(results)
        if geometric_score < 0.8:
            violations.append("几何一致性不足")
        
        # 语义一致性检查
        semantic_score = self._check_semantic_consistency(results)
        if semantic_score < 0.8:
            violations.append("语义一致性不足")
        
        # 拓扑一致性检查
        topological_score = self._check_topological_consistency(results)
        if topological_score < 0.8:
            violations.append("拓扑一致性不足")
        
        # 尺寸一致性检查
        dimensional_score = self._check_dimensional_consistency(results)
        if dimensional_score < 0.8:
            violations.append("尺寸一致性不足")
        
        overall_score = (geometric_score + semantic_score + 
                        topological_score + dimensional_score) / 4
        
        return ConsistencyCheck(
            geometric_consistency=geometric_score,
            semantic_consistency=semantic_score,
            topological_consistency=topological_score,
            dimensional_consistency=dimensional_score,
            overall_score=overall_score,
            violations=violations
        )
    
    def _check_geometric_consistency(self, results: List[RecognitionResult]) -> float:
        """检查几何一致性"""
        geometries = [r for r in results if r.type == ResultType.GEOMETRY]
        if len(geometries) < 2:
            return 1.0
        
        scores = []
        for i, geom1 in enumerate(geometries):
            for geom2 in geometries[i+1:]:
                score = self._calculate_geometric_similarity(geom1, geom2)
                scores.append(score)
        
        return np.mean(scores) if scores else 1.0
    
    def _calculate_geometric_similarity(self, geom1: RecognitionResult, 
                                     geom2: RecognitionResult) -> float:
        """计算几何相似度"""
        # 简化的几何相似度计算
        bbox1 = geom1.bbox
        bbox2 = geom2.bbox
        
        if not bbox1 or not bbox2:
            return 0.5
        
        # 计算边界框重叠度
        x1, y1, w1, h1 = bbox1
        x2, y2, w2, h2 = bbox2
        
        # 计算交集
        inter_x = max(0, min(x1 + w1, x2 + w2) - max(x1, x2))
        inter_y = max(0, min(y1 + h1, y2 + h2) - max(y1, y2))
        inter_area = inter_x * inter_y
        
        # 计算并集
        union_area = w1 * h1 + w2 * h2 - inter_area
        
        if union_area == 0:
            return 0.0
        
        iou = inter_area / union_area
        return min(1.0, iou * 2)  # 标准化到[0,1]
    
    def _check_semantic_consistency(self, results: List[RecognitionResult]) -> float:
        """检查语义一致性"""
        texts = [r for r in results if r.type == ResultType.TEXT]
        if len(texts) < 2:
            return 1.0
        
        # 检查文本内容的一致性
        text_contents = [r.content.get('text', '') for r in texts]
        
        # 简单的重复检测
        text_counter = Counter(text_contents)
        total_texts = len(text_contents)
        duplicates = sum(count - 1 for count in text_counter.values() if count > 1)
        
        consistency = 1.0 - (duplicates / total_texts)
        return max(0.0, consistency)
    
    def _check_topological_consistency(self, results: List[RecognitionResult]) -> float:
        """检查拓扑一致性"""
        # 构建拓扑图
        try:
            graph = nx.Graph()
            
            # 添加节点
            for result in results:
                graph.add_node(result.id, **result.content)
            
            # 添加边（基于空间关系）
            for i, result1 in enumerate(results):
                for j, result2 in enumerate(results[i+1:], i+1):
                    if self._are_spatially_related(result1, result2):
                        graph.add_edge(result1.id, result2.id)
            
            # 检查连通性
            if len(graph.nodes) > 0:
                num_components = nx.number_connected_components(graph)
                max_component_size = max(len(c) for c in nx.connected_components(graph))
                connectivity = max_component_size / len(graph.nodes)
                return connectivity
            return 1.0
            
        except Exception as e:
            logger.warning(f"拓扑一致性检查失败: {e}")
            return 0.5
    
    def _are_spatially_related(self, result1: RecognitionResult, 
                             result2: RecognitionResult) -> bool:
        """判断两个结果是否空间相关"""
        if not result1.bbox or not result2.bbox:
            return False
        
        x1, y1, w1, h1 = result1.bbox
        x2, y2, w2, h2 = result2.bbox
        
        # 计算中心点距离
        center1 = (x1 + w1/2, y1 + h1/2)
        center2 = (x2 + w2/2, y2 + h2/2)
        
        distance = np.sqrt((center1[0] - center2[0])**2 + (center1[1] - center2[1])**2)
        
        # 判断是否在合理距离内
        threshold = min(w1, w2, h1, h2) * 2
        return distance <= threshold
    
    def _check_dimensional_consistency(self, results: List[RecognitionResult]) -> float:
        """检查尺寸一致性"""
        dimensions = [r for r in results if r.type == ResultType.DIMENSION]
        if len(dimensions) < 2:
            return 1.0
        
        # 检查尺寸值的合理性
        dimension_values = []
        for dim in dimensions:
            value = dim.content.get('value', 0)
            if isinstance(value, (int, float)):
                dimension_values.append(value)
        
        if len(dimension_values) < 2:
            return 1.0
        
        # 检查尺寸值的分布
        values = np.array(dimension_values)
        if np.mean(values) == 0:
            return 0.5
        
        cv = np.std(values) / np.mean(values)  # 变异系数
        consistency = max(0.0, 1.0 - cv)  # 变异系数越小，一致性越高
        
        return consistency


class AnomalyDetector:
    """异常检测器"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.isolation_forest = IsolationForest(
            contamination=config.get('contamination', 0.1),
            random_state=42
        )
        self.dbscan = DBSCAN(
            eps=config.get('eps', 0.5),
            min_samples=config.get('min_samples', 5)
        )
        self.is_fitted = False
    
    def fit(self, results: List[RecognitionResult]):
        """训练异常检测模型"""
        features = []
        for result in results:
            feature_vector = self._extract_features(result)
            features.append(feature_vector)
        
        if features:
            X = np.array(features)
            self.isolation_forest.fit(X)
            self.is_fitted = True
            logger.info("异常检测器训练完成")
    
    def _extract_features(self, result: RecognitionResult) -> List[float]:
        """提取特征向量用于异常检测"""
        features = []
        
        # 置信度特征
        features.append(result.confidence)
        
        # 处理时间特征
        features.append(result.processing_time)
        
        # 内容特征
        if result.type == ResultType.TEXT:
            features.append(len(result.content.get('text', '')))
            features.append(result.content.get('font_size', 0))
        elif result.type == ResultType.SYMBOL:
            features.append(result.content.get('symbol_size', 0))
        elif result.type == ResultType.GEOMETRY:
            if result.bbox:
                features.append(result.bbox[2] * result.bbox[3])  # 面积
            else:
                features.append(0)
        
        # 填充到固定长度
        while len(features) < 10:
            features.append(0.0)
        
        return features[:10]
    
    def detect_anomalies(self, results: List[RecognitionResult]) -> Dict[str, List[RecognitionResult]]:
        """检测异常结果"""
        if not self.is_fitted:
            logger.warning("异常检测器未训练，返回空结果")
            return {'anomalies': [], 'normal': results}
        
        features = [self._extract_features(result) for result in results]
        X = np.array(features)
        
        # 孤立森林检测
        anomaly_scores = self.isolation_forest.decision_function(X)
        is_anomaly = self.isolation_forest.predict(X) == -1
        
        anomalies = [result for result, is_anom in zip(results, is_anomaly) if is_anom]
        normal = [result for result, is_anom in zip(results, is_anomaly) if not is_anom]
        
        return {
            'anomalies': anomalies,
            'normal': normal,
            'scores': anomaly_scores
        }
    
    def classify_errors(self, results: List[RecognitionResult]) -> Dict[ErrorType, List[RecognitionResult]]:
        """错误类型分类"""
        error_groups = {
            ErrorType.GEOMETRIC: [],
            ErrorType.SEMANTIC: [],
            ErrorType.TOPOLOGICAL: [],
            ErrorType.DIMENSIONAL: [],
            ErrorType.CONSISTENCY: []
        }
        
        for result in results:
            error_type = self._classify_error_type(result)
            error_groups[error_type].append(result)
        
        return error_groups
    
    def _classify_error_type(self, result: RecognitionResult) -> ErrorType:
        """分类错误类型"""
        if result.confidence < 0.5:
            return ErrorType.GEOMETRIC
        
        if result.type == ResultType.TEXT:
            text = result.content.get('text', '')
            if len(text) > 100 or len(text) < 1:
                return ErrorType.SEMANTIC
        
        elif result.type == ResultType.GEOMETRY:
            if result.bbox:
                w, h = result.bbox[2], result.bbox[3]
                if w > 1000 or h > 1000 or w < 5 or h < 5:
                    return ErrorType.GEOMETRIC
        
        elif result.type == ResultType.DIMENSION:
            value = result.content.get('value', 0)
            if not isinstance(value, (int, float)) or value <= 0:
                return ErrorType.DIMENSIONAL
        
        return ErrorType.CONSISTENCY


class ResultOptimizer:
    """结果优化器"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        
    def optimize_results(self, results: List[RecognitionResult]) -> List[RecognitionResult]:
        """优化识别结果"""
        logger.info(f"开始优化 {len(results)} 个识别结果")
        
        # 1. 去重
        results = self._remove_duplicates(results)
        
        # 2. 合并重叠结果
        results = self._merge_overlapping(results)
        
        # 3. 几何关系优化
        results = self._optimize_geometric_relations(results)
        
        # 4. 语义一致性优化
        results = self._optimize_semantic_consistency(results)
        
        logger.info(f"优化完成，剩余 {len(results)} 个结果")
        return results
    
    def _remove_duplicates(self, results: List[RecognitionResult]) -> List[RecognitionResult]:
        """移除重复结果"""
        seen = set()
        unique_results = []
        
        for result in results:
            # 创建唯一标识
            content_hash = hashlib.md5(
                json.dumps(result.content, sort_keys=True).encode()
            ).hexdigest()
            
            identifier = (result.type.value, content_hash)
            
            if identifier not in seen:
                seen.add(identifier)
                unique_results.append(result)
        
        return unique_results
    
    def _merge_overlapping(self, results: List[RecognitionResult]) -> List[RecognitionResult]:
        """合并重叠结果"""
        merged_results = []
        used = set()
        
        for i, result1 in enumerate(results):
            if i in used:
                continue
            
            current_result = result1
            overlapping_indices = []
            
            for j, result2 in enumerate(results[i+1:], i+1):
                if j in used:
                    continue
                
                if self._are_overlapping(result1, result2):
                    # 合并结果
                    current_result = self._merge_results(current_result, result2)
                    overlapping_indices.append(j)
                    used.add(j)
            
            merged_results.append(current_result)
            used.add(i)
        
        return merged_results
    
    def _are_overlapping(self, result1: RecognitionResult, result2: RecognitionResult) -> bool:
        """判断两个结果是否重叠"""
        if not result1.bbox or not result2.bbox:
            return False
        
        x1, y1, w1, h1 = result1.bbox
        x2, y2, w2, h2 = result2.bbox
        
        # 计算交集
        inter_x = max(0, min(x1 + w1, x2 + w2) - max(x1, x2))
        inter_y = max(0, min(y1 + h1, y2 + h2) - max(y1, y2))
        
        return inter_x > 0 and inter_y > 0
    
    def _merge_results(self, result1: RecognitionResult, result2: RecognitionResult) -> RecognitionResult:
        """合并两个结果"""
        # 选择置信度更高的结果作为基础
        if result2.confidence > result1.confidence:
            base_result = result2
            other_result = result1
        else:
            base_result = result1
            other_result = result2
        
        # 合并内容
        merged_content = {**base_result.content}
        for key, value in other_result.content.items():
            if key not in merged_content:
                merged_content[key] = value
            elif isinstance(value, list) and isinstance(merged_content[key], list):
                merged_content[key].extend(value)
        
        # 合并边界框
        if base_result.bbox and other_result.bbox:
            x1, y1, w1, h1 = base_result.bbox
            x2, y2, w2, h2 = other_result.bbox
            
            new_x = min(x1, x2)
            new_y = min(y1, y2)
            new_w = max(x1 + w1, x2 + w2) - new_x
            new_h = max(y1 + h1, y2 + h2) - new_y
            merged_bbox = (new_x, new_y, new_w, new_h)
        else:
            merged_bbox = base_result.bbox or other_result.bbox
        
        # 合并元数据
        merged_metadata = {**base_result.metadata}
        merged_metadata.update(other_result.metadata)
        
        return RecognitionResult(
            id=base_result.id,
            type=base_result.type,
            content=merged_content,
            confidence=max(base_result.confidence, other_result.confidence),
            bbox=merged_bbox,
            metadata=merged_metadata,
            processing_time=base_result.processing_time + other_result.processing_time
        )
    
    def _optimize_geometric_relations(self, results: List[RecognitionResult]) -> List[RecognitionResult]:
        """优化几何关系"""
        geometries = [r for r in results if r.type == ResultType.GEOMETRY]
        
        # 简化的几何关系优化
        for geom in geometries:
            if geom.bbox:
                x, y, w, h = geom.bbox
                
                # 标准化尺寸
                if w < 1 or h < 1:
                    geom.confidence *= 0.5
                
                # 标准化位置
                if x < 0 or y < 0:
                    geom.bbox = (max(0, x), max(0, y), w, h)
        
        return results
    
    def _optimize_semantic_consistency(self, results: List[RecognitionResult]) -> List[RecognitionResult]:
        """优化语义一致性"""
        texts = [r for r in results if r.type == ResultType.TEXT]
        
        # 检查文本一致性
        text_contents = [r.content.get('text', '') for r in texts]
        
        # 简单的重复文本处理
        text_counter = Counter(text_contents)
        for result in texts:
            text = result.content.get('text', '')
            count = text_counter[text]
            if count > 1:
                # 降低重复文本的置信度
                result.confidence *= (1.0 / count)
        
        return results


class QualityAssessor:
    """质量评估器"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.weights = config.get('quality_weights', {
            'confidence': 0.3,
            'consistency': 0.25,
            'completeness': 0.2,
            'accuracy': 0.25
        })
    
    def assess_quality(self, results: List[RecognitionResult], 
                      validation_result: ValidationResult,
                      consistency_check: ConsistencyCheck) -> QualityLevel:
        """评估整体质量"""
        scores = {}
        
        # 置信度评分
        if results:
            avg_confidence = np.mean([r.confidence for r in results])
            scores['confidence'] = avg_confidence
        else:
            scores['confidence'] = 0.0
        
        # 一致性评分
        scores['consistency'] = consistency_check.overall_score
        
        # 完整性评分
        scores['completeness'] = self._assess_completeness(results)
        
        # 准确性评分
        scores['accuracy'] = validation_result.quality_score
        
        # 计算加权总分
        total_score = sum(scores[key] * self.weights[key] for key in scores)
        
        # 确定质量等级
        if total_score >= 0.8:
            return QualityLevel.HIGH
        elif total_score >= 0.6:
            return QualityLevel.MEDIUM
        elif total_score >= 0.4:
            return QualityLevel.LOW
        else:
            return QualityLevel.FAILED
    
    def _assess_completeness(self, results: List[RecognitionResult]) -> float:
        """评估完整性"""
        if not results:
            return 0.0
        
        # 检查是否包含必要的元素类型
        required_types = [ResultType.TEXT, ResultType.SYMBOL, ResultType.GEOMETRY]
        present_types = set(r.type for r in results)
        
        completeness = len(present_types.intersection(required_types)) / len(required_types)
        
        # 检查结果数量
        if len(results) < 5:
            completeness *= 0.8
        elif len(results) > 1000:
            completeness *= 0.9
        
        return min(1.0, completeness)
    
    def generate_quality_report(self, results: List[RecognitionResult],
                              validation_result: ValidationResult,
                              consistency_check: ConsistencyCheck,
                              quality_level: QualityLevel) -> Dict[str, Any]:
        """生成质量报告"""
        return {
            'timestamp': datetime.now().isoformat(),
            'quality_level': quality_level.value,
            'overall_score': self._calculate_overall_score(results, validation_result, consistency_check),
            'detailed_scores': {
                'confidence_score': np.mean([r.confidence for r in results]) if results else 0.0,
                'consistency_score': consistency_check.overall_score,
                'completeness_score': self._assess_completeness(results),
                'accuracy_score': validation_result.quality_score
            },
            'statistics': {
                'total_results': len(results),
                'result_types': Counter(r.type.value for r in results),
                'average_confidence': np.mean([r.confidence for r in results]) if results else 0.0,
                'processing_time': sum(r.processing_time for r in results)
            },
            'issues': {
                'errors': validation_result.errors,
                'warnings': validation_result.warnings,
                'consistency_violations': consistency_check.violations
            },
            'recommendations': self._generate_recommendations(results, validation_result, consistency_check)
        }
    
    def _calculate_overall_score(self, results: List[RecognitionResult],
                               validation_result: ValidationResult,
                               consistency_check: ConsistencyCheck) -> float:
        """计算总体评分"""
        scores = []
        
        if results:
            scores.append(np.mean([r.confidence for r in results]))
        
        scores.append(consistency_check.overall_score)
        scores.append(validation_result.quality_score)
        scores.append(self._assess_completeness(results))
        
        return np.mean(scores)
    
    def _generate_recommendations(self, results: List[RecognitionResult],
                                validation_result: ValidationResult,
                                consistency_check: ConsistencyCheck) -> List[str]:
        """生成改进建议"""
        recommendations = []
        
        # 基于置信度的建议
        low_confidence_count = sum(1 for r in results if r.confidence < 0.6)
        if low_confidence_count > len(results) * 0.3:
            recommendations.append("提高低置信度结果的识别质量")
        
        # 基于一致性的建议
        if consistency_check.overall_score < 0.8:
            recommendations.append("改善结果间的几何和语义一致性")
        
        # 基于错误的建议
        if validation_result.errors:
            recommendations.append("解决验证过程中发现的错误")
        
        # 基于类型的建议
        type_counts = Counter(r.type.value for r in results)
        if type_counts.get('text', 0) < 5:
            recommendations.append("增加文本识别结果的覆盖率")
        
        if type_counts.get('geometry', 0) < 3:
            recommendations.append("提高几何形状识别的准确性")
        
        return recommendations


class ResultFormatter:
    """结果格式化器"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.output_formats = config.get('output_formats', ['json', 'csv', 'visualization'])
    
    def format_results(self, results: List[RecognitionResult],
                      validation_result: ValidationResult,
                      consistency_check: ConsistencyCheck,
                      quality_level: QualityLevel,
                      quality_report: Dict[str, Any]) -> Dict[str, Any]:
        """格式化结果"""
        formatted_output = {
            'metadata': {
                'version': '1.0.0',
                'timestamp': datetime.now().isoformat(),
                'total_results': len(results),
                'quality_level': quality_level.value,
                'processing_summary': {
                    'optimization_applied': True,
                    'validation_performed': True,
                    'consistency_checked': True,
                    'anomaly_detection_performed': True
                }
            },
            'results': [result.to_dict() for result in results],
            'validation': {
                'is_valid': validation_result.is_valid,
                'confidence': validation_result.confidence,
                'errors': validation_result.errors,
                'warnings': validation_result.warnings,
                'quality_score': validation_result.quality_score,
                'suggestions': validation_result.suggestions
            },
            'consistency': {
                'geometric_consistency': consistency_check.geometric_consistency,
                'semantic_consistency': consistency_check.semantic_consistency,
                'topological_consistency': consistency_check.topological_consistency,
                'dimensional_consistency': consistency_check.dimensional_consistency,
                'overall_score': consistency_check.overall_score,
                'violations': consistency_check.violations
            },
            'quality_report': quality_report,
            'audit_trail': self._generate_audit_trail(results, validation_result)
        }
        
        return formatted_output
    
    def _generate_audit_trail(self, results: List[RecognitionResult],
                            validation_result: ValidationResult) -> List[Dict[str, Any]]:
        """生成审计追踪"""
        audit_entries = []
        
        # 记录每个结果的处理历史
        for result in results:
            audit_entry = {
                'result_id': result.id,
                'type': result.type.value,
                'confidence': result.confidence,
                'processing_time': result.processing_time,
                'timestamp': result.timestamp.isoformat(),
                'metadata': result.metadata
            }
            audit_entries.append(audit_entry)
        
        # 记录验证过程
        validation_entry = {
            'type': 'validation',
            'timestamp': datetime.now().isoformat(),
            'is_valid': validation_result.is_valid,
            'quality_score': validation_result.quality_score,
            'errors_count': len(validation_result.errors),
            'warnings_count': len(validation_result.warnings)
        }
        audit_entries.append(validation_entry)
        
        return audit_entries
    
    def export_to_format(self, formatted_output: Dict[str, Any], 
                        format_type: str) -> Union[str, Dict[str, Any]]:
        """导出到指定格式"""
        if format_type == 'json':
            return json.dumps(formatted_output, indent=2, ensure_ascii=False)
        
        elif format_type == 'csv':
            return self._export_to_csv(formatted_output)
        
        elif format_type == 'visualization':
            return self._generate_visualization(formatted_output)
        
        else:
            raise ValueError(f"不支持的导出格式: {format_type}")
    
    def _export_to_csv(self, formatted_output: Dict[str, Any]) -> str:
        """导出为CSV格式"""
        results = formatted_output['results']
        if not results:
            return "id,type,content,confidence,bbox,processing_time\n"
        
        # 提取CSV数据
        csv_data = []
        for result in results:
            row = {
                'id': result['id'],
                'type': result['type'],
                'content': json.dumps(result['content'], ensure_ascii=False),
                'confidence': result['confidence'],
                'bbox': str(result['bbox']) if result['bbox'] else '',
                'processing_time': result['processing_time']
            }
            csv_data.append(row)
        
        # 转换为DataFrame并保存
        df = pd.DataFrame(csv_data)
        return df.to_csv(index=False, encoding='utf-8')
    
    def _generate_visualization(self, formatted_output: Dict[str, Any]) -> Dict[str, Any]:
        """生成可视化数据"""
        results = formatted_output['results']
        
        # 统计信息
        type_counts = Counter(r['type'] for r in results)
        confidence_scores = [r['confidence'] for r in results]
        
        # 生成图表数据
        visualization_data = {
            'type_distribution': dict(type_counts),
            'confidence_histogram': {
                'bins': list(np.histogram(confidence_scores, bins=10)[0]),
                'ranges': list(np.histogram(confidence_scores, bins=10)[1])
            },
            'quality_metrics': formatted_output['quality_report']['detailed_scores'],
            'spatial_distribution': self._calculate_spatial_distribution(results)
        }
        
        return visualization_data
    
    def _calculate_spatial_distribution(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """计算空间分布"""
        spatial_data = {'x_coords': [], 'y_coords': [], 'areas': [], 'types': []}
        
        for result in results:
            if result['bbox']:
                x, y, w, h = result['bbox']
                spatial_data['x_coords'].append(x + w/2)  # 中心点x
                spatial_data['y_coords'].append(y + h/2)  # 中心点y
                spatial_data['areas'].append(w * h)
                spatial_data['types'].append(result['type'])
        
        return spatial_data


class ResultPostprocessingSystem:
    """识别结果后处理和置信度验证系统主类"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        
        # 初始化各个组件
        self.confidence_calculator = ConfidenceCalculator(config.get('confidence', {}))
        self.consistency_checker = ConsistencyChecker(config.get('consistency', {}))
        self.anomaly_detector = AnomalyDetector(config.get('anomaly', {}))
        self.result_optimizer = ResultOptimizer(config.get('optimization', {}))
        self.quality_assessor = QualityAssessor(config.get('quality', {}))
        self.result_formatter = ResultFormatter(config.get('formatting', {}))
        
        logger.info("识别结果后处理和置信度验证系统初始化完成")
    
    def process_results(self, raw_results: List[RecognitionResult],
                       training_data: Optional[List[RecognitionResult]] = None) -> Dict[str, Any]:
        """处理识别结果的主流程"""
        logger.info(f"开始处理 {len(raw_results)} 个原始识别结果")
        
        try:
            # 1. 结果优化
            logger.info("步骤1: 结果优化")
            optimized_results = self.result_optimizer.optimize_results(raw_results)
            
            # 2. 置信度计算
            logger.info("步骤2: 置信度计算")
            if training_data:
                self.confidence_calculator.fit(training_data)
            
            for result in optimized_results:
                result.confidence = self.confidence_calculator.calculate_confidence(result)
            
            # 3. 异常检测
            logger.info("步骤3: 异常检测")
            self.anomaly_detector.fit(optimized_results)
            anomaly_results = self.anomaly_detector.detect_anomalies(optimized_results)
            
            # 4. 一致性检查
            logger.info("步骤4: 一致性检查")
            consistency_check = self.consistency_checker.check_consistency(optimized_results)
            
            # 5. 验证
            logger.info("步骤5: 结果验证")
            validation_result = self._validate_results(optimized_results, anomaly_results)
            
            # 6. 质量评估
            logger.info("步骤6: 质量评估")
            quality_level = self.quality_assessor.assess_quality(
                optimized_results, validation_result, consistency_check
            )
            quality_report = self.quality_assessor.generate_quality_report(
                optimized_results, validation_result, consistency_check, quality_level
            )
            
            # 7. 结果格式化
            logger.info("步骤7: 结果格式化")
            formatted_output = self.result_formatter.format_results(
                optimized_results, validation_result, consistency_check,
                quality_level, quality_report
            )
            
            logger.info("处理完成")
            return formatted_output
            
        except Exception as e:
            logger.error(f"处理过程中发生错误: {e}")
            raise
    
    def _validate_results(self, results: List[RecognitionResult],
                         anomaly_results: Dict[str, Any]) -> ValidationResult:
        """验证识别结果"""
        errors = []
        warnings = []
        quality_score = 0.0
        
        # 检查异常
        if anomaly_results['anomalies']:
            warnings.append(f"检测到 {len(anomaly_results['anomalies'])} 个异常结果")
        
        # 检查置信度
        low_confidence_count = sum(1 for r in results if r.confidence < 0.5)
        if low_confidence_count > len(results) * 0.2:
            errors.append(f"低置信度结果过多: {low_confidence_count}/{len(results)}")
        
        # 检查内容完整性
        for result in results:
            if not result.content:
                errors.append(f"结果 {result.id} 内容为空")
            
            if result.type == ResultType.TEXT:
                text = result.content.get('text', '')
                if not text.strip():
                    errors.append(f"文本结果 {result.id} 内容为空")
        
        # 计算质量评分
        if results:
            avg_confidence = np.mean([r.confidence for r in results])
            completeness_score = min(1.0, len(results) / 10)  # 假设至少需要10个结果
            quality_score = (avg_confidence + completeness_score) / 2
        
        is_valid = len(errors) == 0
        confidence = quality_score
        
        suggestions = []
        if not is_valid:
            suggestions.append("检查输入数据的质量和完整性")
        if low_confidence_count > 0:
            suggestions.append("优化识别算法以提高置信度")
        
        return ValidationResult(
            is_valid=is_valid,
            confidence=confidence,
            errors=errors,
            warnings=warnings,
            quality_score=quality_score,
            suggestions=suggestions
        )
    
    def get_system_status(self) -> Dict[str, Any]:
        """获取系统状态"""
        return {
            'system_name': '识别结果后处理和置信度验证系统',
            'version': '1.0.0',
            'components': {
                'confidence_calculator': 'ready',
                'consistency_checker': 'ready',
                'anomaly_detector': 'ready',
                'result_optimizer': 'ready',
                'quality_assessor': 'ready',
                'result_formatter': 'ready'
            },
            'config_summary': {
                'confidence_config': self.config.get('confidence', {}),
                'consistency_config': self.config.get('consistency', {}),
                'anomaly_config': self.config.get('anomaly', {}),
                'quality_config': self.config.get('quality', {})
            }
        }


# 示例使用和测试函数
def create_sample_results() -> List[RecognitionResult]:
    """创建示例识别结果"""
    results = []
    
    # 文本结果
    results.append(RecognitionResult(
        id="text_001",
        type=ResultType.TEXT,
        content={"text": "图纸标题", "font_size": 14, "font_weight": "bold"},
        confidence=0.95,
        bbox=(100, 50, 80, 20)
    ))
    
    # 几何结果
    results.append(RecognitionResult(
        id="geom_001",
        type=ResultType.GEOMETRY,
        content={"shape": "rectangle", "area": 1000},
        confidence=0.88,
        bbox=(200, 100, 50, 20)
    ))
    
    # 符号结果
    results.append(RecognitionResult(
        id="symbol_001",
        type=ResultType.SYMBOL,
        content={"symbol_type": "arrow", "size": 15},
        confidence=0.92,
        bbox=(300, 150, 30, 30)
    ))
    
    # 尺寸标注结果
    results.append(RecognitionResult(
        id="dim_001",
        type=ResultType.DIMENSION,
        content={"value": 100, "unit": "mm", "type": "length"},
        confidence=0.85,
        bbox=(400, 200, 60, 15)
    ))
    
    return results


def run_example():
    """运行示例"""
    # 配置
    config = {
        'confidence': {
            'model_type': 'ensemble',
            'feature_count': 20
        },
        'consistency': {
            'tolerance': 0.02,
            'geometric_threshold': 0.8,
            'semantic_threshold': 0.8
        },
        'anomaly': {
            'contamination': 0.1,
            'eps': 0.5,
            'min_samples': 5
        },
        'quality': {
            'quality_weights': {
                'confidence': 0.3,
                'consistency': 0.25,
                'completeness': 0.2,
                'accuracy': 0.25
            }
        },
        'formatting': {
            'output_formats': ['json', 'csv', 'visualization']
        }
    }
    
    # 创建系统实例
    system = ResultPostprocessingSystem(config)
    
    # 创建示例数据
    sample_results = create_sample_results()
    training_data = sample_results[:2]  # 使用前两个作为训练数据
    
    # 处理结果
    try:
        formatted_output = system.process_results(sample_results, training_data)
        
        print("=== 处理结果摘要 ===")
        print(f"总结果数: {formatted_output['metadata']['total_results']}")
        print(f"质量等级: {formatted_output['metadata']['quality_level']}")
        print(f"验证状态: {'通过' if formatted_output['validation']['is_valid'] else '失败'}")
        print(f"一致性评分: {formatted_output['consistency']['overall_score']:.3f}")
        
        print("\n=== 详细结果 ===")
        print(json.dumps(formatted_output, indent=2, ensure_ascii=False))
        
        return formatted_output
        
    except Exception as e:
        logger.error(f"示例运行失败: {e}")
        return None


if __name__ == "__main__":
    # 运行示例
    result = run_example()
