"""
A/B测试框架
用于测试不同模型版本或配置的性能差异
"""

import json
import time
import logging
import random
import hashlib
from typing import Dict, List, Any, Optional, Tuple, Callable
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from scipy import stats
import numpy as np
from pathlib import Path


@dataclass
class ABTestConfig:
    """A/B测试配置"""
    test_name: str
    model_version_a: str
    model_version_b: str
    blueprint_types: List[str]
    sample_size_per_group: int = 1000
    confidence_level: float = 0.95
    minimum_effect_size: float = 0.02  # 最小可检测效应
    test_duration_days: int = 7
    traffic_split: float = 0.5  # A组流量比例
    random_seed: int = 42
    
    # 评估指标配置
    primary_metric: str = "accuracy"
    secondary_metrics: List[str] = None
    
    def __post_init__(self):
        if self.secondary_metrics is None:
            self.secondary_metrics = ["f1_score", "recall", "precision"]


@dataclass
class ABTestResult:
    """A/B测试结果"""
    test_name: str
    start_time: str
    end_time: str
    group_a_results: Dict[str, float]
    group_b_results: Dict[str, float]
    statistical_tests: Dict[str, Any]
    conclusion: str
    recommendation: str
    confidence_level: float
    sample_sizes: Dict[str, int]


class ABTestFramework:
    """A/B测试框架"""
    
    def __init__(self, config: ABTestConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.running_tests = {}
        self.completed_tests = {}
        
        # 设置随机种子
        random.seed(config.random_seed)
        np.random.seed(config.random_seed)
    
    def start_test(self, test_id: str) -> str:
        """开始A/B测试"""
        try:
            if test_id in self.running_tests:
                raise ValueError(f"测试 {test_id} 已在运行中")
            
            test_info = {
                'test_id': test_id,
                'config': asdict(self.config),
                'start_time': datetime.now().isoformat(),
                'status': 'running',
                'group_a_data': [],
                'group_b_data': [],
                'group_a_metrics': {},
                'group_b_metrics': {}
            }
            
            self.running_tests[test_id] = test_info
            
            self.logger.info(f"A/B测试 {test_id} 已开始")
            return test_id
            
        except Exception as e:
            self.logger.error(f"开始A/B测试失败: {e}")
            raise
    
    def assign_user_to_group(self, test_id: str, user_id: str) -> str:
        """将用户分配到测试组"""
        try:
            if test_id not in self.running_tests:
                raise ValueError(f"测试 {test_id} 不存在或已结束")
            
            # 使用哈希确保一致性分配
            hash_input = f"{test_id}_{user_id}_{self.config.random_seed}"
            hash_value = int(hashlib.md5(hash_input.encode()).hexdigest(), 16)
            
            # 基于流量分割比例分配
            if hash_value % 100 < self.config.traffic_split * 100:
                group = 'A'
            else:
                group = 'B'
            
            return group
            
        except Exception as e:
            self.logger.error(f"用户分组失败: {e}")
            raise
    
    def record_test_result(self, 
                          test_id: str,
                          user_id: str,
                          blueprint_type: str,
                          model_version: str,
                          group: str,
                          accuracy: float,
                          f1_score: float,
                          recall: float,
                          precision: float,
                          processing_time: float,
                          memory_usage: float = 0):
        """记录测试结果"""
        try:
            if test_id not in self.running_tests:
                raise ValueError(f"测试 {test_id} 不存在或已结束")
            
            # 验证图纸类型
            if blueprint_type not in self.config.blueprint_types:
                self.logger.warning(f"图纸类型 {blueprint_type} 不在测试范围内")
                return
            
            # 验证模型版本
            if model_version not in [self.config.model_version_a, self.config.model_version_b]:
                self.logger.warning(f"模型版本 {model_version} 不在测试范围内")
                return
            
            # 验证分组
            if group not in ['A', 'B']:
                raise ValueError(f"无效的分组: {group}")
            
            # 记录数据
            result_data = {
                'user_id': user_id,
                'blueprint_type': blueprint_type,
                'model_version': model_version,
                'accuracy': accuracy,
                'f1_score': f1_score,
                'recall': recall,
                'precision': precision,
                'processing_time': processing_time,
                'memory_usage': memory_usage,
                'timestamp': datetime.now().isoformat()
            }
            
            test_info = self.running_tests[test_id]
            if group == 'A':
                test_info['group_a_data'].append(result_data)
            else:
                test_info['group_b_data'].append(result_data)
            
            self.logger.debug(f"记录测试结果 - {test_id}: 用户{user_id}, 组{group}, 准确率{accuracy:.3f}")
            
        except Exception as e:
            self.logger.error(f"记录测试结果失败: {e}")
            raise
    
    def calculate_group_metrics(self, test_id: str) -> Dict[str, Dict[str, float]]:
        """计算各组指标"""
        try:
            if test_id not in self.running_tests:
                raise ValueError(f"测试 {test_id} 不存在或已结束")
            
            test_info = self.running_tests[test_id]
            
            # 计算A组指标
            group_a_metrics = self._calculate_metrics(test_info['group_a_data'])
            
            # 计算B组指标
            group_b_metrics = self._calculate_metrics(test_info['group_b_data'])
            
            # 更新测试信息
            test_info['group_a_metrics'] = group_a_metrics
            test_info['group_b_metrics'] = group_b_metrics
            
            return {
                'group_a': group_a_metrics,
                'group_b': group_b_metrics
            }
            
        except Exception as e:
            self.logger.error(f"计算组指标失败: {e}")
            raise
    
    def _calculate_metrics(self, data: List[Dict[str, Any]]) -> Dict[str, float]:
        """计算单个组的指标"""
        if not data:
            return {}
        
        metrics = {}
        
        # 计算各指标的平均值
        for metric in [self.config.primary_metric] + self.config.secondary_metrics:
            values = [item[metric] for item in data if metric in item]
            if values:
                metrics[f'{metric}_mean'] = np.mean(values)
                metrics[f'{metric}_std'] = np.std(values)
                metrics[f'{metric}_count'] = len(values)
        
        # 计算处理时间和内存使用的统计信息
        processing_times = [item['processing_time'] for item in data]
        memory_usages = [item['memory_usage'] for item in data]
        
        if processing_times:
            metrics['processing_time_mean'] = np.mean(processing_times)
            metrics['processing_time_median'] = np.median(processing_times)
            metrics['processing_time_p95'] = np.percentile(processing_times, 95)
        
        if memory_usages:
            metrics['memory_usage_mean'] = np.mean(memory_usages)
            metrics['memory_usage_median'] = np.median(memory_usages)
        
        return metrics
    
    def perform_statistical_test(self, test_id: str) -> Dict[str, Any]:
        """执行统计检验"""
        try:
            if test_id not in self.running_tests:
                raise ValueError(f"测试 {test_id} 不存在或已结束")
            
            test_info = self.running_tests[test_id]
            group_a_data = test_info['group_a_data']
            group_b_data = test_info['group_b_data']
            
            if not group_a_data or not group_b_data:
                raise ValueError("测试组数据不足，无法进行统计检验")
            
            statistical_tests = {}
            
            # 对主要指标进行统计检验
            metric_a_values = [item[self.config.primary_metric] for item in group_a_data]
            metric_b_values = [item[self.config.primary_metric] for item in group_b_data]
            
            # t检验
            t_stat, t_p_value = stats.ttest_ind(metric_a_values, metric_b_values)
            
            # Mann-Whitney U检验（非参数）
            u_stat, u_p_value = stats.mannwhitneyu(metric_a_values, metric_b_values, alternative='two-sided')
            
            # 效应大小（Cohen's d）
            pooled_std = np.sqrt(((len(metric_a_values) - 1) * np.var(metric_a_values) + 
                                (len(metric_b_values) - 1) * np.var(metric_b_values)) / 
                               (len(metric_a_values) + len(metric_b_values) - 2))
            cohens_d = (np.mean(metric_b_values) - np.mean(metric_a_values)) / pooled_std
            
            statistical_tests = {
                'primary_metric': self.config.primary_metric,
                't_test': {
                    'statistic': t_stat,
                    'p_value': t_p_value,
                    'significant': t_p_value < (1 - self.config.confidence_level)
                },
                'mann_whitney_u': {
                    'statistic': u_stat,
                    'p_value': u_p_value,
                    'significant': u_p_value < (1 - self.config.confidence_level)
                },
                'effect_size': {
                    'cohens_d': cohens_d,
                    'interpretation': self._interpret_effect_size(cohens_d)
                },
                'sample_sizes': {
                    'group_a': len(metric_a_values),
                    'group_b': len(metric_b_values)
                }
            }
            
            # 对次要指标也进行检验
            secondary_tests = {}
            for metric in self.config.secondary_metrics:
                a_values = [item[metric] for item in group_a_data if metric in item]
                b_values = [item[metric] for item in group_b_data if metric in item]
                
                if a_values and b_values:
                    _, p_value = stats.ttest_ind(a_values, b_values)
                    secondary_tests[metric] = {
                        'p_value': p_value,
                        'significant': p_value < (1 - self.config.confidence_level)
                    }
            
            statistical_tests['secondary_metrics'] = secondary_tests
            
            test_info['statistical_tests'] = statistical_tests
            
            return statistical_tests
            
        except Exception as e:
            self.logger.error(f"执行统计检验失败: {e}")
            raise
    
    def _interpret_effect_size(self, cohens_d: float) -> str:
        """解释效应大小"""
        abs_d = abs(cohens_d)
        if abs_d < 0.2:
            return "小效应"
        elif abs_d < 0.5:
            return "中等效应"
        elif abs_d < 0.8:
            return "大效应"
        else:
            return "非常大效应"
    
    def conclude_test(self, test_id: str) -> ABTestResult:
        """结束测试并生成结论"""
        try:
            if test_id not in self.running_tests:
                raise ValueError(f"测试 {test_id} 不存在或已结束")
            
            test_info = self.running_tests[test_id]
            
            # 计算指标
            metrics = self.calculate_group_metrics(test_id)
            
            # 执行统计检验
            statistical_tests = self.perform_statistical_test(test_id)
            
            # 生成结论
            conclusion, recommendation = self._generate_conclusion(
                metrics, statistical_tests
            )
            
            # 创建结果对象
            result = ABTestResult(
                test_name=self.config.test_name,
                start_time=test_info['start_time'],
                end_time=datetime.now().isoformat(),
                group_a_results=metrics['group_a'],
                group_b_results=metrics['group_b'],
                statistical_tests=statistical_tests,
                conclusion=conclusion,
                recommendation=recommendation,
                confidence_level=self.config.confidence_level,
                sample_sizes={
                    'group_a': len(test_info['group_a_data']),
                    'group_b': len(test_info['group_b_data'])
                }
            )
            
            # 移动到完成测试
            self.completed_tests[test_id] = result
            del self.running_tests[test_id]
            
            self.logger.info(f"A/B测试 {test_id} 已完成")
            return result
            
        except Exception as e:
            self.logger.error(f"结束测试失败: {e}")
            raise
    
    def _generate_conclusion(self, 
                           metrics: Dict[str, Dict[str, float]], 
                           statistical_tests: Dict[str, Any]) -> Tuple[str, str]:
        """生成测试结论"""
        try:
            group_a_metrics = metrics['group_a']
            group_b_metrics = metrics['group_b']
            
            primary_metric = self.config.primary_metric
            metric_a = group_a_metrics.get(f'{primary_metric}_mean', 0)
            metric_b = group_b_metrics.get(f'{primary_metric}_mean', 0)
            
            # 判断是否有显著差异
            is_significant = (statistical_tests['t_test']['significant'] and 
                            statistical_tests['mann_whitney_u']['significant'])
            
            # 计算改进幅度
            improvement = (metric_b - metric_a) / metric_a if metric_a > 0 else 0
            
            # 生成结论
            if is_significant and improvement > self.config.minimum_effect_size:
                if improvement > 0:
                    conclusion = f"模型B在{primary_metric}上显著优于模型A，提升幅度为{improvement:.2%}"
                    recommendation = f"建议采用模型B({self.config.model_version_b})"
                else:
                    conclusion = f"模型A在{primary_metric}上显著优于模型B，提升幅度为{abs(improvement):.2%}"
                    recommendation = f"建议采用模型A({self.config.model_version_a})"
            elif is_significant:
                conclusion = f"存在统计显著差异，但改进幅度({improvement:.2%})较小"
                recommendation = "需要进一步评估成本效益后再做决定"
            else:
                conclusion = f"两模型在{primary_metric}上无显著差异"
                recommendation = "两模型性能相当，可根据其他因素（如部署成本）选择"
            
            return conclusion, recommendation
            
        except Exception as e:
            self.logger.error(f"生成测试结论失败: {e}")
            return "测试结论生成失败", "需要人工分析"
    
    def get_test_status(self, test_id: str) -> Dict[str, Any]:
        """获取测试状态"""
        if test_id in self.running_tests:
            test_info = self.running_tests[test_id]
            return {
                'status': 'running',
                'test_id': test_id,
                'start_time': test_info['start_time'],
                'group_a_count': len(test_info['group_a_data']),
                'group_b_count': len(test_info['group_b_data']),
                'target_sample_size': self.config.sample_size_per_group
            }
        elif test_id in self.completed_tests:
            result = self.completed_tests[test_id]
            return {
                'status': 'completed',
                'test_id': test_id,
                'start_time': result.start_time,
                'end_time': result.end_time,
                'conclusion': result.conclusion,
                'recommendation': result.recommendation
            }
        else:
            raise ValueError(f"测试 {test_id} 不存在")
    
    def save_test_results(self, test_id: str, output_path: str):
        """保存测试结果"""
        try:
            if test_id not in self.completed_tests:
                raise ValueError(f"测试 {test_id} 未完成")
            
            result = self.completed_tests[test_id]
            
            # 创建输出目录
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            
            # 保存结果
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(asdict(result), f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"测试结果已保存: {output_path}")
            
        except Exception as e:
            self.logger.error(f"保存测试结果失败: {e}")
            raise


# 使用示例
if __name__ == "__main__":
    # 配置A/B测试
    config = ABTestConfig(
        test_name="模型版本比较测试",
        model_version_a="v1.0",
        model_version_b="v1.1",
        blueprint_types=["architectural", "mechanical"],
        sample_size_per_group=1000,
        confidence_level=0.95,
        minimum_effect_size=0.02
    )
    
    # 创建A/B测试框架
    framework = ABTestFramework(config)
    
    # 开始测试
    test_id = framework.start_test("test_001")
    print(f"测试ID: {test_id}")
    
    # 模拟用户请求和结果记录
    for i in range(100):
        user_id = f"user_{i:04d}"
        
        # 分配用户到组
        group = framework.assign_user_to_group(test_id, user_id)
        
        # 模拟不同的模型性能
        if group == 'A':
            accuracy = np.random.normal(0.85, 0.05)
            model_version = config.model_version_a
        else:
            accuracy = np.random.normal(0.87, 0.05)
            model_version = config.model_version_b
        
        # 确保准确率在合理范围内
        accuracy = max(0, min(1, accuracy))
        
        # 记录测试结果
        framework.record_test_result(
            test_id=test_id,
            user_id=user_id,
            blueprint_type="architectural",
            model_version=model_version,
            group=group,
            accuracy=accuracy,
            f1_score=accuracy * 0.95,  # 简化处理
            recall=accuracy * 0.98,
            precision=accuracy * 0.92,
            processing_time=np.random.normal(25, 5),
            memory_usage=np.random.normal(2048, 200)
        )
    
    # 获取测试状态
    status = framework.get_test_status(test_id)
    print("测试状态:", json.dumps(status, indent=2))
    
    # 结束测试
    result = framework.conclude_test(test_id)
    print("测试结论:", result.conclusion)
    print("建议:", result.recommendation)
    
    # 保存结果
    framework.save_test_results(test_id, "reports/ab_test_result.json")