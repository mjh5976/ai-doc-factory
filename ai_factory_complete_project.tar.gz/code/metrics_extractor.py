#!/usr/bin/env python3
"""
性能指标提取和可视化系统
从日志中提取性能指标，生成可视化报告和仪表板
"""

import os
import sys
import time
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass, field, asdict
from collections import defaultdict, deque
import statistics
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.backends.backend_pdf import PdfPages
import seaborn as sns
import redis
import yaml
from pathlib import Path

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

@dataclass
class MetricPoint:
    """指标数据点"""
    timestamp: datetime
    service: str
    metric_name: str
    value: float
    tags: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'timestamp': self.timestamp.isoformat(),
            'service': self.service,
            'metric_name': self.metric_name,
            'value': self.value,
            'tags': self.tags
        }

@dataclass
class MetricAggregate:
    """指标聚合数据"""
    service: str
    metric_name: str
    time_window: timedelta
    count: int
    min_value: float
    max_value: float
    mean_value: float
    median_value: float
    std_value: float
    p95_value: float
    p99_value: float
    first_seen: datetime
    last_seen: datetime
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'service': self.service,
            'metric_name': self.metric_name,
            'time_window': str(self.time_window),
            'count': self.count,
            'min_value': self.min_value,
            'max_value': self.max_value,
            'mean_value': self.mean_value,
            'median_value': self.median_value,
            'std_value': self.std_value,
            'p95_value': self.p95_value,
            'p99_value': self.p99_value,
            'first_seen': self.first_seen.isoformat(),
            'last_seen': self.last_seen.isoformat()
        }

class MetricsExtractor:
    """性能指标提取器"""
    
    def __init__(self, config_path: str = "config/metrics_config.yaml"):
        self.config = self._load_config(config_path)
        self.logger = logging.getLogger(__name__)
        self.redis_client = None
        self.metrics_buffer = defaultdict(lambda: deque(maxlen=10000))
        self.aggregates = {}
        self.extraction_rules = {}
        
        # 初始化Redis连接
        if self.config.get('redis'):
            self.redis_client = redis.Redis(
                host=self.config['redis']['host'],
                port=self.config['redis']['port'],
                decode_responses=True
            )
        
        # 加载提取规则
        self._load_extraction_rules()
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载提取器配置"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            self.logger.warning(f"指标配置文件加载失败: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """默认指标配置"""
        return {
            'redis': {
                'host': 'localhost',
                'port': 6379
            },
            'extraction': {
                'buffer_size': 10000,
                'aggregation_interval': 300,  # 5分钟
                'retention_days': 30
            },
            'visualization': {
                'output_dir': 'reports',
                'chart_style': 'seaborn',
                'dpi': 300,
                'figure_size': (12, 8)
            },
            'rules': []
        }
    
    def _load_extraction_rules(self):
        """加载指标提取规则"""
        for rule_config in self.config['rules']:
            try:
                rule = self._create_extraction_rule(rule_config)
                self.extraction_rules[rule_config['name']] = rule
            except Exception as e:
                self.logger.error(f"加载指标提取规则失败: {e}")
    
    def _create_extraction_rule(self, config: Dict[str, Any]):
        """创建指标提取规则"""
        metric_name = config['name']
        source_field = config['source_field']
        extraction_type = config.get('type', 'direct')
        service_filter = config.get('service')
        transformation = config.get('transformation', 'identity')
        
        def extract_metric(log_entry):
            # 检查服务过滤
            if service_filter and log_entry.service != service_filter:
                return None
            
            # 检查字段是否存在
            if source_field not in log_entry.custom_fields:
                return None
            
            try:
                value = float(log_entry.custom_fields[source_field])
                
                # 应用变换
                if transformation == 'log':
                    value = np.log10(value + 1)
                elif transformation == 'sqrt':
                    value = np.sqrt(value)
                elif transformation == 'inverse':
                    value = 1 / value if value != 0 else 0
                elif transformation == 'percentage':
                    value = value * 100
                
                return MetricPoint(
                    timestamp=log_entry.timestamp,
                    service=log_entry.service,
                    metric_name=metric_name,
                    value=value,
                    tags={'source_field': source_field, 'transformation': transformation}
                )
                
            except (ValueError, TypeError) as e:
                self.logger.debug(f"指标提取失败: {e}")
                return None
        
        return extract_metric
    
    def extract_metrics(self, log_entry) -> List[MetricPoint]:
        """从日志条目提取指标"""
        metrics = []
        
        for rule_name, rule in self.extraction_rules.items():
            try:
                metric_point = rule(log_entry)
                if metric_point:
                    metrics.append(metric_point)
            except Exception as e:
                self.logger.error(f"指标提取规则 '{rule_name}' 执行失败: {e}")
        
        return metrics
    
    def add_metric_point(self, metric_point: MetricPoint):
        """添加指标点"""
        buffer_key = f"{metric_point.service}:{metric_point.metric_name}"
        self.metrics_buffer[buffer_key].append(metric_point)
        
        # 存储到Redis
        if self.redis_client:
            try:
                metric_key = f"metrics:{buffer_key}"
                self.redis_client.lpush(metric_key, json.dumps(metric_point.to_dict()))
                self.redis_client.ltrim(metric_key, 0, self.config['extraction']['buffer_size'] - 1)
                
                # 设置过期时间
                retention_seconds = self.config['extraction']['retention_days'] * 24 * 3600
                self.redis_client.expire(metric_key, retention_seconds)
            except Exception as e:
                self.logger.error(f"指标存储失败: {e}")
    
    def aggregate_metrics(self, time_window: timedelta = None) -> Dict[str, MetricAggregate]:
        """聚合指标数据"""
        if time_window is None:
            time_window = timedelta(seconds=self.config['extraction']['aggregation_interval'])
        
        aggregates = {}
        cutoff_time = datetime.now() - time_window
        
        for buffer_key, buffer in self.metrics_buffer.items():
            service, metric_name = buffer_key.split(':', 1)
            
            # 过滤时间窗口内的数据
            recent_points = [p for p in buffer if p.timestamp >= cutoff_time]
            
            if len(recent_points) < 2:
                continue
            
            # 计算聚合统计
            values = [p.value for p in recent_points]
            timestamps = [p.timestamp for p in recent_points]
            
            aggregate = MetricAggregate(
                service=service,
                metric_name=metric_name,
                time_window=time_window,
                count=len(values),
                min_value=min(values),
                max_value=max(values),
                mean_value=statistics.mean(values),
                median_value=statistics.median(values),
                std_value=statistics.stdev(values) if len(values) > 1 else 0,
                p95_value=self._percentile(values, 95),
                p99_value=self._percentile(values, 99),
                first_seen=min(timestamps),
                last_seen=max(timestamps)
            )
            
            aggregates[buffer_key] = aggregate
        
        self.aggregates.update(aggregates)
        return aggregates
    
    def _percentile(self, data: List[float], percentile: float) -> float:
        """计算百分位数"""
        if not data:
            return 0.0
        
        sorted_data = sorted(data)
        index = (percentile / 100) * (len(sorted_data) - 1)
        
        if index.is_integer():
            return sorted_data[int(index)]
        else:
            lower = sorted_data[int(index)]
            upper = sorted_data[int(index) + 1]
            return lower + (upper - lower) * (index - int(index))
    
    def get_metric_history(self, service: str, metric_name: str, 
                          hours: int = 24) -> List[MetricPoint]:
        """获取指标历史数据"""
        buffer_key = f"{service}:{metric_name}"
        cutoff_time = datetime.now() - timedelta(hours=hours)
        
        if buffer_key in self.metrics_buffer:
            return [p for p in self.metrics_buffer[buffer_key] if p.timestamp >= cutoff_time]
        
        return []
    
    def get_service_metrics(self, service: str) -> Dict[str, List[MetricPoint]]:
        """获取服务的所有指标"""
        service_metrics = {}
        prefix = f"{service}:"
        
        for buffer_key, buffer in self.metrics_buffer.items():
            if buffer_key.startswith(prefix):
                metric_name = buffer_key[len(prefix):]
                service_metrics[metric_name] = list(buffer)
        
        return service_metrics
    
    def get_metric_summary(self, service: str = None) -> Dict[str, Any]:
        """获取指标摘要"""
        summary = {
            'total_metrics': len(self.metrics_buffer),
            'services': set(),
            'metric_types': set(),
            'data_points': 0,
            'time_range': None
        }
        
        for buffer_key, buffer in self.metrics_buffer.items():
            if service and not buffer_key.startswith(f"{service}:"):
                continue
            
            service_name, metric_name = buffer_key.split(':', 1)
            summary['services'].add(service_name)
            summary['metric_types'].add(metric_name)
            summary['data_points'] += len(buffer)
            
            if buffer:
                if summary['time_range'] is None:
                    summary['time_range'] = {
                        'start': min(p.timestamp for p in buffer),
                        'end': max(p.timestamp for p in buffer)
                    }
                else:
                    start = min(p.timestamp for p in buffer)
                    end = max(p.timestamp for p in buffer)
                    summary['time_range']['start'] = min(summary['time_range']['start'], start)
                    summary['time_range']['end'] = max(summary['time_range']['end'], end)
        
        # 转换set为list以便JSON序列化
        summary['services'] = list(summary['services'])
        summary['metric_types'] = list(summary['metric_types'])
        
        if summary['time_range']:
            summary['time_range']['start'] = summary['time_range']['start'].isoformat()
            summary['time_range']['end'] = summary['time_range']['end'].isoformat()
        
        return summary

class MetricsVisualizer:
    """指标可视化器"""
    
    def __init__(self, config_path: str = "config/visualization_config.yaml"):
        self.config = self._load_config(config_path)
        self.logger = logging.getLogger(__name__)
        self.output_dir = Path(self.config['output_dir'])
        self.output_dir.mkdir(exist_ok=True)
        
        # 设置matplotlib样式
        plt.style.use(self.config.get('chart_style', 'seaborn'))
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载可视化配置"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            self.logger.warning(f"可视化配置文件加载失败: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """默认可视化配置"""
        return {
            'output_dir': 'reports',
            'chart_style': 'seaborn',
            'dpi': 300,
            'figure_size': (12, 8),
            'colors': ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd'],
            'themes': {
                'performance': {
                    'response_time': {'color': '#2ca02c', 'ylabel': '响应时间 (ms)'},
                    'throughput': {'color': '#1f77b4', 'ylabel': '吞吐量 (req/s)'},
                    'error_rate': {'color': '#d62728', 'ylabel': '错误率 (%)'},
                    'cpu_usage': {'color': '#ff7f0e', 'ylabel': 'CPU使用率 (%)'},
                    'memory_usage': {'color': '#9467bd', 'ylabel': '内存使用率 (%)'}
                }
            }
        }
    
    def create_time_series_chart(self, metric_points: List[MetricPoint], 
                               title: str, filename: str = None) -> str:
        """创建时间序列图表"""
        if not metric_points:
            self.logger.warning("没有数据点用于创建图表")
            return ""
        
        # 准备数据
        df = pd.DataFrame([p.to_dict() for p in metric_points])
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp')
        
        # 创建图表
        fig, ax = plt.subplots(figsize=self.config['figure_size'])
        
        # 按服务分组绘制
        services = df['service'].unique()
        colors = self.config['colors'][:len(services)]
        
        for i, service in enumerate(services):
            service_data = df[df['service'] == service]
            ax.plot(service_data['timestamp'], service_data['value'], 
                   label=service, color=colors[i % len(colors)], linewidth=2)
        
        # 设置图表属性
        ax.set_title(title, fontsize=16, fontweight='bold')
        ax.set_xlabel('时间', fontsize=12)
        ax.set_ylabel('值', fontsize=12)
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # 格式化x轴时间
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
        ax.xaxis.set_major_locator(mdates.HourLocator(interval=2))
        plt.xticks(rotation=45)
        
        plt.tight_layout()
        
        # 保存图表
        if filename is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"time_series_{timestamp}.png"
        
        filepath = self.output_dir / filename
        plt.savefig(filepath, dpi=self.config['dpi'], bbox_inches='tight')
        plt.close()
        
        self.logger.info(f"时间序列图表已保存: {filepath}")
        return str(filepath)
    
    def create_histogram(self, metric_points: List[MetricPoint], 
                        title: str, filename: str = None) -> str:
        """创建直方图"""
        if not metric_points:
            self.logger.warning("没有数据点用于创建直方图")
            return ""
        
        # 准备数据
        values = [p.value for p in metric_points]
        
        # 创建图表
        fig, ax = plt.subplots(figsize=self.config['figure_size'])
        
        # 绘制直方图
        n, bins, patches = ax.hist(values, bins=30, alpha=0.7, 
                                 color=self.config['colors'][0], edgecolor='black')
        
        # 添加统计线
        mean_val = statistics.mean(values)
        median_val = statistics.median(values)
        p95_val = self._percentile(values, 95)
        
        ax.axvline(mean_val, color='red', linestyle='--', linewidth=2, label=f'平均值: {mean_val:.2f}')
        ax.axvline(median_val, color='green', linestyle='--', linewidth=2, label=f'中位数: {median_val:.2f}')
        ax.axvline(p95_val, color='orange', linestyle='--', linewidth=2, label=f'P95: {p95_val:.2f}')
        
        # 设置图表属性
        ax.set_title(title, fontsize=16, fontweight='bold')
        ax.set_xlabel('值', fontsize=12)
        ax.set_ylabel('频次', fontsize=12)
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        # 保存图表
        if filename is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"histogram_{timestamp}.png"
        
        filepath = self.output_dir / filename
        plt.savefig(filepath, dpi=self.config['dpi'], bbox_inches='tight')
        plt.close()
        
        self.logger.info(f"直方图已保存: {filepath}")
        return str(filepath)
    
    def create_box_plot(self, metric_data: Dict[str, List[MetricPoint]], 
                       title: str, filename: str = None) -> str:
        """创建箱线图"""
        if not metric_data:
            self.logger.warning("没有数据用于创建箱线图")
            return ""
        
        # 准备数据
        services = list(metric_data.keys())
        data_by_service = []
        labels = []
        
        for service, points in metric_data.items():
            if points:
                data_by_service.append([p.value for p in points])
                labels.append(service)
        
        if not data_by_service:
            self.logger.warning("没有有效数据用于创建箱线图")
            return ""
        
        # 创建图表
        fig, ax = plt.subplots(figsize=self.config['figure_size'])
        
        # 绘制箱线图
        box_plot = ax.boxplot(data_by_service, labels=labels, patch_artist=True)
        
        # 设置颜色
        colors = self.config['colors'][:len(data_by_service)]
        for patch, color in zip(box_plot['boxes'], colors):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)
        
        # 设置图表属性
        ax.set_title(title, fontsize=16, fontweight='bold')
        ax.set_xlabel('服务', fontsize=12)
        ax.set_ylabel('值', fontsize=12)
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        # 保存图表
        if filename is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"box_plot_{timestamp}.png"
        
        filepath = self.output_dir / filename
        plt.savefig(filepath, dpi=self.config['dpi'], bbox_inches='tight')
        plt.close()
        
        self.logger.info(f"箱线图已保存: {filepath}")
        return str(filepath)
    
    def create_correlation_matrix(self, service_metrics: Dict[str, List[MetricPoint]], 
                                 title: str, filename: str = None) -> str:
        """创建相关性矩阵图"""
        if len(service_metrics) < 2:
            self.logger.warning("需要至少2个指标才能创建相关性矩阵")
            return ""
        
        # 准备数据
        metric_names = list(service_metrics.keys())
        data_matrix = []
        
        # 获取相同时间窗口的数据
        for metric_name in metric_names:
            points = service_metrics[metric_name]
            if points:
                # 按时间排序并提取值
                sorted_points = sorted(points, key=lambda x: x.timestamp)
                values = [p.value for p in sorted_points]
                data_matrix.append(values)
        
        if not data_matrix:
            self.logger.warning("没有有效数据用于创建相关性矩阵")
            return ""
        
        # 确保所有序列长度相同
        min_length = min(len(row) for row in data_matrix)
        data_matrix = [row[:min_length] for row in data_matrix]
        
        # 计算相关性矩阵
        df = pd.DataFrame(np.array(data_matrix).T, columns=metric_names)
        correlation_matrix = df.corr()
        
        # 创建图表
        fig, ax = plt.subplots(figsize=self.config['figure_size'])
        
        # 绘制热力图
        sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0,
                   square=True, ax=ax, cbar_kws={'shrink': 0.8})
        
        # 设置图表属性
        ax.set_title(title, fontsize=16, fontweight='bold')
        
        plt.tight_layout()
        
        # 保存图表
        if filename is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"correlation_matrix_{timestamp}.png"
        
        filepath = self.output_dir / filename
        plt.savefig(filepath, dpi=self.config['dpi'], bbox_inches='tight')
        plt.close()
        
        self.logger.info(f"相关性矩阵图已保存: {filepath}")
        return str(filepath)
    
    def generate_performance_report(self, extractor: MetricsExtractor, 
                                   service: str = None, hours: int = 24) -> str:
        """生成性能报告"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        report_filename = f"performance_report_{service or 'all'}_{timestamp}.pdf"
        report_path = self.output_dir / report_filename
        
        with PdfPages(report_path) as pdf:
            # 1. 报告封面
            fig, ax = plt.subplots(figsize=self.config['figure_size'])
            ax.text(0.5, 0.7, '性能监控报告', ha='center', va='center', 
                   fontsize=24, fontweight='bold')
            ax.text(0.5, 0.6, f'服务: {service or "全部服务"}', ha='center', va='center', fontsize=16)
            ax.text(0.5, 0.5, f'时间范围: 最近 {hours} 小时', ha='center', va='center', fontsize=16)
            ax.text(0.5, 0.4, f'生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}', 
                   ha='center', va='center', fontsize=12)
            ax.axis('off')
            pdf.savefig(fig, bbox_inches='tight')
            plt.close()
            
            # 2. 指标摘要
            summary = extractor.get_metric_summary(service)
            fig, ax = plt.subplots(figsize=self.config['figure_size'])
            
            summary_text = f"""
指标摘要:
- 总指标数: {summary['total_metrics']}
- 服务数量: {len(summary['services'])}
- 指标类型: {len(summary['metric_types'])}
- 数据点数: {summary['data_points']}
            """
            
            if summary['time_range']:
                start_time = summary['time_range']['start']
                end_time = summary['time_range']['end']
                summary_text += f"\n- 时间范围: {start_time} 至 {end_time}"
            
            ax.text(0.1, 0.9, summary_text, ha='left', va='top', fontsize=14, 
                   transform=ax.transAxes, fontfamily='monospace')
            ax.axis('off')
            pdf.savefig(fig, bbox_inches='tight')
            plt.close()
            
            # 3. 各服务指标图表
            if service:
                services = [service]
            else:
                services = summary['services']
            
            for svc in services:
                service_metrics = extractor.get_service_metrics(svc)
                if service_metrics:
                    # 时间序列图
                    for metric_name, points in service_metrics.items():
                        if len(points) > 1:
                            title = f'{svc} - {metric_name} 时间序列'
                            filepath = self.create_time_series_chart(points, title)
                            if filepath:
                                # 添加图片到PDF
                                img = plt.imread(filepath)
                                fig, ax = plt.subplots(figsize=self.config['figure_size'])
                                ax.imshow(img)
                                ax.axis('off')
                                pdf.savefig(fig, bbox_inches='tight')
                                plt.close()
                    
                    # 箱线图
                    title = f'{svc} - 指标分布'
                    filepath = self.create_box_plot(service_metrics, title)
                    if filepath:
                        img = plt.imread(filepath)
                        fig, ax = plt.subplots(figsize=self.config['figure_size'])
                        ax.imshow(img)
                        ax.axis('off')
                        pdf.savefig(fig, bbox_inches='tight')
                        plt.close()
        
        self.logger.info(f"性能报告已生成: {report_path}")
        return str(report_path)
    
    def _percentile(self, data: List[float], percentile: float) -> float:
        """计算百分位数"""
        if not data:
            return 0.0
        
        sorted_data = sorted(data)
        index = (percentile / 100) * (len(sorted_data) - 1)
        
        if index.is_integer():
            return sorted_data[int(index)]
        else:
            lower = sorted_data[int(index)]
            upper = sorted_data[int(index) + 1]
            return lower + (upper - lower) * (index - int(index))

def main():
    """主函数 - 测试指标提取和可视化"""
    from log_parser import ParsedLogEntry, LogLevel
    
    # 创建提取器和可视化器
    extractor = MetricsExtractor()
    visualizer = MetricsVisualizer()
    
    # 模拟日志数据
    test_logs = [
        ParsedLogEntry(
            timestamp=datetime.now() - timedelta(minutes=i),
            level=LogLevel.INFO,
            service='api',
            host='server1',
            message='Request processed',
            custom_fields={
                'response_time': 100 + np.random.normal(0, 20),
                'cpu_usage': 50 + np.random.normal(0, 10),
                'memory_usage': 60 + np.random.normal(0, 5),
                'throughput': 100 + np.random.normal(0, 20)
            }
        ) for i in range(100)
    ]
    
    # 提取指标
    for log_entry in test_logs:
        metrics = extractor.extract_metrics(log_entry)
        for metric in metrics:
            extractor.add_metric_point(metric)
    
    # 聚合指标
    aggregates = extractor.aggregate_metrics()
    print(f"聚合了 {len(aggregates)} 个指标")
    
    # 生成报告
    report_path = visualizer.generate_performance_report(extractor, 'api', 1)
    print(f"报告已生成: {report_path}")
    
    # 显示摘要
    summary = extractor.get_metric_summary('api')
    print(f"指标摘要: {summary}")

if __name__ == "__main__":
    main()
