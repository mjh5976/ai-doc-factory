#!/usr/bin/env python3
"""
A/B测试和模型对比机制演示脚本
展示完整的A/B测试流程，包括配置管理、实验执行、统计分析和报告生成
"""

import sys
import os
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import json

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 导入自定义模块
from ab_testing_framework import ABTestFramework, ABTestConfig
from statistical_tests import StatisticalTests, StatisticalTest
from visualization_reporting import ReportGenerator, VisualizationConfig
from config_management import ConfigManager, ExperimentConfig, ParameterConfig, ParameterType

def setup_demo_environment():
    """设置演示环境"""
    print("🚀 初始化A/B测试和模型对比系统...")
    
    # 创建必要的目录
    os.makedirs("configs", exist_ok=True)
    os.makedirs("reports", exist_ok=True)
    os.makedirs("data", exist_ok=True)
    
    print("✅ 环境设置完成")

def create_demo_config():
    """创建演示配置"""
    print("\n📋 创建A/B测试配置...")
    
    # 创建配置管理器
    config_manager = ConfigManager("configs/")
    
    # 创建参数配置
    parameters = {
        "learning_rate": ParameterConfig(
            name="learning_rate",
            param_type=ParameterType.CONTINUOUS,
            value=0.001,
            min_value=0.0001,
            max_value=0.01,
            step=0.0001,
            description="模型学习率"
        ),
        "batch_size": ParameterConfig(
            name="batch_size",
            param_type=ParameterType.DISCRETE,
            value=32,
            min_value=16,
            max_value=256,
            step=16,
            description="训练批次大小"
        ),
        "model_type": ParameterConfig(
            name="model_type",
            param_type=ParameterType.CATEGORICAL,
            value="transformer",
            choices=["cnn", "transformer", "lstm"],
            description="模型架构类型"
        ),
        "use_dropout": ParameterConfig(
            name="use_dropout",
            param_type=ParameterType.BOOLEAN,
            value=True,
            description="是否使用Dropout正则化"
        )
    }
    
    # 创建实验配置
    config = ExperimentConfig(
        name="深度学习模型A/B测试",
        description="比较不同深度学习架构在图像分类任务上的性能",
        config_id="dl_model_ab_test",
        version="1.0.0",
        status="active",
        created_at=datetime.now(),
        updated_at=datetime.now(),
        created_by="demo_user",
        model_versions={
            "control": "resnet50_v1.0",
            "treatment": "efficientnet_v2.0"
        },
        traffic_allocation={
            "control": 0.5,
            "treatment": 0.5
        },
        sample_size_per_group=2000,
        confidence_level=0.95,
        statistical_power=0.8,
        parameters=parameters,
        success_criteria={
            "primary_metric": "accuracy",
            "improvement_threshold": 0.02
        }
    )
    
    # 保存配置
    config_manager.create_config(config)
    print(f"✅ 配置创建成功: {config.config_id} v{config.version}")
    
    return config_manager, config

def run_ab_test_demo():
    """运行A/B测试演示"""
    print("\n🧪 运行A/B测试演示...")
    
    # 创建A/B测试配置
    ab_config = ABTestConfig(
        test_name="深度学习模型性能对比",
        model_version_a="resnet50_v1.0",
        model_version_b="efficientnet_v2.0",
        blueprint_types=["image_classification"],
        sample_size_per_group=1000,
        confidence_level=0.95,
        minimum_effect_size=0.02,
        test_duration_days=7,
        traffic_split=0.5,
        random_seed=42,
        primary_metric="accuracy",
        secondary_metrics=["f1_score", "precision", "recall"]
    )
    
    # 创建A/B测试框架
    framework = ABTestFramework(ab_config)
    
    # 开始测试
    test_id = framework.start_test("demo_test_001")
    print(f"📊 测试ID: {test_id}")
    
    # 模拟用户数据生成
    print("📈 模拟用户数据和模型性能...")
    np.random.seed(42)
    
    for i in range(500):  # 模拟500个用户
        user_id = f"user_{i:04d}"
        
        # 分配用户到组
        group = framework.assign_user_to_group(test_id, user_id)
        
        # 模拟模型性能差异（EfficientNet略优于ResNet）
        if group == 'A':  # ResNet50
            accuracy = np.random.normal(0.85, 0.05)
            f1_score = np.random.normal(0.83, 0.04)
            precision = np.random.normal(0.84, 0.04)
            recall = np.random.normal(0.82, 0.05)
            processing_time = np.random.normal(150, 20)  # ms
            model_version = ab_config.model_version_a
        else:  # EfficientNet
            accuracy = np.random.normal(0.87, 0.05)
            f1_score = np.random.normal(0.85, 0.04)
            precision = np.random.normal(0.86, 0.04)
            recall = np.random.normal(0.84, 0.05)
            processing_time = np.random.normal(120, 15)  # ms
            model_version = ab_config.model_version_b
        
        # 确保指标在合理范围内
        accuracy = max(0.5, min(1.0, accuracy))
        f1_score = max(0.5, min(1.0, f1_score))
        precision = max(0.5, min(1.0, precision))
        recall = max(0.5, min(1.0, recall))
        processing_time = max(50, processing_time)
        
        # 记录测试结果
        framework.record_test_result(
            test_id=test_id,
            user_id=user_id,
            blueprint_type="image_classification",
            model_version=model_version,
            group=group,
            accuracy=accuracy,
            f1_score=f1_score,
            recall=recall,
            precision=precision,
            processing_time=processing_time,
            memory_usage=np.random.normal(2048, 200)
        )
    
    # 获取测试状态
    status = framework.get_test_status(test_id)
    print(f"📋 测试状态: {status['status']}")
    print(f"   - 控制组样本数: {status.get('group_a_count', 0)}")
    print(f"   - 实验组样本数: {status.get('group_b_count', 0)}")
    
    return framework, test_id

def perform_statistical_analysis(framework, test_id):
    """执行统计分析"""
    print("\n📊 执行统计分析...")
    
    # 创建统计分析器
    stats_tests = StatisticalTests(alpha=0.05, power=0.8)
    
    # 获取测试数据
    test_info = framework.running_tests[test_id]
    group_a_data = test_info['group_a_data']
    group_b_data = test_info['group_b_data']
    
    # 提取准确率数据
    accuracy_a = np.array([item['accuracy'] for item in group_a_data])
    accuracy_b = np.array([item['accuracy'] for item in group_b_data])
    
    # 执行t检验
    t_test_result = stats_tests.compare_two_means(accuracy_a, accuracy_b)
    
    # 执行Mann-Whitney U检验
    mannwhitney_result = stats_tests.compare_two_means(
        accuracy_a, accuracy_b, test_type=StatisticalTest.MANN_WHITNEY
    )
    
    # 计算样本量
    sample_calc = stats_tests.calculate_sample_size_two_means(
        baseline_mean=np.mean(accuracy_a),
        expected_difference=np.mean(accuracy_b) - np.mean(accuracy_a),
        pooled_std=np.sqrt((np.var(accuracy_a, ddof=1) + np.var(accuracy_b, ddof=1)) / 2)
    )
    
    print(f"✅ 统计分析完成:")
    print(f"   - t检验 p值: {t_test_result.p_value:.6f}")
    print(f"   - 显著性: {'是' if t_test_result.is_significant else '否'}")
    print(f"   - 效应大小: {t_test_result.effect_size:.4f}")
    print(f"   - 所需样本量: {sample_calc.required_sample_size}")
    
    return t_test_result, mannwhitney_result, sample_calc

def generate_visualizations_and_reports(framework, test_id, t_test_result, sample_calc):
    """生成可视化和报告"""
    print("\n📈 生成可视化和报告...")
    
    # 创建可视化配置
    viz_config = VisualizationConfig(
        figure_size=(12, 8),
        dpi=100,
        interactive=True
    )
    
    # 创建报告生成器
    report_gen = ReportGenerator(viz_config)
    
    # 获取测试数据
    test_info = framework.running_tests[test_id]
    group_a_data = test_info['group_a_data']
    group_b_data = test_info['group_b_data']
    
    # 准备数据
    test_results = {'Primary Metric': t_test_result}
    sample_data = {
        'Control': np.array([item['accuracy'] for item in group_a_data]),
        'Treatment': np.array([item['accuracy'] for item in group_b_data])
    }
    
    # 测试配置
    test_config = {
        'test_name': '深度学习模型性能对比',
        'primary_metric': 'accuracy',
        'model_version_a': 'resnet50_v1.0',
        'model_version_b': 'efficientnet_v2.0',
        'sample_size_per_group': 1000,
        'confidence_level': 0.95
    }
    
    # 生成时间序列数据
    time_series_data = {
        'Control': [(datetime.now() - timedelta(hours=i), np.random.normal(0.85, 0.02)) for i in range(24)],
        'Treatment': [(datetime.now() - timedelta(hours=i), np.random.normal(0.87, 0.02)) for i in range(24)]
    }
    
    # 生成HTML报告
    html_path = report_gen.generate_html_report(
        test_config=test_config,
        test_results=test_results,
        sample_data=sample_data,
        time_series_data=time_series_data,
        sample_size_calc=sample_calc,
        save_path="reports/ab_test_demo_report.html"
    )
    
    # 生成PDF报告
    pdf_path = report_gen.generate_pdf_report(
        test_config=test_config,
        test_results=test_results,
        sample_data=sample_data,
        save_path="reports/ab_test_demo_report.pdf"
    )
    
    print(f"✅ 报告生成完成:")
    print(f"   - HTML报告: {html_path}")
    if pdf_path:
        print(f"   - PDF报告: {pdf_path}")
    
    return html_path, pdf_path

def demonstrate_parameter_optimization(config_manager, config):
    """演示参数优化"""
    print("\n🔧 演示参数优化...")
    
    # 定义目标函数（模拟）
    def objective_function(params):
        """模拟目标函数：基于参数组合计算模型性能分数"""
        score = 0.85  # 基础分数
        
        # 学习率影响
        lr = params.get('learning_rate', 0.001)
        if 0.0005 <= lr <= 0.005:
            score += 0.05
        elif lr > 0.01:
            score -= 0.1
        
        # 批次大小影响
        batch_size = params.get('batch_size', 32)
        if batch_size in [32, 64]:
            score += 0.03
        elif batch_size > 128:
            score -= 0.02
        
        # 模型类型影响
        model_type = params.get('model_type', 'cnn')
        if model_type == 'transformer':
            score += 0.04
        elif model_type == 'lstm':
            score += 0.02
        
        # Dropout影响
        use_dropout = params.get('use_dropout', True)
        if use_dropout:
            score += 0.02
        
        # 添加随机噪声
        score += np.random.normal(0, 0.01)
        return score
    
    # 执行参数优化
    search_result = config_manager.optimize_config_parameters(
        config_id=config.config_id,
        objective_function=objective_function,
        optimization_method="random",
        max_iterations=50
    )
    
    print(f"✅ 参数优化完成:")
    print(f"   - 最佳分数: {search_result.best_score:.4f}")
    print(f"   - 最佳参数: {search_result.best_value}")
    print(f"   - 搜索历史: {len(search_result.search_history)} 次迭代")
    
    return search_result

def run_integration_test():
    """运行集成测试"""
    print("\n🧪 运行集成测试...")
    
    # 测试配置验证
    try:
        config_manager = ConfigManager("configs/")
        config = config_manager.get_config("dl_model_ab_test")
        assert config is not None, "配置加载失败"
        print("✅ 配置管理测试通过")
    except Exception as e:
        print(f"❌ 配置管理测试失败: {e}")
        return False
    
    # 测试统计检验
    try:
        stats_tests = StatisticalTests()
        control_data = np.random.normal(100, 15, 100)
        treatment_data = np.random.normal(103, 15, 100)
        result = stats_tests.compare_two_means(control_data, treatment_data)
        assert result.p_value is not None, "统计检验失败"
        print("✅ 统计检验测试通过")
    except Exception as e:
        print(f"❌ 统计检验测试失败: {e}")
        return False
    
    # 测试可视化
    try:
        viz_config = VisualizationConfig()
        visualizer = ABTestVisualizer(viz_config)
        chart_data = visualizer.plot_metric_distribution(
            np.random.normal(100, 15, 100),
            np.random.normal(103, 15, 100),
            "test_metric",
            StatisticalTests().compare_two_means(np.random.normal(100, 15, 100), np.random.normal(103, 15, 100))
        )
        assert len(chart_data) > 0, "可视化生成失败"
        print("✅ 可视化测试通过")
    except Exception as e:
        print(f"❌ 可视化测试失败: {e}")
        return False
    
    print("✅ 所有集成测试通过")
    return True

def main():
    """主演示函数"""
    print("=" * 80)
    print("🎯 A/B测试和模型对比机制 - 完整演示")
    print("=" * 80)
    
    try:
        # 1. 设置环境
        setup_demo_environment()
        
        # 2. 创建配置
        config_manager, config = create_demo_config()
        
        # 3. 运行A/B测试
        framework, test_id = run_ab_test_demo()
        
        # 4. 执行统计分析
        t_test_result, mannwhitney_result, sample_calc = perform_statistical_analysis(framework, test_id)
        
        # 5. 生成可视化和报告
        html_path, pdf_path = generate_visualizations_and_reports(framework, test_id, t_test_result, sample_calc)
        
        # 6. 演示参数优化
        search_result = demonstrate_parameter_optimization(config_manager, config)
        
        # 7. 运行集成测试
        integration_success = run_integration_test()
        
        # 8. 总结
        print("\n" + "=" * 80)
        print("📋 演示总结")
        print("=" * 80)
        print(f"✅ A/B测试框架: 已完成")
        print(f"✅ 统计分析: t检验p值={t_test_result.p_value:.6f}, 显著性={'是' if t_test_result.is_significant else '否'}")
        print(f"✅ 可视化报告: HTML={html_path}")
        if pdf_path:
            print(f"✅ PDF报告: {pdf_path}")
        print(f"✅ 参数优化: 最佳分数={search_result.best_score:.4f}")
        print(f"✅ 集成测试: {'通过' if integration_success else '失败'}")
        
        print("\n🎉 A/B测试和模型对比机制演示完成！")
        print("\n📁 生成的文件:")
        print("   - 配置文件: configs/")
        print("   - HTML报告: reports/ab_test_demo_report.html")
        print("   - PDF报告: reports/ab_test_demo_report.pdf")
        
        return True
        
    except Exception as e:
        print(f"\n❌ 演示过程中出现错误: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)