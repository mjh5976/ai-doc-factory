"""
识别结果后处理和置信度验证系统配置
=====================================

包含各种配置模板和示例配置

作者: MiniMax Agent
版本: 1.0.0
日期: 2025-11-06
"""

import json
from typing import Dict, Any, List
from dataclasses import dataclass, field


@dataclass
class SystemConfig:
    """系统配置数据类"""
    confidence: Dict[str, Any] = field(default_factory=dict)
    consistency: Dict[str, Any] = field(default_factory=dict)
    anomaly: Dict[str, Any] = field(default_factory=dict)
    optimization: Dict[str, Any] = field(default_factory=dict)
    quality: Dict[str, Any] = field(default_factory=dict)
    formatting: Dict[str, Any] = field(default_factory=dict)
    monitoring: Dict[str, Any] = field(default_factory=dict)
    logging: Dict[str, Any] = field(default_factory=dict)


# 配置文件模板
DEFAULT_CONFIG = SystemConfig(
    confidence={
        'model_type': 'ensemble',
        'feature_count': 20,
        'training_required': True,
        'confidence_weights': {
            'base_confidence': 0.4,
            'feature_confidence': 0.3,
            'spatial_confidence': 0.2,
            'temporal_confidence': 0.1
        }
    },
    consistency={
        'tolerance': 0.02,
        'geometric_threshold': 0.8,
        'semantic_threshold': 0.8,
        'topological_threshold': 0.8,
        'dimensional_threshold': 0.8,
        'spatial_relation_threshold': 0.5,
        'duplicate_detection': True,
        'overlap_detection': True
    },
    anomaly={
        'contamination': 0.1,
        'eps': 0.5,
        'min_samples': 5,
        'isolation_forest_params': {
            'n_estimators': 100,
            'max_samples': 'auto',
            'random_state': 42
        },
        'dbscan_params': {
            'eps': 0.5,
            'min_samples': 5,
            'metric': 'euclidean'
        }
    },
    optimization={
        'enable_deduplication': True,
        'enable_merging': True,
        'enable_geometric_optimization': True,
        'enable_semantic_optimization': True,
        'merge_threshold': 0.3,
        'duplicate_similarity_threshold': 0.9
    },
    quality={
        'quality_weights': {
            'confidence': 0.3,
            'consistency': 0.25,
            'completeness': 0.2,
            'accuracy': 0.25
        },
        'thresholds': {
            'high_quality': 0.8,
            'medium_quality': 0.6,
            'low_quality': 0.4
        },
        'enable_real_time_monitoring': True,
        'enable_feedback_collection': True
    },
    formatting={
        'output_formats': ['json', 'csv', 'visualization'],
        'include_audit_trail': True,
        'include_metadata': True,
        'compression': False,
        'pretty_print': True
    },
    monitoring={
        'enable_performance_monitoring': True,
        'metrics_collection_interval': 60,  # 秒
        'alert_thresholds': {
            'processing_time': 30.0,
            'memory_usage': 500 * 1024 * 1024,  # 500MB
            'error_rate': 0.05
        }
    },
    logging={
        'level': 'INFO',
        'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        'file': 'result_postprocessing.log',
        'max_file_size': 10 * 1024 * 1024,  # 10MB
        'backup_count': 5
    }
)


# 生产环境配置
PRODUCTION_CONFIG = SystemConfig(
    confidence={
        'model_type': 'ensemble',
        'feature_count': 25,
        'training_required': True,
        'confidence_weights': {
            'base_confidence': 0.3,
            'feature_confidence': 0.35,
            'spatial_confidence': 0.25,
            'temporal_confidence': 0.1
        }
    },
    consistency={
        'tolerance': 0.015,
        'geometric_threshold': 0.85,
        'semantic_threshold': 0.85,
        'topological_threshold': 0.85,
        'dimensional_threshold': 0.85,
        'spatial_relation_threshold': 0.4,
        'duplicate_detection': True,
        'overlap_detection': True
    },
    anomaly={
        'contamination': 0.05,
        'eps': 0.3,
        'min_samples': 10,
        'isolation_forest_params': {
            'n_estimators': 200,
            'max_samples': 'auto',
            'random_state': 42
        },
        'dbscan_params': {
            'eps': 0.3,
            'min_samples': 10,
            'metric': 'euclidean'
        }
    },
    optimization={
        'enable_deduplication': True,
        'enable_merging': True,
        'enable_geometric_optimization': True,
        'enable_semantic_optimization': True,
        'merge_threshold': 0.2,
        'duplicate_similarity_threshold': 0.95
    },
    quality={
        'quality_weights': {
            'confidence': 0.25,
            'consistency': 0.3,
            'completeness': 0.25,
            'accuracy': 0.2
        },
        'thresholds': {
            'high_quality': 0.85,
            'medium_quality': 0.7,
            'low_quality': 0.5
        },
        'enable_real_time_monitoring': True,
        'enable_feedback_collection': True
    },
    formatting={
        'output_formats': ['json', 'csv', 'visualization'],
        'include_audit_trail': True,
        'include_metadata': True,
        'compression': True,
        'pretty_print': False
    },
    monitoring={
        'enable_performance_monitoring': True,
        'metrics_collection_interval': 30,
        'alert_thresholds': {
            'processing_time': 15.0,
            'memory_usage': 300 * 1024 * 1024,
            'error_rate': 0.02
        }
    },
    logging={
        'level': 'WARNING',
        'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        'file': '/var/log/result_postprocessing.log',
        'max_file_size': 50 * 1024 * 1024,
        'backup_count': 10
    }
)


# 开发环境配置
DEVELOPMENT_CONFIG = SystemConfig(
    confidence={
        'model_type': 'simple',
        'feature_count': 15,
        'training_required': False,
        'confidence_weights': {
            'base_confidence': 0.6,
            'feature_confidence': 0.2,
            'spatial_confidence': 0.1,
            'temporal_confidence': 0.1
        }
    },
    consistency={
        'tolerance': 0.05,
        'geometric_threshold': 0.7,
        'semantic_threshold': 0.7,
        'topological_threshold': 0.7,
        'dimensional_threshold': 0.7,
        'spatial_relation_threshold': 0.6,
        'duplicate_detection': True,
        'overlap_detection': False
    },
    anomaly={
        'contamination': 0.2,
        'eps': 0.8,
        'min_samples': 3,
        'isolation_forest_params': {
            'n_estimators': 50,
            'max_samples': 'auto',
            'random_state': 42
        },
        'dbscan_params': {
            'eps': 0.8,
            'min_samples': 3,
            'metric': 'euclidean'
        }
    },
    optimization={
        'enable_deduplication': True,
        'enable_merging': False,
        'enable_geometric_optimization': False,
        'enable_semantic_optimization': False,
        'merge_threshold': 0.5,
        'duplicate_similarity_threshold': 0.8
    },
    quality={
        'quality_weights': {
            'confidence': 0.4,
            'consistency': 0.2,
            'completeness': 0.2,
            'accuracy': 0.2
        },
        'thresholds': {
            'high_quality': 0.7,
            'medium_quality': 0.5,
            'low_quality': 0.3
        },
        'enable_real_time_monitoring': False,
        'enable_feedback_collection': True
    },
    formatting={
        'output_formats': ['json'],
        'include_audit_trail': False,
        'include_metadata': True,
        'compression': False,
        'pretty_print': True
    },
    monitoring={
        'enable_performance_monitoring': False,
        'metrics_collection_interval': 300,
        'alert_thresholds': {
            'processing_time': 60.0,
            'memory_usage': 1000 * 1024 * 1024,
            'error_rate': 0.1
        }
    },
    logging={
        'level': 'DEBUG',
        'format': '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s',
        'file': 'dev_result_postprocessing.log',
        'max_file_size': 5 * 1024 * 1024,
        'backup_count': 3
    }
)


# 高性能配置（用于大批量处理）
HIGH_PERFORMANCE_CONFIG = SystemConfig(
    confidence={
        'model_type': 'lightweight',
        'feature_count': 10,
        'training_required': False,
        'confidence_weights': {
            'base_confidence': 0.8,
            'feature_confidence': 0.1,
            'spatial_confidence': 0.05,
            'temporal_confidence': 0.05
        }
    },
    consistency={
        'tolerance': 0.01,
        'geometric_threshold': 0.9,
        'semantic_threshold': 0.9,
        'topological_threshold': 0.9,
        'dimensional_threshold': 0.9,
        'spatial_relation_threshold': 0.3,
        'duplicate_detection': True,
        'overlap_detection': True
    },
    anomaly={
        'contamination': 0.05,
        'eps': 0.2,
        'min_samples': 20,
        'isolation_forest_params': {
            'n_estimators': 50,
            'max_samples': 'auto',
            'random_state': 42
        },
        'dbscan_params': {
            'eps': 0.2,
            'min_samples': 20,
            'metric': 'euclidean'
        }
    },
    optimization={
        'enable_deduplication': True,
        'enable_merging': True,
        'enable_geometric_optimization': True,
        'enable_semantic_optimization': True,
        'merge_threshold': 0.1,
        'duplicate_similarity_threshold': 0.98
    },
    quality={
        'quality_weights': {
            'confidence': 0.2,
            'consistency': 0.4,
            'completeness': 0.2,
            'accuracy': 0.2
        },
        'thresholds': {
            'high_quality': 0.9,
            'medium_quality': 0.8,
            'low_quality': 0.6
        },
        'enable_real_time_monitoring': True,
        'enable_feedback_collection': False
    },
    formatting={
        'output_formats': ['json'],
        'include_audit_trail': False,
        'include_metadata': False,
        'compression': True,
        'pretty_print': False
    },
    monitoring={
        'enable_performance_monitoring': True,
        'metrics_collection_interval': 10,
        'alert_thresholds': {
            'processing_time': 5.0,
            'memory_usage': 200 * 1024 * 1024,
            'error_rate': 0.01
        }
    },
    logging={
        'level': 'ERROR',
        'format': '%(asctime)s - %(levelname)s - %(message)s',
        'file': None,  # 不写入文件
        'max_file_size': 0,
        'backup_count': 0
    }
)


def get_config_by_environment(env: str = 'default') -> SystemConfig:
    """根据环境获取配置"""
    configs = {
        'default': DEFAULT_CONFIG,
        'production': PRODUCTION_CONFIG,
        'development': DEVELOPMENT_CONFIG,
        'high_performance': HIGH_PERFORMANCE_CONFIG
    }
    
    return configs.get(env, DEFAULT_CONFIG)


def save_config_to_file(config: SystemConfig, filename: str):
    """保存配置到文件"""
    config_dict = {
        'confidence': config.confidence,
        'consistency': config.consistency,
        'anomaly': config.anomaly,
        'optimization': config.optimization,
        'quality': config.quality,
        'formatting': config.formatting,
        'monitoring': config.monitoring,
        'logging': config.logging
    }
    
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(config_dict, f, indent=2, ensure_ascii=False)


def load_config_from_file(filename: str) -> SystemConfig:
    """从文件加载配置"""
    with open(filename, 'r', encoding='utf-8') as f:
        config_dict = json.load(f)
    
    return SystemConfig(
        confidence=config_dict.get('confidence', {}),
        consistency=config_dict.get('consistency', {}),
        anomaly=config_dict.get('anomaly', {}),
        optimization=config_dict.get('optimization', {}),
        quality=config_dict.get('quality', {}),
        formatting=config_dict.get('formatting', {}),
        monitoring=config_dict.get('monitoring', {}),
        logging=config_dict.get('logging', {})
    )


def create_custom_config(**kwargs) -> SystemConfig:
    """创建自定义配置"""
    config = SystemConfig()
    
    for key, value in kwargs.items():
        if hasattr(config, key):
            setattr(config, key, value)
    
    return config


# 配置验证函数
def validate_config(config: SystemConfig) -> List[str]:
    """验证配置的有效性"""
    errors = []
    
    # 验证置信度配置
    if 'confidence_weights' in config.confidence:
        weights = config.confidence['confidence_weights']
        total_weight = sum(weights.values())
        if abs(total_weight - 1.0) > 0.01:
            errors.append(f"置信度权重总和应为1.0，当前为{total_weight}")
    
    # 验证一致性阈值
    thresholds = ['geometric_threshold', 'semantic_threshold', 
                  'topological_threshold', 'dimensional_threshold']
    for threshold in thresholds:
        if threshold in config.consistency:
            value = config.consistency[threshold]
            if not 0 <= value <= 1:
                errors.append(f"{threshold}应在[0,1]范围内，当前为{value}")
    
    # 验证质量权重
    if 'quality_weights' in config.quality:
        weights = config.quality['quality_weights']
        total_weight = sum(weights.values())
        if abs(total_weight - 1.0) > 0.01:
            errors.append(f"质量权重总和应为1.0，当前为{total_weight}")
    
    # 验证异常检测参数
    if 'contamination' in config.anomaly:
        contamination = config.anomaly['contamination']
        if not 0 <= contamination <= 0.5:
            errors.append(f"contamination应在[0,0.5]范围内，当前为{contamination}")
    
    return errors


# 配置文件示例
EXAMPLE_CONFIGS = {
    'simple': {
        'confidence': {'model_type': 'simple'},
        'consistency': {'tolerance': 0.05},
        'anomaly': {'contamination': 0.1},
        'quality': {'quality_weights': {'confidence': 0.5, 'consistency': 0.5}},
        'formatting': {'output_formats': ['json']}
    },
    
    'advanced': {
        'confidence': {
            'model_type': 'ensemble',
            'feature_count': 20,
            'confidence_weights': {
                'base_confidence': 0.4,
                'feature_confidence': 0.3,
                'spatial_confidence': 0.2,
                'temporal_confidence': 0.1
            }
        },
        'consistency': {
            'tolerance': 0.02,
            'geometric_threshold': 0.8,
            'semantic_threshold': 0.8,
            'topological_threshold': 0.8,
            'dimensional_threshold': 0.8,
            'spatial_relation_threshold': 0.5,
            'duplicate_detection': True,
            'overlap_detection': True
        },
        'anomaly': {
            'contamination': 0.05,
            'eps': 0.3,
            'min_samples': 10,
            'isolation_forest_params': {
                'n_estimators': 200,
                'max_samples': 'auto',
                'random_state': 42
            }
        },
        'optimization': {
            'enable_deduplication': True,
            'enable_merging': True,
            'enable_geometric_optimization': True,
            'enable_semantic_optimization': True,
            'merge_threshold': 0.2,
            'duplicate_similarity_threshold': 0.95
        },
        'quality': {
            'quality_weights': {
                'confidence': 0.25,
                'consistency': 0.3,
                'completeness': 0.25,
                'accuracy': 0.2
            },
            'thresholds': {
                'high_quality': 0.85,
                'medium_quality': 0.7,
                'low_quality': 0.5
            }
        },
        'formatting': {
            'output_formats': ['json', 'csv', 'visualization'],
            'include_audit_trail': True,
            'include_metadata': True,
            'compression': False,
            'pretty_print': True
        }
    },
    
    'real_time': {
        'confidence': {'model_type': 'lightweight'},
        'consistency': {'tolerance': 0.01},
        'anomaly': {'contamination': 0.02},
        'quality': {
            'quality_weights': {'confidence': 0.6, 'consistency': 0.4},
            'enable_real_time_monitoring': True
        },
        'formatting': {
            'output_formats': ['json'],
            'compression': True,
            'pretty_print': False
        },
        'monitoring': {
            'enable_performance_monitoring': True,
            'metrics_collection_interval': 10
        }
    }
}


if __name__ == "__main__":
    # 创建配置文件示例
    print("创建配置文件示例...")
    
    # 保存默认配置
    save_config_to_file(DEFAULT_CONFIG, 'config/default_config.json')
    print("默认配置已保存到: config/default_config.json")
    
    # 保存生产环境配置
    save_config_to_file(PRODUCTION_CONFIG, 'config/production_config.json')
    print("生产环境配置已保存到: config/production_config.json")
    
    # 保存开发环境配置
    save_config_to_file(DEVELOPMENT_CONFIG, 'config/development_config.json')
    print("开发环境配置已保存到: config/development_config.json")
    
    # 保存高性能配置
    save_config_to_file(HIGH_PERFORMANCE_CONFIG, 'config/high_performance_config.json')
    print("高性能配置已保存到: config/high_performance_config.json")
    
    # 创建示例配置
    for name, config_dict in EXAMPLE_CONFIGS.items():
        config = SystemConfig(**config_dict)
        filename = f'config/example_{name}_config.json'
        save_config_to_file(config, filename)
        print(f"示例配置 '{name}' 已保存到: {filename}")
    
    print("\n配置文件创建完成！")
