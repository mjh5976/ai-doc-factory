#!/usr/bin/env python3
"""
部署管理模块
自动模型部署、版本管理和回滚
"""

import os
import json
import time
import logging
import threading
import requests
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Union
from dataclasses import dataclass, asdict
from enum import Enum
import yaml
import numpy as np
import pandas as pd
import torch
import mlflow
import mlflow.pytorch
import docker
import kubernetes.client
from kubernetes.client.rest import ApiException
import celery
from celery import Celery
import psutil
import GPUtil
from prometheus_client import Gauge, Counter, Histogram, start_http_server
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger(__name__)

class DeploymentStrategy(Enum):
    """部署策略枚举"""
    BLUE_GREEN = "blue_green"
    CANARY = "canary"
    ROLLING = "rolling"
    RECREATE = "recreate"

class DeploymentStatus(Enum):
    """部署状态枚举"""
    PENDING = "pending"
    DEPLOYING = "deploying"
    RUNNING = "running"
    FAILED = "failed"
    ROLLING_BACK = "rolling_back"
    ROLLED_BACK = "rolled_back"

class ServiceHealth(Enum):
    """服务健康状态枚举"""
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"

@dataclass
class DeploymentConfig:
    """部署配置数据类"""
    model_version: str
    deployment_strategy: DeploymentStrategy
    resource_requirements: Dict[str, Any]
    health_check_config: Dict[str, Any]
    rollout_config: Dict[str, Any]
    rollback_config: Dict[str, Any]
    monitoring_config: Dict[str, Any]

@dataclass
class DeploymentResult:
    """部署结果数据类"""
    deployment_id: str
    model_version: str
    strategy: DeploymentStrategy
    status: DeploymentStatus
    start_time: datetime
    end_time: Optional[datetime] = None
    health_status: ServiceHealth = ServiceHealth.UNKNOWN
    metrics: Dict[str, float] = None
    error_message: Optional[str] = None

class DeploymentManager:
    """部署管理器"""
    
    def __init__(self, config_path: str = "config/deployment_manager_config.yaml"):
        """初始化部署管理器"""
        self.config = self._load_config(config_path)
        self.setup_logging()
        self.setup_monitoring()
        self.setup_kubernetes()
        self.setup_docker()
        self.setup_mlflow()
        self.setup_celery()
        
        # 部署状态管理
        self.active_deployments = {}
        self.deployment_history = []
        self.service_registry = {}
        
        # 监控指标
        self.deployment_gauge = Gauge('deployments_total', 'Total deployments', ['status'])
        self.deployment_duration = Histogram('deployment_duration_seconds', 'Deployment duration in seconds')
        self.health_check_counter = Counter('health_checks_total', 'Total health checks', ['status'])
        
        logger.info("部署管理器初始化完成")
    
    def _load_config(self, config_path: str) -> Dict:
        """加载配置文件"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            logger.info(f"部署管理器配置文件加载成功: {config_path}")
            return config
        except Exception as e:
            logger.error(f"部署管理器配置文件加载失败: {e}")
            raise
    
    def setup_logging(self):
        """设置日志"""
        log_config = self.config.get('logging', {})
        log_dir = Path(log_config.get('directory', 'logs'))
        log_dir.mkdir(exist_ok=True)
        
        # 配置日志格式
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        file_handler = logging.FileHandler(log_dir / 'deployment_manager.log')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logging.INFO)
        
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)
        
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
    
    def setup_monitoring(self):
        """设置监控系统"""
        monitor_config = self.config['monitoring']
        
        # 启动Prometheus指标服务器
        if monitor_config.get('prometheus', {}).get('enabled', True):
            port = monitor_config.get('prometheus', {}).get('port', 8002)
            start_http_server(port)
            logger.info(f"部署管理器Prometheus指标服务器启动在端口: {port}")
    
    def setup_kubernetes(self):
        """设置Kubernetes客户端"""
        try:
            self.k8s_client = kubernetes.client.ApiClient()
            self.apps_v1 = kubernetes.client.AppsV1Api(self.k8s_client)
            self.core_v1 = kubernetes.client.CoreV1Api(self.k8s_client)
            self.networking_v1 = kubernetes.client.NetworkingV1Api(self.k8s_client)
            logger.info("Kubernetes客户端设置完成")
        except Exception as e:
            logger.warning(f"Kubernetes设置失败: {e}")
            self.k8s_client = None
    
    def setup_docker(self):
        """设置Docker客户端"""
        try:
            self.docker_client = docker.from_env()
            logger.info("Docker客户端设置完成")
        except Exception as e:
            logger.warning(f"Docker客户端设置失败: {e}")
            self.docker_client = None
    
    def setup_mlflow(self):
        """设置MLflow"""
        mlflow_config = self.config['mlflow']
        
        mlflow.set_tracking_uri(mlflow_config['tracking_uri'])
        mlflow.set_experiment(mlflow_config['experiment_name'])
        
        logger.info("MLflow设置完成")
    
    def setup_celery(self):
        """设置Celery任务队列"""
        celery_config = self.config['celery']
        
        self.celery_app = Celery(
            'deployment_manager',
            broker=celery_config['broker_url'],
            backend=celery_config['result_backend']
        )
        
        self.celery_app.conf.update(celery_config['config'])
        logger.info("Celery任务队列设置完成")
    
    def deploy_model(self, model_version: str, deployment_config: DeploymentConfig) -> str:
        """部署模型"""
        logger.info(f"开始部署模型: {model_version}")
        
        try:
            # 生成部署ID
            deployment_id = f"deploy_{int(time.time())}_{np.random.randint(1000, 9999)}"
            
            # 创建部署结果
            result = DeploymentResult(
                deployment_id=deployment_id,
                model_version=model_version,
                strategy=deployment_config.deployment_strategy,
                status=DeploymentStatus.PENDING,
                start_time=datetime.now(),
                metrics={}
            )
            
            # 添加到活跃部署
            self.active_deployments[deployment_id] = result
            
            # 提交部署任务到Celery
            self.celery_app.send_task(
                'deployment_manager.execute_deployment',
                args=[deployment_id, model_version, asdict(deployment_config)]
            )
            
            logger.info(f"模型部署任务已提交: {deployment_id}")
            return deployment_id
            
        except Exception as e:
            logger.error(f"部署模型失败 {model_version}: {e}")
            raise
    
    def execute_deployment(self, deployment_id: str, model_version: str, config_dict: Dict):
        """执行部署任务的Celery任务"""
        logger.info(f"开始执行部署: {deployment_id}")
        
        try:
            # 更新部署状态
            self._update_deployment_status(deployment_id, DeploymentStatus.DEPLOYING)
            
            # 解析配置
            config = DeploymentConfig(**config_dict)
            
            # 根据部署策略执行部署
            if config.deployment_strategy == DeploymentStrategy.BLUE_GREEN:
                self._execute_blue_green_deployment(deployment_id, model_version, config)
            elif config.deployment_strategy == DeploymentStrategy.CANARY:
                self._execute_canary_deployment(deployment_id, model_version, config)
            elif config.deployment_strategy == DeploymentStrategy.ROLLING:
                self._execute_rolling_deployment(deployment_id, model_version, config)
            elif config.deployment_strategy == DeploymentStrategy.RECREATE:
                self._execute_recreate_deployment(deployment_id, model_version, config)
            else:
                raise ValueError(f"不支持的部署策略: {config.deployment_strategy}")
            
            # 更新部署状态为完成
            self._update_deployment_status(deployment_id, DeploymentStatus.RUNNING)
            
            logger.info(f"部署执行完成: {deployment_id}")
            
        except Exception as e:
            logger.error(f"部署执行失败 {deployment_id}: {e}")
            self._update_deployment_status(deployment_id, DeploymentStatus.FAILED, str(e))
    
    def _execute_blue_green_deployment(self, deployment_id: str, model_version: str, config: DeploymentConfig):
        """执行蓝绿部署"""
        logger.info(f"执行蓝绿部署: {deployment_id}")
        
        try:
            # 创建绿色环境
            green_service_name = f"{model_version}-green"
            self._create_service(green_service_name, model_version, config)
            
            # 健康检查
            if self._health_check(green_service_name, config.health_check_config):
                # 切换流量到绿色环境
                self._switch_traffic_to_green(model_version)
                
                # 删除蓝色环境（如果存在）
                blue_service_name = f"{model_version}-blue"
                self._delete_service(blue_service_name)
                
                # 更新服务注册
                self.service_registry[model_version] = green_service_name
                
            else:
                raise Exception("绿色环境健康检查失败")
            
        except Exception as e:
            logger.error(f"蓝绿部署失败: {e}")
            raise
    
    def _execute_canary_deployment(self, deployment_id: str, model_version: str, config: DeploymentConfig):
        """执行金丝雀部署"""
        logger.info(f"执行金丝雀部署: {deployment_id}")
        
        try:
            # 创建金丝雀服务
            canary_service_name = f"{model_version}-canary"
            self._create_service(canary_service_name, model_version, config)
            
            # 初始流量分配
            initial_traffic = config.rollout_config.get('initial_canary_traffic', 10)
            self._set_traffic_split(model_version, initial_traffic)
            
            # 监控和渐进式流量增加
            max_traffic = config.rollout_config.get('max_canary_traffic', 100)
            increment = config.rollout_config.get('traffic_increment', 10)
            interval = config.rollout_config.get('traffic_increment_interval', 300)  # 5分钟
            
            current_traffic = initial_traffic
            while current_traffic < max_traffic:
                time.sleep(interval)
                
                # 健康检查
                if self._health_check(canary_service_name, config.health_check_config):
                    current_traffic += increment
                    self._set_traffic_split(model_version, current_traffic)
                    
                    logger.info(f"金丝雀流量增加到 {current_traffic}%")
                else:
                    # 回滚
                    logger.warning("金丝雀健康检查失败，开始回滚")
                    self._rollback_deployment(deployment_id, model_version, config)
                    return
            
            # 完成部署
            self._complete_canary_deployment(model_version, config)
            
        except Exception as e:
            logger.error(f"金丝雀部署失败: {e}")
            raise
    
    def _execute_rolling_deployment(self, deployment_id: str, model_version: str, config: DeploymentConfig):
        """执行滚动部署"""
        logger.info(f"执行滚动部署: {deployment_id}")
        
        try:
            # 获取当前部署的副本数
            current_replicas = self._get_current_replicas(model_version)
            
            # 滚动更新配置
            max_unavailable = config.rollout_config.get('max_unavailable', 1)
            max_surge = config.rollout_config.get('max_surge', 1)
            
            # 执行滚动更新
            self._perform_rolling_update(model_version, config, current_replicas, max_unavailable, max_surge)
            
        except Exception as e:
            logger.error(f"滚动部署失败: {e}")
            raise
    
    def _execute_recreate_deployment(self, deployment_id: str, model_version: str, config: DeploymentConfig):
        """执行重新创建部署"""
        logger.info(f"执行重新创建部署: {deployment_id}")
        
        try:
            # 删除现有服务
            self._delete_service(model_version)
            
            # 等待一段时间确保服务完全删除
            time.sleep(5)
            
            # 创建新服务
            self._create_service(model_version, model_version, config)
            
            # 健康检查
            if not self._health_check(model_version, config.health_check_config):
                raise Exception("新服务健康检查失败")
            
        except Exception as e:
            logger.error(f"重新创建部署失败: {e}")
            raise
    
    def _create_service(self, service_name: str, model_version: str, config: DeploymentConfig):
        """创建服务"""
        try:
            if self.k8s_client:
                # 使用Kubernetes创建服务
                self._create_kubernetes_service(service_name, model_version, config)
            else:
                # 使用Docker创建服务
                self._create_docker_service(service_name, model_version, config)
            
            logger.info(f"服务创建成功: {service_name}")
            
        except Exception as e:
            logger.error(f"创建服务失败 {service_name}: {e}")
            raise
    
    def _create_kubernetes_service(self, service_name: str, model_version: str, config: DeploymentConfig):
        """创建Kubernetes服务"""
        try:
            # 定义Deployment
            deployment = kubernetes.client.V1Deployment(
                api_version="apps/v1",
                kind="Deployment",
                metadata=kubernetes.client.V1ObjectMeta(
                    name=service_name,
                    labels={"app": service_name, "model_version": model_version}
                ),
                spec=kubernetes.client.V1DeploymentSpec(
                    replicas=config.resource_requirements.get('replicas', 1),
                    selector=kubernetes.client.V1LabelSelector(
                        match_labels={"app": service_name}
                    ),
                    template=kubernetes.client.V1PodTemplateSpec(
                        metadata=kubernetes.client.V1ObjectMeta(
                            labels={"app": service_name, "model_version": model_version}
                        ),
                        spec=kubernetes.client.V1PodSpec(
                            containers=[
                                kubernetes.client.V1Container(
                                    name=service_name,
                                    image=config.resource_requirements.get('image', f'model:{model_version}'),
                                    ports=[
                                        kubernetes.client.V1ContainerPort(
                                            container_port=config.resource_requirements.get('port', 8080)
                                        )
                                    ],
                                    resources=kubernetes.client.V1ResourceRequirements(
                                        requests={
                                            "cpu": config.resource_requirements.get('cpu', "100m"),
                                            "memory": config.resource_requirements.get('memory', "256Mi")
                                        },
                                        limits={
                                            "cpu": config.resource_requirements.get('cpu_limit', "500m"),
                                            "memory": config.resource_requirements.get('memory_limit', "512Mi")
                                        }
                                    )
                                )
                            ]
                        )
                    )
                )
            )
            
            # 创建Deployment
            self.apps_v1.create_namespaced_deployment(
                namespace="default",
                body=deployment
            )
            
            # 定义Service
            service = kubernetes.client.V1Service(
                api_version="v1",
                kind="Service",
                metadata=kubernetes.client.V1ObjectMeta(
                    name=service_name,
                    labels={"app": service_name}
                ),
                spec=kubernetes.client.V1ServiceSpec(
                    selector={"app": service_name},
                    ports=[
                        kubernetes.client.V1ServicePort(
                            port=config.resource_requirements.get('port', 8080),
                            target_port=config.resource_requirements.get('target_port', 8080)
                        )
                    ],
                    type="ClusterIP"
                )
            )
            
            # 创建Service
            self.core_v1.create_namespaced_service(
                namespace="default",
                body=service
            )
            
        except ApiException as e:
            if e.status == 409:  # 已存在
                logger.warning(f"服务已存在: {service_name}")
            else:
                raise
    
    def _create_docker_service(self, service_name: str, model_version: str, config: DeploymentConfig):
        """创建Docker服务"""
        try:
            # 拉取模型镜像（这里假设镜像已存在）
            image = config.resource_requirements.get('image', f'model:{model_version}')
            
            # 运行容器
            container = self.docker_client.containers.run(
                image=image,
                name=service_name,
                ports={f"{config.resource_requirements.get('port', 8080)}/tcp": config.resource_requirements.get('host_port', 8080)},
                detach=True,
                environment={
                    'MODEL_VERSION': model_version,
                    'SERVICE_NAME': service_name
                }
            )
            
            logger.info(f"Docker容器启动成功: {service_name}")
            
        except docker.errors.APIError as e:
            if "already in use" in str(e):
                logger.warning(f"Docker容器已存在: {service_name}")
            else:
                raise
    
    def _delete_service(self, service_name: str):
        """删除服务"""
        try:
            if self.k8s_client:
                # 删除Kubernetes服务
                try:
                    self.core_v1.delete_namespaced_service(
                        name=service_name,
                        namespace="default"
                    )
                except ApiException as e:
                    if e.status == 404:
                        logger.warning(f"Kubernetes服务不存在: {service_name}")
                
                # 删除Kubernetes Deployment
                try:
                    self.apps_v1.delete_namespaced_deployment(
                        name=service_name,
                        namespace="default"
                    )
                except ApiException as e:
                    if e.status == 404:
                        logger.warning(f"Kubernetes Deployment不存在: {service_name}")
            
            else:
                # 删除Docker容器
                try:
                    container = self.docker_client.containers.get(service_name)
                    container.stop()
                    container.remove()
                    logger.info(f"Docker容器已删除: {service_name}")
                except docker.errors.NotFound:
                    logger.warning(f"Docker容器不存在: {service_name}")
            
        except Exception as e:
            logger.error(f"删除服务失败 {service_name}: {e}")
    
    def _health_check(self, service_name: str, health_config: Dict) -> bool:
        """健康检查"""
        try:
            max_attempts = health_config.get('max_attempts', 3)
            timeout = health_config.get('timeout', 30)
            interval = health_config.get('interval', 5)
            
            for attempt in range(max_attempts):
                try:
                    if self.k8s_client:
                        # Kubernetes健康检查
                        result = self._k8s_health_check(service_name, health_config)
                    else:
                        # Docker健康检查
                        result = self._docker_health_check(service_name, health_config)
                    
                    if result:
                        self.health_check_counter.labels(status='success').inc()
                        return True
                    
                except Exception as e:
                    logger.warning(f"健康检查失败 (尝试 {attempt + 1}/{max_attempts}): {e}")
                
                if attempt < max_attempts - 1:
                    time.sleep(interval)
            
            self.health_check_counter.labels(status='failure').inc()
            return False
            
        except Exception as e:
            logger.error(f"健康检查异常 {service_name}: {e}")
            return False
    
    def _k8s_health_check(self, service_name: str, health_config: Dict) -> bool:
        """Kubernetes健康检查"""
        try:
            # 检查Pod状态
            pods = self.core_v1.list_namespaced_pod(
                namespace="default",
                label_selector=f"app={service_name}"
            )
            
            for pod in pods.items:
                if pod.status.phase == "Running":
                    # 检查容器状态
                    for container_status in pod.status.container_statuses:
                        if container_status.ready:
                            return True
            
            return False
            
        except Exception as e:
            logger.error(f"Kubernetes健康检查失败: {e}")
            return False
    
    def _docker_health_check(self, service_name: str, health_config: Dict) -> bool:
        """Docker健康检查"""
        try:
            container = self.docker_client.containers.get(service_name)
            return container.status == "running"
            
        except docker.errors.NotFound:
            return False
        except Exception as e:
            logger.error(f"Docker健康检查失败: {e}")
            return False
    
    def _switch_traffic_to_green(self, model_version: str):
        """切换流量到绿色环境"""
        logger.info(f"切换流量到绿色环境: {model_version}")
        # 这里实现流量切换逻辑
        # 在实际环境中，可能需要更新负载均衡器配置
    
    def _set_traffic_split(self, model_version: str, canary_traffic: int):
        """设置流量分配"""
        logger.info(f"设置流量分配: {model_version}, 金丝雀流量: {canary_traffic}%")
        # 这里实现流量分配逻辑
        # 在实际环境中，可能需要更新服务网格或负载均衡器配置
    
    def _complete_canary_deployment(self, model_version: str, config: DeploymentConfig):
        """完成金丝雀部署"""
        logger.info(f"完成金丝雀部署: {model_version}")
        
        # 将所有流量切换到金丝雀服务
        self._set_traffic_split(model_version, 100)
        
        # 更新服务注册
        canary_service_name = f"{model_version}-canary"
        self.service_registry[model_version] = canary_service_name
    
    def _perform_rolling_update(self, model_version: str, config: DeploymentConfig, 
                              current_replicas: int, max_unavailable: int, max_surge: int):
        """执行滚动更新"""
        logger.info(f"执行滚动更新: {model_version}")
        
        # 这里实现滚动更新逻辑
        # 在Kubernetes中，这通常通过更新Deployment的镜像版本来实现
        pass
    
    def _get_current_replicas(self, model_version: str) -> int:
        """获取当前副本数"""
        try:
            if self.k8s_client:
                deployment = self.apps_v1.read_namespaced_deployment_status(
                    name=model_version,
                    namespace="default"
                )
                return deployment.spec.replicas
            else:
                # Docker环境下的副本数逻辑
                return 1
        except:
            return 1
    
    def _rollback_deployment(self, deployment_id: str, model_version: str, config: DeploymentConfig):
        """回滚部署"""
        logger.info(f"开始回滚部署: {deployment_id}")
        
        try:
            # 更新部署状态
            self._update_deployment_status(deployment_id, DeploymentStatus.ROLLING_BACK)
            
            # 执行回滚逻辑
            if config.deployment_strategy == DeploymentStrategy.CANARY:
                self._rollback_canary_deployment(model_version, config)
            else:
                self._rollback_standard_deployment(model_version, config)
            
            # 更新部署状态
            self._update_deployment_status(deployment_id, DeploymentStatus.ROLLED_BACK)
            
            logger.info(f"部署回滚完成: {deployment_id}")
            
        except Exception as e:
            logger.error(f"部署回滚失败 {deployment_id}: {e}")
            self._update_deployment_status(deployment_id, DeploymentStatus.FAILED, str(e))
    
    def _rollback_canary_deployment(self, model_version: str, config: DeploymentConfig):
        """回滚金丝雀部署"""
        logger.info(f"回滚金丝雀部署: {model_version}")
        
        # 将流量全部切换回原始服务
        self._set_traffic_split(model_version, 0)
        
        # 删除金丝雀服务
        canary_service_name = f"{model_version}-canary"
        self._delete_service(canary_service_name)
    
    def _rollback_standard_deployment(self, model_version: str, config: DeploymentConfig):
        """回滚标准部署"""
        logger.info(f"回滚标准部署: {model_version}")
        
        # 恢复上一个版本的部署
        # 这里需要实现版本回滚逻辑
    
    def _update_deployment_status(self, deployment_id: str, status: DeploymentStatus, error_message: str = None):
        """更新部署状态"""
        try:
            if deployment_id in self.active_deployments:
                result = self.active_deployments[deployment_id]
                result.status = status
                
                if error_message:
                    result.error_message = error_message
                
                if status in [DeploymentStatus.RUNNING, DeploymentStatus.FAILED, DeploymentStatus.ROLLED_BACK]:
                    result.end_time = datetime.now()
                    
                    # 移动到历史记录
                    self.deployment_history.append(result)
                    del self.active_deployments[deployment_id]
                    
                    # 更新监控指标
                    if status == DeploymentStatus.RUNNING:
                        self.deployment_gauge.labels(status='success').inc()
                    else:
                        self.deployment_gauge.labels(status='failure').inc()
                    
                    # 记录部署时长
                    duration = (result.end_time - result.start_time).total_seconds()
                    self.deployment_duration.observe(duration)
                
                logger.info(f"部署状态更新: {deployment_id} -> {status.value}")
                
        except Exception as e:
            logger.error(f"更新部署状态失败 {deployment_id}: {e}")
    
    def get_deployment_status(self, deployment_id: str) -> Optional[Dict]:
        """获取部署状态"""
        # 检查活跃部署
        if deployment_id in self.active_deployments:
            return asdict(self.active_deployments[deployment_id])
        
        # 检查历史部署
        for deployment in self.deployment_history:
            if deployment.deployment_id == deployment_id:
                return asdict(deployment)
        
        return None
    
    def get_deployment_history(self, model_version: str = None, limit: int = 10) -> List[Dict]:
        """获取部署历史"""
        history = self.deployment_history
        
        if model_version:
            history = [d for d in history if d.model_version == model_version]
        
        # 按时间倒序排列
        history.sort(key=lambda x: x.start_time, reverse=True)
        
        return [asdict(d) for d in history[:limit]]
    
    def monitor_deployments(self):
        """监控部署状态"""
        logger.info("开始监控部署状态...")
        
        def monitoring_task():
            while True:
                try:
                    # 检查活跃部署的健康状态
                    for deployment_id, result in self.active_deployments.items():
                        if result.status == DeploymentStatus.RUNNING:
                            # 执行健康检查
                            service_name = self.service_registry.get(result.model_version)
                            if service_name:
                                health_status = self._check_service_health(service_name)
                                if health_status == ServiceHealth.UNHEALTHY:
                                    logger.warning(f"服务健康检查失败: {service_name}")
                                    # 这里可以触发自动回滚
                    
                    # 等待下一个监控周期
                    interval = self.config.get('monitoring_interval', 60)  # 1分钟
                    time.sleep(interval)
                    
                except Exception as e:
                    logger.error(f"部署监控错误: {e}")
                    time.sleep(60)
        
        # 启动后台线程
        monitor_thread = threading.Thread(target=monitoring_task, daemon=True)
        monitor_thread.start()
        
        logger.info("部署监控已启动")
    
    def _check_service_health(self, service_name: str) -> ServiceHealth:
        """检查服务健康状态"""
        try:
            if self.k8s_client:
                # Kubernetes健康检查
                pods = self.core_v1.list_namespaced_pod(
                    namespace="default",
                    label_selector=f"app={service_name}"
                )
                
                healthy_pods = 0
                total_pods = len(pods.items)
                
                for pod in pods.items:
                    if pod.status.phase == "Running" and all(
                        cs.ready for cs in pod.status.container_statuses or []
                    ):
                        healthy_pods += 1
                
                if healthy_pods == total_pods and total_pods > 0:
                    return ServiceHealth.HEALTHY
                elif healthy_pods == 0:
                    return ServiceHealth.UNHEALTHY
                else:
                    return ServiceHealth.UNKNOWN
            
            else:
                # Docker健康检查
                try:
                    container = self.docker_client.containers.get(service_name)
                    if container.status == "running":
                        return ServiceHealth.HEALTHY
                    else:
                        return ServiceHealth.UNHEALTHY
                except docker.errors.NotFound:
                    return ServiceHealth.UNHEALTHY
                    
        except Exception as e:
            logger.error(f"检查服务健康状态失败 {service_name}: {e}")
            return ServiceHealth.UNKNOWN
    
    def generate_deployment_report(self, model_version: str = None) -> Dict:
        """生成部署报告"""
        logger.info("生成部署报告...")
        
        try:
            # 获取部署历史
            history = self.get_deployment_history(model_version)
            
            # 计算统计信息
            total_deployments = len(history)
            successful_deployments = len([d for d in history if d['status'] == 'running'])
            failed_deployments = len([d for d in history if d['status'] == 'failed'])
            rolled_back_deployments = len([d for d in history if d['status'] == 'rolled_back'])
            
            # 计算平均部署时间
            completed_deployments = [d for d in history if d['end_time']]
            if completed_deployments:
                durations = []
                for d in completed_deployments:
                    start_time = datetime.fromisoformat(d['start_time'])
                    end_time = datetime.fromisoformat(d['end_time'])
                    duration = (end_time - start_time).total_seconds()
                    durations.append(duration)
                
                avg_duration = np.mean(durations) if durations else 0
            else:
                avg_duration = 0
            
            # 计算成功率
            success_rate = successful_deployments / total_deployments if total_deployments > 0 else 0
            
            report = {
                'timestamp': datetime.now().isoformat(),
                'model_version': model_version,
                'statistics': {
                    'total_deployments': total_deployments,
                    'successful_deployments': successful_deployments,
                    'failed_deployments': failed_deployments,
                    'rolled_back_deployments': rolled_back_deployments,
                    'success_rate': success_rate,
                    'average_duration_seconds': avg_duration
                },
                'recent_deployments': history[:10],  # 最近10次部署
                'deployment_trends': self._analyze_deployment_trends(history)
            }
            
            # 生成报告图表
            self._generate_deployment_charts(report)
            
            # 保存报告
            report_path = Path('reports') / f'deployment_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
            report_path.parent.mkdir(exist_ok=True)
            
            with open(report_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False, default=str)
            
            logger.info(f"部署报告已生成: {report_path}")
            return report
            
        except Exception as e:
            logger.error(f"生成部署报告失败: {e}")
            return {}
    
    def _analyze_deployment_trends(self, history: List[Dict]) -> Dict:
        """分析部署趋势"""
        if len(history) < 2:
            return {'trend': 'insufficient_data'}
        
        # 按时间排序
        history_sorted = sorted(history, key=lambda x: x['start_time'])
        
        # 分析成功率趋势
        recent_success_rates = []
        window_size = min(5, len(history_sorted))
        
        for i in range(window_size, len(history_sorted) + 1):
            window = history_sorted[i-window_size:i]
            successful = len([d for d in window if d['status'] == 'running'])
            success_rate = successful / len(window)
            recent_success_rates.append(success_rate)
        
        if len(recent_success_rates) >= 2:
            if recent_success_rates[-1] > recent_success_rates[0]:
                trend = 'improving'
            elif recent_success_rates[-1] < recent_success_rates[0]:
                trend = 'declining'
            else:
                trend = 'stable'
        else:
            trend = 'insufficient_data'
        
        return {
            'trend': trend,
            'recent_success_rates': recent_success_rates
        }
    
    def _generate_deployment_charts(self, report: Dict):
        """生成部署图表"""
        try:
            charts_dir = Path('reports') / 'charts'
            charts_dir.mkdir(parents=True, exist_ok=True)
            
            # 设置中文字体
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False
            
            recent_deployments = report['recent_deployments']
            
            if not recent_deployments:
                logger.warning("没有部署数据可生成图表")
                return
            
            fig, axes = plt.subplots(2, 2, figsize=(15, 10))
            fig.suptitle('部署分析报告', fontsize=16)
            
            # 部署状态分布
            statuses = ['running', 'failed', 'rolled_back']
            counts = [
                len([d for d in recent_deployments if d['status'] == status])
                for status in statuses
            ]
            
            axes[0, 0].pie(counts, labels=statuses, autopct='%1.1f%%')
            axes[0, 0].set_title('部署状态分布')
            
            # 部署时间趋势
            if len(recent_deployments) > 1:
                timestamps = [datetime.fromisoformat(d['start_time']) for d in recent_deployments]
                durations = []
                for d in recent_deployments:
                    if d['end_time']:
                        start_time = datetime.fromisoformat(d['start_time'])
                        end_time = datetime.fromisoformat(d['end_time'])
                        duration = (end_time - start_time).total_seconds() / 60  # 转换为分钟
                        durations.append(duration)
                    else:
                        durations.append(0)
                
                axes[0, 1].plot(range(len(timestamps)), durations, marker='o')
                axes[0, 1].set_title('部署时间趋势')
                axes[0, 1].set_xlabel('部署序号')
                axes[0, 1].set_ylabel('部署时间 (分钟)')
                axes[0, 1].tick_params(axis='x', rotation=45)
            
            # 成功率趋势
            trends = report['deployment_trends']
            if 'recent_success_rates' in trends:
                success_rates = trends['recent_success_rates']
                axes[1, 0].plot(range(len(success_rates)), success_rates, marker='s')
                axes[1, 0].set_title('成功率趋势')
                axes[1, 0].set_xlabel('时间窗口')
                axes[1, 0].set_ylabel('成功率')
                axes[1, 0].set_ylim(0, 1)
            
            # 部署统计摘要
            stats = report['statistics']
            metrics_names = ['总部署数', '成功部署', '失败部署', '回滚部署']
            metrics_values = [
                stats['total_deployments'],
                stats['successful_deployments'],
                stats['failed_deployments'],
                stats['rolled_back_deployments']
            ]
            
            axes[1, 1].bar(metrics_names, metrics_values, color='lightblue')
            axes[1, 1].set_title('部署统计摘要')
            axes[1, 1].set_ylabel('数量')
            axes[1, 1].tick_params(axis='x', rotation=45)
            
            plt.tight_layout()
            
            # 保存图表
            chart_path = charts_dir / 'deployment_analysis.png'
            plt.savefig(chart_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info(f"部署分析图表已生成: {chart_path}")
            
        except Exception as e:
            logger.error(f"生成部署图表失败: {e}")

# Celery任务定义
@celery_app.task
def execute_deployment(deployment_id: str, model_version: str, config_dict: Dict):
    """执行部署任务的Celery任务"""
    try:
        # 创建部署管理器实例
        manager = DeploymentManager()
        manager.execute_deployment(deployment_id, model_version, config_dict)
        
    except Exception as e:
        logger.error(f"Celery部署任务失败 {deployment_id}: {e}")

def main():
    """主函数"""
    try:
        # 创建部署管理器
        manager = DeploymentManager()
        
        # 启动监控
        manager.monitor_deployments()
        
        # 保持主线程运行
        while True:
            time.sleep(60)
            
    except KeyboardInterrupt:
        logger.info("部署管理器停止")
    except Exception as e:
        logger.error(f"部署管理器运行错误: {e}")
        raise

if __name__ == "__main__":
    main()