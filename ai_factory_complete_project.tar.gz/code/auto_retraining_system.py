#!/usr/bin/env python3
"""
自动重训练系统核心模块
基于性能指标的自动重训练流程系统
"""

import asyncio
import logging
import json
import os
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Union
from dataclasses import dataclass, asdict
from enum import Enum
import yaml
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import mlflow
import mlflow.pytorch
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import docker
import kubernetes.client
from kubernetes.client.rest import ApiException
import redis
import celery
from celery import Celery
import schedule
import threading
from pathlib import Path
import hashlib
import shutil
import subprocess
import psutil
import GPUtil
from prometheus_client import Gauge, Counter, Histogram, start_http_server
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix
import warnings
warnings.filterwarnings('ignore')

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 数据库模型
Base = declarative_base()

@dataclass
class PerformanceMetrics:
    """性能指标数据类"""
    model_version: str
    timestamp: datetime
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    auc: float
    loss: float
    inference_time: float
    cpu_usage: float
    memory_usage: float
    gpu_usage: float
    gpu_memory: float
    throughput: float
    error_rate: float

@dataclass
class RetrainingTrigger:
    """重训练触发条件"""
    trigger_id: str
    model_version: str
    trigger_type: str  # 'performance_degradation', 'data_drift', 'schedule', 'manual'
    trigger_value: float
    threshold: float
    severity: str  # 'low', 'medium', 'high', 'critical'
    timestamp: datetime
    status: str  # 'pending', 'processing', 'completed', 'failed'

class AutoRetrainingSystem:
    """自动重训练系统主类"""
    
    def __init__(self, config_path: str = "config/auto_retraining_config.yaml"):
        """初始化自动重训练系统"""
        self.config = self._load_config(config_path)
        self._setup_logging()
        self._setup_database()
        self._setup_monitoring()
        self._setup_mlflow()
        self._setup_storage()
        self._setup_kubernetes()
        self._setup_celery()
        self._setup_redis()
        
        # 性能监控指标
        self.performance_gauge = Gauge('model_performance_score', 'Model performance score', ['model_version'])
        self.retraining_counter = Counter('retraining_events_total', 'Total retraining events', ['trigger_type'])
        self.training_duration = Histogram('training_duration_seconds', 'Training duration in seconds')
        
        logger.info("自动重训练系统初始化完成")
    
    def _load_config(self, config_path: str) -> Dict:
        """加载配置文件"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            logger.info(f"配置文件加载成功: {config_path}")
            return config
        except Exception as e:
            logger.error(f"配置文件加载失败: {e}")
            raise
    
    def _setup_logging(self):
        """设置日志系统"""
        log_config = self.config.get('logging', {})
        
        # 创建日志目录
        log_dir = Path(log_config.get('directory', 'logs'))
        log_dir.mkdir(exist_ok=True)
        
        # 配置日志格式
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # 文件处理器
        file_handler = logging.FileHandler(
            log_dir / 'auto_retraining.log'
        )
        file_handler.setFormatter(formatter)
        file_handler.setLevel(logging.INFO)
        
        # 控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)
        
        # 配置根日志器
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
    
    def _setup_database(self):
        """设置数据库连接"""
        db_config = self.config['database']
        self.db_url = db_config['url']
        
        self.engine = create_engine(self.db_url)
        self.SessionLocal = sessionmaker(bind=self.engine)
        
        # 创建表
        Base.metadata.create_all(bind=self.engine)
        logger.info("数据库连接设置完成")
    
    def _setup_monitoring(self):
        """设置监控系统"""
        monitor_config = self.config['monitoring']
        
        # 启动Prometheus指标服务器
        if monitor_config.get('prometheus', {}).get('enabled', True):
            port = monitor_config.get('prometheus', {}).get('port', 8000)
            start_http_server(port)
            logger.info(f"Prometheus指标服务器启动在端口: {port}")
    
    def _setup_mlflow(self):
        """设置MLflow"""
        mlflow_config = self.config['mlflow']
        
        mlflow.set_tracking_uri(mlflow_config['tracking_uri'])
        mlflow.set_experiment(mlflow_config['experiment_name'])
        
        logger.info("MLflow设置完成")
    
    def _setup_storage(self):
        """设置存储系统"""
        storage_config = self.config['storage']
        
        # 创建存储目录
        for dir_path in ['models', 'data', 'logs', 'reports']:
            Path(storage_config['base_path'] / dir_path).mkdir(parents=True, exist_ok=True)
        
        self.storage_config = storage_config
        logger.info("存储系统设置完成")
    
    def _setup_kubernetes(self):
        """设置Kubernetes客户端"""
        try:
            self.k8s_client = kubernetes.client.ApiClient()
            self.apps_v1 = kubernetes.client.AppsV1Api(self.k8s_client)
            self.core_v1 = kubernetes.client.CoreV1Api(self.k8s_client)
            logger.info("Kubernetes客户端设置完成")
        except Exception as e:
            logger.warning(f"Kubernetes设置失败: {e}")
            self.k8s_client = None
    
    def _setup_celery(self):
        """设置Celery任务队列"""
        celery_config = self.config['celery']
        
        self.celery_app = Celery(
            'auto_retraining',
            broker=celery_config['broker_url'],
            backend=celery_config['result_backend']
        )
        
        self.celery_app.conf.update(celery_config['config'])
        logger.info("Celery任务队列设置完成")
    
    def _setup_redis(self):
        """设置Redis连接"""
        redis_config = self.config.get('redis', {})
        if redis_config.get('enabled', False):
            self.redis_client = redis.Redis(
                host=redis_config.get('host', 'localhost'),
                port=redis_config.get('port', 6379),
                db=redis_config.get('db', 0)
            )
            logger.info("Redis连接设置完成")
        else:
            self.redis_client = None
    
    def monitor_performance(self) -> List[PerformanceMetrics]:
        """监控模型性能"""
        logger.info("开始性能监控...")
        
        metrics_list = []
        
        try:
            # 获取所有活跃模型版本
            active_models = self._get_active_models()
            
            for model_version in active_models:
                # 获取模型性能指标
                metrics = self._collect_model_metrics(model_version)
                if metrics:
                    metrics_list.append(metrics)
                    
                    # 更新Prometheus指标
                    performance_score = (metrics.accuracy + metrics.f1_score) / 2
                    self.performance_gauge.labels(model_version=model_version).set(performance_score)
                    
                    # 存储到数据库
                    self._store_performance_metrics(metrics)
            
            logger.info(f"性能监控完成，收集到 {len(metrics_list)} 个模型指标")
            return metrics_list
            
        except Exception as e:
            logger.error(f"性能监控失败: {e}")
            return []
    
    def _get_active_models(self) -> List[str]:
        """获取活跃模型版本"""
        try:
            with self.SessionLocal() as db:
                # 从数据库查询活跃模型
                result = db.execute(
                    "SELECT DISTINCT model_version FROM model_performance "
                    "WHERE status = 'active' AND timestamp > NOW() - INTERVAL '24 hours'"
                )
                return [row[0] for row in result.fetchall()]
        except Exception as e:
            logger.error(f"获取活跃模型失败: {e}")
            return []
    
    def _collect_model_metrics(self, model_version: str) -> Optional[PerformanceMetrics]:
        """收集单个模型的性能指标"""
        try:
            # 模拟性能数据收集（在实际环境中需要连接真实的监控系统）
            current_time = datetime.now()
            
            # 获取系统资源使用情况
            cpu_usage = psutil.cpu_percent(interval=1)
            memory_usage = psutil.virtual_memory().percent
            
            # 获取GPU使用情况
            gpu_usage = 0.0
            gpu_memory = 0.0
            try:
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu_usage = gpus[0].load * 100
                    gpu_memory = gpus[0].memoryUtil * 100
            except:
                pass
            
            # 模拟模型性能指标（在实际环境中需要从实际模型获取）
            metrics = PerformanceMetrics(
                model_version=model_version,
                timestamp=current_time,
                accuracy=np.random.normal(0.92, 0.02),  # 模拟准确率
                precision=np.random.normal(0.90, 0.02),
                recall=np.random.normal(0.88, 0.02),
                f1_score=np.random.normal(0.89, 0.02),
                auc=np.random.normal(0.94, 0.02),
                loss=np.random.exponential(0.1),
                inference_time=np.random.normal(50, 10),  # ms
                cpu_usage=cpu_usage,
                memory_usage=memory_usage,
                gpu_usage=gpu_usage,
                gpu_memory=gpu_memory,
                throughput=np.random.normal(100, 20),  # requests/sec
                error_rate=np.random.exponential(0.01)
            )
            
            return metrics
            
        except Exception as e:
            logger.error(f"收集模型 {model_version} 指标失败: {e}")
            return None
    
    def _store_performance_metrics(self, metrics: PerformanceMetrics):
        """存储性能指标到数据库"""
        try:
            with self.SessionLocal() as db:
                # 存储到数据库
                db.execute("""
                    INSERT INTO model_performance (
                        model_version, timestamp, accuracy, precision, recall, f1_score,
                        auc, loss, inference_time, cpu_usage, memory_usage, gpu_usage,
                        gpu_memory, throughput, error_rate, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    metrics.model_version, metrics.timestamp, metrics.accuracy,
                    metrics.precision, metrics.recall, metrics.f1_score, metrics.auc,
                    metrics.loss, metrics.inference_time, metrics.cpu_usage,
                    metrics.memory_usage, metrics.gpu_usage, metrics.gpu_memory,
                    metrics.throughput, metrics.error_rate, datetime.now()
                ))
                db.commit()
                
        except Exception as e:
            logger.error(f"存储性能指标失败: {e}")
    
    def check_retraining_triggers(self, metrics_list: List[PerformanceMetrics]) -> List[RetrainingTrigger]:
        """检查重训练触发条件"""
        logger.info("检查重训练触发条件...")
        
        triggers = []
        
        for metrics in metrics_list:
            # 检查性能退化
            trigger = self._check_performance_degradation(metrics)
            if trigger:
                triggers.append(trigger)
            
            # 检查数据漂移
            trigger = self._check_data_drift(metrics)
            if trigger:
                triggers.append(trigger)
            
            # 检查资源使用
            trigger = self._check_resource_usage(metrics)
            if trigger:
                triggers.append(trigger)
        
        # 检查定时触发
        scheduled_triggers = self._check_scheduled_triggers()
        triggers.extend(scheduled_triggers)
        
        logger.info(f"发现 {len(triggers)} 个重训练触发条件")
        return triggers
    
    def _check_performance_degradation(self, metrics: PerformanceMetrics) -> Optional[RetrainingTrigger]:
        """检查性能退化"""
        threshold_config = self.config['triggers']['performance_degradation']
        
        try:
            # 获取历史性能基线
            with self.SessionLocal() as db:
                result = db.execute("""
                    SELECT AVG(f1_score) as baseline_f1, AVG(accuracy) as baseline_acc
                    FROM model_performance 
                    WHERE model_version = ? AND timestamp > NOW() - INTERVAL '7 days'
                """, (metrics.model_version,))
                
                row = result.fetchone()
                if not row or row[0] is None:
                    return None
                
                baseline_f1 = row[0]
                baseline_acc = row[1]
                
                # 检查性能退化
                f1_degradation = (baseline_f1 - metrics.f1_score) / baseline_f1
                acc_degradation = (baseline_acc - metrics.accuracy) / baseline_acc
                
                # 触发条件
                if f1_degradation > threshold_config.get('f1_threshold', 0.05):
                    return RetrainingTrigger(
                        trigger_id=f"perf_{metrics.model_version}_{int(time.time())}",
                        model_version=metrics.model_version,
                        trigger_type='performance_degradation',
                        trigger_value=f1_degradation,
                        threshold=threshold_config.get('f1_threshold', 0.05),
                        severity='high' if f1_degradation > 0.1 else 'medium',
                        timestamp=datetime.now(),
                        status='pending'
                    )
                
                if acc_degradation > threshold_config.get('accuracy_threshold', 0.03):
                    return RetrainingTrigger(
                        trigger_id=f"perf_{metrics.model_version}_{int(time.time())}",
                        model_version=metrics.model_version,
                        trigger_type='performance_degradation',
                        trigger_value=acc_degradation,
                        threshold=threshold_config.get('accuracy_threshold', 0.03),
                        severity='high' if acc_degradation > 0.08 else 'medium',
                        timestamp=datetime.now(),
                        status='pending'
                    )
        
        except Exception as e:
            logger.error(f"检查性能退化失败: {e}")
        
        return None
    
    def _check_data_drift(self, metrics: PerformanceMetrics) -> Optional[RetrainingTrigger]:
        """检查数据漂移"""
        drift_config = self.config['triggers'].get('data_drift', {})
        
        if not drift_config.get('enabled', False):
            return None
        
        try:
            # 模拟数据漂移检测
            # 在实际环境中需要实现真正的数据漂移检测算法
            drift_score = np.random.beta(2, 5)  # 模拟漂移分数
            
            if drift_score > drift_config.get('threshold', 0.3):
                return RetrainingTrigger(
                    trigger_id=f"drift_{metrics.model_version}_{int(time.time())}",
                    model_version=metrics.model_version,
                    trigger_type='data_drift',
                    trigger_value=drift_score,
                    threshold=drift_config.get('threshold', 0.3),
                    severity='medium',
                    timestamp=datetime.now(),
                    status='pending'
                )
        
        except Exception as e:
            logger.error(f"检查数据漂移失败: {e}")
        
        return None
    
    def _check_resource_usage(self, metrics: PerformanceMetrics) -> Optional[RetrainingTrigger]:
        """检查资源使用"""
        resource_config = self.config['triggers'].get('resource_usage', {})
        
        try:
            # 检查GPU使用率
            if metrics.gpu_usage > resource_config.get('gpu_threshold', 90):
                return RetrainingTrigger(
                    trigger_id=f"resource_{metrics.model_version}_{int(time.time())}",
                    model_version=metrics.model_version,
                    trigger_type='resource_usage',
                    trigger_value=metrics.gpu_usage,
                    threshold=resource_config.get('gpu_threshold', 90),
                    severity='medium',
                    timestamp=datetime.now(),
                    status='pending'
                )
            
            # 检查内存使用率
            if metrics.memory_usage > resource_config.get('memory_threshold', 85):
                return RetrainingTrigger(
                    trigger_id=f"resource_{metrics.model_version}_{int(time.time())}",
                    model_version=metrics.model_version,
                    trigger_type='resource_usage',
                    trigger_value=metrics.memory_usage,
                    threshold=resource_config.get('memory_threshold', 85),
                    severity='low',
                    timestamp=datetime.now(),
                    status='pending'
                )
        
        except Exception as e:
            logger.error(f"检查资源使用失败: {e}")
        
        return None
    
    def _check_scheduled_triggers(self) -> List[RetrainingTrigger]:
        """检查定时触发"""
        triggers = []
        
        try:
            # 检查是否到了定时重训练时间
            schedule_config = self.config['triggers'].get('scheduled', {})
            
            if schedule_config.get('enabled', False):
                # 模拟定时检查
                if datetime.now().hour == schedule_config.get('hour', 2):  # 默认凌晨2点
                    active_models = self._get_active_models()
                    
                    for model_version in active_models:
                        trigger = RetrainingTrigger(
                            trigger_id=f"schedule_{model_version}_{int(time.time())}",
                            model_version=model_version,
                            trigger_type='scheduled',
                            trigger_value=1.0,
                            threshold=1.0,
                            severity='low',
                            timestamp=datetime.now(),
                            status='pending'
                        )
                        triggers.append(trigger)
        
        except Exception as e:
            logger.error(f"检查定时触发失败: {e}")
        
        return triggers
    
    def process_retraining_triggers(self, triggers: List[RetrainingTrigger]):
        """处理重训练触发条件"""
        logger.info(f"处理 {len(triggers)} 个重训练触发条件...")
        
        # 按严重程度排序
        triggers.sort(key=lambda x: {'critical': 4, 'high': 3, 'medium': 2, 'low': 1}[x.severity], reverse=True)
        
        for trigger in triggers:
            try:
                # 检查是否已经在处理中
                if self._is_trigger_processing(trigger.trigger_id):
                    logger.info(f"触发条件 {trigger.trigger_id} 正在处理中，跳过")
                    continue
                
                # 标记为处理中
                self._update_trigger_status(trigger.trigger_id, 'processing')
                
                # 触发重训练任务
                self._trigger_retraining_job(trigger)
                
                # 更新计数器
                self.retraining_counter.labels(trigger_type=trigger.trigger_type).inc()
                
                logger.info(f"重训练任务已触发: {trigger.trigger_id}")
                
            except Exception as e:
                logger.error(f"处理触发条件失败 {trigger.trigger_id}: {e}")
                self._update_trigger_status(trigger.trigger_id, 'failed')
    
    def _is_trigger_processing(self, trigger_id: str) -> bool:
        """检查触发条件是否正在处理中"""
        try:
            with self.SessionLocal() as db:
                result = db.execute(
                    "SELECT status FROM retraining_triggers WHERE trigger_id = ?",
                    (trigger_id,)
                )
                row = result.fetchone()
                return row and row[0] == 'processing'
        except:
            return False
    
    def _update_trigger_status(self, trigger_id: str, status: str):
        """更新触发条件状态"""
        try:
            with self.SessionLocal() as db:
                db.execute(
                    "UPDATE retraining_triggers SET status = ?, updated_at = ? WHERE trigger_id = ?",
                    (status, datetime.now(), trigger_id)
                )
                db.commit()
        except Exception as e:
            logger.error(f"更新触发状态失败: {e}")
    
    def _trigger_retraining_job(self, trigger: RetrainingTrigger):
        """触发重训练任务"""
        try:
            # 准备训练配置
            training_config = {
                'model_version': trigger.model_version,
                'trigger_type': trigger.trigger_type,
                'trigger_id': trigger.trigger_id,
                'config': self.config['training']
            }
            
            # 提交Celery任务
            self.celery_app.send_task(
                'auto_retraining_system.retrain_model',
                args=[training_config]
            )
            
        except Exception as e:
            logger.error(f"触发重训练任务失败: {e}")
            raise
    
    def start_monitoring_loop(self):
        """启动监控循环"""
        logger.info("启动性能监控循环...")
        
        def monitoring_task():
            while True:
                try:
                    # 性能监控
                    metrics_list = self.monitor_performance()
                    
                    # 检查触发条件
                    triggers = self.check_retraining_triggers(metrics_list)
                    
                    # 存储触发条件到数据库
                    for trigger in triggers:
                        self._store_retraining_trigger(trigger)
                    
                    # 处理触发条件
                    self.process_retraining_triggers(triggers)
                    
                    # 等待下一个监控周期
                    interval = self.config['monitoring'].get('interval', 300)  # 5分钟
                    time.sleep(interval)
                    
                except Exception as e:
                    logger.error(f"监控循环错误: {e}")
                    time.sleep(60)  # 错误时等待1分钟
    
    def _store_retraining_trigger(self, trigger: RetrainingTrigger):
        """存储重训练触发条件到数据库"""
        try:
            with self.SessionLocal() as db:
                db.execute("""
                    INSERT OR REPLACE INTO retraining_triggers (
                        trigger_id, model_version, trigger_type, trigger_value,
                        threshold, severity, timestamp, status, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    trigger.trigger_id, trigger.model_version, trigger.trigger_type,
                    trigger.trigger_value, trigger.threshold, trigger.severity,
                    trigger.timestamp, trigger.status, datetime.now()
                ))
                db.commit()
        except Exception as e:
            logger.error(f"存储触发条件失败: {e}")
    
    def generate_performance_report(self, model_version: str, days: int = 7) -> Dict:
        """生成性能报告"""
        logger.info(f"生成模型 {model_version} 的性能报告...")
        
        try:
            with self.SessionLocal() as db:
                # 获取历史数据
                result = db.execute("""
                    SELECT timestamp, accuracy, precision, recall, f1_score, auc,
                           loss, inference_time, cpu_usage, memory_usage, gpu_usage,
                           throughput, error_rate
                    FROM model_performance
                    WHERE model_version = ? AND timestamp > NOW() - INTERVAL ? days
                    ORDER BY timestamp
                """, (model_version, days))
                
                rows = result.fetchall()
                
                if not rows:
                    return {'error': '没有找到性能数据'}
                
                # 转换为DataFrame
                columns = ['timestamp', 'accuracy', 'precision', 'recall', 'f1_score', 'auc',
                          'loss', 'inference_time', 'cpu_usage', 'memory_usage', 'gpu_usage',
                          'throughput', 'error_rate']
                
                df = pd.DataFrame(rows, columns=columns)
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                
                # 生成报告
                report = {
                    'model_version': model_version,
                    'period_days': days,
                    'summary': {
                        'total_records': len(df),
                        'avg_accuracy': float(df['accuracy'].mean()),
                        'avg_f1_score': float(df['f1_score'].mean()),
                        'avg_inference_time': float(df['inference_time'].mean()),
                        'avg_throughput': float(df['throughput'].mean()),
                        'avg_error_rate': float(df['error_rate'].mean())
                    },
                    'trends': {
                        'accuracy_trend': 'improving' if df['accuracy'].iloc[-1] > df['accuracy'].iloc[0] else 'declining',
                        'f1_trend': 'improving' if df['f1_score'].iloc[-1] > df['f1_score'].iloc[0] else 'declining',
                        'performance_stability': float(df['f1_score'].std())
                    },
                    'recommendations': self._generate_recommendations(df)
                }
                
                # 生成图表
                self._generate_performance_charts(df, model_version)
                
                # 保存报告
                report_path = Path(self.storage_config['base_path']) / 'reports' / f'{model_version}_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
                with open(report_path, 'w', encoding='utf-8') as f:
                    json.dump(report, f, indent=2, ensure_ascii=False, default=str)
                
                logger.info(f"性能报告已生成: {report_path}")
                return report
                
        except Exception as e:
            logger.error(f"生成性能报告失败: {e}")
            return {'error': str(e)}
    
    def _generate_recommendations(self, df: pd.DataFrame) -> List[str]:
        """生成性能改进建议"""
        recommendations = []
        
        # 性能趋势分析
        if df['f1_score'].iloc[-1] < df['f1_score'].iloc[0]:
            recommendations.append("模型性能呈下降趋势，建议考虑重训练")
        
        # 稳定性分析
        if df['f1_score'].std() > 0.05:
            recommendations.append("模型性能波动较大，建议检查数据质量或增加正则化")
        
        # 资源使用分析
        if df['gpu_usage'].mean() > 80:
            recommendations.append("GPU使用率较高，建议优化模型或增加硬件资源")
        
        if df['memory_usage'].mean() > 80:
            recommendations.append("内存使用率较高，建议优化数据处理流程")
        
        # 推理时间分析
        if df['inference_time'].mean() > 100:  # ms
            recommendations.append("推理时间较长，建议优化模型结构或使用模型压缩技术")
        
        # 吞吐量分析
        if df['throughput'].mean() < 50:  # requests/sec
            recommendations.append("吞吐量较低，建议优化推理服务或增加并行度")
        
        return recommendations
    
    def _generate_performance_charts(self, df: pd.DataFrame, model_version: str):
        """生成性能图表"""
        try:
            # 设置中文字体
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False
            
            # 创建图表目录
            charts_dir = Path(self.storage_config['base_path']) / 'reports' / 'charts'
            charts_dir.mkdir(parents=True, exist_ok=True)
            
            # 性能指标趋势图
            fig, axes = plt.subplots(2, 2, figsize=(15, 10))
            fig.suptitle(f'模型 {model_version} 性能趋势', fontsize=16)
            
            # 准确率和F1分数
            axes[0, 0].plot(df['timestamp'], df['accuracy'], label='准确率', color='blue')
            axes[0, 0].plot(df['timestamp'], df['f1_score'], label='F1分数', color='red')
            axes[0, 0].set_title('准确率和F1分数趋势')
            axes[0, 0].legend()
            axes[0, 0].tick_params(axis='x', rotation=45)
            
            # 推理时间和吞吐量
            axes[0, 1].plot(df['timestamp'], df['inference_time'], label='推理时间(ms)', color='green')
            axes[0, 1].set_title('推理时间趋势')
            axes[0, 1].legend()
            axes[0, 1].tick_params(axis='x', rotation=45)
            
            # 资源使用情况
            axes[1, 0].plot(df['timestamp'], df['cpu_usage'], label='CPU使用率(%)', color='orange')
            axes[1, 0].plot(df['timestamp'], df['memory_usage'], label='内存使用率(%)', color='purple')
            axes[1, 0].set_title('系统资源使用趋势')
            axes[1, 0].legend()
            axes[1, 0].tick_params(axis='x', rotation=45)
            
            # 错误率
            axes[1, 1].plot(df['timestamp'], df['error_rate'], label='错误率', color='red')
            axes[1, 1].set_title('错误率趋势')
            axes[1, 1].legend()
            axes[1, 1].tick_params(axis='x', rotation=45)
            
            plt.tight_layout()
            
            # 保存图表
            chart_path = charts_dir / f'{model_version}_performance_trends.png'
            plt.savefig(chart_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info(f"性能图表已生成: {chart_path}")
            
        except Exception as e:
            logger.error(f"生成性能图表失败: {e}")

def main():
    """主函数"""
    try:
        # 创建自动重训练系统实例
        system = AutoRetrainingSystem()
        
        # 启动监控循环（在实际部署中应该作为后台服务运行）
        system.start_monitoring_loop()
        
    except KeyboardInterrupt:
        logger.info("系统停止")
    except Exception as e:
        logger.error(f"系统运行错误: {e}")
        raise

if __name__ == "__main__":
    main()