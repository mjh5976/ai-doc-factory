"""
统计显著性检验模块
提供完整的A/B测试统计分析功能，包括假设检验、样本量计算、多重比较校正等
"""

import numpy as np
import pandas as pd
from scipy import stats
from typing import Dict, List, Tuple, Optional, Union, Any
from dataclasses import dataclass
from enum import Enum
import warnings
import logging

logger = logging.getLogger(__name__)

class StatisticalTest(Enum):
    """统计检验方法枚举"""
    T_TEST = "t_test"
    WELCH_T_TEST = "welch_t_test"
    CHI_SQUARE = "chi_square"
    FISHER_EXACT = "fisher_exact"
    MANN_WHITNEY = "mann_whitney"
    WILCOXON = "wilcoxon"
    KRUSKAL_WALLIS = "kruskal_wallis"
    ANOVA = "anova"
    BAYESIAN = "bayesian"
    SEQUENTIAL = "sequential"

class EffectSizeMeasure(Enum):
    """效应大小度量枚举"""
    COHENS_D = "cohens_d"
    HEDGES_G = "hedges_g"
    ODDS_RATIO = "odds_ratio"
    RELATIVE_RISK = "relative_risk"
    PHI = "phi"
    CRAMERS_V = "cramers_v"

@dataclass
class TestResult:
    """统计检验结果"""
    test_name: str
    statistic: float
    p_value: float
    degrees_of_freedom: Optional[float]
    confidence_interval: Optional[Tuple[float, float]]
    effect_size: Optional[float]
    effect_size_name: str
    is_significant: bool
    alpha: float
    power: Optional[float]
    sample_size: int
    interpretation: str

@dataclass
class SampleSizeCalculation:
    """样本量计算结果"""
    required_sample_size: int
    effect_size: float
    alpha: float
    power: float
    test_type: str
    allocation_ratio: float = 1.0
    notes: str = ""

class StatisticalTests:
    """统计检验类"""
    
    def __init__(self, alpha: float = 0.05, power: float = 0.8):
        self.alpha = alpha
        self.power = power
        
    def compare_two_means(self, 
                         control_data: np.ndarray, 
                         treatment_data: np.ndarray,
                         test_type: StatisticalTest = StatisticalTest.T_TEST,
                         equal_variance: bool = True) -> TestResult:
        """比较两个均值"""
        
        if len(control_data) == 0 or len(treatment_data) == 0:
            raise ValueError("数据不能为空")
        
        control_mean = np.mean(control_data)
        treatment_mean = np.mean(treatment_data)
        difference = treatment_mean - control_mean
        
        # 计算效应大小
        effect_size = self._calculate_cohens_d(control_data, treatment_data)
        
        if test_type == StatisticalTest.T_TEST:
            if equal_variance:
                statistic, p_value = stats.ttest_ind(treatment_data, control_data, equal_var=True)
                df = len(control_data) + len(treatment_data) - 2
            else:
                statistic, p_value = stats.ttest_ind(treatment_data, control_data, equal_var=False)
                # Welch's t-test degrees of freedom
                s1_sq = np.var(control_data, ddof=1)
                s2_sq = np.var(treatment_data, ddof=1)
                n1, n2 = len(control_data), len(treatment_data)
                df = (s1_sq/n1 + s2_sq/n2)**2 / ((s1_sq/n1)**2/(n1-1) + (s2_sq/n2)**2/(n2-1))
            
        elif test_type == StatisticalTest.MANN_WHITNEY:
            statistic, p_value = stats.mannwhitneyu(treatment_data, control_data, 
                                                   alternative='two-sided')
            df = None
            
        elif test_type == StatisticalTest.WILCOXON:
            # 配对t检验的的非参数版本
            if len(control_data) != len(treatment_data):
                raise ValueError("配对检验需要相同长度的数据")
            statistic, p_value = stats.wilcoxon(treatment_data - control_data)
            df = None
            
        else:
            raise ValueError(f"不支持的检验方法: {test_type}")
        
        # 计算置信区间
        se = np.sqrt(np.var(control_data, ddof=1) / len(control_data) +
                    np.var(treatment_data, ddof=1) / len(treatment_data))
        margin_error = stats.t.ppf(1 - self.alpha/2, df) * se if df else stats.norm.ppf(1 - self.alpha/2) * se
        ci_lower = difference - margin_error
        ci_upper = difference + margin_error
        
        # 解释结果
        interpretation = self._interpret_p_value(p_value)
        
        return TestResult(
            test_name=test_type.value,
            statistic=statistic,
            p_value=p_value,
            degrees_of_freedom=df,
            confidence_interval=(ci_lower, ci_upper),
            effect_size=effect_size,
            effect_size_name="Cohen's d",
            is_significant=p_value < self.alpha,
            alpha=self.alpha,
            power=None,
            sample_size=len(control_data) + len(treatment_data),
            interpretation=interpretation
        )
    
    def compare_two_proportions(self,
                               control_success: int,
                               control_total: int,
                               treatment_success: int,
                               treatment_total: int,
                               test_type: StatisticalTest = StatisticalTest.CHI_SQUARE) -> TestResult:
        """比较两个比例"""
        
        if control_total == 0 or treatment_total == 0:
            raise ValueError("总样本量不能为零")
        
        control_rate = control_success / control_total
        treatment_rate = treatment_success / treatment_total
        difference = treatment_rate - control_rate
        
        # 计算效应大小（相对风险）
        effect_size = treatment_rate / control_rate if control_rate > 0 else float('inf')
        
        if test_type == StatisticalTest.CHI_SQUARE:
            # 创建列联表
            contingency_table = np.array([[control_success, control_total - control_success],
                                        [treatment_success, treatment_total - treatment_success]])
            statistic, p_value, df, expected = stats.chi2_contingency(contingency_table)
            
            # 计算Cramer's V作为效应大小
            n = control_total + treatment_total
            cramers_v = np.sqrt(statistic / (n * (min(contingency_table.shape) - 1)))
            effect_size = cramers_v
            
        elif test_type == StatisticalTest.FISHER_EXACT:
            # Fisher精确检验
            contingency_table = np.array([[control_success, control_total - control_success],
                                        [treatment_success, treatment_total - treatment_success]])
            _, p_value = stats.fisher_exact(contingency_table)
            statistic = None
            df = None
            effect_size = self._calculate_odds_ratio(control_success, control_total, 
                                                   treatment_success, treatment_total)
            
        else:
            raise ValueError(f"不支持的检验方法: {test_type}")
        
        # 计算置信区间（使用Wald方法）
        se = np.sqrt(control_rate * (1 - control_rate) / control_total + 
                    treatment_rate * (1 - treatment_rate) / treatment_total)
        margin_error = stats.norm.ppf(1 - self.alpha/2) * se
        ci_lower = difference - margin_error
        ci_upper = difference + margin_error
        
        interpretation = self._interpret_p_value(p_value)
        
        return TestResult(
            test_name=test_type.value,
            statistic=statistic,
            p_value=p_value,
            degrees_of_freedom=df,
            confidence_interval=(ci_lower, ci_upper),
            effect_size=effect_size,
            effect_size_name="Effect size",
            is_significant=p_value < self.alpha,
            alpha=self.alpha,
            power=None,
            sample_size=control_total + treatment_total,
            interpretation=interpretation
        )
    
    def multiple_comparison_correction(self, p_values: List[float], 
                                     method: str = "bonferroni") -> Dict[str, Any]:
        """多重比较校正"""
        
        if not p_values:
            raise ValueError("p值列表不能为空")
        
        n = len(p_values)
        
        if method == "bonferroni":
            corrected_alpha = self.alpha / n
            corrected_p_values = [min(1.0, p * n) for p in p_values]
            
        elif method == "holm":
            sorted_indices = np.argsort(p_values)
            sorted_p = [p_values[i] for i in sorted_indices]
            corrected_p = []
            
            for i, p in enumerate(sorted_p):
                adjusted_p = max(0, min(1, p * (n - i)))
                corrected_p.append(adjusted_p)
            
            # 恢复原始顺序
            corrected_p_values = [0] * n
            for i, orig_idx in enumerate(sorted_indices):
                corrected_p_values[orig_idx] = corrected_p[i]
            
            corrected_alpha = self.alpha
            
        elif method == "fdr":
            # Benjamini-Hochberg方法
            sorted_indices = np.argsort(p_values)
            sorted_p = [p_values[i] for i in sorted_indices]
            corrected_p = []
            
            for i in range(n-1, -1, -1):
                if i == n-1:
                    corrected_p.append(sorted_p[i])
                else:
                    corrected_p.append(min(sorted_p[i], corrected_p[-1] * n / (i + 1)))
            
            corrected_p_values = [0] * n
            for i, orig_idx in enumerate(sorted_indices):
                corrected_p_values[orig_idx] = corrected_p[i]
            
            corrected_alpha = self.alpha
            
        else:
            raise ValueError(f"不支持的校正方法: {method}")
        
        return {
            'method': method,
            'original_alpha': self.alpha,
            'corrected_alpha': corrected_alpha,
            'original_p_values': p_values,
            'corrected_p_values': corrected_p_values,
            'significant_tests': [i for i, p in enumerate(corrected_p_values) if p < corrected_alpha]
        }
    
    def calculate_sample_size_two_means(self,
                                       baseline_mean: float,
                                       expected_difference: float,
                                       pooled_std: float,
                                       allocation_ratio: float = 1.0) -> SampleSizeCalculation:
        """计算两均值比较的样本量"""
        
        if expected_difference == 0:
            raise ValueError("期望差异不能为零")
        
        # 计算效应大小
        d = abs(expected_difference) / pooled_std
        
        # 计算样本量（使用Cohen's公式）
        z_alpha = stats.norm.ppf(1 - self.alpha/2)
        z_beta = stats.norm.ppf(self.power)
        
        # 两组样本量
        n1 = ((z_alpha + z_beta)**2 * (1 + 1/allocation_ratio)) / d**2
        n2 = n1 * allocation_ratio
        
        total_sample_size = int(np.ceil(n1 + n2))
        
        return SampleSizeCalculation(
            required_sample_size=total_sample_size,
            effect_size=d,
            alpha=self.alpha,
            power=self.power,
            test_type="two_means",
            allocation_ratio=allocation_ratio,
            notes=f"效应大小: {d:.3f} (Cohen's d)"
        )
    
    def calculate_sample_size_two_proportions(self,
                                            baseline_rate: float,
                                            expected_rate: float,
                                            allocation_ratio: float = 1.0) -> SampleSizeCalculation:
        """计算两比例比较的样本量"""
        
        if expected_rate == baseline_rate:
            raise ValueError("期望比例不能等于基线比例")
        
        # 计算效应大小
        effect_size = abs(expected_rate - baseline_rate)
        
        # 使用Fleiss公式
        p1 = baseline_rate
        p2 = expected_rate
        p_bar = (p1 + p2) / 2
        
        z_alpha = stats.norm.ppf(1 - self.alpha/2)
        z_beta = stats.norm.ppf(self.power)
        
        # 两组样本量
        n1 = ((z_alpha * np.sqrt(2 * p_bar * (1 - p_bar)) + 
               z_beta * np.sqrt(p1 * (1 - p1) + p2 * (1 - p2)))**2) / (p2 - p1)**2
        
        n2 = n1 * allocation_ratio
        total_sample_size = int(np.ceil(n1 + n2))
        
        return SampleSizeCalculation(
            required_sample_size=total_sample_size,
            effect_size=effect_size,
            alpha=self.alpha,
            power=self.power,
            test_type="two_proportions",
            allocation_ratio=allocation_ratio,
            notes=f"期望改进: {effect_size:.3f} ({effect_size/p1*100:.1f}%)"
        )
    
    def bayesian_comparison(self,
                           control_data: np.ndarray,
                           treatment_data: np.ndarray,
                           prior_strength: float = 1.0) -> Dict[str, Any]:
        """贝叶斯比较分析"""
        
        # 使用贝塔分布作为先验（适用于比例数据）
        # 使用正态分布作为先验（适用于连续数据）
        
        # 计算后验分布参数
        control_mean = np.mean(control_data)
        treatment_mean = np.mean(treatment_data)
        control_std = np.std(control_data)
        treatment_std = np.std(treatment_data)
        
        # 简化的贝叶斯因子计算
        # 实际中应该使用更复杂的MCMC或变分推断方法
        
        # 计算似然比
        pooled_std = np.sqrt((control_std**2 + treatment_std**2) / 2)
        t_stat = abs(treatment_mean - control_mean) / (pooled_std * np.sqrt(1/len(control_data) + 1/len(treatment_data)))
        
        # 简化的贝叶斯因子（基于t统计量）
        bayes_factor = np.exp(0.5 * t_stat**2)
        
        # 计算后验概率
        prior_prob = 0.5  # 假设先验概率相等
        likelihood_ratio = bayes_factor
        posterior_prob = (prior_prob * likelihood_ratio) / (prior_prob * likelihood_ratio + (1 - prior_prob))
        
        return {
            'bayes_factor': bayes_factor,
            'posterior_probability': posterior_prob,
            'evidence_strength': self._interpret_bayes_factor(bayes_factor),
            'recommendation': 'strong_evidence_for_difference' if bayes_factor > 10 else 
                             'moderate_evidence_for_difference' if bayes_factor > 3 else
                             'weak_evidence_for_difference' if bayes_factor > 1 else
                             'no_evidence_for_difference'
        }
    
    def _calculate_cohens_d(self, control_data: np.ndarray, treatment_data: np.ndarray) -> float:
        """计算Cohen's d效应大小"""
        control_mean = np.mean(control_data)
        treatment_mean = np.mean(treatment_data)
        
        # 计算合并标准差
        n1, n2 = len(control_data), len(treatment_data)
        pooled_std = np.sqrt(((n1 - 1) * np.var(control_data, ddof=1) + 
                             (n2 - 1) * np.var(treatment_data, ddof=1)) / (n1 + n2 - 2))
        
        return (treatment_mean - control_mean) / pooled_std
    
    def _calculate_odds_ratio(self, control_success: int, control_total: int,
                             treatment_success: int, treatment_total: int) -> float:
        """计算比值比"""
        control_failure = control_total - control_success
        treatment_failure = treatment_total - treatment_success
        
        if control_failure == 0 or treatment_failure == 0:
            return float('inf') if (control_success > 0 and treatment_success > 0) else 0
        
        return (treatment_success * control_failure) / (control_success * treatment_failure)
    
    def _interpret_p_value(self, p_value: float) -> str:
        """解释p值"""
        if p_value < 0.001:
            return "极显著 (p < 0.001)"
        elif p_value < 0.01:
            return "非常显著 (p < 0.01)"
        elif p_value < 0.05:
            return "显著 (p < 0.05)"
        elif p_value < 0.1:
            return "边缘显著 (p < 0.1)"
        else:
            return "不显著 (p ≥ 0.1)"
    
    def _interpret_bayes_factor(self, bayes_factor: float) -> str:
        """解释贝叶斯因子"""
        if bayes_factor > 100:
            return "极强证据"
        elif bayes_factor > 30:
            return "强证据"
        elif bayes_factor > 10:
            return "强证据"
        elif bayes_factor > 3:
            return "中等证据"
        elif bayes_factor > 1:
            return "弱证据"
        else:
            return "无证据"

class PowerAnalysis:
    """功效分析类"""
    
    def __init__(self, alpha: float = 0.05):
        self.alpha = alpha
    
    def calculate_power(self,
                       effect_size: float,
                       sample_size: int,
                       test_type: str = "two_means") -> float:
        """计算统计功效"""
        
        if test_type == "two_means":
            # 两均值比较的功效
            z_alpha = stats.norm.ppf(1 - self.alpha/2)
            z_effect = effect_size * np.sqrt(sample_size / 4)  # 假设两组样本量相等
            power = 1 - stats.norm.cdf(z_alpha - z_effect) + stats.norm.cdf(-z_alpha - z_effect)
            
        elif test_type == "two_proportions":
            # 两比例比较的功效（简化计算）
            # 实际计算更复杂，需要考虑基线比例
            z_alpha = stats.norm.ppf(1 - self.alpha/2)
            z_effect = effect_size * np.sqrt(sample_size / 4)
            power = 1 - stats.norm.cdf(z_alpha - z_effect) + stats.norm.cdf(-z_alpha - z_effect)
            
        else:
            raise ValueError(f"不支持的检验类型: {test_type}")
        
        return max(0, min(1, power))
    
    def minimum_detectable_effect(self,
                                 sample_size: int,
                                 power: float = 0.8,
                                 test_type: str = "two_means") -> float:
        """计算最小可检测效应"""
        
        z_alpha = stats.norm.ppf(1 - self.alpha/2)
        z_beta = stats.norm.ppf(power)
        
        if test_type == "two_means":
            # 两均值比较的MDE
            mde = (z_alpha + z_beta) * 2 / np.sqrt(sample_size)
            
        elif test_type == "two_proportions":
            # 两比例比较的MDE（简化）
            mde = (z_alpha + z_beta) * 2 / np.sqrt(sample_size)
            
        else:
            raise ValueError(f"不支持的检验类型: {test_type}")
        
        return mde

# 使用示例和测试函数
def run_statistical_tests_example():
    """运行统计检验示例"""
    
    # 创建统计检验实例
    stats_tests = StatisticalTests(alpha=0.05, power=0.8)
    
    # 生成模拟数据
    np.random.seed(42)
    control_data = np.random.normal(100, 15, 1000)  # 控制组：均值100，标准差15
    treatment_data = np.random.normal(103, 15, 1000)  # 实验组：均值103，标准差15
    
    # 进行t检验
    t_test_result = stats_tests.compare_two_means(control_data, treatment_data)
    print("t检验结果:")
    print(f"  统计量: {t_test_result.statistic:.4f}")
    print(f"  p值: {t_test_result.p_value:.6f}")
    print(f"  显著性: {t_test_result.is_significant}")
    print(f"  效应大小: {t_test_result.effect_size:.4f}")
    print(f"  解释: {t_test_result.interpretation}")
    
    # 贝叶斯分析
    bayesian_result = stats_tests.bayesian_comparison(control_data, treatment_data)
    print("\n贝叶斯分析:")
    print(f"  贝叶斯因子: {bayesian_result['bayes_factor']:.4f}")
    print(f"  证据强度: {bayesian_result['evidence_strength']}")
    
    # 样本量计算
    sample_calc = stats_tests.calculate_sample_size_two_means(
        baseline_mean=100,
        expected_difference=3,
        pooled_std=15
    )
    print(f"\n样本量计算:")
    print(f"  所需样本量: {sample_calc.required_sample_size}")
    print(f"  效应大小: {sample_calc.effect_size:.4f}")
    print(f"  备注: {sample_calc.notes}")
    
    # 比例比较示例
    control_success = 450
    control_total = 1000
    treatment_success = 520
    treatment_total = 1000
    
    prop_test_result = stats_tests.compare_two_proportions(
        control_success, control_total, treatment_success, treatment_total
    )
    print(f"\n比例比较结果:")
    print(f"  p值: {prop_test_result.p_value:.6f}")
    print(f"  显著性: {prop_test_result.is_significant}")

if __name__ == "__main__":
    run_statistical_tests_example()