"""
性能报告生成器
自动生成PDF图纸识别性能监控报告
"""

import json
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from dataclasses import asdict
from pathlib import Path
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.backends.backend_pdf import PdfPages
import seaborn as sns
import pandas as pd
import numpy as np
from jinja2 import Template
import base64
from io import BytesIO


class PerformanceReportGenerator:
    """性能报告生成器"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # 设置matplotlib中文字体
        plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False
        plt.style.use('seaborn-v0_8')
    
    def generate_daily_report(self, 
                            metrics_data: Dict[str, Any],
                            output_path: str) -> str:
        """生成日报"""
        try:
            # 创建输出目录
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            
            # 生成报告内容
            report_content = self._generate_report_content(metrics_data, "daily")
            
            # 保存报告
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(report_content)
            
            self.logger.info(f"日报已生成: {output_path}")
            return output_path
            
        except Exception as e:
            self.logger.error(f"生成日报失败: {e}")
            raise
    
    def generate_weekly_report(self,
                             metrics_data: Dict[str, Any],
                             output_path: str) -> str:
        """生成周报"""
        try:
            # 创建输出目录
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            
            # 生成报告内容
            report_content = self._generate_report_content(metrics_data, "weekly")
            
            # 保存报告
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(report_content)
            
            self.logger.info(f"周报已生成: {output_path}")
            return output_path
            
        except Exception as e:
            self.logger.error(f"生成周报失败: {e}")
            raise
    
    def generate_monthly_report(self,
                              metrics_data: Dict[str, Any],
                              output_path: str) -> str:
        """生成月报"""
        try:
            # 创建输出目录
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            
            # 生成报告内容
            report_content = self._generate_report_content(metrics_data, "monthly")
            
            # 保存报告
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(report_content)
            
            self.logger.info(f"月报已生成: {output_path}")
            return output_path
            
        except Exception as e:
            self.logger.error(f"生成月报失败: {e}")
            raise
    
    def generate_pdf_report(self,
                          metrics_data: Dict[str, Any],
                          output_path: str) -> str:
        """生成PDF报告"""
        try:
            # 创建输出目录
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            
            with PdfPages(output_path) as pdf:
                # 封面
                self._create_cover_page(pdf, metrics_data)
                
                # 执行摘要
                self._create_executive_summary(pdf, metrics_data)
                
                # 性能趋势图
                self._create_performance_trends(pdf, metrics_data)
                
                # 详细指标
                self._create_detailed_metrics(pdf, metrics_data)
                
                # 告警汇总
                self._create_alerts_summary(pdf, metrics_data)
                
                # 建议与行动计划
                self._create_recommendations(pdf, metrics_data)
            
            self.logger.info(f"PDF报告已生成: {output_path}")
            return output_path
            
        except Exception as e:
            self.logger.error(f"生成PDF报告失败: {e}")
            raise
    
    def _generate_report_content(self, metrics_data: Dict[str, Any], report_type: str) -> str:
        """生成报告内容"""
        try:
            # 使用Jinja2模板
            template_str = self._get_report_template(report_type)
            template = Template(template_str)
            
            # 准备模板数据
            template_data = self._prepare_template_data(metrics_data, report_type)
            
            # 渲染模板
            content = template.render(**template_data)
            
            return content
            
        except Exception as e:
            self.logger.error(f"生成报告内容失败: {e}")
            raise
    
    def _get_report_template(self, report_type: str) -> str:
        """获取报告模板"""
        templates = {
            "daily": """
# PDF图纸识别性能日报
## {{ report_date }}

### 执行摘要
- **总识别请求数**: {{ total_requests | number_format }}
- **平均准确率**: {{ avg_accuracy | percentage_format }}
- **平均处理时间**: {{ avg_processing_time | number_format }}秒
- **系统可用性**: {{ system_availability | percentage_format }}
- **告警数量**: {{ alert_count }}个

### 关键指标概览
| 指标 | 当前值 | 目标值 | 状态 |
|------|--------|--------|------|
| 识别准确率 | {{ metrics.accuracy.current }} | {{ metrics.accuracy.target }} | {{ metrics.accuracy.status }} |
| 识别召回率 | {{ metrics.recall.current }} | {{ metrics.recall.target }} | {{ metrics.recall.status }} |
| F1-score | {{ metrics.f1_score.current }} | {{ metrics.f1_score.target }} | {{ metrics.f1_score.status }} |
| 平均处理时间 | {{ metrics.processing_time.current }}秒 | {{ metrics.processing_time.target }}秒 | {{ metrics.processing_time.status }} |

### 图纸类型性能分析
{% for blueprint_type, data in blueprint_performance.items() %}
#### {{ blueprint_type | title }}图纸
- 识别准确率: {{ data.accuracy | percentage_format }}
- 处理样本数: {{ data.sample_count | number_format }}
- 平均处理时间: {{ data.avg_processing_time | number_format }}秒
{% endfor %}

### 告警汇总
{% if alerts %}
| 时间 | 告警级别 | 告警内容 | 状态 |
|------|----------|----------|------|
{% for alert in alerts %}
| {{ alert.timestamp }} | {{ alert.severity }} | {{ alert.message }} | {{ alert.status }} |
{% endfor %}
{% else %}
本期无重要告警。
{% endif %}

### 性能趋势
{% for metric_name, trend in performance_trends.items() %}
- **{{ metric_name | title }}**: {{ trend.description }}
{% endfor %}

### 建议与行动计划
{% for recommendation in recommendations %}
- {{ recommendation }}
{% endfor %}

---
*报告生成时间: {{ generation_time }}*
            """,
            
            "weekly": """
# PDF图纸识别性能周报
## {{ week_range }}

### 执行摘要
本周PDF图纸识别系统整体运行稳定，性能指标均达到预期目标。

#### 关键成果
- 总识别请求数: {{ total_requests | number_format }} (环比{{ request_growth | percentage_format }})
- 平均准确率: {{ avg_accuracy | percentage_format }} (环比{{ accuracy_change | percentage_format }})
- 系统可用性: {{ system_availability | percentage_format }}
- 处理效率提升: {{ efficiency_improvement | percentage_format }}

### 周度性能对比
| 指标 | 本周 | 上周 | 变化 |
|------|------|------|------|
| 识别准确率 | {{ current_week.accuracy | percentage_format }} | {{ previous_week.accuracy | percentage_format }} | {{ accuracy_change | percentage_format }} |
| 平均处理时间 | {{ current_week.processing_time | number_format }}秒 | {{ previous_week.processing_time | number_format }}秒 | {{ processing_time_change | number_format }}秒 |
| 系统可用性 | {{ current_week.availability | percentage_format }} | {{ previous_week.availability | percentage_format }} | {{ availability_change | percentage_format }} |

### 图纸类型周度表现
{% for blueprint_type, data in blueprint_weekly.items() %}
#### {{ blueprint_type | title }}图纸
- 本周准确率: {{ data.current_accuracy | percentage_format }}
- 上周准确率: {{ data.previous_accuracy | percentage_format }}
- 改进幅度: {{ data.improvement | percentage_format }}
- 处理样本: {{ data.sample_count | number_format }}
{% endfor %}

### A/B测试结果
{% if ab_test_results %}
#### 当前进行的A/B测试
{% for test in ab_test_results %}
- **测试名称**: {{ test.name }}
- **测试组A准确率**: {{ test.group_a_accuracy | percentage_format }}
- **测试组B准确率**: {{ test.group_b_accuracy | percentage_format }}
- **统计显著性**: {{ test.significance }}
- **建议**: {{ test.recommendation }}
{% endfor %}
{% else %}
本周无A/B测试进行。
{% endif %}

### 性能优化建议
{% for suggestion in optimization_suggestions %}
- {{ suggestion }}
{% endfor %}

---
*报告生成时间: {{ generation_time }}*
            """,
            
            "monthly": """
# PDF图纸识别性能月报
## {{ month_range }}

### 月度执行摘要
本月PDF图纸识别系统性能表现优异，各项核心指标均超额完成目标。

#### 核心成就
- 月度总识别请求: {{ monthly_requests | number_format }}
- 月度平均准确率: {{ monthly_accuracy | percentage_format }}
- 性能提升幅度: {{ performance_improvement | percentage_format }}
- 成本优化效果: {{ cost_optimization | percentage_format }}

### 月度趋势分析
#### 准确率趋势
{{ accuracy_trend_description }}

#### 处理效率趋势
{{ efficiency_trend_description }}

#### 系统稳定性趋势
{{ stability_trend_description }}

### 图纸类型月度分析
{% for blueprint_type, data in blueprint_monthly.items() %}
#### {{ blueprint_type | title }}图纸
- 月度准确率: {{ data.monthly_accuracy | percentage_format }}
- 月度样本数: {{ data.monthly_samples | number_format }}
- 性能评级: {{ data.performance_grade }}
- 改进建议: {{ data.improvement_suggestion }}
{% endfor %}

### 重大事件回顾
{% for event in major_events %}
#### {{ event.date }}: {{ event.title }}
{{ event.description }}
影响: {{ event.impact }}
处理结果: {{ event.resolution }}
{% endfor %}

### 下月行动计划
{% for action in next_month_actions %}
- **{{ action.title }}**
  - 负责人: {{ action.owner }}
  - 完成时间: {{ action.deadline }}
  - 预期效果: {{ action.expected_impact }}
{% endfor %}

### 成本效益分析
- 本月识别成本: {{ monthly_cost | currency_format }}
- 成本优化幅度: {{ cost_savings | percentage_format }}
- ROI提升: {{ roi_improvement | percentage_format }}

---
*报告生成时间: {{ generation_time }}*
            """
        }
        
        return templates.get(report_type, templates["daily"])
    
    def _prepare_template_data(self, metrics_data: Dict[str, Any], report_type: str) -> Dict[str, Any]:
        """准备模板数据"""
        template_data = {
            'report_date': datetime.now().strftime('%Y-%m-%d'),
            'generation_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'metrics': metrics_data.get('metrics', {}),
            'blueprint_performance': metrics_data.get('blueprint_performance', {}),
            'alerts': metrics_data.get('alerts', []),
            'performance_trends': metrics_data.get('performance_trends', {}),
            'recommendations': metrics_data.get('recommendations', [])
        }
        
        if report_type == "weekly":
            template_data.update({
                'week_range': self._get_week_range(),
                'total_requests': metrics_data.get('total_requests', 0),
                'request_growth': metrics_data.get('request_growth', 0),
                'avg_accuracy': metrics_data.get('avg_accuracy', 0),
                'accuracy_change': metrics_data.get('accuracy_change', 0),
                'system_availability': metrics_data.get('system_availability', 0),
                'efficiency_improvement': metrics_data.get('efficiency_improvement', 0),
                'current_week': metrics_data.get('current_week', {}),
                'previous_week': metrics_data.get('previous_week', {}),
                'processing_time_change': metrics_data.get('processing_time_change', 0),
                'availability_change': metrics_data.get('availability_change', 0),
                'blueprint_weekly': metrics_data.get('blueprint_weekly', {}),
                'ab_test_results': metrics_data.get('ab_test_results', []),
                'optimization_suggestions': metrics_data.get('optimization_suggestions', [])
            })
        
        elif report_type == "monthly":
            template_data.update({
                'month_range': self._get_month_range(),
                'monthly_requests': metrics_data.get('monthly_requests', 0),
                'monthly_accuracy': metrics_data.get('monthly_accuracy', 0),
                'performance_improvement': metrics_data.get('performance_improvement', 0),
                'cost_optimization': metrics_data.get('cost_optimization', 0),
                'accuracy_trend_description': metrics_data.get('accuracy_trend', ''),
                'efficiency_trend_description': metrics_data.get('efficiency_trend', ''),
                'stability_trend_description': metrics_data.get('stability_trend', ''),
                'blueprint_monthly': metrics_data.get('blueprint_monthly', {}),
                'major_events': metrics_data.get('major_events', []),
                'next_month_actions': metrics_data.get('next_month_actions', []),
                'monthly_cost': metrics_data.get('monthly_cost', 0),
                'cost_savings': metrics_data.get('cost_savings', 0),
                'roi_improvement': metrics_data.get('roi_improvement', 0)
            })
        
        return template_data
    
    def _get_week_range(self) -> str:
        """获取本周日期范围"""
        today = datetime.now()
        start_of_week = today - timedelta(days=today.weekday())
        end_of_week = start_of_week + timedelta(days=6)
        return f"{start_of_week.strftime('%Y-%m-%d')} 至 {end_of_week.strftime('%Y-%m-%d')}"
    
    def _get_month_range(self) -> str:
        """获取本月日期范围"""
        today = datetime.now()
        start_of_month = today.replace(day=1)
        if today.month == 12:
            end_of_month = today.replace(year=today.year + 1, month=1, day=1) - timedelta(days=1)
        else:
            end_of_month = today.replace(month=today.month + 1, day=1) - timedelta(days=1)
        return f"{start_of_month.strftime('%Y-%m-%d')} 至 {end_of_month.strftime('%Y-%m-%d')}"
    
    def _create_cover_page(self, pdf, metrics_data: Dict[str, Any]):
        """创建封面页"""
        fig, ax = plt.subplots(figsize=(8.5, 11))
        ax.axis('off')
        
        # 标题
        ax.text(0.5, 0.8, 'PDF图纸识别系统', 
                fontsize=24, fontweight='bold', ha='center', va='center')
        ax.text(0.5, 0.75, '性能监控报告', 
                fontsize=20, ha='center', va='center')
        
        # 报告类型
        report_type = metrics_data.get('report_type', '日报')
        ax.text(0.5, 0.65, f'{report_type}', 
                fontsize=16, ha='center', va='center')
        
        # 报告日期
        report_date = datetime.now().strftime('%Y年%m月%d日')
        ax.text(0.5, 0.55, f'报告日期: {report_date}', 
                fontsize=14, ha='center', va='center')
        
        # 关键指标
        ax.text(0.5, 0.4, '关键指标概览', 
                fontsize=16, fontweight='bold', ha='center', va='center')
        
        key_metrics = [
            f"总识别请求: {metrics_data.get('total_requests', 0):,}",
            f"平均准确率: {metrics_data.get('avg_accuracy', 0):.2%}",
            f"平均处理时间: {metrics_data.get('avg_processing_time', 0):.1f}秒",
            f"系统可用性: {metrics_data.get('system_availability', 0):.2%}"
        ]
        
        for i, metric in enumerate(key_metrics):
            ax.text(0.5, 0.32 - i*0.04, metric, 
                    fontsize=12, ha='center', va='center')
        
        # 页脚
        ax.text(0.5, 0.1, 'Generated by PDF Blueprint Recognition Monitoring System', 
                fontsize=10, ha='center', va='center', style='italic')
        
        pdf.savefig(fig, bbox_inches='tight')
        plt.close()
    
    def _create_executive_summary(self, pdf, metrics_data: Dict[str, Any]):
        """创建执行摘要页"""
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(8.5, 11))
        fig.suptitle('执行摘要', fontsize=16, fontweight='bold')
        
        # 准确率趋势
        accuracy_data = metrics_data.get('accuracy_trend', [])
        if accuracy_data:
            ax1.plot(accuracy_data, marker='o')
            ax1.set_title('准确率趋势')
            ax1.set_ylabel('准确率')
            ax1.grid(True)
        
        # 处理时间分布
        processing_times = metrics_data.get('processing_times', [])
        if processing_times:
            ax2.hist(processing_times, bins=20, alpha=0.7)
            ax2.set_title('处理时间分布')
            ax2.set_xlabel('处理时间(秒)')
            ax2.set_ylabel('频次')
        
        # 图纸类型性能对比
        blueprint_perf = metrics_data.get('blueprint_performance', {})
        if blueprint_perf:
            types = list(blueprint_perf.keys())
            accuracies = [blueprint_perf[t].get('accuracy', 0) for t in types]
            ax3.bar(types, accuracies)
            ax3.set_title('各图纸类型准确率')
            ax3.set_ylabel('准确率')
            ax3.tick_params(axis='x', rotation=45)
        
        # 系统资源使用
        resource_data = metrics_data.get('resource_usage', {})
        if resource_data:
            metrics = list(resource_data.keys())
            values = list(resource_data.values())
            ax4.bar(metrics, values)
            ax4.set_title('系统资源使用率')
            ax4.set_ylabel('使用率(%)')
        
        pdf.savefig(fig, bbox_inches='tight')
        plt.close()
    
    def _create_performance_trends(self, pdf, metrics_data: Dict[str, Any]):
        """创建性能趋势页"""
        fig, axes = plt.subplots(2, 2, figsize=(8.5, 11))
        fig.suptitle('性能趋势分析', fontsize=16, fontweight='bold')
        
        # 准确率与召回率趋势
        trend_data = metrics_data.get('performance_trends', {})
        if 'accuracy' in trend_data and 'recall' in trend_data:
            axes[0,0].plot(trend_data['accuracy'], label='准确率', marker='o')
            axes[0,0].plot(trend_data['recall'], label='召回率', marker='s')
            axes[0,0].set_title('准确率与召回率趋势')
            axes[0,0].legend()
            axes[0,0].grid(True)
        
        # F1-score趋势
        if 'f1_score' in trend_data:
            axes[0,1].plot(trend_data['f1_score'], marker='o', color='green')
            axes[0,1].set_title('F1-score趋势')
            axes[0,1].set_ylabel('F1-score')
            axes[0,1].grid(True)
        
        # 处理时间趋势
        if 'processing_time' in trend_data:
            axes[1,0].plot(trend_data['processing_time'], marker='o', color='red')
            axes[1,0].set_title('处理时间趋势')
            axes[1,0].set_ylabel('处理时间(秒)')
            axes[1,0].grid(True)
        
        # 错误率趋势
        if 'error_rate' in trend_data:
            axes[1,1].plot(trend_data['error_rate'], marker='o', color='orange')
            axes[1,1].set_title('错误率趋势')
            axes[1,1].set_ylabel('错误率')
            axes[1,1].grid(True)
        
        pdf.savefig(fig, bbox_inches='tight')
        plt.close()
    
    def _create_detailed_metrics(self, pdf, metrics_data: Dict[str, Any]):
        """创建详细指标页"""
        fig, ax = plt.subplots(figsize=(8.5, 11))
        ax.axis('off')
        
        # 标题
        ax.text(0.5, 0.95, '详细性能指标', 
                fontsize=16, fontweight='bold', ha='center', va='center')
        
        # 指标表格
        metrics = metrics_data.get('detailed_metrics', {})
        if metrics:
            y_pos = 0.85
            ax.text(0.1, y_pos, '指标名称', fontsize=12, fontweight='bold')
            ax.text(0.4, y_pos, '当前值', fontsize=12, fontweight='bold')
            ax.text(0.6, y_pos, '目标值', fontsize=12, fontweight='bold')
            ax.text(0.8, y_pos, '状态', fontsize=12, fontweight='bold')
            
            y_pos -= 0.05
            for metric_name, metric_data in metrics.items():
                ax.text(0.1, y_pos, metric_name, fontsize=10)
                ax.text(0.4, y_pos, str(metric_data.get('current', 'N/A')), fontsize=10)
                ax.text(0.6, y_pos, str(metric_data.get('target', 'N/A')), fontsize=10)
                ax.text(0.8, y_pos, metric_data.get('status', 'N/A'), fontsize=10)
                y_pos -= 0.04
        
        pdf.savefig(fig, bbox_inches='tight')
        plt.close()
    
    def _create_alerts_summary(self, pdf, metrics_data: Dict[str, Any]):
        """创建告警汇总页"""
        fig, ax = plt.subplots(figsize=(8.5, 11))
        ax.axis('off')
        
        # 标题
        ax.text(0.5, 0.95, '告警事件汇总', 
                fontsize=16, fontweight='bold', ha='center', va='center')
        
        # 告警列表
        alerts = metrics_data.get('alerts', [])
        if alerts:
            y_pos = 0.85
            ax.text(0.1, y_pos, '时间', fontsize=12, fontweight='bold')
            ax.text(0.3, y_pos, '级别', fontsize=12, fontweight='bold')
            ax.text(0.5, y_pos, '告警内容', fontsize=12, fontweight='bold')
            ax.text(0.9, y_pos, '状态', fontsize=12, fontweight='bold')
            
            y_pos -= 0.05
            for alert in alerts:
                ax.text(0.1, y_pos, alert.get('timestamp', ''), fontsize=10)
                ax.text(0.3, y_pos, alert.get('severity', ''), fontsize=10)
                ax.text(0.5, y_pos, alert.get('message', ''), fontsize=10)
                ax.text(0.9, y_pos, alert.get('status', ''), fontsize=10)
                y_pos -= 0.04
        else:
            ax.text(0.5, 0.5, '本期无重要告警事件', 
                    fontsize=14, ha='center', va='center')
        
        pdf.savefig(fig, bbox_inches='tight')
        plt.close()
    
    def _create_recommendations(self, pdf, metrics_data: Dict[str, Any]):
        """创建建议与行动计划页"""
        fig, ax = plt.subplots(figsize=(8.5, 11))
        ax.axis('off')
        
        # 标题
        ax.text(0.5, 0.95, '建议与行动计划', 
                fontsize=16, fontweight='bold', ha='center', va='center')
        
        # 建议列表
        recommendations = metrics_data.get('recommendations', [])
        if recommendations:
            y_pos = 0.85
            ax.text(0.1, y_pos, '序号', fontsize=12, fontweight='bold')
            ax.text(0.2, y_pos, '建议内容', fontsize=12, fontweight='bold')
            
            y_pos -= 0.05
            for i, recommendation in enumerate(recommendations, 1):
                ax.text(0.1, y_pos, f"{i}.", fontsize=10)
                ax.text(0.2, y_pos, recommendation, fontsize=10, wrap=True)
                y_pos -= 0.08
        else:
            ax.text(0.5, 0.5, '暂无特殊建议', 
                    fontsize=14, ha='center', va='center')
        
        pdf.savefig(fig, bbox_inches='tight')
        plt.close()


# Jinja2过滤器
def number_format(value):
    """数字格式化"""
    if isinstance(value, (int, float)):
        return f"{value:,}"
    return str(value)

def percentage_format(value):
    """百分比格式化"""
    if isinstance(value, (int, float)):
        return f"{value:.2%}"
    return str(value)

def currency_format(value):
    """货币格式化"""
    if isinstance(value, (int, float)):
        return f"¥{value:,.2f}"
    return str(value)

# 注册过滤器
Template.globals.update({
    'number_format': number_format,
    'percentage_format': percentage_format,
    'currency_format': currency_format
})


# 使用示例
if __name__ == "__main__":
    # 创建报告生成器
    generator = PerformanceReportGenerator()
    
    # 模拟指标数据
    metrics_data = {
        'report_type': '日报',
        'total_requests': 15420,
        'avg_accuracy': 0.876,
        'avg_processing_time': 23.5,
        'system_availability': 0.998,
        'alert_count': 2,
        'metrics': {
            'accuracy': {'current': '87.6%', 'target': '85%', 'status': '✓'},
            'recall': {'current': '82.3%', 'target': '80%', 'status': '✓'},
            'f1_score': {'current': '84.9%', 'target': '82%', 'status': '✓'},
            'processing_time': {'current': '23.5', 'target': '30', 'status': '✓'}
        },
        'blueprint_performance': {
            'architectural': {
                'accuracy': 0.89,
                'sample_count': 5230,
                'avg_processing_time': 21.2
            },
            'mechanical': {
                'accuracy': 0.85,
                'sample_count': 4890,
                'avg_processing_time': 25.8
            },
            'electrical': {
                'accuracy': 0.91,
                'sample_count': 3120,
                'avg_processing_time': 19.3
            },
            'pid': {
                'accuracy': 0.83,
                'sample_count': 2180,
                'avg_processing_time': 28.7
            }
        },
        'alerts': [
            {
                'timestamp': '2025-11-06 14:23:15',
                'severity': 'warning',
                'message': '机械图纸识别准确率低于阈值',
                'status': '已处理'
            },
            {
                'timestamp': '2025-11-06 16:45:32',
                'severity': 'info',
                'message': '系统维护完成',
                'status': '已关闭'
            }
        ],
        'performance_trends': {
            'accuracy': '本周准确率保持稳定，略高于上周',
            'recall': '召回率有所提升，主要得益于算法优化',
            'f1_score': 'F1-score稳步提升，综合性能良好',
            'processing_time': '处理时间略有增加，需要关注性能优化'
        },
        'recommendations': [
            '继续优化机械图纸识别算法，提高准确率',
            '监控处理时间变化，必要时进行性能调优',
            '加强A/B测试，验证新模型效果',
            '完善监控告警机制，及时发现性能问题'
        ]
    }
    
    # 生成日报
    daily_report = generator.generate_daily_report(
        metrics_data, 
        "reports/daily_report.html"
    )
    print(f"日报已生成: {daily_report}")
    
    # 生成PDF报告
    pdf_report = generator.generate_pdf_report(
        metrics_data,
        "reports/performance_report.pdf"
    )
    print(f"PDF报告已生成: {pdf_report}")