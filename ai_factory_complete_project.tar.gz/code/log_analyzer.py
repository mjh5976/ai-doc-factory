#!/usr/bin/env python3
"""
实时日志分析和告警系统
基于流式处理进行日志分析、异常检测和告警触发
"""

import os
import sys
import time
import json
import logging
import threading
import queue
import statistics
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Callable, Tuple
from dataclasses import dataclass, field, asdict
from collections import defaultdict, deque
from enum import Enum
import yaml
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import redis
import smtplib
from email.mime.text import MimeText
from email.mime.multipart import MimeMultipart
import requests

class AlertLevel(Enum):
    """告警级别"""
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

class AlertStatus(Enum):
    """告警状态"""
    ACTIVE = "ACTIVE"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    RESOLVED = "RESOLVED"
    SUPPRESSED = "SUPPRESSED"

@dataclass
class Alert:
    """告警对象"""
    id: str
    level: AlertLevel
    title: str
    description: str
    service: str
    host: str
    timestamp: datetime
    tags: Dict[str, Any] = field(default_factory=dict)
    metrics: Dict[str, Any] = field(default_factory=dict)
    status: AlertStatus = AlertStatus.ACTIVE
    acknowledged_by: Optional[str] = None
    acknowledged_at: Optional[datetime] = None
    resolved_by: Optional[str] = None
    resolved_at: Optional[datetime] = None
    escalation_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        result = asdict(self)
        result['timestamp'] = self.timestamp.isoformat()
        if self.acknowledged_at:
            result['acknowledged_at'] = self.acknowledged_at.isoformat()
        if self.resolved_at:
            result['resolved_at'] = self.resolved_at.isoformat()
        return result

@dataclass
class LogPattern:
    """日志模式"""
    pattern_id: str
    regex: str
    service: str
    level: str
    frequency_threshold: int
    time_window: int  # 秒
    severity: AlertLevel
    description: str
    last_seen: Optional[datetime] = None
    occurrence_count: int = 0

class LogAnalyzer:
    """日志分析器"""
    
    def __init__(self, config_path: str = "config/analyzer_config.yaml"):
        self.config = self._load_config(config_path)
        self.logger = logging.getLogger(__name__)
        self.redis_client = None
        self.notification_handlers = []
        self.alert_rules = []
        self.patterns = {}
        self.metrics_buffer = defaultdict(lambda: deque(maxlen=1000))
        self.anomaly_detectors = {}
        self.alert_cache = {}
        
        # 初始化Redis连接
        if self.config.get('redis'):
            self.redis_client = redis.Redis(
                host=self.config['redis']['host'],
                port=self.config['redis']['port'],
                decode_responses=True
            )
        
        # 设置通知处理器
        self._setup_notification_handlers()
        
        # 加载告警规则
        self._load_alert_rules()
        
        # 初始化异常检测器
        self._setup_anomaly_detectors()
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载分析器配置"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            self.logger.warning(f"分析器配置文件加载失败: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """默认分析器配置"""
        return {
            'redis': {
                'host': 'localhost',
                'port': 6379
            },
            'analysis': {
                'window_size': 300,  # 5分钟
                'min_samples': 10,
                'anomaly_threshold': 0.1
            },
            'alerting': {
                'dedup_window': 300,  # 5分钟
                'escalation_intervals': [300, 900, 1800],  # 5分钟、15分钟、30分钟
                'max_escalations': 3
            },
            'notifications': {
                'email': {
                    'enabled': False,
                    'smtp_server': 'localhost',
                    'smtp_port': 587,
                    'username': '',
                    'password': '',
                    'from_address': '',
                    'to_addresses': []
                },
                'webhook': {
                    'enabled': False,
                    'url': '',
                    'headers': {}
                },
                'slack': {
                    'enabled': False,
                    'webhook_url': '',
                    'channel': '#alerts'
                }
            },
            'rules': []
        }
    
    def _setup_notification_handlers(self):
        """设置通知处理器"""
        # 邮件通知
        if self.config['notifications']['email']['enabled']:
            self.notification_handlers.append(self._send_email_alert)
        
        # Webhook通知
        if self.config['notifications']['webhook']['enabled']:
            self.notification_handlers.append(self._send_webhook_alert)
        
        # Slack通知
        if self.config['notifications']['slack']['enabled']:
            self.notification_handlers.append(self._send_slack_alert)
        
        # Redis通知
        if self.redis_client:
            self.notification_handlers.append(self._send_redis_alert)
    
    def _load_alert_rules(self):
        """加载告警规则"""
        for rule_config in self.config['rules']:
            try:
                rule = self._create_alert_rule(rule_config)
                self.alert_rules.append(rule)
            except Exception as e:
                self.logger.error(f"加载告警规则失败: {e}")
    
    def _create_alert_rule(self, rule_config: Dict[str, Any]) -> Callable:
        """创建告警规则"""
        rule_type = rule_config.get('type')
        
        if rule_type == 'threshold':
            return self._create_threshold_rule(rule_config)
        elif rule_type == 'pattern':
            return self._create_pattern_rule(rule_config)
        elif rule_type == 'anomaly':
            return self._create_anomaly_rule(rule_config)
        elif rule_type == 'rate':
            return self._create_rate_rule(rule_config)
        else:
            raise ValueError(f"未知的告警规则类型: {rule_type}")
    
    def _create_threshold_rule(self, config: Dict[str, Any]) -> Callable:
        """创建阈值告警规则"""
        metric = config['metric']
        threshold = config['threshold']
        operator = config.get('operator', '>')
        window = config.get('window', 300)
        
        def threshold_rule(log_entry):
            # 检查是否匹配窗口
            if log_entry.timestamp < datetime.now() - timedelta(seconds=window):
                return None
            
            # 检查是否匹配指标
            if metric in log_entry.custom_fields:
                value = float(log_entry.custom_fields[metric])
                
                # 应用操作符
                if operator == '>' and value > threshold:
                    return Alert(
                        id=f"threshold_{metric}_{int(time.time())}",
                        level=AlertLevel.ERROR,
                        title=f"阈值告警: {metric}",
                        description=f"{metric} = {value}, 阈值 = {threshold}",
                        service=log_entry.service,
                        host=log_entry.host,
                        timestamp=log_entry.timestamp,
                        metrics={metric: value, 'threshold': threshold}
                    )
                elif operator == '<' and value < threshold:
                    return Alert(
                        id=f"threshold_{metric}_{int(time.time())}",
                        level=AlertLevel.WARNING,
                        title=f"阈值告警: {metric}",
                        description=f"{metric} = {value}, 阈值 = {threshold}",
                        service=log_entry.service,
                        host=log_entry.host,
                        timestamp=log_entry.timestamp,
                        metrics={metric: value, 'threshold': threshold}
                    )
            return None
        
        return threshold_rule
    
    def _create_pattern_rule(self, config: Dict[str, Any]) -> Callable:
        """创建模式匹配告警规则"""
        import re
        pattern = re.compile(config['pattern'])
        service = config.get('service')
        level = config.get('level')
        frequency = config.get('frequency', 5)
        window = config.get('window', 60)
        
        def pattern_rule(log_entry):
            # 检查服务匹配
            if service and log_entry.service != service:
                return None
            
            # 检查级别匹配
            if level and log_entry.level.value != level:
                return None
            
            # 检查模式匹配
            if pattern.search(log_entry.message):
                # 记录模式匹配
                pattern_key = f"{service}_{level}_{config['pattern']}"
                self.patterns[pattern_key] = self.patterns.get(pattern_key, 0) + 1
                
                # 检查频率阈值
                if self.patterns[pattern_key] >= frequency:
                    # 重置计数器
                    self.patterns[pattern_key] = 0
                    
                    return Alert(
                        id=f"pattern_{pattern_key}_{int(time.time())}",
                        level=AlertLevel.WARNING,
                        title=f"模式匹配告警",
                        description=f"在{window}秒内匹配模式 {config['pattern']} {frequency} 次",
                        service=log_entry.service,
                        host=log_entry.host,
                        timestamp=log_entry.timestamp,
                        tags={'pattern': config['pattern'], 'frequency': frequency}
                    )
            return None
        
        return pattern_rule
    
    def _create_anomaly_rule(self, config: Dict[str, Any]) -> Callable:
        """创建异常检测告警规则"""
        metric = config['metric']
        service = config.get('service')
        sensitivity = config.get('sensitivity', 0.1)
        
        def anomaly_rule(log_entry):
            if service and log_entry.service != service:
                return None
            
            if metric in log_entry.custom_fields:
                value = float(log_entry.custom_fields[metric])
                
                # 添加到指标缓冲区
                buffer_key = f"{service}_{metric}"
                self.metrics_buffer[buffer_key].append(value)
                
                # 检查是否有足够的样本进行异常检测
                if len(self.metrics_buffer[buffer_key]) >= self.config['analysis']['min_samples']:
                    # 使用Z-score检测异常
                    values = list(self.metrics_buffer[buffer_key])
                    mean_val = statistics.mean(values)
                    std_val = statistics.stdev(values) if len(values) > 1 else 1
                    
                    if std_val > 0:
                        z_score = abs((value - mean_val) / std_val)
                        if z_score > (1 / sensitivity):
                            return Alert(
                                id=f"anomaly_{buffer_key}_{int(time.time())}",
                                level=AlertLevel.WARNING,
                                title=f"异常检测告警: {metric}",
                                description=f"{metric} = {value}, Z-score = {z_score:.2f}",
                                service=log_entry.service,
                                host=log_entry.host,
                                metrics={metric: value, 'z_score': z_score, 'mean': mean_val}
                            )
            return None
        
        return anomaly_rule
    
    def _create_rate_rule(self, config: Dict[str, Any]) -> Callable:
        """创建速率告警规则"""
        metric = config['metric']
        threshold = config['threshold']
        window = config.get('window', 60)
        service = config.get('service')
        
        def rate_rule(log_entry):
            if service and log_entry.service != service:
                return None
            
            # 记录指标值
            buffer_key = f"{service}_{metric}"
            self.metrics_buffer[buffer_key].append((log_entry.timestamp, log_entry.custom_fields.get(metric, 0)))
            
            # 计算窗口内的速率
            cutoff_time = datetime.now() - timedelta(seconds=window)
            recent_values = [v for t, v in self.metrics_buffer[buffer_key] if t >= cutoff_time]
            
            if len(recent_values) >= 2:
                # 计算变化率
                rate = (recent_values[-1] - recent_values[0]) / len(recent_values)
                
                if abs(rate) > threshold:
                    return Alert(
                        id=f"rate_{buffer_key}_{int(time.time())}",
                        level=AlertLevel.WARNING,
                        title=f"速率告警: {metric}",
                        description=f"{metric} 变化率 = {rate:.2f}, 阈值 = {threshold}",
                        service=log_entry.service,
                        host=log_entry.host,
                        metrics={metric: rate, 'threshold': threshold}
                    )
            return None
        
        return rate_rule
    
    def _setup_anomaly_detectors(self):
        """设置异常检测器"""
        # 为每个服务设置异常检测器
        for service in ['api', 'database', 'cache', 'web']:
            detector = IsolationForest(contamination=0.1, random_state=42)
            self.anomaly_detectors[service] = detector
    
    def analyze_log(self, log_entry) -> List[Alert]:
        """分析单个日志条目"""
        alerts = []
        
        # 应用所有告警规则
        for rule in self.alert_rules:
            try:
                alert = rule(log_entry)
                if alert:
                    alerts.append(alert)
            except Exception as e:
                self.logger.error(f"告警规则执行失败: {e}")
        
        # 去重和抑制
        alerts = self._deduplicate_alerts(alerts)
        alerts = self._suppress_alerts(alerts)
        
        # 发送通知
        for alert in alerts:
            self._send_alert(alert)
        
        return alerts
    
    def _deduplicate_alerts(self, alerts: List[Alert]) -> List[Alert]:
        """告警去重"""
        deduped_alerts = []
        current_time = datetime.now()
        dedup_window = timedelta(seconds=self.config['alerting']['dedup_window'])
        
        for alert in alerts:
            # 检查是否在去重窗口内已有相似告警
            is_duplicate = False
            for cached_alert in self.alert_cache.values():
                if (cached_alert.title == alert.title and 
                    cached_alert.service == alert.service and
                    current_time - cached_alert.timestamp < dedup_window):
                    is_duplicate = True
                    break
            
            if not is_duplicate:
                deduped_alerts.append(alert)
                # 缓存告警
                self.alert_cache[alert.id] = alert
        
        return deduped_alerts
    
    def _suppress_alerts(self, alerts: List[Alert]) -> List[Alert]:
        """告警抑制"""
        # 简单的抑制逻辑 - 可以根据需要扩展
        suppressed_alerts = []
        
        for alert in alerts:
            # 检查是否应该抑制
            if self._should_suppress_alert(alert):
                alert.status = AlertStatus.SUPPRESSED
            else:
                suppressed_alerts.append(alert)
        
        return suppressed_alerts
    
    def _should_suppress_alert(self, alert: Alert) -> bool:
        """判断是否应该抑制告警"""
        # 检查维护窗口
        maintenance_window = self.config.get('maintenance_window')
        if maintenance_window:
            # 这里可以添加维护窗口检查逻辑
            pass
        
        # 检查依赖关系
        dependency_alerts = self.config.get('dependency_alerts', {})
        if alert.service in dependency_alerts:
            dependent_service = dependency_alerts[alert.service]
            # 如果依赖服务已有告警，抑制当前告警
            if self._has_active_alert_for_service(dependent_service):
                return True
        
        return False
    
    def _has_active_alert_for_service(self, service: str) -> bool:
        """检查服务是否有活跃告警"""
        current_time = datetime.now()
        for alert in self.alert_cache.values():
            if (alert.service == service and 
                alert.status == AlertStatus.ACTIVE and
                current_time - alert.timestamp < timedelta(hours=1)):
                return True
        return False
    
    def _send_alert(self, alert: Alert):
        """发送告警"""
        # 存储告警
        self._store_alert(alert)
        
        # 发送通知
        for handler in self.notification_handlers:
            try:
                handler(alert)
            except Exception as e:
                self.logger.error(f"通知发送失败: {e}")
        
        # 升级检查
        self._check_escalation(alert)
    
    def _store_alert(self, alert: Alert):
        """存储告警"""
        if self.redis_client:
            try:
                alert_key = f"alerts:{alert.id}"
                self.redis_client.hset(alert_key, mapping={
                    'id': alert.id,
                    'level': alert.level.value,
                    'title': alert.title,
                    'service': alert.service,
                    'host': alert.host,
                    'timestamp': alert.timestamp.isoformat(),
                    'status': alert.status.value
                })
                self.redis_client.expire(alert_key, 86400)  # 24小时过期
            except Exception as e:
                self.logger.error(f"告警存储失败: {e}")
    
    def _send_email_alert(self, alert: Alert):
        """发送邮件告警"""
        config = self.config['notifications']['email']
        
        try:
            msg = MimeMultipart()
            msg['From'] = config['from_address']
            msg['To'] = ', '.join(config['to_addresses'])
            msg['Subject'] = f"[{alert.level.value}] {alert.title}"
            
            body = f"""
告警详情:
级别: {alert.level.value}
服务: {alert.service}
主机: {alert.host}
时间: {alert.timestamp}
描述: {alert.description}

请及时处理此告警。
            """
            
            msg.attach(MimeText(body, 'plain', 'utf-8'))
            
            server = smtplib.SMTP(config['smtp_server'], config['smtp_port'])
            server.starttls()
            server.login(config['username'], config['password'])
            server.send_message(msg)
            server.quit()
            
            self.logger.info(f"邮件告警已发送: {alert.id}")
            
        except Exception as e:
            self.logger.error(f"邮件发送失败: {e}")
    
    def _send_webhook_alert(self, alert: Alert):
        """发送Webhook告警"""
        config = self.config['notifications']['webhook']
        
        try:
            payload = {
                'alert': alert.to_dict(),
                'timestamp': datetime.now().isoformat()
            }
            
            response = requests.post(
                config['url'],
                json=payload,
                headers=config['headers'],
                timeout=10
            )
            response.raise_for_status()
            
            self.logger.info(f"Webhook告警已发送: {alert.id}")
            
        except Exception as e:
            self.logger.error(f"Webhook发送失败: {e}")
    
    def _send_slack_alert(self, alert: Alert):
        """发送Slack告警"""
        config = self.config['notifications']['slack']
        
        try:
            color = {
                AlertLevel.INFO: 'good',
                AlertLevel.WARNING: 'warning',
                AlertLevel.ERROR: 'danger',
                AlertLevel.CRITICAL: 'danger'
            }.get(alert.level, 'warning')
            
            payload = {
                'channel': config['channel'],
                'username': 'LogAnalyzer',
                'icon_emoji': ':warning:',
                'attachments': [{
                    'color': color,
                    'title': f"[{alert.level.value}] {alert.title}",
                    'text': alert.description,
                    'fields': [
                        {'title': 'Service', 'value': alert.service, 'short': True},
                        {'title': 'Host', 'value': alert.host, 'short': True},
                        {'title': 'Time', 'value': alert.timestamp.strftime('%Y-%m-%d %H:%M:%S'), 'short': True}
                    ],
                    'footer': 'LogAnalyzer',
                    'ts': int(alert.timestamp.timestamp())
                }]
            }
            
            response = requests.post(
                config['webhook_url'],
                json=payload,
                timeout=10
            )
            response.raise_for_status()
            
            self.logger.info(f"Slack告警已发送: {alert.id}")
            
        except Exception as e:
            self.logger.error(f"Slack发送失败: {e}")
    
    def _send_redis_alert(self, alert: Alert):
        """发送Redis告警"""
        if self.redis_client:
            try:
                # 发布告警到Redis频道
                channel = f"alerts:{alert.level.value.lower()}"
                message = json.dumps(alert.to_dict())
                self.redis_client.publish(channel, message)
                
                self.logger.debug(f"Redis告警已发布: {alert.id}")
                
            except Exception as e:
                self.logger.error(f"Redis发布失败: {e}")
    
    def _check_escalation(self, alert: Alert):
        """检查告警升级"""
        escalation_intervals = self.config['alerting']['escalation_intervals']
        max_escalations = self.config['alerting']['max_escalations']
        
        current_time = datetime.now()
        time_since_creation = current_time - alert.timestamp
        
        # 检查是否需要升级
        for i, interval in enumerate(escalation_intervals):
            if (time_since_creation.total_seconds() >= interval and 
                alert.escalation_count <= i and
                alert.status == AlertStatus.ACTIVE):
                
                alert.escalation_count = i + 1
                self._escalate_alert(alert, i + 1)
    
    def _escalate_alert(self, alert: Alert, escalation_level: int):
        """升级告警"""
        self.logger.warning(f"告警升级: {alert.id}, 级别: {escalation_level}")
        
        # 添加升级标签
        alert.tags['escalation_level'] = escalation_level
        alert.tags['escalated_at'] = datetime.now().isoformat()
        
        # 重新发送通知（使用更高级别的处理器）
        for handler in self.notification_handlers:
            try:
                handler(alert)
            except Exception as e:
                self.logger.error(f"升级通知发送失败: {e}")
    
    def acknowledge_alert(self, alert_id: str, user: str) -> bool:
        """确认告警"""
        if alert_id in self.alert_cache:
            alert = self.alert_cache[alert_id]
            alert.status = AlertStatus.ACKNOWLEDGED
            alert.acknowledged_by = user
            alert.acknowledged_at = datetime.now()
            
            # 更新存储
            self._store_alert(alert)
            
            self.logger.info(f"告警已确认: {alert_id} by {user}")
            return True
        
        return False
    
    def resolve_alert(self, alert_id: str, user: str) -> bool:
        """解决告警"""
        if alert_id in self.alert_cache:
            alert = self.alert_cache[alert_id]
            alert.status = AlertStatus.RESOLVED
            alert.resolved_by = user
            alert.resolved_at = datetime.now()
            
            # 更新存储
            self._store_alert(alert)
            
            self.logger.info(f"告警已解决: {alert_id} by {user}")
            return True
        
        return False
    
    def get_active_alerts(self) -> List[Alert]:
        """获取活跃告警"""
        active_alerts = []
        current_time = datetime.now()
        
        for alert in self.alert_cache.values():
            if (alert.status == AlertStatus.ACTIVE and 
                current_time - alert.timestamp < timedelta(hours=24)):
                active_alerts.append(alert)
        
        return sorted(active_alerts, key=lambda x: x.timestamp, reverse=True)
    
    def get_alert_stats(self) -> Dict[str, Any]:
        """获取告警统计"""
        stats = {
            'total': len(self.alert_cache),
            'active': 0,
            'acknowledged': 0,
            'resolved': 0,
            'by_level': defaultdict(int),
            'by_service': defaultdict(int)
        }
        
        current_time = datetime.now()
        
        for alert in self.alert_cache.values():
            if current_time - alert.timestamp > timedelta(hours=24):
                continue
            
            stats['by_level'][alert.level.value] += 1
            stats['by_service'][alert.service] += 1
            
            if alert.status == AlertStatus.ACTIVE:
                stats['active'] += 1
            elif alert.status == AlertStatus.ACKNOWLEDGED:
                stats['acknowledged'] += 1
            elif alert.status == AlertStatus.RESOLVED:
                stats['resolved'] += 1
        
        return dict(stats)

def main():
    """主函数 - 测试分析器"""
    # 创建分析器
    analyzer = LogAnalyzer()
    
    # 模拟日志条目
    from log_parser import ParsedLogEntry, LogLevel
    
    test_log = ParsedLogEntry(
        timestamp=datetime.now(),
        level=LogLevel.ERROR,
        service='api',
        host='server1',
        message='Database connection failed',
        custom_fields={'response_time': 5000, 'error_rate': 0.15}
    )
    
    # 分析日志
    alerts = analyzer.analyze_log(test_log)
    
    print(f"检测到 {len(alerts)} 个告警:")
    for alert in alerts:
        print(f"- {alert.level.value}: {alert.title}")
    
    # 显示统计信息
    stats = analyzer.get_alert_stats()
    print(f"\n告警统计: {stats}")

if __name__ == "__main__":
    main()
