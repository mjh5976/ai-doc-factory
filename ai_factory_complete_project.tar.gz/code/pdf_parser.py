#!/usr/bin/env python3
"""
PDF解析和内容提取模块
支持矢量图形、文本和图像的提取
"""

import os
import sys
import logging
import json
import traceback
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, asdict
from pathlib import Path
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import threading
import time
from abc import ABC, abstractmethod

import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFont
import fitz  # PyMuPDF
import pytesseract
from paddleocr import PaddleOCR
import easyocr
import torch
import torchvision.transforms as transforms
from torchvision.models import resnet50
import torch.nn.functional as F

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@dataclass
class BoundingBox:
    """边界框数据类"""
    x: float
    y: float
    width: float
    height: float
    
    def to_dict(self):
        return asdict(self)
    
    def area(self):
        return self.width * self.height
    
    def intersects(self, other: 'BoundingBox') -> bool:
        """检查两个边界框是否相交"""
        return not (self.x + self.width < other.x or 
                   other.x + other.width < self.x or
                   self.y + self.height < other.y or 
                   other.y + other.height < self.y)


@dataclass
class TextElement:
    """文本元素数据类"""
    text: str
    bbox: BoundingBox
    confidence: float
    font_size: float
    font_name: str
    color: Tuple[int, int, int] = (0, 0, 0)
    ocr_engine: str = "unknown"
    
    def to_dict(self):
        return {
            'text': self.text,
            'bbox': self.bbox.to_dict(),
            'confidence': self.confidence,
            'font_size': self.font_size,
            'font_name': self.font_name,
            'color': self.color,
            'ocr_engine': self.ocr_engine
        }


@dataclass
class VectorElement:
    """矢量元素数据类"""
    element_type: str  # line, rectangle, circle, path, text
    points: List[Tuple[float, float]]
    bbox: BoundingBox
    stroke_color: Tuple[int, int, int] = (0, 0, 0)
    fill_color: Optional[Tuple[int, int, int]] = None
    stroke_width: float = 1.0
    layer: str = "default"
    
    def to_dict(self):
        return {
            'element_type': self.element_type,
            'points': self.points,
            'bbox': self.bbox.to_dict(),
            'stroke_color': self.stroke_color,
            'fill_color': self.fill_color,
            'stroke_width': self.stroke_width,
            'layer': self.layer
        }


@dataclass
class ImageElement:
    """图像元素数据类"""
    bbox: BoundingBox
    image_data: bytes
    image_format: str = "PNG"
    resolution: Tuple[int, int] = (0, 0)
    
    def to_dict(self):
        return {
            'bbox': self.bbox.to_dict(),
            'image_format': self.image_format,
            'resolution': self.resolution,
            'image_size': len(self.image_data)
        }


@dataclass
class PageData:
    """页面数据类"""
    page_number: int
    width: float
    height: float
    text_elements: List[TextElement]
    vector_elements: List[VectorElement]
    image_elements: List[ImageElement]
    metadata: Dict[str, Any]
    
    def to_dict(self):
        return {
            'page_number': self.page_number,
            'width': self.width,
            'height': self.height,
            'text_elements': [elem.to_dict() for elem in self.text_elements],
            'vector_elements': [elem.to_dict() for elem in self.vector_elements],
            'image_elements': [elem.to_dict() for elem in self.image_elements],
            'metadata': self.metadata
        }


class PDFParsingError(Exception):
    """PDF解析错误"""
    pass


class ImageProcessingError(Exception):
    """图像处理错误"""
    pass


class OCREngine(ABC):
    """OCR引擎抽象基类"""
    
    @abstractmethod
    def extract_text(self, image: np.ndarray, bbox: Optional[BoundingBox] = None) -> List[TextElement]:
        """从图像中提取文本"""
        pass


class TesseractOCR(OCREngine):
    """Tesseract OCR引擎"""
    
    def __init__(self, language='eng', config='--oem 3 --psm 6'):
        self.language = language
        self.config = config
        logger.info(f"初始化Tesseract OCR引擎，语言：{language}")
    
    def extract_text(self, image: np.ndarray, bbox: Optional[BoundingBox] = None) -> List[TextElement]:
        """使用Tesseract提取文本"""
        try:
            # 如果有边界框，裁剪图像
            if bbox:
                x, y, w, h = int(bbox.x), int(bbox.y), int(bbox.width), int(bbox.height)
                cropped_image = image[y:y+h, x:x+w]
            else:
                cropped_image = image
            
            # 使用pytesseract提取文本
            data = pytesseract.image_to_data(cropped_image, config=self.config, output_type=pytesseract.Output.DICT)
            
            text_elements = []
            n_boxes = len(data['level'])
            
            for i in range(n_boxes):
                confidence = int(data['conf'][i])
                if confidence > 30:  # 置信度阈值
                    text = data['text'][i].strip()
                    if text:
                        x = data['left'][i]
                        y = data['top'][i]
                        w = data['width'][i]
                        h = data['height'][i]
                        
                        if bbox:
                            x += bbox.x
                            y += bbox.y
                        
                        bbox_obj = BoundingBox(x, y, w, h)
                        text_element = TextElement(
                            text=text,
                            bbox=bbox_obj,
                            confidence=confidence / 100.0,
                            font_size=h,
                            font_name="unknown",
                            ocr_engine="tesseract"
                        )
                        text_elements.append(text_element)
            
            logger.info(f"Tesseract提取到 {len(text_elements)} 个文本元素")
            return text_elements
            
        except Exception as e:
            logger.error(f"Tesseract OCR错误: {e}")
            raise OCREngineError(f"Tesseract OCR失败: {e}")


class PaddleOCREngine(OCREngine):
    """PaddleOCR引擎"""
    
    def __init__(self, use_angle_cls=True, lang='en'):
        self.use_angle_cls = use_angle_cls
        self.lang = lang
        self.ocr = PaddleOCR(use_angle_cls=use_angle_cls, lang=lang, show_log=False)
        logger.info(f"初始化PaddleOCR引擎，语言：{lang}")
    
    def extract_text(self, image: np.ndarray, bbox: Optional[BoundingBox] = None) -> List[TextElement]:
        """使用PaddleOCR提取文本"""
        try:
            # 如果有边界框，裁剪图像
            if bbox:
                x, y, w, h = int(bbox.x), int(bbox.y), int(bbox.width), int(bbox.height)
                cropped_image = image[y:y+h, x:x+w]
            else:
                cropped_image = image
            
            # 使用PaddleOCR提取文本
            result = self.ocr.ocr(cropped_image, cls=True)
            
            text_elements = []
            if result and result[0]:
                for line in result[0]:
                    if line:
                        bbox_coords = line[0]
                        text = line[1][0]
                        confidence = line[1][1]
                        
                        # 计算边界框
                        x_coords = [point[0] for point in bbox_coords]
                        y_coords = [point[1] for point in bbox_coords]
                        x = min(x_coords)
                        y = min(y_coords)
                        w = max(x_coords) - x
                        h = max(y_coords) - y
                        
                        if bbox:
                            x += bbox.x
                            y += bbox.y
                        
                        bbox_obj = BoundingBox(x, y, w, h)
                        text_element = TextElement(
                            text=text,
                            bbox=bbox_obj,
                            confidence=confidence,
                            font_size=h,
                            font_name="unknown",
                            ocr_engine="paddleocr"
                        )
                        text_elements.append(text_element)
            
            logger.info(f"PaddleOCR提取到 {len(text_elements)} 个文本元素")
            return text_elements
            
        except Exception as e:
            logger.error(f"PaddleOCR错误: {e}")
            raise OCREngineError(f"PaddleOCR失败: {e}")


class EasyOCROptimized(OCREngine):
    """优化的EasyOCR引擎"""
    
    def __init__(self, languages=['en'], gpu=True):
        self.languages = languages
        self.gpu = gpu
        self.reader = easyocr.Reader(languages, gpu=gpu)
        logger.info(f"初始化EasyOCR引擎，语言：{languages}，GPU：{gpu}")
    
    def extract_text(self, image: np.ndarray, bbox: Optional[BoundingBox] = None) -> List[TextElement]:
        """使用EasyOCR提取文本"""
        try:
            # 如果有边界框，裁剪图像
            if bbox:
                x, y, w, h = int(bbox.x), int(bbox.y), int(bbox.width), int(bbox.height)
                cropped_image = image[y:y+h, x:x+w]
            else:
                cropped_image = image
            
            # 使用EasyOCR提取文本
            result = self.reader.readtext(cropped_image)
            
            text_elements = []
            for (bbox_coords, text, confidence) in result:
                if confidence > 0.3:  # 置信度阈值
                    # 计算边界框
                    x_coords = [point[0] for point in bbox_coords]
                    y_coords = [point[1] for point in bbox_coords]
                    x = min(x_coords)
                    y = min(y_coords)
                    w = max(x_coords) - x
                    h = max(y_coords) - y
                    
                    if bbox:
                        x += bbox.x
                        y += bbox.y
                    
                    bbox_obj = BoundingBox(x, y, w, h)
                    text_element = TextElement(
                        text=text,
                        bbox=bbox_obj,
                        confidence=confidence,
                        font_size=h,
                        font_name="unknown",
                        ocr_engine="easyocr"
                    )
                    text_elements.append(text_element)
            
            logger.info(f"EasyOCR提取到 {len(text_elements)} 个文本元素")
            return text_elements
            
        except Exception as e:
            logger.error(f"EasyOCR错误: {e}")
            raise OCREngineError(f"EasyOCR失败: {e}")


class OCREngineError(Exception):
    """OCR引擎错误"""
    pass


class PDFParser:
    """PDF解析器主类"""
    
    def __init__(self, 
                 ocr_engines: Optional[List[OCREngine]] = None,
                 max_workers: int = 4,
                 enable_image_extraction: bool = True,
                 enable_vector_extraction: bool = True):
        """
        初始化PDF解析器
        
        Args:
            ocr_engines: OCR引擎列表
            max_workers: 最大工作线程数
            enable_image_extraction: 是否启用图像提取
            enable_vector_extraction: 是否启用矢量提取
        """
        self.max_workers = max_workers
        self.enable_image_extraction = enable_image_extraction
        self.enable_vector_extraction = enable_vector_extraction
        
        # 初始化OCR引擎
        if ocr_engines is None:
            self.ocr_engines = [
                TesseractOCR(language='eng'),
                PaddleOCREngine(lang='en'),
                EasyOCROptimized(languages=['en'])
            ]
        else:
            self.ocr_engines = ocr_engines
        
        logger.info(f"PDF解析器初始化完成，OCR引擎数量：{len(self.ocr_engines)}")
    
    def parse_pdf(self, pdf_path: Union[str, Path]) -> List[PageData]:
        """
        解析PDF文件
        
        Args:
            pdf_path: PDF文件路径
            
        Returns:
            List[PageData]: 页面数据列表
        """
        pdf_path = Path(pdf_path)
        if not pdf_path.exists():
            raise FileNotFoundError(f"PDF文件不存在: {pdf_path}")
        
        try:
            # 打开PDF文档
            doc = fitz.open(str(pdf_path))
            logger.info(f"打开PDF文档，页数：{len(doc)}")
            
            # 并行处理页面
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = []
                for page_num in range(len(doc)):
                    future = executor.submit(self._parse_page, doc, page_num)
                    futures.append(future)
                
                # 收集结果
                page_data_list = []
                for future in concurrent.futures.as_completed(futures):
                    try:
                        page_data = future.result()
                        page_data_list.append(page_data)
                    except Exception as e:
                        logger.error(f"页面解析错误: {e}")
                        logger.error(traceback.format_exc())
            
            # 按页码排序
            page_data_list.sort(key=lambda x: x.page_number)
            doc.close()
            
            logger.info(f"PDF解析完成，共处理 {len(page_data_list)} 页")
            return page_data_list
            
        except Exception as e:
            logger.error(f"PDF解析错误: {e}")
            logger.error(traceback.format_exc())
            raise PDFParsingError(f"PDF解析失败: {e}")
    
    def _parse_page(self, doc: fitz.Document, page_num: int) -> PageData:
        """解析单个页面"""
        try:
            page = doc.load_page(page_num)
            
            # 获取页面基本信息
            width = page.rect.width
            height = page.rect.height
            
            logger.info(f"解析页面 {page_num + 1}，尺寸：{width}x{height}")
            
            # 提取文本元素
            text_elements = self._extract_text_elements(page)
            
            # 提取矢量元素
            vector_elements = []
            if self.enable_vector_extraction:
                vector_elements = self._extract_vector_elements(page)
            
            # 提取图像元素
            image_elements = []
            if self.enable_image_extraction:
                image_elements = self._extract_image_elements(page)
            
            # 获取页面元数据
            metadata = self._extract_page_metadata(page)
            
            page_data = PageData(
                page_number=page_num,
                width=width,
                height=height,
                text_elements=text_elements,
                vector_elements=vector_elements,
                image_elements=image_elements,
                metadata=metadata
            )
            
            logger.info(f"页面 {page_num + 1} 解析完成："
                       f"文本元素 {len(text_elements)}，"
                       f"矢量元素 {len(vector_elements)}，"
                       f"图像元素 {len(image_elements)}")
            
            return page_data
            
        except Exception as e:
            logger.error(f"页面 {page_num} 解析错误: {e}")
            logger.error(traceback.format_exc())
            raise PDFParsingError(f"页面 {page_num} 解析失败: {e}")
    
    def _extract_text_elements(self, page: fitz.Page) -> List[TextElement]:
        """提取文本元素"""
        text_elements = []
        
        try:
            # 获取文本字典
            text_dict = page.get_text("dict")
            
            for block in text_dict.get("blocks", []):
                if "lines" in block:
                    for line in block["lines"]:
                        for span in line.get("spans", []):
                            text = span.get("text", "").strip()
                            if text:
                                bbox_data = span.get("bbox", [0, 0, 0, 0])
                                bbox = BoundingBox(
                                    x=bbox_data[0],
                                    y=bbox_data[1],
                                    width=bbox_data[2] - bbox_data[0],
                                    height=bbox_data[3] - bbox_data[1]
                                )
                                
                                text_element = TextElement(
                                    text=text,
                                    bbox=bbox,
                                    confidence=1.0,
                                    font_size=span.get("size", 12),
                                    font_name=span.get("font", "unknown"),
                                    color=(0, 0, 0),
                                    ocr_engine="pdf_native"
                                )
                                text_elements.append(text_element)
            
            # 如果原生文本提取结果较少，使用OCR补充
            if len(text_elements) < 5:
                logger.info("原生文本提取结果较少，使用OCR补充")
                text_elements.extend(self._ocr_text_extraction(page))
            
        except Exception as e:
            logger.error(f"文本提取错误: {e}")
            logger.error(traceback.format_exc())
        
        return text_elements
    
    def _ocr_text_extraction(self, page: fitz.Page) -> List[TextElement]:
        """使用OCR提取文本"""
        text_elements = []
        
        try:
            # 将页面转换为图像
            mat = fitz.Matrix(2.0, 2.0)  # 2倍缩放以提高OCR精度
            pix = page.get_pixmap(matrix=mat)
            img_data = pix.tobytes("png")
            
            # 转换为OpenCV格式
            nparr = np.frombuffer(img_data, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # 使用多个OCR引擎
            for ocr_engine in self.ocr_engines:
                try:
                    ocr_results = ocr_engine.extract_text(image)
                    
                    # 调整坐标（因为我们使用了2倍缩放）
                    for text_element in ocr_results:
                        text_element.bbox.x /= 2.0
                        text_element.bbox.y /= 2.0
                        text_element.bbox.width /= 2.0
                        text_element.bbox.height /= 2.0
                    
                    text_elements.extend(ocr_results)
                    
                except Exception as e:
                    logger.warning(f"OCR引擎 {ocr_engine.__class__.__name__} 失败: {e}")
                    continue
            
            # 去重（基于边界框重叠）
            text_elements = self._deduplicate_text_elements(text_elements)
            
        except Exception as e:
            logger.error(f"OCR文本提取错误: {e}")
            logger.error(traceback.format_exc())
        
        return text_elements
    
    def _deduplicate_text_elements(self, text_elements: List[TextElement]) -> List[TextElement]:
        """去重文本元素（基于边界框重叠）"""
        if not text_elements:
            return text_elements
        
        # 按置信度排序
        sorted_elements = sorted(text_elements, key=lambda x: x.confidence, reverse=True)
        deduplicated = []
        
        for element in sorted_elements:
            is_duplicate = False
            for existing in deduplicated:
                if self._bbox_overlap_ratio(element.bbox, existing.bbox) > 0.5:
                    is_duplicate = True
                    break
            
            if not is_duplicate:
                deduplicated.append(element)
        
        return deduplicated
    
    def _bbox_overlap_ratio(self, bbox1: BoundingBox, bbox2: BoundingBox) -> float:
        """计算两个边界框的重叠比例"""
        if not bbox1.intersects(bbox2):
            return 0.0
        
        # 计算交集
        intersection_x = max(0, min(bbox1.x + bbox1.width, bbox2.x + bbox2.width) - max(bbox1.x, bbox2.x))
        intersection_y = max(0, min(bbox1.y + bbox1.height, bbox2.y + bbox2.height) - max(bbox1.y, bbox2.y))
        intersection_area = intersection_x * intersection_y
        
        # 计算并集
        union_area = bbox1.area() + bbox2.area() - intersection_area
        
        return intersection_area / union_area if union_area > 0 else 0.0
    
    def _extract_vector_elements(self, page: fitz.Page) -> List[VectorElement]:
        """提取矢量元素"""
        vector_elements = []
        
        try:
            # 获取绘图命令
            paths = page.get_drawings()
            
            for path in paths:
                try:
                    # 提取路径信息
                    element_type = "path"
                    points = []
                    stroke_color = (0, 0, 0)
                    fill_color = None
                    stroke_width = path.get("width", 1.0)
                    
                    # 提取颜色信息
                    if "color" in path:
                        stroke_color = self._pdf_color_to_rgb(path["color"])
                    
                    if "fill" in path and path["fill"]:
                        fill_color = self._pdf_color_to_rgb(path["fill"])
                    
                    # 提取点信息
                    for item in path.get("items", []):
                        if item[0] == "l":  # line
                            points.append((item[1].x, item[1].y))
                        elif item[0] == "c":  # curve
                            points.append((item[1].x, item[1].y))
                            points.append((item[2].x, item[2].y))
                            points.append((item[3].x, item[3].y))
                    
                    if points:
                        # 计算边界框
                        x_coords = [p[0] for p in points]
                        y_coords = [p[1] for p in points]
                        bbox = BoundingBox(
                            x=min(x_coords),
                            y=min(y_coords),
                            width=max(x_coords) - min(x_coords),
                            height=max(y_coords) - min(y_coords)
                        )
                        
                        vector_element = VectorElement(
                            element_type=element_type,
                            points=points,
                            bbox=bbox,
                            stroke_color=stroke_color,
                            fill_color=fill_color,
                            stroke_width=stroke_width
                        )
                        vector_elements.append(vector_element)
                
                except Exception as e:
                    logger.warning(f"路径解析错误: {e}")
                    continue
            
        except Exception as e:
            logger.error(f"矢量元素提取错误: {e}")
            logger.error(traceback.format_exc())
        
        return vector_elements
    
    def _extract_image_elements(self, page: fitz.Page) -> List[ImageElement]:
        """提取图像元素"""
        image_elements = []
        
        try:
            # 获取图像列表
            image_list = page.get_images()
            
            for img_index, img in enumerate(image_list):
                try:
                    # 获取图像数据
                    xref = img[0]
                    base_image = page.parent.extract_image(xref)
                    image_bytes = base_image["image"]
                    
                    # 获取图像位置信息
                    img_rect = fitz.Rect(img[1:])  # xref, x0, y0, x1, y1
                    bbox = BoundingBox(
                        x=img_rect.x0,
                        y=img_rect.y0,
                        width=img_rect.width,
                        height=img_rect.height
                    )
                    
                    # 获取图像格式
                    image_format = base_image.get("ext", "png")
                    
                    image_element = ImageElement(
                        bbox=bbox,
                        image_data=image_bytes,
                        image_format=image_format,
                        resolution=(int(img_rect.width), int(img_rect.height))
                    )
                    image_elements.append(image_element)
                
                except Exception as e:
                    logger.warning(f"图像 {img_index} 提取错误: {e}")
                    continue
            
        except Exception as e:
            logger.error(f"图像元素提取错误: {e}")
            logger.error(traceback.format_exc())
        
        return image_elements
    
    def _extract_page_metadata(self, page: fitz.Page) -> Dict[str, Any]:
        """提取页面元数据"""
        metadata = {}
        
        try:
            # 页面属性
            metadata["rotation"] = page.rotation
            metadata["mediabox"] = list(page.mediabox)
            metadata["cropbox"] = list(page.cropbox)
            
            # 文本统计
            text_dict = page.get_text("dict")
            total_chars = 0
            for block in text_dict.get("blocks", []):
                if "lines" in block:
                    for line in block["lines"]:
                        for span in line.get("spans", []):
                            total_chars += len(span.get("text", ""))
            
            metadata["total_characters"] = total_chars
            metadata["text_blocks"] = len(text_dict.get("blocks", []))
            
            # 图像统计
            metadata["image_count"] = len(page.get_images())
            
            # 矢量统计
            metadata["path_count"] = len(page.get_drawings())
            
        except Exception as e:
            logger.warning(f"元数据提取错误: {e}")
        
        return metadata
    
    def _pdf_color_to_rgb(self, color) -> Tuple[int, int, int]:
        """将PDF颜色转换为RGB"""
        try:
            if isinstance(color, (list, tuple)) and len(color) >= 3:
                # 假设是RGB值，范围0-1
                r, g, b = color[:3]
                return (int(r * 255), int(g * 255), int(b * 255))
            elif isinstance(color, str):
                # 解析颜色字符串
                if color.startswith("#"):
                    hex_color = color[1:]
                    if len(hex_color) == 6:
                        r = int(hex_color[0:2], 16)
                        g = int(hex_color[2:4], 16)
                        b = int(hex_color[4:6], 16)
                        return (r, g, b)
        except:
            pass
        
        return (0, 0, 0)  # 默认黑色


def setup_matplotlib_for_plotting():
    """
    Setup matplotlib and seaborn for plotting with proper configuration.
    Call this function before creating any plots to ensure proper rendering.
    """
    import warnings
    import matplotlib.pyplot as plt
    import seaborn as sns

    # Ensure warnings are printed
    warnings.filterwarnings('default')  # Show all warnings

    # Configure matplotlib for non-interactive mode
    plt.switch_backend("Agg")

    # Set chart style
    plt.style.use("seaborn-v0_8")
    sns.set_palette("husl")

    # Configure platform-appropriate fonts for cross-platform compatibility
    # Must be set after style.use, otherwise will be overridden by style configuration
    plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC", "WenQuanYi Zen Hei", "PingFang SC", "Arial Unicode MS", "Hiragino Sans GB"]
    plt.rcParams["axes.unicode_minus"] = False


# 使用示例
if __name__ == "__main__":
    # 创建解析器
    parser = PDFParser(
        max_workers=4,
        enable_image_extraction=True,
        enable_vector_extraction=True
    )
    
    # 解析PDF文件
    try:
        pdf_path = "example.pdf"
        if os.path.exists(pdf_path):
            page_data_list = parser.parse_pdf(pdf_path)
            
            # 输出结果
            for page_data in page_data_list:
                print(f"页面 {page_data.page_number + 1}:")
                print(f"  文本元素: {len(page_data.text_elements)}")
                print(f"  矢量元素: {len(page_data.vector_elements)}")
                print(f"  图像元素: {len(page_data.image_elements)}")
                
                # 保存为JSON
                output_file = f"page_{page_data.page_number + 1}_data.json"
                with open(output_file, 'w', encoding='utf-8') as f:
                    json.dump(page_data.to_dict(), f, ensure_ascii=False, indent=2)
                print(f"  保存到: {output_file}")
        else:
            print(f"PDF文件不存在: {pdf_path}")
    
    except Exception as e:
        logger.error(f"解析失败: {e}")
        logger.error(traceback.format_exc())
