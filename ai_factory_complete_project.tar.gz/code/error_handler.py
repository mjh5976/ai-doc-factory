#!/usr/bin/env python3
"""
错误处理和异常恢复模块
提供全面的错误处理和异常恢复机制
"""

import os
import sys
import logging
import json
import traceback
import time
import threading
import pickle
import hashlib
from typing import Dict, List, Tuple, Optional, Any, Union, Callable
from dataclasses import dataclass, asdict, field
from pathlib import Path
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
import psutil
import numpy as np
import cv2

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@dataclass
class ErrorInfo:
    """错误信息数据类"""
    error_id: str
    error_type: str
    error_message: str
    stack_trace: str
    context: Dict[str, Any]
    timestamp: datetime = field(default_factory=datetime.now)
    severity: str = "ERROR"  # DEBUG, INFO, WARNING, ERROR, CRITICAL
    source_module: str = ""
    source_function: str = ""
    line_number: int = 0
    
    def to_dict(self):
        return {
            'error_id': self.error_id,
            'error_type': self.error_type,
            'error_message': self.error_message,
            'stack_trace': self.stack_trace,
            'context': self.context,
            'timestamp': self.timestamp.isoformat(),
            'severity': self.severity,
            'source_module': self.source_module,
            'source_function': self.source_function,
            'line_number': self.line_number
        }


@dataclass
class RecoveryStrategy:
    """恢复策略数据类"""
    strategy_id: str
    strategy_type: str  # 'retry', 'fallback', 'skip', 'compensate'
    max_attempts: int = 3
    delay_seconds: float = 1.0
    backoff_factor: float = 2.0
    conditions: Dict[str, Any] = field(default_factory=dict)
    fallback_function: Optional[Callable] = None
    compensation_function: Optional[Callable] = None
    
    def to_dict(self):
        return {
            'strategy_id': self.strategy_id,
            'strategy_type': self.strategy_type,
            'max_attempts': self.max_attempts,
            'delay_seconds': self.delay_seconds,
            'backoff_factor': self.backoff_factor,
            'conditions': self.conditions
        }


@dataclass
class ErrorPattern:
    """错误模式数据类"""
    pattern_id: str
    pattern_name: str
    error_types: List[str]
    error_patterns: List[str]  # 正则表达式模式
    frequency_threshold: int = 1
    severity_threshold: str = "ERROR"
    auto_recovery: bool = True
    recovery_strategy: str = ""
    
    def to_dict(self):
        return asdict(self)


@dataclass
class SystemHealth:
    """系统健康状态"""
    timestamp: datetime = field(default_factory=datetime.now)
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    disk_usage: float = 0.0
    error_rate: float = 0.0
    throughput: float = 0.0
    active_connections: int = 0
    queue_size: int = 0
    
    def to_dict(self):
        return {
            'timestamp': self.timestamp.isoformat(),
            'cpu_usage': self.cpu_usage,
            'memory_usage': self.memory_usage,
            'disk_usage': self.disk_usage,
            'error_rate': self.error_rate,
            'throughput': self.throughput,
            'active_connections': self.active_connections,
            'queue_size': self.queue_size
        }


class ErrorHandler:
    """错误处理器"""
    
    def __init__(self, max_error_history: int = 10000):
        """
        初始化错误处理器
        
        Args:
            max_error_history: 最大错误历史记录数
        """
        self.max_error_history = max_error_history
        self.error_history = []
        self.error_patterns = []
        self.recovery_strategies = {}
        self.error_lock = threading.Lock()
        self.error_callbacks = []
        
        # 加载默认错误模式
        self._load_default_patterns()
        
        logger.info(f"错误处理器初始化完成，最大历史记录：{max_error_history}")
    
    def handle_error(self, error: Exception, context: Dict[str, Any] = None, 
                    severity: str = "ERROR") -> ErrorInfo:
        """
        处理错误
        
        Args:
            error: 异常对象
            context: 错误上下文
            severity: 严重程度
            
        Returns:
            ErrorInfo: 错误信息
        """
        try:
            # 生成错误ID
            error_id = self._generate_error_id(error, context)
            
            # 创建错误信息
            error_info = ErrorInfo(
                error_id=error_id,
                error_type=type(error).__name__,
                error_message=str(error),
                stack_trace=traceback.format_exc(),
                context=context or {},
                severity=severity,
                source_module=error.__class__.__module__,
                source_function=self._get_function_name(error),
                line_number=self._get_line_number(error)
            )
            
            # 记录错误
            self._log_error(error_info)
            
            # 检查错误模式
            self._check_error_patterns(error_info)
            
            # 触发错误回调
            self._trigger_error_callbacks(error_info)
            
            return error_info
            
        except Exception as e:
            logger.error(f"错误处理器自身错误: {e}")
            # 返回基本错误信息
            return ErrorInfo(
                error_id="handler_error",
                error_type="ErrorHandlerError",
                error_message=str(e),
                stack_trace=traceback.format_exc(),
                context={'original_error': str(error)},
                severity="CRITICAL"
            )
    
    def register_error_callback(self, callback: Callable[[ErrorInfo], None]):
        """注册错误回调函数"""
        with self.error_lock:
            self.error_callbacks.append(callback)
    
    def add_recovery_strategy(self, strategy: RecoveryStrategy):
        """添加恢复策略"""
        with self.error_lock:
            self.recovery_strategies[strategy.strategy_id] = strategy
        logger.info(f"添加恢复策略: {strategy.strategy_id}")
    
    def get_error_statistics(self, time_window: Optional[timedelta] = None) -> Dict[str, Any]:
        """获取错误统计"""
        with self.error_lock:
            if time_window:
                cutoff_time = datetime.now() - time_window
                filtered_errors = [e for e in self.error_history if e.timestamp > cutoff_time]
            else:
                filtered_errors = self.error_history
            
            # 统计信息
            total_errors = len(filtered_errors)
            error_types = {}
            severity_counts = {}
            module_counts = {}
            
            for error in filtered_errors:
                # 错误类型统计
                error_types[error.error_type] = error_types.get(error.error_type, 0) + 1
                
                # 严重程度统计
                severity_counts[error.severity] = severity_counts.get(error.severity, 0) + 1
                
                # 模块统计
                module_counts[error.source_module] = module_counts.get(error.source_module, 0) + 1
            
            return {
                'total_errors': total_errors,
                'error_types': error_types,
                'severity_counts': severity_counts,
                'module_counts': module_counts,
                'time_window': str(time_window) if time_window else 'all'
            }
    
    def _generate_error_id(self, error: Exception, context: Dict[str, Any]) -> str:
        """生成错误ID"""
        try:
            # 基于错误类型、消息和上下文生成哈希
            error_data = f"{type(error).__name__}:{str(error)}:{json.dumps(context or {}, sort_keys=True)}"
            return hashlib.md5(error_data.encode()).hexdigest()[:12]
        except:
            return f"err_{int(time.time())}"
    
    def _get_function_name(self, error: Exception) -> str:
        """获取函数名"""
        try:
            tb = error.__traceback__
            if tb:
                return tb.tb_frame.f_code.co_name
        except:
            pass
        return "unknown"
    
    def _get_line_number(self, error: Exception) -> int:
        """获取行号"""
        try:
            tb = error.__traceback__
            if tb:
                return tb.tb_lineno
        except:
            pass
        return 0
    
    def _log_error(self, error_info: ErrorInfo):
        """记录错误"""
        with self.error_lock:
            # 添加到历史记录
            self.error_history.append(error_info)
            
            # 限制历史记录数量
            if len(self.error_history) > self.max_error_history:
                self.error_history = self.error_history[-self.max_error_history:]
            
            # 记录到日志
            log_message = f"[{error_info.error_id}] {error_info.error_type}: {error_info.error_message}"
            if error_info.context:
                log_message += f" | Context: {error_info.context}"
            
            if error_info.severity == "CRITICAL":
                logger.critical(log_message)
            elif error_info.severity == "ERROR":
                logger.error(log_message)
            elif error_info.severity == "WARNING":
                logger.warning(log_message)
            else:
                logger.info(log_message)
    
    def _check_error_patterns(self, error_info: ErrorInfo):
        """检查错误模式"""
        try:
            for pattern in self.error_patterns:
                if self._matches_pattern(error_info, pattern):
                    logger.warning(f"检测到错误模式: {pattern.pattern_name}")
                    
                    # 如果启用了自动恢复
                    if pattern.auto_recovery and pattern.recovery_strategy:
                        self._trigger_recovery(pattern.recovery_strategy, error_info)
        except Exception as e:
            logger.error(f"错误模式检查错误: {e}")
    
    def _matches_pattern(self, error_info: ErrorInfo, pattern: ErrorPattern) -> bool:
        """检查是否匹配错误模式"""
        try:
            # 检查错误类型
            if pattern.error_types and error_info.error_type not in pattern.error_types:
                return False
            
            # 检查严重程度
            severity_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
            if severity_levels.index(error_info.severity) < severity_levels.index(pattern.severity_threshold):
                return False
            
            # 检查错误模式
            for error_pattern in pattern.error_patterns:
                import re
                if re.search(error_pattern, error_info.error_message, re.IGNORECASE):
                    return True
            
            return False
        except Exception as e:
            logger.warning(f"模式匹配检查错误: {e}")
            return False
    
    def _trigger_recovery(self, strategy_id: str, error_info: ErrorInfo):
        """触发恢复策略"""
        try:
            if strategy_id in self.recovery_strategies:
                strategy = self.recovery_strategies[strategy_id]
                logger.info(f"触发恢复策略: {strategy_id}")
                
                # 这里可以添加实际的恢复逻辑
                # 例如：重启服务、清理缓存、调整参数等
                
        except Exception as e:
            logger.error(f"恢复策略触发错误: {e}")
    
    def _trigger_error_callbacks(self, error_info: ErrorInfo):
        """触发错误回调"""
        try:
            for callback in self.error_callbacks:
                try:
                    callback(error_info)
                except Exception as e:
                    logger.error(f"错误回调执行错误: {e}")
        except Exception as e:
            logger.error(f"错误回调触发错误: {e}")
    
    def _load_default_patterns(self):
        """加载默认错误模式"""
        try:
            # PDF解析错误模式
            pdf_pattern = ErrorPattern(
                pattern_id="pdf_parse_errors",
                pattern_name="PDF解析错误",
                error_types=["PDFParsingError", "FileNotFoundError", "PermissionError"],
                error_patterns=[r"PDF.*error", r"解析.*失败", r"文件.*不存在"],
                frequency_threshold=3,
                severity_threshold="ERROR",
                auto_recovery=True,
                recovery_strategy="retry_pdf_parse"
            )
            
            # OCR错误模式
            ocr_pattern = ErrorPattern(
                pattern_id="ocr_errors",
                pattern_name="OCR错误",
                error_types=["OCREngineError", "ImageProcessingError"],
                error_patterns=[r"OCR.*失败", r"图像.*处理.*错误"],
                frequency_threshold=5,
                severity_threshold="WARNING",
                auto_recovery=True,
                recovery_strategy="retry_ocr"
            )
            
            # 内存错误模式
            memory_pattern = ErrorPattern(
                pattern_id="memory_errors",
                pattern_name="内存错误",
                error_types=["MemoryError", "ResourceWarning"],
                error_patterns=[r"内存.*不足", r"out.*of.*memory"],
                frequency_threshold=1,
                severity_threshold="CRITICAL",
                auto_recovery=True,
                recovery_strategy="cleanup_memory"
            )
            
            self.error_patterns = [pdf_pattern, ocr_pattern, memory_pattern]
            
        except Exception as e:
            logger.warning(f"默认错误模式加载错误: {e}")


class RecoveryManager:
    """恢复管理器"""
    
    def __init__(self, error_handler: ErrorHandler):
        """
        初始化恢复管理器
        
        Args:
            error_handler: 错误处理器
        """
        self.error_handler = error_handler
        self.recovery_history = []
        self.recovery_lock = threading.Lock()
        
        # 注册默认恢复策略
        self._register_default_strategies()
        
        logger.info("恢复管理器初始化完成")
    
    def recover_from_error(self, error_info: ErrorInfo, 
                          strategy_id: Optional[str] = None) -> bool:
        """
        从错误中恢复
        
        Args:
            error_info: 错误信息
            strategy_id: 恢复策略ID
            
        Returns:
            bool: 恢复是否成功
        """
        try:
            # 选择恢复策略
            if not strategy_id:
                strategy_id = self._select_recovery_strategy(error_info)
            
            if not strategy_id:
                logger.warning(f"没有找到适合的恢复策略: {error_info.error_id}")
                return False
            
            # 执行恢复
            success = self._execute_recovery_strategy(strategy_id, error_info)
            
            # 记录恢复历史
            self._record_recovery_attempt(error_info, strategy_id, success)
            
            return success
            
        except Exception as e:
            logger.error(f"恢复过程错误: {e}")
            return False
    
    def add_recovery_strategy(self, strategy: RecoveryStrategy):
        """添加恢复策略"""
        self.error_handler.add_recovery_strategy(strategy)
    
    def _select_recovery_strategy(self, error_info: ErrorInfo) -> Optional[str]:
        """选择恢复策略"""
        try:
            # 基于错误类型选择策略
            error_type = error_info.error_type
            
            if error_type == "PDFParsingError":
                return "retry_pdf_parse"
            elif error_type == "OCREngineError":
                return "retry_ocr"
            elif error_type == "MemoryError":
                return "cleanup_memory"
            elif error_type == "FileNotFoundError":
                return "retry_file_access"
            elif error_type == "ConnectionError":
                return "retry_connection"
            else:
                return "general_retry"
                
        except Exception as e:
            logger.error(f"恢复策略选择错误: {e}")
            return None
    
    def _execute_recovery_strategy(self, strategy_id: str, error_info: ErrorInfo) -> bool:
        """执行恢复策略"""
        try:
            strategies = self.error_handler.recovery_strategies
            if strategy_id not in strategies:
                logger.warning(f"恢复策略不存在: {strategy_id}")
                return False
            
            strategy = strategies[strategy_id]
            
            if strategy.strategy_type == "retry":
                return self._execute_retry_strategy(strategy, error_info)
            elif strategy.strategy_type == "fallback":
                return self._execute_fallback_strategy(strategy, error_info)
            elif strategy.strategy_type == "skip":
                return self._execute_skip_strategy(strategy, error_info)
            elif strategy.strategy_type == "compensate":
                return self._execute_compensate_strategy(strategy, error_info)
            else:
                logger.warning(f"未知的恢复策略类型: {strategy.strategy_type}")
                return False
                
        except Exception as e:
            logger.error(f"恢复策略执行错误: {e}")
            return False
    
    def _execute_retry_strategy(self, strategy: RecoveryStrategy, error_info: ErrorInfo) -> bool:
        """执行重试策略"""
        try:
            max_attempts = strategy.max_attempts
            delay = strategy.delay_seconds
            
            for attempt in range(1, max_attempts + 1):
                logger.info(f"重试尝试 {attempt}/{max_attempts}: {error_info.error_id}")
                
                # 等待延迟
                if attempt > 1:
                    time.sleep(delay * (strategy.backoff_factor ** (attempt - 2)))
                
                # 检查系统资源
                if not self._check_system_resources():
                    logger.warning("系统资源不足，跳过重试")
                    continue
                
                # 模拟重试逻辑（实际应用中需要具体的重试实现）
                success = self._simulate_retry(error_info)
                
                if success:
                    logger.info(f"重试成功: {error_info.error_id}")
                    return True
                else:
                    logger.warning(f"重试失败，尝试 {attempt}: {error_info.error_id}")
            
            logger.error(f"重试策略失败，已达到最大尝试次数: {error_info.error_id}")
            return False
            
        except Exception as e:
            logger.error(f"重试策略执行错误: {e}")
            return False
    
    def _execute_fallback_strategy(self, strategy: RecoveryStrategy, error_info: ErrorInfo) -> bool:
        """执行回退策略"""
        try:
            if strategy.fallback_function:
                logger.info(f"执行回退策略: {error_info.error_id}")
                result = strategy.fallback_function(error_info)
                return result is not None
            else:
                logger.warning(f"回退策略没有定义回调函数: {strategy.strategy_id}")
                return False
                
        except Exception as e:
            logger.error(f"回退策略执行错误: {e}")
            return False
    
    def _execute_skip_strategy(self, strategy: RecoveryStrategy, error_info: ErrorInfo) -> bool:
        """执行跳过策略"""
        try:
            logger.info(f"跳过错误: {error_info.error_id}")
            # 跳过策略通常总是返回True，表示成功跳过
            return True
            
        except Exception as e:
            logger.error(f"跳过策略执行错误: {e}")
            return False
    
    def _execute_compensate_strategy(self, strategy: RecoveryStrategy, error_info: ErrorInfo) -> bool:
        """执行补偿策略"""
        try:
            if strategy.compensation_function:
                logger.info(f"执行补偿策略: {error_info.error_id}")
                result = strategy.compensation_function(error_info)
                return result is not None
            else:
                logger.warning(f"补偿策略没有定义回调函数: {strategy.strategy_id}")
                return False
                
        except Exception as e:
            logger.error(f"补偿策略执行错误: {e}")
            return False
    
    def _check_system_resources(self) -> bool:
        """检查系统资源"""
        try:
            # 检查内存使用
            memory = psutil.virtual_memory()
            if memory.percent > 90:
                logger.warning(f"内存使用率过高: {memory.percent}%")
                return False
            
            # 检查CPU使用
            cpu_percent = psutil.cpu_percent(interval=1)
            if cpu_percent > 90:
                logger.warning(f"CPU使用率过高: {cpu_percent}%")
                return False
            
            # 检查磁盘空间
            disk = psutil.disk_usage('/')
            if disk.percent > 95:
                logger.warning(f"磁盘使用率过高: {disk.percent}%")
                return False
            
            return True
            
        except Exception as e:
            logger.warning(f"系统资源检查错误: {e}")
            return True  # 检查失败时默认允许继续
    
    def _simulate_retry(self, error_info: ErrorInfo) -> bool:
        """模拟重试逻辑"""
        try:
            # 这里应该实现实际的重试逻辑
            # 例如：重新执行失败的函数调用
            
            # 模拟随机成功率
            import random
            success_rate = 0.7  # 70%成功率
            return random.random() < success_rate
            
        except Exception as e:
            logger.error(f"重试模拟错误: {e}")
            return False
    
    def _record_recovery_attempt(self, error_info: ErrorInfo, strategy_id: str, success: bool):
        """记录恢复尝试"""
        try:
            with self.recovery_lock:
                recovery_record = {
                    'error_id': error_info.error_id,
                    'strategy_id': strategy_id,
                    'success': success,
                    'timestamp': datetime.now().isoformat(),
                    'error_type': error_info.error_type
                }
                self.recovery_history.append(recovery_record)
                
                # 限制历史记录数量
                if len(self.recovery_history) > 1000:
                    self.recovery_history = self.recovery_history[-1000:]
                    
        except Exception as e:
            logger.error(f"恢复记录错误: {e}")
    
    def _register_default_strategies(self):
        """注册默认恢复策略"""
        try:
            # 重试策略
            retry_strategy = RecoveryStrategy(
                strategy_id="general_retry",
                strategy_type="retry",
                max_attempts=3,
                delay_seconds=1.0,
                backoff_factor=2.0
            )
            
            # PDF重试策略
            pdf_retry_strategy = RecoveryStrategy(
                strategy_id="retry_pdf_parse",
                strategy_type="retry",
                max_attempts=2,
                delay_seconds=2.0,
                backoff_factor=1.5
            )
            
            # OCR重试策略
            ocr_retry_strategy = RecoveryStrategy(
                strategy_id="retry_ocr",
                strategy_type="retry",
                max_attempts=3,
                delay_seconds=0.5,
                backoff_factor=1.2
            )
            
            # 内存清理策略
            memory_strategy = RecoveryStrategy(
                strategy_id="cleanup_memory",
                strategy_type="compensate",
                max_attempts=1,
                compensation_function=self._cleanup_memory
            )
            
            # 文件访问重试策略
            file_retry_strategy = RecoveryStrategy(
                strategy_id="retry_file_access",
                strategy_type="retry",
                max_attempts=2,
                delay_seconds=1.0,
                backoff_factor=1.0
            )
            
            # 连接重试策略
            connection_retry_strategy = RecoveryStrategy(
                strategy_id="retry_connection",
                strategy_type="retry",
                max_attempts=5,
                delay_seconds=2.0,
                backoff_factor=1.5
            )
            
            strategies = [
                retry_strategy, pdf_retry_strategy, ocr_retry_strategy,
                memory_strategy, file_retry_strategy, connection_retry_strategy
            ]
            
            for strategy in strategies:
                self.add_recovery_strategy(strategy)
                
        except Exception as e:
            logger.warning(f"默认策略注册错误: {e}")
    
    def _cleanup_memory(self, error_info: ErrorInfo) -> bool:
        """清理内存"""
        try:
            logger.info("执行内存清理")
            
            # 强制垃圾回收
            import gc
            gc.collect()
            
            # 清理缓存
            # 这里可以添加具体的缓存清理逻辑
            
            return True
            
        except Exception as e:
            logger.error(f"内存清理错误: {e}")
            return False
    
    def get_recovery_statistics(self) -> Dict[str, Any]:
        """获取恢复统计"""
        try:
            with self.recovery_lock:
                total_attempts = len(self.recovery_history)
                successful_attempts = sum(1 for record in self.recovery_history if record['success'])
                
                strategy_stats = {}
                for record in self.recovery_history:
                    strategy_id = record['strategy_id']
                    if strategy_id not in strategy_stats:
                        strategy_stats[strategy_id] = {'total': 0, 'success': 0}
                    
                    strategy_stats[strategy_id]['total'] += 1
                    if record['success']:
                        strategy_stats[strategy_id]['success'] += 1
                
                return {
                    'total_recovery_attempts': total_attempts,
                    'successful_recoveries': successful_attempts,
                    'recovery_success_rate': (successful_attempts / max(total_attempts, 1)) * 100,
                    'strategy_statistics': strategy_stats
                }
                
        except Exception as e:
            logger.error(f"恢复统计错误: {e}")
            return {}


class HealthMonitor:
    """健康监控器"""
    
    def __init__(self, monitoring_interval: float = 30.0):
        """
        初始化健康监控器
        
        Args:
            monitoring_interval: 监控间隔（秒）
        """
        self.monitoring_interval = monitoring_interval
        self.health_history = []
        self.monitoring = False
        self.monitor_thread = None
        self.health_lock = threading.Lock()
        self.alerts = []
        
        logger.info(f"健康监控器初始化完成，监控间隔：{monitoring_interval}秒")
    
    def start_monitoring(self):
        """开始监控"""
        if self.monitoring:
            logger.warning("健康监控已在运行")
            return
        
        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitor_thread.start()
        
        logger.info("健康监控已启动")
    
    def stop_monitoring(self):
        """停止监控"""
        if not self.monitoring:
            return
        
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5.0)
        
        logger.info("健康监控已停止")
    
    def get_current_health(self) -> SystemHealth:
        """获取当前健康状态"""
        try:
            # 获取系统指标
            cpu_usage = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            health = SystemHealth(
                cpu_usage=cpu_usage,
                memory_usage=memory.percent,
                disk_usage=disk.percent,
                active_connections=len(psutil.net_connections()),
                queue_size=0  # 需要从外部设置
            )
            
            return health
            
        except Exception as e:
            logger.error(f"健康状态获取错误: {e}")
            return SystemHealth()
    
    def set_queue_size(self, queue_size: int):
        """设置队列大小"""
        # 这个方法应该从外部调用来更新队列大小
        pass
    
    def check_health_alerts(self, health: SystemHealth) -> List[str]:
        """检查健康告警"""
        alerts = []
        
        try:
            # CPU告警
            if health.cpu_usage > 90:
                alerts.append(f"CPU使用率过高: {health.cpu_usage}%")
            
            # 内存告警
            if health.memory_usage > 90:
                alerts.append(f"内存使用率过高: {health.memory_usage}%")
            
            # 磁盘告警
            if health.disk_usage > 95:
                alerts.append(f"磁盘使用率过高: {health.disk_usage}%")
            
            # 错误率告警（需要从错误处理器获取）
            # 这里可以添加错误率检查逻辑
            
        except Exception as e:
            logger.error(f"健康告警检查错误: {e}")
        
        return alerts
    
    def _monitoring_loop(self):
        """监控循环"""
        try:
            while self.monitoring:
                # 获取健康状态
                health = self.get_current_health()
                
                # 检查告警
                alerts = self.check_health_alerts(health)
                if alerts:
                    with self.health_lock:
                        self.alerts.extend(alerts)
                    
                    for alert in alerts:
                        logger.warning(f"健康告警: {alert}")
                
                # 记录健康状态
                with self.health_lock:
                    self.health_history.append(health)
                    
                    # 限制历史记录数量
                    if len(self.health_history) > 1000:
                        self.health_history = self.health_history[-1000:]
                
                # 等待下次监控
                time.sleep(self.monitoring_interval)
                
        except Exception as e:
            logger.error(f"监控循环错误: {e}")
    
    def get_health_report(self) -> Dict[str, Any]:
        """获取健康报告"""
        try:
            with self.health_lock:
                if not self.health_history:
                    return {'message': '没有健康数据'}
                
                # 计算统计信息
                cpu_values = [h.cpu_usage for h in self.health_history]
                memory_values = [h.memory_usage for h in self.health_history]
                disk_values = [h.disk_usage for h in self.health_history]
                
                return {
                    'monitoring_period': {
                        'start': self.health_history[0].timestamp.isoformat(),
                        'end': self.health_history[-1].timestamp.isoformat(),
                        'duration_minutes': (self.health_history[-1].timestamp - 
                                           self.health_history[0].timestamp).total_seconds() / 60
                    },
                    'statistics': {
                        'cpu_usage': {
                            'avg': np.mean(cpu_values),
                            'max': np.max(cpu_values),
                            'min': np.min(cpu_values)
                        },
                        'memory_usage': {
                            'avg': np.mean(memory_values),
                            'max': np.max(memory_values),
                            'min': np.min(memory_values)
                        },
                        'disk_usage': {
                            'avg': np.mean(disk_values),
                            'max': np.max(disk_values),
                            'min': np.min(disk_values)
                        }
                    },
                    'recent_alerts': self.alerts[-10:],  # 最近10个告警
                    'total_data_points': len(self.health_history)
                }
                
        except Exception as e:
            logger.error(f"健康报告生成错误: {e}")
            return {'error': str(e)}


class ErrorRecoverySystem:
    """错误恢复系统"""
    
    def __init__(self, max_error_history: int = 10000, monitoring_interval: float = 30.0):
        """
        初始化错误恢复系统
        
        Args:
            max_error_history: 最大错误历史记录数
            monitoring_interval: 监控间隔
        """
        self.error_handler = ErrorHandler(max_error_history)
        self.recovery_manager = RecoveryManager(self.error_handler)
        self.health_monitor = HealthMonitor(monitoring_interval)
        
        # 错误恢复装饰器
        self.setup_error_decorators()
        
        logger.info("错误恢复系统初始化完成")
    
    def setup_error_decorators(self):
        """设置错误装饰器"""
        # 这里可以添加装饰器相关的设置
        pass
    
    def handle_operation(self, operation: Callable, *args, **kwargs) -> Tuple[Any, bool]:
        """
        处理操作，包含错误恢复
        
        Args:
            operation: 要执行的操作
            *args: 操作参数
            **kwargs: 操作关键字参数
            
        Returns:
            Tuple[Any, bool]: (结果, 是否成功)
        """
        try:
            # 执行操作
            result = operation(*args, **kwargs)
            return result, True
            
        except Exception as e:
            # 处理错误
            error_info = self.error_handler.handle_error(e, {
                'operation': operation.__name__,
                'args': str(args)[:200],  # 限制长度
                'kwargs': str(kwargs)[:200]
            })
            
            # 尝试恢复
            recovery_success = self.recovery_manager.recover_from_error(error_info)
            
            if recovery_success:
                logger.info(f"错误恢复成功: {error_info.error_id}")
                # 重新尝试操作
                try:
                    result = operation(*args, **kwargs)
                    return result, True
                except Exception as retry_e:
                    retry_error = self.error_handler.handle_error(retry_e, {
                        'operation': operation.__name__,
                        'retry_attempt': True
                    })
                    return None, False
            else:
                logger.error(f"错误恢复失败: {error_info.error_id}")
                return None, False
    
    def start_monitoring(self):
        """开始监控"""
        self.health_monitor.start_monitoring()
    
    def stop_monitoring(self):
        """停止监控"""
        self.health_monitor.stop_monitoring()
    
    def get_system_status(self) -> Dict[str, Any]:
        """获取系统状态"""
        try:
            # 获取错误统计
            error_stats = self.error_handler.get_error_statistics()
            
            # 获取恢复统计
            recovery_stats = self.recovery_manager.get_recovery_statistics()
            
            # 获取健康报告
            health_report = self.health_monitor.get_health_report()
            
            return {
                'error_statistics': error_stats,
                'recovery_statistics': recovery_stats,
                'health_report': health_report,
                'system_status': 'healthy' if not error_stats.get('severity_counts', {}).get('CRITICAL', 0) else 'critical'
            }
            
        except Exception as e:
            logger.error(f"系统状态获取错误: {e}")
            return {'error': str(e)}
    
    def export_error_report(self, output_path: Union[str, Path]) -> bool:
        """导出错误报告"""
        try:
            output_path = Path(output_path)
            
            # 获取完整报告
            report = {
                'timestamp': datetime.now().isoformat(),
                'system_status': self.get_system_status(),
                'error_history': [error.to_dict() for error in self.error_handler.error_history[-100:]],  # 最近100个错误
                'recovery_history': self.recovery_manager.recovery_history[-100:],  # 最近100个恢复记录
                'health_history': [health.to_dict() for health in self.health_monitor.health_history[-100:]]  # 最近100个健康记录
            }
            
            # 保存为JSON
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, ensure_ascii=False, indent=2, default=str)
            
            logger.info(f"错误报告已导出: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"错误报告导出错误: {e}")
            return False


# 装饰器函数
def with_error_recovery(recovery_system: ErrorRecoverySystem):
    """错误恢复装饰器"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            return recovery_system.handle_operation(func, *args, **kwargs)
        return wrapper
    return decorator


# 使用示例
if __name__ == "__main__":
    # 创建错误恢复系统
    recovery_system = ErrorRecoverySystem()
    
    # 启动监控
    recovery_system.start_monitoring()
    
    # 示例操作
    @with_error_recovery(recovery_system)
    def sample_operation(data):
        """示例操作"""
        if np.random.random() < 0.3:  # 30%概率失败
            raise ValueError("模拟操作失败")
        return f"操作成功处理数据: {data}"
    
    # 执行示例操作
    try:
        for i in range(10):
            result, success = sample_operation(f"数据_{i}")
            print(f"操作 {i}: {'成功' if success else '失败'} - {result}")
    except KeyboardInterrupt:
        print("用户中断")
    
    # 获取系统状态
    status = recovery_system.get_system_status()
    print(f"系统状态: {status['system_status']}")
    
    # 导出错误报告
    recovery_system.export_error_report("error_report.json")
    
    # 停止监控
    recovery_system.stop_monitoring()
    
    print("错误恢复系统演示完成")
