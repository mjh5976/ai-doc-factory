"""
A/B测试结果可视化和报告模块
提供完整的A/B测试结果可视化功能，包括统计图表、趋势分析和自动化报告生成
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.offline as pyo
from typing import Dict, List, Optional, Tuple, Any, Union
from dataclasses import dataclass
import json
import base64
from io import BytesIO
import warnings
from datetime import datetime, timedelta
import logging

# 导入自定义模块
from statistical_tests import TestResult, SampleSizeCalculation

# 配置matplotlib
def setup_matplotlib_for_plotting():
    """
    Setup matplotlib and seaborn for plotting with proper configuration.
    Call this function before creating any plots to ensure proper rendering.
    """
    warnings.filterwarnings('default')  # Show all warnings

    # Configure matplotlib for non-interactive mode
    plt.switch_backend("Agg")

    # Set chart style
    plt.style.use("seaborn-v0_8")
    sns.set_palette("husl")

    # Configure platform-appropriate fonts for cross-platform compatibility
    plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC", "WenQuanYi Zen Hei", "PingFang SC", "Arial Unicode MS", "Hiragino Sans GB"]
    plt.rcParams["axes.unicode_minus"] = False

# 初始化matplotlib
setup_matplotlib_for_plotting()

logger = logging.getLogger(__name__)

@dataclass
class VisualizationConfig:
    """可视化配置"""
    figure_size: Tuple[int, int] = (12, 8)
    dpi: int = 100
    color_scheme: str = "husl"
    font_size: int = 12
    title_font_size: int = 16
    save_format: str = "png"
    save_quality: int = 300
    interactive: bool = True

class ABTestVisualizer:
    """A/B测试结果可视化器"""
    
    def __init__(self, config: VisualizationConfig = None):
        self.config = config or VisualizationConfig()
        plt.rcParams['figure.figsize'] = self.config.figure_size
        plt.rcParams['figure.dpi'] = self.config.dpi
        
    def plot_metric_distribution(self, 
                               control_data: np.ndarray, 
                               treatment_data: np.ndarray,
                               metric_name: str,
                               test_result: TestResult,
                               save_path: Optional[str] = None) -> str:
        """绘制指标分布对比图"""
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # 直方图对比
        ax1.hist(control_data, bins=50, alpha=0.7, label='Control Group', color='skyblue', density=True)
        ax1.hist(treatment_data, bins=50, alpha=0.7, label='Treatment Group', color='lightcoral', density=True)
        ax1.axvline(np.mean(control_data), color='blue', linestyle='--', linewidth=2, label=f'Control Mean: {np.mean(control_data):.3f}')
        ax1.axvline(np.mean(treatment_data), color='red', linestyle='--', linewidth=2, label=f'Treatment Mean: {np.mean(treatment_data):.3f}')
        ax1.set_xlabel(metric_name)
        ax1.set_ylabel('Density')
        ax1.set_title(f'{metric_name} Distribution Comparison')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 箱线图对比
        data_for_box = [control_data, treatment_data]
        labels = ['Control', 'Treatment']
        box_plot = ax2.boxplot(data_for_box, labels=labels, patch_artist=True)
        box_plot['boxes'][0].set_facecolor('skyblue')
        box_plot['boxes'][1].set_facecolor('lightcoral')
        
        # 添加统计信息
        control_stats = f"Mean: {np.mean(control_data):.3f}\\nStd: {np.std(control_data):.3f}\\nN: {len(control_data)}"
        treatment_stats = f"Mean: {np.mean(treatment_data):.3f}\\nStd: {np.std(treatment_data):.3f}\\nN: {len(treatment_data)}"
        
        ax2.text(0.02, 0.98, control_stats, transform=ax2.transAxes, verticalalignment='top',
                bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.8))
        ax2.text(0.98, 0.98, treatment_stats, transform=ax2.transAxes, verticalalignment='top', horizontalalignment='right',
                bbox=dict(boxstyle='round', facecolor='lightcoral', alpha=0.8))
        
        ax2.set_ylabel(metric_name)
        ax2.set_title(f'{metric_name} Box Plot Comparison')
        ax2.grid(True, alpha=0.3)
        
        # 添加检验结果
        significance_text = f"Statistical Test: {test_result.test_name}\\n"
        significance_text += f"P-value: {test_result.p_value:.6f}\\n"
        significance_text += f"Significant: {'Yes' if test_result.is_significant else 'No'}\\n"
        significance_text += f"Effect Size: {test_result.effect_size:.4f}"
        
        fig.text(0.5, 0.02, significance_text, ha='center', fontsize=10,
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))
        
        plt.tight_layout()
        plt.subplots_adjust(bottom=0.15)
        
        if save_path:
            plt.savefig(save_path, dpi=self.config.save_quality, bbox_inches='tight')
            logger.info(f"图表已保存: {save_path}")
        
        # 转换为base64用于HTML报告
        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=self.config.save_quality, bbox_inches='tight')
        buffer.seek(0)
        image_base64 = base64.b64encode(buffer.getvalue()).decode()
        buffer.close()
        plt.close()
        
        return image_base64
    
    def plot_time_series_analysis(self,
                                 time_series_data: Dict[str, List[Tuple[datetime, float]]],
                                 save_path: Optional[str] = None) -> str:
        """绘制时间序列分析图"""
        
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.suptitle('A/B Test Time Series Analysis', fontsize=16)
        
        # 1. 指标随时间变化
        ax1 = axes[0, 0]
        for group, data in time_series_data.items():
            times, values = zip(*data)
            ax1.plot(times, values, marker='o', label=group, alpha=0.7)
        ax1.set_xlabel('Time')
        ax1.set_ylabel('Metric Value')
        ax1.set_title('Metric Trend Over Time')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        ax1.tick_params(axis='x', rotation=45)
        
        # 2. 滚动平均值
        ax2 = axes[0, 1]
        window_size = 24  # 24小时滚动窗口
        
        for group, data in time_series_data.items():
            times, values = zip(*data)
            df = pd.DataFrame({'time': times, 'value': values})
            df.set_index('time', inplace=True)
            rolling_mean = df['value'].rolling(window=window_size).mean()
            ax2.plot(rolling_mean.index, rolling_mean.values, label=f'{group} (Rolling {window_size}h)', linewidth=2)
        
        ax2.set_xlabel('Time')
        ax2.set_ylabel('Rolling Average')
        ax2.set_title('Rolling Average Analysis')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        ax2.tick_params(axis='x', rotation=45)
        
        # 3. 差异随时间变化
        ax3 = axes[1, 0]
        if 'Control' in time_series_data and 'Treatment' in time_series_data:
            control_data = time_series_data['Control']
            treatment_data = time_series_data['Treatment']
            
            # 确保时间对齐
            control_df = pd.DataFrame(control_data, columns=['time', 'value']).set_index('time')
            treatment_df = pd.DataFrame(treatment_data, columns=['time', 'value']).set_index('time')
            
            # 重采样到相同频率并计算差异
            combined_df = pd.concat([control_df, treatment_df], axis=1, keys=['control', 'treatment'])
            combined_df = combined_df.dropna()
            
            if not combined_df.empty:
                combined_df['difference'] = combined_df[('treatment', 'value')] - combined_df[('control', 'value')]
                ax3.plot(combined_df.index, combined_df['difference'], color='green', linewidth=2)
                ax3.axhline(y=0, color='black', linestyle='--', alpha=0.5)
                ax3.fill_between(combined_df.index, combined_df['difference'], 0, 
                               alpha=0.3, color='green')
        
        ax3.set_xlabel('Time')
        ax3.set_ylabel('Treatment - Control')
        ax3.set_title('Difference Over Time')
        ax3.grid(True, alpha=0.3)
        ax3.tick_params(axis='x', rotation=45)
        
        # 4. 累积效应
        ax4 = axes[1, 1]
        if 'Control' in time_series_data and 'Treatment' in time_series_data:
            control_data = time_series_data['Control']
            treatment_data = time_series_data['Treatment']
            
            control_df = pd.DataFrame(control_data, columns=['time', 'value']).set_index('time')
            treatment_df = pd.DataFrame(treatment_data, columns=['time', 'value']).set_index('time')
            
            combined_df = pd.concat([control_df, treatment_df], axis=1, keys=['control', 'treatment'])
            combined_df = combined_df.dropna()
            
            if not combined_df.empty:
                combined_df['cumulative_diff'] = (combined_df[('treatment', 'value')] - 
                                                combined_df[('control', 'value')]).cumsum()
                ax4.plot(combined_df.index, combined_df['cumulative_diff'], color='purple', linewidth=2)
                ax4.axhline(y=0, color='black', linestyle='--', alpha=0.5)
        
        ax4.set_xlabel('Time')
        ax4.set_ylabel('Cumulative Difference')
        ax4.set_title('Cumulative Effect')
        ax4.grid(True, alpha=0.3)
        ax4.tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=self.config.save_quality, bbox_inches='tight')
            logger.info(f"时间序列图表已保存: {save_path}")
        
        # 转换为base64
        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=self.config.save_quality, bbox_inches='tight')
        buffer.seek(0)
        image_base64 = base64.b64encode(buffer.getvalue()).decode()
        buffer.close()
        plt.close()
        
        return image_base64
    
    def plot_statistical_power_analysis(self,
                                      sample_size_calculation: SampleSizeCalculation,
                                      save_path: Optional[str] = None) -> str:
        """绘制统计功效分析图"""
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # 1. 样本量 vs 效应大小
        effect_sizes = np.linspace(0.1, 2.0, 100)
        sample_sizes = []
        
        for effect_size in effect_sizes:
            if sample_size_calculation.test_type == "two_means":
                # 简化的样本量计算
                n = ((1.96 + 0.84) ** 2 * 2) / (effect_size ** 2)
            else:
                n = ((1.96 + 0.84) ** 2 * 2) / (effect_size ** 2)
            sample_sizes.append(int(n))
        
        ax1.plot(effect_sizes, sample_sizes, linewidth=2, color='blue')
        ax1.axvline(x=sample_size_calculation.effect_size, color='red', linestyle='--', 
                   label=f'Current Effect Size: {sample_size_calculation.effect_size:.3f}')
        ax1.axhline(y=sample_size_calculation.required_sample_size, color='green', linestyle='--',
                   label=f'Required Sample Size: {sample_size_calculation.required_sample_size}')
        ax1.set_xlabel('Effect Size (Cohen\'s d)')
        ax1.set_ylabel('Required Sample Size')
        ax1.set_title('Sample Size vs Effect Size')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        ax1.set_yscale('log')
        
        # 2. 功效 vs 样本量
        sample_sizes_range = np.linspace(50, 2000, 100)
        powers = []
        
        for n in sample_sizes_range:
            # 简化的功效计算
            effect_size = sample_size_calculation.effect_size
            z_alpha = 1.96
            z_effect = effect_size * np.sqrt(n / 4)
            power = 1 - scipy.stats.norm.cdf(z_alpha - z_effect) + scipy.stats.norm.cdf(-z_alpha - z_effect)
            powers.append(max(0, min(1, power)))
        
        ax2.plot(sample_sizes_range, powers, linewidth=2, color='purple')
        ax2.axhline(y=0.8, color='red', linestyle='--', label='Target Power: 0.8')
        ax2.axvline(x=sample_size_calculation.required_sample_size, color='green', linestyle='--',
                   label=f'Required Sample Size: {sample_size_calculation.required_sample_size}')
        ax2.set_xlabel('Sample Size')
        ax2.set_ylabel('Statistical Power')
        ax2.set_title('Power vs Sample Size')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        ax2.set_ylim(0, 1)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=self.config.save_quality, bbox_inches='tight')
            logger.info(f"功效分析图表已保存: {save_path}")
        
        # 转换为base64
        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=self.config.save_quality, bbox_inches='tight')
        buffer.seek(0)
        image_base64 = base64.b64encode(buffer.getvalue()).decode()
        buffer.close()
        plt.close()
        
        return image_base64
    
    def create_interactive_dashboard(self,
                                   test_results: Dict[str, TestResult],
                                   sample_data: Dict[str, np.ndarray],
                                   save_path: Optional[str] = None) -> str:
        """创建交互式仪表板"""
        
        # 创建子图
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Metric Distributions', 'Statistical Tests', 'Sample Sizes', 'Effect Sizes'),
            specs=[[{"secondary_y": False}, {"secondary_y": False}],
                   [{"secondary_y": False}, {"secondary_y": False}]]
        )
        
        # 1. 指标分布对比
        for group, data in sample_data.items():
            fig.add_trace(
                go.Histogram(x=data, name=f'{group} Group', opacity=0.7, nbinsx=30),
                row=1, col=1
            )
        
        # 2. p值条形图
        test_names = list(test_results.keys())
        p_values = [test_results[name].p_value for name in test_names]
        colors = ['red' if p < 0.05 else 'blue' for p in p_values]
        
        fig.add_trace(
            go.Bar(x=test_names, y=p_values, name='P-values', marker_color=colors),
            row=1, col=2
        )
        
        # 添加显著性线
        fig.add_hline(y=0.05, line_dash="dash", line_color="red", row=1, col=2)
        
        # 3. 样本量对比
        sample_sizes = [len(data) for data in sample_data.values()]
        fig.add_trace(
            go.Bar(x=list(sample_data.keys()), y=sample_sizes, name='Sample Sizes'),
            row=2, col=1
        )
        
        # 4. 效应大小
        effect_sizes = [test_results[name].effect_size for name in test_names]
        fig.add_trace(
            go.Bar(x=test_names, y=effect_sizes, name='Effect Sizes'),
            row=2, col=2
        )
        
        # 更新布局
        fig.update_layout(
            title_text="A/B Test Interactive Dashboard",
            showlegend=True,
            height=800
        )
        
        # 更新x轴标签
        fig.update_xaxes(title_text="Value", row=1, col=1)
        fig.update_xaxes(title_text="Test", row=1, col=2)
        fig.update_xaxes(title_text="Group", row=2, col=1)
        fig.update_xaxes(title_text="Test", row=2, col=2)
        
        # 更新y轴标签
        fig.update_yaxes(title_text="Frequency", row=1, col=1)
        fig.update_yaxes(title_text="P-value", row=1, col=2)
        fig.update_yaxes(title_text="Sample Size", row=2, col=1)
        fig.update_yaxes(title_text="Effect Size", row=2, col=2)
        
        if save_path:
            fig.write_html(save_path)
            logger.info(f"交互式仪表板已保存: {save_path}")
        
        # 转换为HTML字符串
        html_string = fig.to_html(include_plotlyjs='cdn')
        
        return html_string

class ReportGenerator:
    """报告生成器"""
    
    def __init__(self, config: VisualizationConfig = None):
        self.config = config or VisualizationConfig()
        self.visualizer = ABTestVisualizer(config)
    
    def generate_html_report(self,
                           test_config: Dict[str, Any],
                           test_results: Dict[str, TestResult],
                           sample_data: Dict[str, np.ndarray],
                           time_series_data: Optional[Dict[str, List[Tuple[datetime, float]]]] = None,
                           sample_size_calc: Optional[SampleSizeCalculation] = None,
                           save_path: str = "reports/ab_test_report.html") -> str:
        """生成HTML报告"""
        
        # 生成各种图表
        charts = {}
        
        # 主要指标分布图
        if len(sample_data) >= 2:
            group_names = list(sample_data.keys())
            charts['distribution'] = self.visualizer.plot_metric_distribution(
                sample_data[group_names[0]], 
                sample_data[group_names[1]],
                test_config.get('primary_metric', 'Metric'),
                list(test_results.values())[0]
            )
        
        # 时间序列分析
        if time_series_data:
            charts['timeseries'] = self.visualizer.plot_time_series_analysis(time_series_data)
        
        # 功效分析
        if sample_size_calc:
            charts['power_analysis'] = self.visualizer.plot_statistical_power_analysis(sample_size_calc)
        
        # 交互式仪表板
        charts['dashboard'] = self.visualizer.create_interactive_dashboard(test_results, sample_data)
        
        # 生成HTML报告
        html_content = self._create_html_template(test_config, test_results, charts, sample_size_calc)
        
        # 保存报告
        with open(save_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"HTML报告已生成: {save_path}")
        return save_path
    
    def generate_pdf_report(self,
                          test_config: Dict[str, Any],
                          test_results: Dict[str, TestResult],
                          sample_data: Dict[str, np.ndarray],
                          save_path: str = "reports/ab_test_report.pdf") -> str:
        """生成PDF报告（需要安装reportlab）"""
        
        try:
            from reportlab.lib.pagesizes import letter, A4
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import inch
            from reportlab.lib import colors
            
            # 创建PDF文档
            doc = SimpleDocTemplate(save_path, pagesize=A4)
            styles = getSampleStyleSheet()
            story = []
            
            # 标题
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=18,
                spaceAfter=30,
                alignment=1  # 居中
            )
            story.append(Paragraph("A/B Test Analysis Report", title_style))
            story.append(Spacer(1, 12))
            
            # 测试配置
            config_data = [
                ['Test Name', test_config.get('test_name', 'N/A')],
                ['Primary Metric', test_config.get('primary_metric', 'N/A')],
                ['Control Group', test_config.get('model_version_a', 'N/A')],
                ['Treatment Group', test_config.get('model_version_b', 'N/A')],
                ['Sample Size per Group', str(test_config.get('sample_size_per_group', 'N/A'))],
                ['Confidence Level', str(test_config.get('confidence_level', 'N/A'))]
            ]
            
            config_table = Table(config_data, colWidths=[2*inch, 3*inch])
            config_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 14),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(Paragraph("Test Configuration", styles['Heading2']))
            story.append(config_table)
            story.append(Spacer(1, 12))
            
            # 统计结果
            story.append(Paragraph("Statistical Test Results", styles['Heading2']))
            
            for test_name, result in test_results.items():
                result_data = [
                    ['Test', test_name],
                    ['Statistic', f"{result.statistic:.4f}"],
                    ['P-value', f"{result.p_value:.6f}"],
                    ['Significant', 'Yes' if result.is_significant else 'No'],
                    ['Effect Size', f"{result.effect_size:.4f}"],
                    ['Interpretation', result.interpretation]
                ]
                
                result_table = Table(result_data, colWidths=[2*inch, 3*inch])
                result_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.lightblue),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 12),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                
                story.append(result_table)
                story.append(Spacer(1, 12))
            
            # 生成PDF
            doc.build(story)
            logger.info(f"PDF报告已生成: {save_path}")
            return save_path
            
        except ImportError:
            logger.warning("reportlab未安装，无法生成PDF报告")
            return ""
    
    def _create_html_template(self,
                            test_config: Dict[str, Any],
                            test_results: Dict[str, TestResult],
                            charts: Dict[str, str],
                            sample_size_calc: Optional[SampleSizeCalculation] = None) -> str:
        """创建HTML报告模板"""
        
        html_template = f"""
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A/B测试分析报告</title>
    <style>
        body {{
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #333;
            text-align: center;
            border-bottom: 3px solid #007bff;
            padding-bottom: 10px;
        }}
        h2 {{
            color: #007bff;
            border-left: 4px solid #007bff;
            padding-left: 15px;
            margin-top: 30px;
        }}
        .config-table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }}
        .config-table th, .config-table td {{
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }}
        .config-table th {{
            background-color: #f8f9fa;
            font-weight: bold;
        }}
        .result-card {{
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }}
        .significant {{
            color: #28a745;
            font-weight: bold;
        }}
        .not-significant {{
            color: #dc3545;
            font-weight: bold;
        }}
        .chart-container {{
            text-align: center;
            margin: 30px 0;
        }}
        .chart-container img {{
            max-width: 100%;
            height: auto;
            border: 1px solid #ddd;
            border-radius: 8px;
        }}
        .dashboard-container {{
            margin: 30px 0;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
        }}
        .summary {{
            background-color: #e9ecef;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
        }}
        .footer {{
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            color: #666;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>A/B测试分析报告</h1>
        
        <div class="summary">
            <h2>执行摘要</h2>
            <p><strong>测试名称:</strong> {test_config.get('test_name', 'N/A')}</p>
            <p><strong>主要指标:</strong> {test_config.get('primary_metric', 'N/A')}</p>
            <p><strong>控制组:</strong> {test_config.get('model_version_a', 'N/A')}</p>
            <p><strong>实验组:</strong> {test_config.get('model_version_b', 'N/A')}</p>
            <p><strong>置信水平:</strong> {test_config.get('confidence_level', 'N/A')}</p>
        </div>
        
        <h2>测试配置</h2>
        <table class="config-table">
            <tr><th>参数</th><th>值</th></tr>
            <tr><td>测试名称</td><td>{test_config.get('test_name', 'N/A')}</td></tr>
            <tr><td>控制组模型</td><td>{test_config.get('model_version_a', 'N/A')}</td></tr>
            <tr><td>实验组模型</td><td>{test_config.get('model_version_b', 'N/A')}</td></tr>
            <tr><td>每组样本量</td><td>{test_config.get('sample_size_per_group', 'N/A')}</td></tr>
            <tr><td>置信水平</td><td>{test_config.get('confidence_level', 'N/A')}</td></tr>
            <tr><td>最小效应大小</td><td>{test_config.get('minimum_effect_size', 'N/A')}</td></tr>
            <tr><td>测试持续时间</td><td>{test_config.get('test_duration_days', 'N/A')}天</td></tr>
        </table>
        
        <h2>统计检验结果</h2>
"""
        
        # 添加统计检验结果
        for test_name, result in test_results.items():
            significance_class = "significant" if result.is_significant else "not-significant"
            html_template += f"""
        <div class="result-card">
            <h3>{test_name}</h3>
            <p><strong>统计量:</strong> {result.statistic:.4f}</p>
            <p><strong>P值:</strong> <span class="{significance_class}">{result.p_value:.6f}</span></p>
            <p><strong>显著性:</strong> <span class="{significance_class}">{'是' if result.is_significant else '否'}</span></p>
            <p><strong>效应大小:</strong> {result.effect_size:.4f}</p>
            <p><strong>解释:</strong> {result.interpretation}</p>
        </div>
"""
        
        # 添加图表
        if 'distribution' in charts:
            html_template += f"""
        <h2>指标分布对比</h2>
        <div class="chart-container">
            <img src="data:image/png;base64,{charts['distribution']}" alt="指标分布对比图">
        </div>
"""
        
        if 'timeseries' in charts:
            html_template += f"""
        <h2>时间序列分析</h2>
        <div class="chart-container">
            <img src="data:image/png;base64,{charts['timeseries']}" alt="时间序列分析图">
        </div>
"""
        
        if 'power_analysis' in charts:
            html_template += f"""
        <h2>功效分析</h2>
        <div class="chart-container">
            <img src="data:image/png;base64,{charts['power_analysis']}" alt="功效分析图">
        </div>
"""
        
        # 添加交互式仪表板
        if 'dashboard' in charts:
            html_template += f"""
        <h2>交互式仪表板</h2>
        <div class="dashboard-container">
            {charts['dashboard']}
        </div>
"""
        
        # 添加样本量计算结果
        if sample_size_calc:
            html_template += f"""
        <h2>样本量分析</h2>
        <div class="result-card">
            <p><strong>所需样本量:</strong> {sample_size_calc.required_sample_size}</p>
            <p><strong>效应大小:</strong> {sample_size_calc.effect_size:.4f}</p>
            <p><strong>统计功效:</strong> {sample_size_calc.power:.2f}</p>
            <p><strong>备注:</strong> {sample_size_calc.notes}</p>
        </div>
"""
        
        html_template += """
        <div class="footer">
            <p>报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <p>由A/B测试分析系统自动生成</p>
        </div>
    </div>
</body>
</html>
"""
        
        return html_template

# 使用示例
def run_visualization_example():
    """运行可视化示例"""
    
    # 生成示例数据
    np.random.seed(42)
    control_data = np.random.normal(100, 15, 1000)
    treatment_data = np.random.normal(103, 15, 1000)
    
    # 创建可视化配置
    config = VisualizationConfig(
        figure_size=(12, 8),
        dpi=100,
        interactive=True
    )
    
    # 创建可视化器
    visualizer = ABTestVisualizer(config)
    
    # 创建报告生成器
    generator = ReportGenerator(config)
    
    # 示例测试结果
    from statistical_tests import StatisticalTests
    stats_tests = StatisticalTests()
    test_result = stats_tests.compare_two_means(control_data, treatment_data)
    
    test_results = {'Primary Metric': test_result}
    sample_data = {'Control': control_data, 'Treatment': treatment_data}
    
    # 测试配置
    test_config = {
        'test_name': '模型性能对比测试',
        'primary_metric': 'accuracy',
        'model_version_a': 'v1.0',
        'model_version_b': 'v1.1',
        'sample_size_per_group': 1000,
        'confidence_level': 0.95
    }
    
    # 生成时间序列数据
    time_series_data = {
        'Control': [(datetime.now() - timedelta(hours=i), np.random.normal(100, 5)) for i in range(24)],
        'Treatment': [(datetime.now() - timedelta(hours=i), np.random.normal(103, 5)) for i in range(24)]
    }
    
    # 生成样本量计算
    sample_calc = stats_tests.calculate_sample_size_two_means(
        baseline_mean=100,
        expected_difference=3,
        pooled_std=15
    )
    
    # 生成HTML报告
    html_path = generator.generate_html_report(
        test_config=test_config,
        test_results=test_results,
        sample_data=sample_data,
        time_series_data=time_series_data,
        sample_size_calc=sample_calc,
        save_path="reports/ab_test_report.html"
    )
    
    print(f"HTML报告已生成: {html_path}")
    
    # 生成PDF报告
    pdf_path = generator.generate_pdf_report(
        test_config=test_config,
        test_results=test_results,
        sample_data=sample_data,
        save_path="reports/ab_test_report.pdf"
    )
    
    if pdf_path:
        print(f"PDF报告已生成: {pdf_path}")

if __name__ == "__main__":
    run_visualization_example()