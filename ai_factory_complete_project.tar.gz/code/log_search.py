#!/usr/bin/env python3
"""
日志搜索和查询优化系统
提供高效的日志搜索、过滤、聚合和查询优化功能
"""

import os
import sys
import time
import json
import logging
import re
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Union, Set
from dataclasses import dataclass, field, asdict
from collections import defaultdict, Counter
from enum import Enum
import yaml
import sqlite3
import whoosh
from whoosh import index
from whoosh.qparser import QueryParser, MultifieldParser, OrGroup
from whoosh.fields import Schema, TEXT, DATETIME, KEYWORD, NUMERIC, STORED
from whoosh.scoring import TF_IDF, BM25F
from whoosh.analysis import StemmingAnalyzer, StandardAnalyzer
from whoosh.writing import AsyncWriter
import redis
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class SearchOperator(Enum):
    """搜索操作符"""
    AND = "AND"
    OR = "OR"
    NOT = "NOT"
    EXACT = "EXACT"
    REGEX = "REGEX"
    FUZZY = "FUZZY"

@dataclass
class SearchQuery:
    """搜索查询对象"""
    query_text: str
    fields: List[str] = field(default_factory=lambda: ['message', 'service', 'host'])
    operators: List[SearchOperator] = field(default_factory=list)
    filters: Dict[str, Any] = field(default_factory=dict)
    time_range: Optional[Tuple[datetime, datetime]] = None
    limit: int = 1000
    offset: int = 0
    sort_by: str = 'timestamp'
    sort_order: str = 'desc'
    
    def to_dict(self) -> Dict[str, Any]:
        result = asdict(self)
        if self.time_range:
            result['time_range'] = (
                self.time_range[0].isoformat(),
                self.time_range[1].isoformat()
            )
        return result

@dataclass
class SearchResult:
    """搜索结果对象"""
    total_count: int
    results: List[Dict[str, Any]]
    facets: Dict[str, Any] = field(default_factory=dict)
    aggregations: Dict[str, Any] = field(default_factory=dict)
    search_time: float = 0.0
    query: Optional[SearchQuery] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'total_count': self.total_count,
            'results': self.results,
            'facets': self.facets,
            'aggregations': self.aggregations,
            'search_time': self.search_time,
            'query': self.query.to_dict() if self.query else None
        }

class LogSearchEngine:
    """日志搜索引擎"""
    
    def __init__(self, config_path: str = "config/search_config.yaml"):
        self.config = self._load_config(config_path)
        self.logger = logging.getLogger(__name__)
        self.redis_client = None
        self.whoosh_index = None
        self.schema = None
        self.vectorizer = None
        self.cache = {}
        self.query_cache = {}
        
        # 初始化Redis连接
        if self.config.get('redis'):
            self.redis_client = redis.Redis(
                host=self.config['redis']['host'],
                port=self.config['redis']['port'],
                decode_responses=True
            )
        
        # 初始化搜索引擎
        self._setup_whoosh_index()
        self._setup_vectorizer()
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载搜索引擎配置"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            self.logger.warning(f"搜索引擎配置文件加载失败: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """默认搜索引擎配置"""
        return {
            'redis': {
                'host': 'localhost',
                'port': 6379
            },
            'index': {
                'path': 'indexes/logs',
                'max_length': 1000000,
                'auto_commit': True
            },
            'search': {
                'default_operator': 'AND',
                'fuzzy_search': True,
                'spell_check': True,
                'cache_results': True,
                'cache_ttl': 3600  # 1小时
            },
            'performance': {
                'batch_size': 1000,
                'max_results': 10000,
                'timeout': 30
            }
        }
    
    def _setup_whoosh_index(self):
        """设置Whoosh索引"""
        try:
            # 创建索引目录
            index_dir = self.config['index']['path']
            os.makedirs(index_dir, exist_ok=True)
            
            # 定义模式
            self.schema = Schema(
                id=STORED(),
                timestamp=DATETIME(stored=True),
                level=KEYWORD(stored=True),
                service=KEYWORD(stored=True),
                host=KEYWORD(stored=True),
                pid=NUMERIC(stored=True),
                thread=TEXT(stored=True),
                logger_name=TEXT(stored=True),
                message=TEXT(analyzer=StemmingAnalyzer(), stored=True),
                exception=TEXT(stored=True),
                stack_trace=TEXT(stored=True),
                source_file=TEXT(stored=True),
                source_line=NUMERIC(stored=True),
                custom_fields=STORED()
            )
            
            # 创建或打开索引
            if not index.exists_in(index_dir):
                self.whoosh_index = index.create_in(index_dir, self.schema)
            else:
                self.whoosh_index = index.open_dir(index_dir)
            
            self.logger.info("Whoosh索引初始化成功")
            
        except Exception as e:
            self.logger.error(f"Whoosh索引初始化失败: {e}")
            self.whoosh_index = None
    
    def _setup_vectorizer(self):
        """设置TF-IDF向量化器"""
        try:
            self.vectorizer = TfidfVectorizer(
                max_features=10000,
                stop_words='english',
                ngram_range=(1, 2),
                min_df=2,
                max_df=0.95
            )
            self.logger.info("TF-IDF向量化器初始化成功")
        except Exception as e:
            self.logger.error(f"TF-IDF向量化器初始化失败: {e}")
            self.vectorizer = None
    
    def index_log_entry(self, log_entry_id: str, log_entry):
        """索引日志条目"""
        if not self.whoosh_index:
            return False
        
        try:
            writer = self.whoosh_index.writer()
            
            # 构建文档
            doc = {
                'id': log_entry_id,
                'timestamp': log_entry.timestamp,
                'level': log_entry.level.value,
                'service': log_entry.service,
                'host': log_entry.host,
                'pid': log_entry.pid,
                'thread': log_entry.thread,
                'logger_name': log_entry.logger_name,
                'message': log_entry.message,
                'exception': log_entry.exception or '',
                'stack_trace': log_entry.stack_trace or '',
                'source_file': log_entry.source_file or '',
                'source_line': log_entry.source_line,
                'custom_fields': json.dumps(log_entry.custom_fields)
            }
            
            # 添加文档
            writer.add_document(**doc)
            writer.commit()
            
            # 缓存到Redis
            if self.redis_client:
                cache_key = f"log:{log_entry_id}"
                self.redis_client.setex(
                    cache_key, 
                    self.config['search']['cache_ttl'], 
                    json.dumps(doc, default=str)
                )
            
            return True
            
        except Exception as e:
            self.logger.error(f"索引日志条目失败: {e}")
            return False
    
    def search(self, query: SearchQuery) -> SearchResult:
        """执行搜索"""
        start_time = time.time()
        
        # 检查缓存
        if self.config['search']['cache_results']:
            cache_key = self._get_cache_key(query)
            cached_result = self._get_cached_result(cache_key)
            if cached_result:
                cached_result.search_time = time.time() - start_time
                return cached_result
        
        # 执行搜索
        if self.whoosh_index:
            result = self._whoosh_search(query)
        else:
            result = self._fallback_search(query)
        
        result.search_time = time.time() - start_time
        result.query = query
        
        # 缓存结果
        if self.config['search']['cache_results']:
            self._cache_result(cache_key, result)
        
        return result
    
    def _whoosh_search(self, query: SearchQuery) -> SearchResult:
        """Whoosh搜索实现"""
        try:
            with self.whoosh_index.searcher() as searcher:
                # 构建查询
                parser = MultifieldParser(query.fields, self.schema, group=OrGroup)
                whoosh_query = parser.parse(query.query_text)
                
                # 应用过滤器
                filters = self._build_filters(query.filters, query.time_range)
                
                # 执行搜索
                results = searcher.search(
                    whoosh_query,
                    limit=query.limit,
                    sortedby=query.sort_by,
                    reverse=(query.sort_order == 'desc'),
                    filter=filters
                )
                
                # 转换结果
                search_results = []
                for hit in results:
                    search_results.append(hit.fields())
                
                # 构建分面
                facets = self._build_facets(results, query)
                
                # 构建聚合
                aggregations = self._build_aggregations(results, query)
                
                return SearchResult(
                    total_count=results.scored_length(),
                    results=search_results,
                    facets=facets,
                    aggregations=aggregations
                )
                
        except Exception as e:
            self.logger.error(f"Whoosh搜索失败: {e}")
            return SearchResult(total_count=0, results=[])
    
    def _fallback_search(self, query: SearchQuery) -> SearchResult:
        """回退搜索实现（使用Redis）"""
        if not self.redis_client:
            return SearchResult(total_count=0, results=[])
        
        try:
            # 简单的字符串匹配搜索
            pattern = re.compile(query.query_text, re.IGNORECASE)
            search_results = []
            
            # 扫描缓存的日志条目
            for key in self.redis_client.keys("log:*"):
                log_data = self.redis_client.get(key)
                if log_data:
                    log_doc = json.loads(log_data)
                    
                    # 检查是否匹配查询
                    if self._matches_query(log_doc, query, pattern):
                        search_results.append(log_doc)
            
            # 应用时间范围过滤
            if query.time_range:
                start_time, end_time = query.time_range
                search_results = [
                    doc for doc in search_results
                    if start_time <= datetime.fromisoformat(doc['timestamp']) <= end_time
                ]
            
            # 排序
            search_results.sort(
                key=lambda x: x.get(query.sort_by, ''),
                reverse=(query.sort_order == 'desc')
            )
            
            # 分页
            offset = query.offset
            limit = query.limit
            paginated_results = search_results[offset:offset + limit]
            
            return SearchResult(
                total_count=len(search_results),
                results=paginated_results
            )
            
        except Exception as e:
            self.logger.error(f"回退搜索失败: {e}")
            return SearchResult(total_count=0, results=[])
    
    def _build_filters(self, filters: Dict[str, Any], 
                      time_range: Optional[Tuple[datetime, datetime]]) -> Optional:
        """构建Whoosh过滤器"""
        from whoosh.query import And, Term, Range
        
        filter_queries = []
        
        # 添加字段过滤器
        for field, value in filters.items():
            if field in self.schema:
                if isinstance(value, list):
                    filter_queries.append(Or([Term(field, v) for v in value]))
                else:
                    filter_queries.append(Term(field, value))
        
        # 添加时间范围过滤器
        if time_range:
            start_time, end_time = time_range
            filter_queries.append(Range('timestamp', start_time, end_time))
        
        return And(filter_queries) if filter_queries else None
    
    def _matches_query(self, log_doc: Dict[str, Any], query: SearchQuery, 
                      pattern: re.Pattern) -> bool:
        """检查文档是否匹配查询"""
        # 检查字段匹配
        for field in query.fields:
            if field in log_doc:
                value = str(log_doc[field])
                if pattern.search(value):
                    return True
        
        return False
    
    def _build_facets(self, results, query: SearchQuery) -> Dict[str, Any]:
        """构建分面统计"""
        facets = {}
        
        # 统计各字段的值分布
        for field in ['level', 'service', 'host']:
            if field in self.schema:
                field_counts = Counter()
                for hit in results:
                    if field in hit.fields():
                        field_counts[hit[field]] += 1
                facets[field] = dict(field_counts.most_common(20))
        
        return facets
    
    def _build_aggregations(self, results, query: SearchQuery) -> Dict[str, Any]:
        """构建聚合统计"""
        aggregations = {}
        
        # 时间聚合（按小时统计）
        if 'timestamp' in self.schema:
            time_buckets = defaultdict(int)
            for hit in results:
                if 'timestamp' in hit.fields():
                    timestamp = hit['timestamp']
                    hour_bucket = timestamp.replace(minute=0, second=0, microsecond=0)
                    time_buckets[hour_bucket] += 1
            
            aggregations['time_distribution'] = {
                k.isoformat(): v for k, v in sorted(time_buckets.items())
            }
        
        return aggregations
    
    def _get_cache_key(self, query: SearchQuery) -> str:
        """生成缓存键"""
        query_dict = query.to_dict()
        return f"search:{hash(json.dumps(query_dict, sort_keys=True))}"
    
    def _get_cached_result(self, cache_key: str) -> Optional[SearchResult]:
        """获取缓存结果"""
        if self.redis_client:
            try:
                cached_data = self.redis_client.get(cache_key)
                if cached_data:
                    result_dict = json.loads(cached_data)
                    return SearchResult(**result_dict)
            except Exception as e:
                self.logger.debug(f"获取缓存结果失败: {e}")
        return None
    
    def _cache_result(self, cache_key: str, result: SearchResult):
        """缓存搜索结果"""
        if self.redis_client:
            try:
                result_dict = result.to_dict()
                self.redis_client.setex(
                    cache_key,
                    self.config['search']['cache_ttl'],
                    json.dumps(result_dict, default=str)
                )
            except Exception as e:
                self.logger.debug(f"缓存结果失败: {e}")
    
    def suggest_completions(self, partial_query: str, field: str = 'message') -> List[str]:
        """查询建议和自动完成"""
        if not self.whoosh_index:
            return []
        
        try:
            with self.whoosh_index.searcher() as searcher:
                # 获取字段的词项
                field_reader = searcher.reader()
                terms = field_reader.terms()
                
                # 查找匹配的词项
                suggestions = []
                for term, freq in terms:
                    if term.startswith(partial_query.lower()) and freq > 1:
                        suggestions.append((term, freq))
                
                # 按频率排序并返回前10个
                suggestions.sort(key=lambda x: x[1], reverse=True)
                return [term for term, freq in suggestions[:10]]
                
        except Exception as e:
            self.logger.error(f"查询建议失败: {e}")
            return []
    
    def find_similar_logs(self, log_entry, top_k: int = 10) -> List[Tuple[str, float]]:
        """查找相似日志"""
        if not self.vectorizer:
            return []
        
        try:
            # 获取所有日志消息
            all_messages = []
            log_ids = []
            
            if self.redis_client:
                for key in self.redis_client.keys("log:*"):
                    log_data = self.redis_client.get(key)
                    if log_data:
                        log_doc = json.loads(log_data)
                        all_messages.append(log_doc.get('message', ''))
                        log_ids.append(log_doc.get('id', ''))
            
            if not all_messages:
                return []
            
            # 向量化
            tfidf_matrix = self.vectorizer.fit_transform(all_messages)
            
            # 向量化查询消息
            query_vector = self.vectorizer.transform([log_entry.message])
            
            # 计算相似度
            similarities = cosine_similarity(query_vector, tfidf_matrix).flatten()
            
            # 获取最相似的日志
            similar_indices = similarities.argsort()[-top_k-1:-1][::-1]
            
            results = []
            for idx in similar_indices:
                if idx < len(log_ids):
                    similarity_score = similarities[idx]
                    if similarity_score > 0.1:  # 相似度阈值
                        results.append((log_ids[idx], float(similarity_score)))
            
            return results
            
        except Exception as e:
            self.logger.error(f"相似日志查找失败: {e}")
            return []
    
    def get_search_stats(self) -> Dict[str, Any]:
        """获取搜索统计"""
        stats = {
            'index_size': 0,
            'cached_queries': 0,
            'cache_hit_rate': 0.0,
            'avg_search_time': 0.0,
            'popular_queries': []
        }
        
        # 索引大小
        if self.whoosh_index:
            try:
                with self.whoosh_index.searcher() as searcher:
                    stats['index_size'] = searcher.doc_count()
            except Exception:
                pass
        
        # 缓存统计
        if self.redis_client:
            try:
                stats['cached_queries'] = len(self.redis_client.keys("search:*"))
                stats['cache_hit_rate'] = self._calculate_cache_hit_rate()
            except Exception:
                pass
        
        return stats
    
    def _calculate_cache_hit_rate(self) -> float:
        """计算缓存命中率"""
        # 这里可以实现更复杂的缓存命中率计算
        # 简化实现，返回一个估算值
        return 0.75
    
    def optimize_index(self):
        """优化索引"""
        if self.whoosh_index:
            try:
                self.whoosh_index.optimize()
                self.logger.info("索引优化完成")
            except Exception as e:
                self.logger.error(f"索引优化失败: {e}")
    
    def clear_cache(self):
        """清除缓存"""
        if self.redis_client:
            try:
                self.redis_client.delete(*self.redis_client.keys("search:*"))
                self.logger.info("搜索缓存已清除")
            except Exception as e:
                self.logger.error(f"清除缓存失败: {e}")

class LogQueryOptimizer:
    """日志查询优化器"""
    
    def __init__(self, search_engine: LogSearchEngine):
        self.search_engine = search_engine
        self.logger = logging.getLogger(__name__)
        self.query_patterns = {}
        self.performance_stats = defaultdict(list)
    
    def optimize_query(self, query: SearchQuery) -> SearchQuery:
        """优化查询"""
        optimized_query = query
        
        # 1. 查询重写
        optimized_query = self._rewrite_query(optimized_query)
        
        # 2. 字段选择优化
        optimized_query = self._optimize_field_selection(optimized_query)
        
        # 3. 时间范围优化
        optimized_query = self._optimize_time_range(optimized_query)
        
        # 4. 限制优化
        optimized_query = self._optimize_limits(optimized_query)
        
        return optimized_query
    
    def _rewrite_query(self, query: SearchQuery) -> SearchQuery:
        """查询重写"""
        # 简单的查询重写规则
        rewritten_text = query.query_text
        
        # 扩展常见缩写
        replacements = {
            'err': 'error',
            'warn': 'warning',
            'info': 'information',
            'db': 'database',
            'api': 'application'
        }
        
        for abbrev, full in replacements.items():
            rewritten_text = re.sub(rf'\b{abbrev}\b', full, rewritten_text, flags=re.IGNORECASE)
        
        if rewritten_text != query.query_text:
            query.query_text = rewritten_text
            self.logger.debug(f"查询重写: {query.query_text}")
        
        return query
    
    def _optimize_field_selection(self, query: SearchQuery) -> SearchQuery:
        """字段选择优化"""
        # 如果查询包含特定服务，优先搜索服务字段
        if 'service:' in query.query_text:
            if 'service' not in query.fields:
                query.fields.insert(0, 'service')
        
        # 如果查询包含特定级别，优先搜索级别字段
        if any(level in query.query_text.lower() for level in ['error', 'warning', 'info']):
            if 'level' not in query.fields:
                query.fields.insert(0, 'level')
        
        return query
    
    def _optimize_time_range(self, query: SearchQuery) -> SearchQuery:
        """时间范围优化"""
        if not query.time_range:
            # 如果没有指定时间范围，限制为最近24小时
            end_time = datetime.now()
            start_time = end_time - timedelta(hours=24)
            query.time_range = (start_time, end_time)
        
        return query
    
    def _optimize_limits(self, query: SearchQuery) -> SearchQuery:
        """限制优化"""
        # 如果查询没有限制结果数量，设置合理的默认值
        if query.limit > self.search_engine.config['performance']['max_results']:
            query.limit = self.search_engine.config['performance']['max_results']
        
        return query
    
    def analyze_query_performance(self, query: SearchQuery, execution_time: float):
        """分析查询性能"""
        query_signature = self._get_query_signature(query)
        self.performance_stats[query_signature].append(execution_time)
        
        # 如果某个查询频繁且慢，建议优化
        if len(self.performance_stats[query_signature]) > 10:
            avg_time = statistics.mean(self.performance_stats[query_signature])
            if avg_time > 5.0:  # 5秒阈值
                self._suggest_optimization(query_signature, avg_time)
    
    def _get_query_signature(self, query: SearchQuery) -> str:
        """获取查询签名"""
        return f"{query.query_text}:{':'.join(query.fields)}"
    
    def _suggest_optimization(self, query_signature: str, avg_time: float):
        """建议优化"""
        self.logger.warning(f"查询性能较差: {query_signature}, 平均执行时间: {avg_time:.2f}秒")
        # 这里可以实现更具体的优化建议
    
    def get_optimization_recommendations(self) -> List[str]:
        """获取优化建议"""
        recommendations = []
        
        # 分析慢查询
        slow_queries = [
            signature for signature, times in self.performance_stats.items()
            if len(times) > 5 and statistics.mean(times) > 3.0
        ]
        
        if slow_queries:
            recommendations.append(f"发现 {len(slow_queries)} 个慢查询，建议优化索引或查询结构")
        
        # 检查缓存使用情况
        stats = self.search_engine.get_search_stats()
        if stats['cache_hit_rate'] < 0.5:
            recommendations.append("缓存命中率较低，建议增加缓存时间或优化查询模式")
        
        return recommendations

def main():
    """主函数 - 测试搜索引擎"""
    from log_parser import ParsedLogEntry, LogLevel
    
    # 创建搜索引擎
    search_engine = LogSearchEngine()
    optimizer = LogQueryOptimizer(search_engine)
    
    # 创建测试日志条目
    test_logs = [
        ParsedLogEntry(
            timestamp=datetime.now() - timedelta(minutes=i),
            level=LogLevel.ERROR,
            service='api',
            host='server1',
            message='Database connection timeout occurred',
            custom_fields={'response_time': 5000}
        ),
        ParsedLogEntry(
            timestamp=datetime.now() - timedelta(minutes=i+1),
            level=LogLevel.WARNING,
            service='database',
            host='server2',
            message='High memory usage detected',
            custom_fields={'memory_usage': 85}
        )
    ]
    
    # 索引日志
    for i, log_entry in enumerate(test_logs):
        search_engine.index_log_entry(f"log_{i}", log_entry)
    
    # 执行搜索
    query = SearchQuery(
        query_text="error OR timeout",
        fields=['message', 'level'],
        time_range=(datetime.now() - timedelta(hours=1), datetime.now())
    )
    
    # 优化查询
    optimized_query = optimizer.optimize_query(query)
    
    # 执行搜索
    start_time = time.time()
    results = search_engine.search(optimized_query)
    execution_time = time.time() - start_time
    
    # 分析性能
    optimizer.analyze_query_performance(optimized_query, execution_time)
    
    print(f"搜索结果: {results.total_count} 条记录")
    print(f"执行时间: {execution_time:.3f} 秒")
    
    # 获取优化建议
    recommendations = optimizer.get_optimization_recommendations()
    if recommendations:
        print("优化建议:")
        for rec in recommendations:
            print(f"- {rec}")

if __name__ == "__main__":
    main()
