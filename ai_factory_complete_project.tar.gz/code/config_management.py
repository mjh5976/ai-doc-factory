"""
A/B测试配置和参数管理模块
提供完整的实验配置管理、参数调优、版本控制和审计功能
"""

import json
import yaml
import os
import logging
import hashlib
import copy
import numpy as np
from typing import Dict, List, Optional, Any, Union, Tuple
from dataclasses import dataclass, asdict, field
from datetime import datetime
from pathlib import Path
from enum import Enum
import jsonschema
from abc import ABC, abstractmethod
import threading
import time

# 配置日志
logger = logging.getLogger(__name__)

class ConfigStatus(Enum):
    """配置状态枚举"""
    DRAFT = "draft"
    ACTIVE = "active"
    PAUSED = "paused"
    ARCHIVED = "archived"

class ParameterType(Enum):
    """参数类型枚举"""
    CONTINUOUS = "continuous"
    DISCRETE = "discrete"
    CATEGORICAL = "categorical"
    BOOLEAN = "boolean"

@dataclass
class ParameterConfig:
    """参数配置"""
    name: str
    param_type: ParameterType
    value: Any
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    step: Optional[float] = None
    choices: Optional[List[Any]] = None
    description: str = ""
    is_tunable: bool = True
    constraints: Optional[Dict[str, Any]] = None

@dataclass
class ExperimentConfig:
    """实验配置"""
    name: str
    description: str
    config_id: str
    version: str
    status: ConfigStatus
    created_at: datetime
    updated_at: datetime
    created_by: str
    
    # 基础配置
    model_versions: Dict[str, str]  # 变体到模型版本的映射
    traffic_allocation: Dict[str, float]  # 变体到流量比例的映射
    sample_size_per_group: int
    confidence_level: float
    statistical_power: float
    
    # 参数配置
    parameters: Dict[str, ParameterConfig] = field(default_factory=dict)
    
    # 高级配置
    stratification_vars: Optional[List[str]] = None
    filters: Optional[Dict[str, Any]] = None
    success_criteria: Optional[Dict[str, Any]] = None
    stopping_rules: Optional[Dict[str, Any]] = None
    
    # 元数据
    tags: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ParameterSearchResult:
    """参数搜索结果"""
    parameter_name: str
    search_space: Dict[str, Any]
    best_value: Any
    best_score: float
    search_history: List[Dict[str, Any]]
    convergence_info: Dict[str, Any]

class ConfigValidator:
    """配置验证器"""
    
    def __init__(self):
        self.schema = self._create_schema()
    
    def _create_schema(self) -> Dict[str, Any]:
        """创建配置验证模式"""
        return {
            "type": "object",
            "required": ["name", "description", "config_id", "version", "model_versions", "traffic_allocation"],
            "properties": {
                "name": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 100
                },
                "description": {
                    "type": "string",
                    "maxLength": 1000
                },
                "config_id": {
                    "type": "string",
                    "pattern": "^[a-zA-Z0-9_-]+$"
                },
                "version": {
                    "type": "string",
                    "pattern": "^\\d+\\.\\d+\\.\\d+$"
                },
                "sample_size_per_group": {
                    "type": "integer",
                    "minimum": 100,
                    "maximum": 1000000
                },
                "confidence_level": {
                    "type": "number",
                    "minimum": 0.5,
                    "maximum": 0.99
                },
                "statistical_power": {
                    "type": "number",
                    "minimum": 0.5,
                    "maximum": 0.99
                },
                "traffic_allocation": {
                    "type": "object",
                    "patternProperties": {
                        "^[a-zA-Z0-9_-]+$": {
                            "type": "number",
                            "minimum": 0.0,
                            "maximum": 1.0
                        }
                    },
                    "minProperties": 2
                },
                "model_versions": {
                    "type": "object",
                    "patternProperties": {
                        "^[a-zA-Z0-9_-]+$": {
                            "type": "string",
                            "pattern": "^[a-zA-Z0-9._-]+$"
                        }
                    },
                    "minProperties": 2
                }
            }
        }
    
    def validate_config(self, config: ExperimentConfig) -> Tuple[bool, List[str]]:
        """验证配置"""
        errors = []
        
        try:
            # 使用jsonschema验证
            config_dict = asdict(config)
            jsonschema.validate(config_dict, self.schema)
            
            # 验证流量分配
            total_allocation = sum(config.traffic_allocation.values())
            if abs(total_allocation - 1.0) > 1e-6:
                errors.append(f"流量分配总和必须为1.0，当前为{total_allocation}")
            
            # 验证变体数量一致性
            if len(config.model_versions) != len(config.traffic_allocation):
                errors.append("模型版本和流量分配的变体数量不一致")
            
            # 验证参数配置
            for param_name, param_config in config.parameters.items():
                param_errors = self._validate_parameter(param_config)
                errors.extend([f"参数 {param_name}: {error}" for error in param_errors])
            
            # 验证成功标准
            if config.success_criteria:
                success_errors = self._validate_success_criteria(config.success_criteria)
                errors.extend(success_errors)
            
        except jsonschema.ValidationError as e:
            errors.append(f"配置验证失败: {e.message}")
        except Exception as e:
            errors.append(f"配置验证异常: {str(e)}")
        
        return len(errors) == 0, errors
    
    def _validate_parameter(self, param: ParameterConfig) -> List[str]:
        """验证参数配置"""
        errors = []
        
        if param.param_type == ParameterType.CONTINUOUS:
            if param.min_value is None or param.max_value is None:
                errors.append("连续参数必须指定最小值和最大值")
            elif param.min_value >= param.max_value:
                errors.append("连续参数的最小值必须小于最大值")
            if param.value < param.min_value or param.value > param.max_value:
                errors.append(f"参数值 {param.value} 超出范围 [{param.min_value}, {param.max_value}]")
        
        elif param.param_type == ParameterType.DISCRETE:
            if param.step is None or param.step <= 0:
                errors.append("离散参数必须指定正数步长")
            if param.min_value is not None and param.value < param.min_value:
                errors.append(f"参数值 {param.value} 小于最小值 {param.min_value}")
            if param.max_value is not None and param.value > param.max_value:
                errors.append(f"参数值 {param.value} 大于最大值 {param.max_value}")
        
        elif param.param_type == ParameterType.CATEGORICAL:
            if param.choices is None or len(param.choices) == 0:
                errors.append("分类参数必须指定选择列表")
            elif param.value not in param.choices:
                errors.append(f"参数值 {param.value} 不在选择列表 {param.choices} 中")
        
        elif param.param_type == ParameterType.BOOLEAN:
            if not isinstance(param.value, bool):
                errors.append("布尔参数的值必须是布尔类型")
        
        return errors
    
    def _validate_success_criteria(self, criteria: Dict[str, Any]) -> List[str]:
        """验证成功标准"""
        errors = []
        
        if 'primary_metric' not in criteria:
            errors.append("成功标准必须指定主要指标")
        
        if 'improvement_threshold' not in criteria:
            errors.append("成功标准必须指定改进阈值")
        
        improvement = criteria.get('improvement_threshold', 0)
        if not isinstance(improvement, (int, float)) or improvement <= 0:
            errors.append("改进阈值必须为正数")
        
        return errors

class ParameterOptimizer:
    """参数优化器"""
    
    def __init__(self, optimization_method: str = "bayesian"):
        self.optimization_method = optimization_method
        self.logger = logging.getLogger(__name__)
    
    def optimize_parameters(self,
                          config: ExperimentConfig,
                          objective_function: callable,
                          max_iterations: int = 100,
                          convergence_threshold: float = 1e-6) -> ParameterSearchResult:
        """优化参数"""
        
        tunable_params = {name: param for name, param in config.parameters.items() 
                         if param.is_tunable}
        
        if not tunable_params:
            raise ValueError("没有可调参数")
        
        search_result = ParameterSearchResult(
            parameter_name="multi_param",
            search_space={name: self._get_param_bounds(param) for name, param in tunable_params.items()},
            best_value=None,
            best_score=float('-inf'),
            search_history=[],
            convergence_info={}
        )
        
        if self.optimization_method == "bayesian":
            return self._bayesian_optimization(config, objective_function, max_iterations, search_result)
        elif self.optimization_method == "random":
            return self._random_search(config, objective_function, max_iterations, search_result)
        elif self.optimization_method == "grid":
            return self._grid_search(config, objective_function, search_result)
        else:
            raise ValueError(f"不支持的优化方法: {self.optimization_method}")
    
    def _bayesian_optimization(self,
                             config: ExperimentConfig,
                             objective_function: callable,
                             max_iterations: int,
                             search_result: ParameterSearchResult) -> ParameterSearchResult:
        """贝叶斯优化（简化实现）"""
        
        # 简化的贝叶斯优化实现
        # 实际中应该使用scikit-optimize或类似库
        
        tunable_params = {name: param for name, param in config.parameters.items() 
                         if param.is_tunable}
        
        best_score = float('-inf')
        best_params = {}
        
        # 初始随机采样
        n_initial = min(10, max_iterations // 4)
        for i in range(n_initial):
            params = self._sample_random_params(tunable_params)
            score = objective_function(params)
            
            search_result.search_history.append({
                'iteration': i,
                'params': params,
                'score': score
            })
            
            if score > best_score:
                best_score = score
                best_params = params.copy()
        
        # 迭代优化
        for i in range(n_initial, max_iterations):
            # 简化的获取函数（实际中应该使用高斯过程）
            params = self._suggest_next_params(tunable_params, search_result.search_history)
            score = objective_function(params)
            
            search_result.search_history.append({
                'iteration': i,
                'params': params,
                'score': score
            })
            
            if score > best_score:
                best_score = score
                best_params = params.copy()
            
            # 检查收敛
            if len(search_result.search_history) >= 10:
                recent_scores = [h['score'] for h in search_result.search_history[-10:]]
                if max(recent_scores) - min(recent_scores) < convergence_threshold:
                    search_result.convergence_info['converged'] = True
                    search_result.convergence_info['iterations'] = i + 1
                    break
        
        search_result.best_value = best_params
        search_result.best_score = best_score
        
        return search_result
    
    def _random_search(self,
                      config: ExperimentConfig,
                      objective_function: callable,
                      max_iterations: int,
                      search_result: ParameterSearchResult) -> ParameterSearchResult:
        """随机搜索"""
        
        tunable_params = {name: param for name, param in config.parameters.items() 
                         if param.is_tunable}
        
        best_score = float('-inf')
        best_params = {}
        
        for i in range(max_iterations):
            params = self._sample_random_params(tunable_params)
            score = objective_function(params)
            
            search_result.search_history.append({
                'iteration': i,
                'params': params,
                'score': score
            })
            
            if score > best_score:
                best_score = score
                best_params = params.copy()
        
        search_result.best_value = best_params
        search_result.best_score = best_score
        
        return search_result
    
    def _grid_search(self,
                    config: ExperimentConfig,
                    objective_function: callable,
                    search_result: ParameterSearchResult) -> ParameterSearchResult:
        """网格搜索"""
        
        tunable_params = {name: param for name, param in config.parameters.items() 
                         if param.is_tunable}
        
        # 生成网格点
        param_grids = self._generate_param_grids(tunable_params)
        
        best_score = float('-inf')
        best_params = {}
        
        total_combinations = 1
        for grid in param_grids.values():
            total_combinations *= len(grid)
        
        if total_combinations > 1000:
            self.logger.warning(f"网格搜索组合数过多 ({total_combinations})，限制为1000个")
            total_combinations = 1000
        
        # 随机采样网格点
        import itertools
        all_combinations = list(itertools.product(*param_grids.values()))
        
        if len(all_combinations) > 1000:
            import random
            random.shuffle(all_combinations)
            all_combinations = all_combinations[:1000]
        
        param_names = list(param_grids.keys())
        
        for i, combination in enumerate(all_combinations):
            params = dict(zip(param_names, combination))
            score = objective_function(params)
            
            search_result.search_history.append({
                'iteration': i,
                'params': params,
                'score': score
            })
            
            if score > best_score:
                best_score = score
                best_params = params.copy()
        
        search_result.best_value = best_params
        search_result.best_score = best_score
        
        return search_result
    
    def _get_param_bounds(self, param: ParameterConfig) -> Dict[str, Any]:
        """获取参数边界"""
        if param.param_type == ParameterType.CONTINUOUS:
            return {'min': param.min_value, 'max': param.max_value, 'type': 'continuous'}
        elif param.param_type == ParameterType.DISCRETE:
            return {'min': param.min_value, 'max': param.max_value, 'step': param.step, 'type': 'discrete'}
        elif param.param_type == ParameterType.CATEGORICAL:
            return {'choices': param.choices, 'type': 'categorical'}
        elif param.param_type == ParameterType.BOOLEAN:
            return {'choices': [True, False], 'type': 'boolean'}
    
    def _sample_random_params(self, tunable_params: Dict[str, ParameterConfig]) -> Dict[str, Any]:
        """随机采样参数"""
        params = {}
        
        for name, param in tunable_params.items():
            if param.param_type == ParameterType.CONTINUOUS:
                params[name] = np.random.uniform(param.min_value, param.max_value)
            elif param.param_type == ParameterType.DISCRETE:
                if param.step is not None:
                    n_steps = int((param.max_value - param.min_value) / param.step) + 1
                    step_idx = np.random.randint(0, n_steps)
                    params[name] = param.min_value + step_idx * param.step
                else:
                    params[name] = np.random.randint(param.min_value, param.max_value + 1)
            elif param.param_type == ParameterType.CATEGORICAL:
                params[name] = np.random.choice(param.choices)
            elif param.param_type == ParameterType.BOOLEAN:
                params[name] = np.random.choice([True, False])
        
        return params
    
    def _suggest_next_params(self, tunable_params: Dict[str, ParameterConfig], 
                           history: List[Dict[str, Any]]) -> Dict[str, Any]:
        """建议下一个参数组合（简化实现）"""
        # 简化实现：基于历史最佳结果添加随机扰动
        if not history:
            return self._sample_random_params(tunable_params)
        
        best_entry = max(history, key=lambda x: x['score'])
        best_params = best_entry['params'].copy()
        
        # 添加随机扰动
        for name, param in tunable_params.items():
            if param.param_type == ParameterType.CONTINUOUS:
                noise = np.random.normal(0, (param.max_value - param.min_value) * 0.1)
                best_params[name] = np.clip(best_params[name] + noise, 
                                          param.min_value, param.max_value)
            elif param.param_type == ParameterType.DISCRETE:
                if param.step is not None:
                    noise = int(np.random.normal(0, 2))
                    step_idx = int((best_params[name] - param.min_value) / param.step) + noise
                    step_idx = max(0, step_idx)
                    max_steps = int((param.max_value - param.min_value) / param.step)
                    step_idx = min(step_idx, max_steps)
                    best_params[name] = param.min_value + step_idx * param.step
        
        return best_params
    
    def _generate_param_grids(self, tunable_params: Dict[str, ParameterConfig]) -> Dict[str, List[Any]]:
        """生成参数网格"""
        grids = {}
        
        for name, param in tunable_params.items():
            if param.param_type == ParameterType.CONTINUOUS:
                # 为连续参数生成网格点
                n_points = min(10, max(2, int((param.max_value - param.min_value) / param.step) + 1))
                grids[name] = np.linspace(param.min_value, param.max_value, n_points).tolist()
            elif param.param_type == ParameterType.DISCRETE:
                if param.step is not None:
                    n_points = int((param.max_value - param.min_value) / param.step) + 1
                    grids[name] = [param.min_value + i * param.step for i in range(n_points)]
                else:
                    grids[name] = list(range(int(param.min_value), int(param.max_value) + 1))
            elif param.param_type == ParameterType.CATEGORICAL:
                grids[name] = param.choices
            elif param.param_type == ParameterType.BOOLEAN:
                grids[name] = [True, False]
        
        return grids

class ConfigManager:
    """配置管理器"""
    
    def __init__(self, storage_path: str = "configs/"):
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self.validator = ConfigValidator()
        self.optimizer = ParameterOptimizer()
        self.configs: Dict[str, ExperimentConfig] = {}
        self.config_versions: Dict[str, List[str]] = {}  # config_id -> versions
        self.lock = threading.RLock()
        
        # 加载现有配置
        self._load_configs()
    
    def create_config(self, config: ExperimentConfig) -> bool:
        """创建配置"""
        with self.lock:
            # 验证配置
            is_valid, errors = self.validator.validate_config(config)
            if not is_valid:
                error_msg = "; ".join(errors)
                raise ValueError(f"配置验证失败: {error_msg}")
            
            # 检查配置ID是否已存在
            if config.config_id in self.configs:
                raise ValueError(f"配置ID {config.config_id} 已存在")
            
            # 保存配置
            self.configs[config.config_id] = config
            if config.config_id not in self.config_versions:
                self.config_versions[config.config_id] = []
            self.config_versions[config.config_id].append(config.version)
            
            # 保存到文件
            self._save_config_to_file(config)
            
            logger.info(f"创建配置成功: {config.config_id} v{config.version}")
            return True
    
    def update_config(self, config_id: str, updated_config: ExperimentConfig) -> bool:
        """更新配置"""
        with self.lock:
            if config_id not in self.configs:
                raise ValueError(f"配置 {config_id} 不存在")
            
            # 验证更新后的配置
            is_valid, errors = self.validator.validate_config(updated_config)
            if not is_valid:
                error_msg = "; ".join(errors)
                raise ValueError(f"配置验证失败: {error_msg}")
            
            # 更新配置
            self.configs[config_id] = updated_config
            if config_id not in self.config_versions:
                self.config_versions[config_id] = []
            if updated_config.version not in self.config_versions[config_id]:
                self.config_versions[config_id].append(updated_config.version)
            
            # 保存到文件
            self._save_config_to_file(updated_config)
            
            logger.info(f"更新配置成功: {config_id} v{updated_config.version}")
            return True
    
    def get_config(self, config_id: str, version: Optional[str] = None) -> Optional[ExperimentConfig]:
        """获取配置"""
        with self.lock:
            if config_id not in self.configs:
                return None
            
            if version is None:
                return self.configs[config_id]
            
            # 从文件加载指定版本
            config_file = self.storage_path / f"{config_id}_{version}.json"
            if config_file.exists():
                return self._load_config_from_file(config_file)
            
            return None
    
    def list_configs(self, status: Optional[ConfigStatus] = None) -> List[ExperimentConfig]:
        """列出配置"""
        with self.lock:
            configs = list(self.configs.values())
            if status:
                configs = [config for config in configs if config.status == status]
            return configs
    
    def delete_config(self, config_id: str) -> bool:
        """删除配置"""
        with self.lock:
            if config_id not in self.configs:
                return False
            
            # 只能删除草稿状态的配置
            if self.configs[config_id].status != ConfigStatus.DRAFT:
                raise ValueError("只能删除草稿状态的配置")
            
            # 删除文件
            for version in self.config_versions.get(config_id, []):
                config_file = self.storage_path / f"{config_id}_{version}.json"
                if config_file.exists():
                    config_file.unlink()
            
            # 删除内存中的配置
            del self.configs[config_id]
            del self.config_versions[config_id]
            
            logger.info(f"删除配置成功: {config_id}")
            return True
    
    def optimize_config_parameters(self,
                                 config_id: str,
                                 objective_function: callable,
                                 optimization_method: str = "bayesian",
                                 max_iterations: int = 100) -> ParameterSearchResult:
        """优化配置参数"""
        with self.lock:
            if config_id not in self.configs:
                raise ValueError(f"配置 {config_id} 不存在")
            
            config = self.configs[config_id]
            
            # 创建优化器
            optimizer = ParameterOptimizer(optimization_method)
            
            # 执行优化
            search_result = optimizer.optimize_parameters(
                config, objective_function, max_iterations
            )
            
            # 更新配置参数
            if search_result.best_value:
                for param_name, value in search_result.best_value.items():
                    if param_name in config.parameters:
                        config.parameters[param_name].value = value
            
            logger.info(f"参数优化完成: {config_id}, 最佳分数: {search_result.best_score:.4f}")
            
            return search_result
    
    def clone_config(self, config_id: str, new_config_id: str, 
                    new_version: str = None) -> ExperimentConfig:
        """克隆配置"""
        with self.lock:
            if config_id not in self.configs:
                raise ValueError(f"配置 {config_id} 不存在")
            
            original_config = self.configs[config_id]
            
            # 创建新配置
            cloned_config = copy.deepcopy(original_config)
            cloned_config.config_id = new_config_id
            cloned_config.version = new_version or self._generate_next_version(config_id)
            cloned_config.status = ConfigStatus.DRAFT
            cloned_config.created_at = datetime.now()
            cloned_config.updated_at = datetime.now()
            cloned_config.created_by = "clone"
            
            return cloned_config
    
    def export_config(self, config_id: str, version: Optional[str] = None, 
                     format: str = "json") -> str:
        """导出配置"""
        config = self.get_config(config_id, version)
        if config is None:
            raise ValueError(f"配置 {config_id} 不存在")
        
        config_dict = asdict(config)
        
        if format.lower() == "json":
            return json.dumps(config_dict, ensure_ascii=False, indent=2, default=str)
        elif format.lower() == "yaml":
            return yaml.dump(config_dict, allow_unicode=True, default_flow_style=False)
        else:
            raise ValueError(f"不支持的导出格式: {format}")
    
    def import_config(self, config_data: str, format: str = "json") -> str:
        """导入配置"""
        try:
            if format.lower() == "json":
                config_dict = json.loads(config_data)
            elif format.lower() == "yaml":
                config_dict = yaml.safe_load(config_data)
            else:
                raise ValueError(f"不支持的导入格式: {format}")
            
            # 转换为ExperimentConfig对象
            config = self._dict_to_config(config_dict)
            
            # 生成配置ID（如果不存在）
            if not config.config_id:
                config.config_id = self._generate_config_id(config.name)
            
            # 生成版本号
            if not config.version:
                config.version = self._generate_next_version(config.config_id)
            
            # 创建配置
            self.create_config(config)
            
            logger.info(f"导入配置成功: {config.config_id} v{config.version}")
            return config.config_id
            
        except Exception as e:
            logger.error(f"导入配置失败: {e}")
            raise
    
    def _load_configs(self):
        """加载所有配置"""
        for config_file in self.storage_path.glob("*.json"):
            try:
                config = self._load_config_from_file(config_file)
                if config:
                    self.configs[config.config_id] = config
                    if config.config_id not in self.config_versions:
                        self.config_versions[config.config_id] = []
                    if config.version not in self.config_versions[config.config_id]:
                        self.config_versions[config.config_id].append(config.version)
            except Exception as e:
                logger.error(f"加载配置文件失败 {config_file}: {e}")
    
    def _save_config_to_file(self, config: ExperimentConfig):
        """保存配置到文件"""
        config_file = self.storage_path / f"{config.config_id}_{config.version}.json"
        config_dict = asdict(config)
        
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(config_dict, f, ensure_ascii=False, indent=2, default=str)
    
    def _load_config_from_file(self, config_file: Path) -> Optional[ExperimentConfig]:
        """从文件加载配置"""
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                config_dict = json.load(f)
            
            return self._dict_to_config(config_dict)
        except Exception as e:
            logger.error(f"加载配置文件失败 {config_file}: {e}")
            return None
    
    def _dict_to_config(self, config_dict: Dict[str, Any]) -> ExperimentConfig:
        """将字典转换为ExperimentConfig对象"""
        # 处理日期时间字段
        if 'created_at' in config_dict and isinstance(config_dict['created_at'], str):
            config_dict['created_at'] = datetime.fromisoformat(config_dict['created_at'])
        if 'updated_at' in config_dict and isinstance(config_dict['updated_at'], str):
            config_dict['updated_at'] = datetime.fromisoformat(config_dict['updated_at'])
        
        # 处理枚举字段
        if 'status' in config_dict and isinstance(config_dict['status'], str):
            config_dict['status'] = ConfigStatus(config_dict['status'])
        
        # 处理参数配置
        if 'parameters' in config_dict:
            for param_name, param_dict in config_dict['parameters'].items():
                if 'param_type' in param_dict and isinstance(param_dict['param_type'], str):
                    param_dict['param_type'] = ParameterType(param_dict['param_type'])
        
        return ExperimentConfig(**config_dict)
    
    def _generate_config_id(self, name: str) -> str:
        """生成配置ID"""
        # 基于名称生成ID
        base_id = name.lower().replace(' ', '_').replace('-', '_')
        base_id = ''.join(c for c in base_id if c.isalnum() or c in '_-')
        
        # 确保唯一性
        counter = 1
        config_id = base_id
        while config_id in self.configs:
            counter += 1
            config_id = f"{base_id}_{counter}"
        
        return config_id
    
    def _generate_next_version(self, config_id: str) -> str:
        """生成下一个版本号"""
        versions = self.config_versions.get(config_id, [])
        
        if not versions:
            return "1.0.0"
        
        # 解析最新版本
        latest_version = max(versions)
        major, minor, patch = map(int, latest_version.split('.'))
        
        # 生成新版本
        return f"{major}.{minor}.{patch + 1}"

# 使用示例和测试函数
def run_config_management_example():
    """运行配置管理示例"""
    
    # 创建配置管理器
    config_manager = ConfigManager("configs/")
    
    # 创建示例参数
    params = {
        "learning_rate": ParameterConfig(
            name="learning_rate",
            param_type=ParameterType.CONTINUOUS,
            value=0.001,
            min_value=0.0001,
            max_value=0.1,
            step=0.0001,
            description="学习率"
        ),
        "batch_size": ParameterConfig(
            name="batch_size",
            param_type=ParameterType.DISCRETE,
            value=32,
            min_value=16,
            max_value=256,
            step=16,
            description="批次大小"
        ),
        "optimizer": ParameterConfig(
            name="optimizer",
            param_type=ParameterType.CATEGORICAL,
            value="adam",
            choices=["adam", "sgd", "rmsprop"],
            description="优化器"
        ),
        "use_dropout": ParameterConfig(
            name="use_dropout",
            param_type=ParameterType.BOOLEAN,
            value=True,
            description="是否使用Dropout"
        )
    }
    
    # 创建实验配置
    config = ExperimentConfig(
        name="模型A/B测试配置",
        description="用于比较两个模型版本性能的A/B测试配置",
        config_id="model_ab_test",
        version="1.0.0",
        status=ConfigStatus.DRAFT,
        created_at=datetime.now(),
        updated_at=datetime.now(),
        created_by="admin",
        model_versions={
            "control": "model_v1.0",
            "treatment": "model_v1.1"
        },
        traffic_allocation={
            "control": 0.5,
            "treatment": 0.5
        },
        sample_size_per_group=1000,
        confidence_level=0.95,
        statistical_power=0.8,
        parameters=params,
        success_criteria={
            "primary_metric": "accuracy",
            "improvement_threshold": 0.02
        }
    )
    
    # 创建配置
    try:
        config_manager.create_config(config)
        print("配置创建成功")
    except ValueError as e:
        print(f"配置创建失败: {e}")
        return
    
    # 获取配置
    retrieved_config = config_manager.get_config("model_ab_test")
    print(f"获取配置: {retrieved_config.name}")
    
    # 优化参数（模拟目标函数）
    def objective_function(params):
        """模拟目标函数"""
        # 简化的模拟函数
        score = 0.9
        if params.get("learning_rate", 0.001) > 0.01:
            score -= 0.1
        if params.get("batch_size", 32) > 128:
            score -= 0.05
        if params.get("optimizer") == "adam":
            score += 0.05
        if params.get("use_dropout", True):
            score += 0.02
        return score + np.random.normal(0, 0.01)  # 添加噪声
    
    try:
        search_result = config_manager.optimize_config_parameters(
            "model_ab_test",
            objective_function,
            optimization_method="random",
            max_iterations=20
        )
        print(f"参数优化完成，最佳分数: {search_result.best_score:.4f}")
        print(f"最佳参数: {search_result.best_value}")
    except Exception as e:
        print(f"参数优化失败: {e}")
    
    # 克隆配置
    try:
        cloned_config = config_manager.clone_config("model_ab_test", "model_ab_test_v2")
        print(f"配置克隆成功: {cloned_config.config_id}")
    except Exception as e:
        print(f"配置克隆失败: {e}")
    
    # 导出配置
    try:
        exported_config = config_manager.export_config("model_ab_test", format="json")
        print("配置导出成功")
        print(f"导出内容长度: {len(exported_config)} 字符")
    except Exception as e:
        print(f"配置导出失败: {e}")
    
    # 列出所有配置
    all_configs = config_manager.list_configs()
    print(f"当前配置数量: {len(all_configs)}")
    
    for config in all_configs:
        print(f"  - {config.config_id} v{config.version}: {config.name}")

if __name__ == "__main__":
    run_config_management_example()