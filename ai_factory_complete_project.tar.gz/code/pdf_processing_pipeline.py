#!/usr/bin/env python3
"""
PDF解析和图像预处理主模块
整合所有功能模块，提供完整的PDF处理解决方案
"""

import os
import sys
import logging
import json
import traceback
import time
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, asdict, field
from pathlib import Path
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor
import threading

import numpy as np
import cv2
from PIL import Image

# 导入自定义模块
from pdf_parser import PDFParser, ProcessingConfig, BoundingBox, TextElement, VectorElement, ImageElement, PageData
from image_preprocessor import ImagePreprocessor, BatchImageProcessor, ProcessingResult, AdvancedImageProcessor
from data_converter import DataStandardizer, DocumentStructure, BatchDataProcessor, DataVisualizer
from batch_processor import SmartBatchProcessor, BatchConfig, Task, TaskResult
from error_handler import ErrorRecoverySystem, with_error_recovery, ErrorInfo

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@dataclass
class ProcessingPipelineConfig:
    """处理流水线配置"""
    # PDF解析配置
    pdf_max_workers: int = 4
    pdf_enable_image_extraction: bool = True
    pdf_enable_vector_extraction: bool = True
    
    # 图像预处理配置
    image_resize_factor: float = 1.5
    image_denoise_method: str = "bilateral"
    image_contrast_factor: float = 1.3
    image_enable_skew_correction: bool = True
    image_enable_line_enhancement: bool = True
    image_binarization_method: str = "adaptive"
    
    # 数据转换配置
    data_output_formats: List[str] = field(default_factory=lambda: ['json', 'csv', 'excel'])
    data_enable_visualization: bool = True
    
    # 批处理配置
    batch_max_workers: int = 4
    batch_max_queue_size: int = 100
    batch_enable_monitoring: bool = True
    batch_enable_caching: bool = True
    
    # 错误处理配置
    error_max_history: int = 1000
    error_monitoring_interval: float = 30.0
    error_auto_recovery: bool = True
    
    def to_dict(self):
        return asdict(self)


@dataclass
class ProcessingResult:
    """处理结果数据类"""
    document_id: str
    success: bool
    processing_time: float
    output_files: List[str] = field(default_factory=list)
    error_info: Optional[ErrorInfo] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self):
        return {
            'document_id': self.document_id,
            'success': self.success,
            'processing_time': self.processing_time,
            'output_files': self.output_files,
            'error_info': self.error_info.to_dict() if self.error_info else None,
            'metadata': self.metadata
        }


class PDFProcessingPipeline:
    """PDF处理流水线"""
    
    def __init__(self, config: ProcessingPipelineConfig = None):
        """
        初始化PDF处理流水线
        
        Args:
            config: 处理配置
        """
        self.config = config or ProcessingPipelineConfig()
        
        # 初始化组件
        self._initialize_components()
        
        # 流水线状态
        self.is_initialized = False
        self.processing_lock = threading.Lock()
        
        logger.info("PDF处理流水线初始化完成")
    
    def _initialize_components(self):
        """初始化组件"""
        try:
            # 错误恢复系统
            self.error_system = ErrorRecoverySystem(
                max_error_history=self.config.error_max_history,
                monitoring_interval=self.config.error_monitoring_interval
            )
            
            # PDF解析器
            pdf_config = ProcessingConfig(
                max_workers=self.config.pdf_max_workers,
                enable_image_extraction=self.config.pdf_enable_image_extraction,
                enable_vector_extraction=self.config.pdf_enable_vector_extraction
            )
            self.pdf_parser = PDFParser(
                max_workers=self.config.pdf_max_workers,
                enable_image_extraction=self.config.pdf_enable_image_extraction,
                enable_vector_extraction=self.config.pdf_enable_vector_extraction
            )
            
            # 图像预处理器
            image_config = ProcessingConfig(
                resize_factor=self.config.image_resize_factor,
                denoise_method=self.config.image_denoise_method,
                contrast_factor=self.config.image_contrast_factor,
                enable_skew_correction=self.config.image_enable_skew_correction,
                enable_line_enhancement=self.config.image_enable_line_enhancement,
                binarization_method=self.config.image_binarization_method
            )
            self.image_preprocessor = BatchImageProcessor(image_config, self.config.batch_max_workers)
            
            # 数据转换器
            self.data_converter = DataStandardizer()
            self.batch_data_processor = BatchDataProcessor(self.data_converter, self.config.batch_max_workers)
            
            # 批处理器
            batch_config = BatchConfig(
                max_workers=self.config.batch_max_workers,
                max_queue_size=self.config.batch_max_queue_size,
                enable_monitoring=self.config.batch_enable_monitoring,
                enable_caching=self.config.batch_enable_caching
            )
            self.batch_processor = SmartBatchProcessor(batch_config)
            
            # 数据可视化器
            self.data_visualizer = DataVisualizer()
            
            self.is_initialized = True
            logger.info("所有组件初始化完成")
            
        except Exception as e:
            logger.error(f"组件初始化错误: {e}")
            raise
    
    def process_pdf_file(self, pdf_path: Union[str, Path], 
                        output_dir: Union[str, Path],
                        output_formats: Optional[List[str]] = None) -> ProcessingResult:
        """
        处理单个PDF文件
        
        Args:
            pdf_path: PDF文件路径
            output_dir: 输出目录
            output_formats: 输出格式列表
            
        Returns:
            ProcessingResult: 处理结果
        """
        if not self.is_initialized:
            raise RuntimeError("流水线未初始化")
        
        start_time = time.time()
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        if output_formats is None:
            output_formats = self.config.data_output_formats
        
        try:
            with self.processing_lock:
                logger.info(f"开始处理PDF文件: {pdf_path}")
                
                # 生成文档ID
                document_id = self._generate_document_id(pdf_path)
                
                # 步骤1: PDF解析
                logger.info("步骤1: PDF解析")
                page_data_list = self.pdf_parser.parse_pdf(pdf_path)
                
                if not page_data_list:
                    raise ValueError("PDF解析失败，未找到页面数据")
                
                # 步骤2: 图像预处理
                logger.info("步骤2: 图像预处理")
                processed_images = self._preprocess_page_images(page_data_list, output_dir)
                
                # 步骤3: 数据标准化
                logger.info("步骤3: 数据标准化")
                doc_structure = self._standardize_data(page_data_list, document_id)
                
                # 步骤4: 数据转换
                logger.info("步骤4: 数据转换")
                output_files = self._convert_data(doc_structure, output_dir, output_formats)
                
                # 步骤5: 数据可视化
                if self.config.data_enable_visualization:
                    logger.info("步骤5: 数据可视化")
                    self._create_visualizations(doc_structure, output_dir)
                
                # 步骤6: 生成处理报告
                logger.info("步骤6: 生成处理报告")
                report_file = self._generate_processing_report(
                    document_id, page_data_list, doc_structure, 
                    processed_images, output_dir
                )
                output_files.append(str(report_file))
                
                processing_time = time.time() - start_time
                
                result = ProcessingResult(
                    document_id=document_id,
                    success=True,
                    processing_time=processing_time,
                    output_files=output_files,
                    metadata={
                        'pages_processed': len(page_data_list),
                        'total_text_elements': sum(len(page.text_elements) for page in page_data_list),
                        'total_vector_elements': sum(len(page.vector_elements) for page in page_data_list),
                        'total_image_elements': sum(len(page.image_elements) for page in page_data_list),
                        'processed_images': len(processed_images)
                    }
                )
                
                logger.info(f"PDF文件处理完成: {document_id}, 耗时: {processing_time:.2f}秒")
                return result
                
        except Exception as e:
            processing_time = time.time() - start_time
            error_info = self.error_system.error_handler.handle_error(e, {
                'pdf_path': str(pdf_path),
                'output_dir': str(output_dir),
                'document_id': document_id if 'document_id' in locals() else 'unknown'
            })
            
            result = ProcessingResult(
                document_id=document_id if 'document_id' in locals() else 'unknown',
                success=False,
                processing_time=processing_time,
                error_info=error_info,
                metadata={'error_type': type(e).__name__}
            )
            
            logger.error(f"PDF文件处理失败: {e}")
            return result
    
    def process_pdf_batch(self, pdf_paths: List[Union[str, Path]], 
                         output_dir: Union[str, Path],
                         output_formats: Optional[List[str]] = None,
                         progress_callback: Optional[callable] = None) -> List[ProcessingResult]:
        """
        批量处理PDF文件
        
        Args:
            pdf_paths: PDF文件路径列表
            output_dir: 输出目录
            output_formats: 输出格式列表
            progress_callback: 进度回调函数
            
        Returns:
            List[ProcessingResult]: 处理结果列表
        """
        if not self.is_initialized:
            raise RuntimeError("流水线未初始化")
        
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        if output_formats is None:
            output_formats = self.config.data_output_formats
        
        results = []
        
        try:
            logger.info(f"开始批量处理PDF文件，数量: {len(pdf_paths)}")
            
            # 创建进度跟踪器
            progress_tracker = ProgressTracker(len(pdf_paths))
            
            # 使用批处理器处理
            def process_single_pdf(pdf_path):
                try:
                    result = self.process_pdf_file(pdf_path, output_dir, output_formats)
                    progress_tracker.update_progress(completed=1)
                    return result
                except Exception as e:
                    error_info = self.error_system.error_handler.handle_error(e, {
                        'pdf_path': str(pdf_path),
                        'batch_processing': True
                    })
                    progress_tracker.update_progress(failed=1)
                    
                    return ProcessingResult(
                        document_id=self._generate_document_id(pdf_path),
                        success=False,
                        processing_time=0.0,
                        error_info=error_info
                    )
            
            # 并行处理
            with ThreadPoolExecutor(max_workers=self.config.batch_max_workers) as executor:
                futures = [executor.submit(process_single_pdf, pdf_path) for pdf_path in pdf_paths]
                
                for future in concurrent.futures.as_completed(futures):
                    try:
                        result = future.result()
                        results.append(result)
                    except Exception as e:
                        logger.error(f"批处理任务错误: {e}")
            
            # 按原始顺序排序
            results.sort(key=lambda x: x.document_id)
            
            logger.info(f"批量处理完成，成功: {sum(1 for r in results if r.success)}/{len(results)}")
            return results
            
        except Exception as e:
            logger.error(f"批量处理错误: {e}")
            return results
    
    def _preprocess_page_images(self, page_data_list: List[PageData], output_dir: Path) -> List[str]:
        """预处理页面图像"""
        try:
            processed_images = []
            
            for page_data in page_data_list:
                # 提取页面图像
                page_image = self._extract_page_image(page_data)
                
                if page_image is not None:
                    # 预处理图像
                    result = self.image_preprocessor.preprocessor.preprocess_image(page_image)
                    
                    # 保存处理后的图像
                    image_filename = f"processed_page_{page_data.page_number + 1}.png"
                    image_path = output_dir / image_filename
                    cv2.imwrite(str(image_path), result.processed_image)
                    processed_images.append(str(image_path))
                    
                    # 保存处理信息
                    info_filename = f"page_{page_data.page_number + 1}_processing_info.json"
                    info_path = output_dir / info_filename
                    with open(info_path, 'w', encoding='utf-8') as f:
                        json.dump(result.to_dict(), f, ensure_ascii=False, indent=2)
            
            return processed_images
            
        except Exception as e:
            logger.error(f"图像预处理错误: {e}")
            return []
    
    def _extract_page_image(self, page_data: PageData) -> Optional[np.ndarray]:
        """提取页面图像"""
        try:
            # 这里应该实现从PDF页面提取图像的逻辑
            # 由于复杂性，这里返回一个模拟图像
            
            # 创建模拟图像
            image = np.ones((int(page_data.height), int(page_data.width), 3), dtype=np.uint8) * 255
            
            # 添加一些模拟内容
            cv2.rectangle(image, (50, 50), (200, 100), (0, 0, 0), 2)
            cv2.putText(image, f"Page {page_data.page_number + 1}", (60, 80), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
            
            return image
            
        except Exception as e:
            logger.error(f"页面图像提取错误: {e}")
            return None
    
    def _standardize_data(self, page_data_list: List[PageData], document_id: str) -> DocumentStructure:
        """标准化数据"""
        try:
            # 构建PDF数据字典
            pdf_data = {
                'document_id': document_id,
                'pages': [page_data.to_dict() for page_data in page_data_list],
                'metadata': {
                    'total_pages': len(page_data_list),
                    'processing_timestamp': time.time()
                }
            }
            
            # 使用数据转换器标准化
            doc_structure = self.data_converter.standardize_pdf_data(pdf_data, document_id)
            
            return doc_structure
            
        except Exception as e:
            logger.error(f"数据标准化错误: {e}")
            raise
    
    def _convert_data(self, doc_structure: DocumentStructure, output_dir: Path, 
                     output_formats: List[str]) -> List[str]:
        """转换数据"""
        try:
            output_files = []
            
            for format_type in output_formats:
                try:
                    output_file = output_dir / f"document_structure.{format_type}"
                    success = self.data_converter.convert_to_format(
                        doc_structure.to_dict(), format_type, output_file
                    )
                    
                    if success:
                        output_files.append(str(output_file))
                        logger.info(f"数据转换成功: {format_type} -> {output_file}")
                    else:
                        logger.warning(f"数据转换失败: {format_type}")
                        
                except Exception as e:
                    logger.error(f"格式转换错误 {format_type}: {e}")
            
            return output_files
            
        except Exception as e:
            logger.error(f"数据转换错误: {e}")
            return []
    
    def _create_visualizations(self, doc_structure: DocumentStructure, output_dir: Path):
        """创建可视化"""
        try:
            # 文档结构可视化
            viz_file = output_dir / "document_structure.png"
            success = self.data_visualizer.visualize_document_structure(doc_structure, viz_file)
            if success:
                logger.info(f"文档结构可视化已保存: {viz_file}")
            
            # 数据质量报告
            quality_file = output_dir / "data_quality.png"
            success = self.data_visualizer.create_data_quality_report(doc_structure.to_dict(), quality_file)
            if success:
                logger.info(f"数据质量报告已保存: {quality_file}")
                
        except Exception as e:
            logger.error(f"可视化创建错误: {e}")
    
    def _generate_processing_report(self, document_id: str, page_data_list: List[PageData],
                                  doc_structure: DocumentStructure, processed_images: List[str],
                                  output_dir: Path) -> Path:
        """生成处理报告"""
        try:
            report_data = {
                'document_id': document_id,
                'processing_timestamp': time.time(),
                'processing_config': self.config.to_dict(),
                'statistics': {
                    'total_pages': len(page_data_list),
                    'total_text_elements': sum(len(page.text_elements) for page in page_data_list),
                    'total_vector_elements': sum(len(page.vector_elements) for page in page_data_list),
                    'total_image_elements': sum(len(page.image_elements) for page in page_data_list),
                    'processed_images': len(processed_images)
                },
                'page_details': [page_data.to_dict() for page in page_data_list],
                'document_structure_summary': {
                    'title': doc_structure.title,
                    'author': doc_structure.author,
                    'total_sections': len(doc_structure.sections),
                    'table_of_contents_items': len(doc_structure.table_of_contents)
                },
                'output_files': processed_images
            }
            
            report_file = output_dir / f"processing_report_{document_id}.json"
            with open(report_file, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, ensure_ascii=False, indent=2, default=str)
            
            return report_file
            
        except Exception as e:
            logger.error(f"处理报告生成错误: {e}")
            raise
    
    def _generate_document_id(self, pdf_path: Union[str, Path]) -> str:
        """生成文档ID"""
        try:
            import hashlib
            path_str = str(pdf_path)
            hash_object = hashlib.md5(path_str.encode())
            return f"doc_{hash_object.hexdigest()[:8]}"
        except:
            return f"doc_{int(time.time())}"
    
    def get_system_status(self) -> Dict[str, Any]:
        """获取系统状态"""
        try:
            if not self.is_initialized:
                return {'status': 'not_initialized'}
            
            # 获取错误恢复系统状态
            error_status = self.error_system.get_system_status()
            
            # 获取批处理器状态
            batch_stats = self.batch_processor.get_optimization_report()
            
            return {
                'status': 'healthy',
                'initialized': self.is_initialized,
                'error_system': error_status,
                'batch_processor': batch_stats,
                'configuration': self.config.to_dict()
            }
            
        except Exception as e:
            logger.error(f"系统状态获取错误: {e}")
            return {'status': 'error', 'error': str(e)}
    
    def export_system_report(self, output_path: Union[str, Path]) -> bool:
        """导出系统报告"""
        try:
            output_path = Path(output_path)
            
            # 获取系统状态
            system_status = self.get_system_status()
            
            # 导出错误报告
            error_report_path = output_path.parent / "error_report.json"
            self.error_system.export_error_report(error_report_path)
            
            # 生成综合报告
            comprehensive_report = {
                'timestamp': time.time(),
                'system_status': system_status,
                'pipeline_config': self.config.to_dict(),
                'component_status': {
                    'pdf_parser': 'initialized' if hasattr(self, 'pdf_parser') else 'not_initialized',
                    'image_preprocessor': 'initialized' if hasattr(self, 'image_preprocessor') else 'not_initialized',
                    'data_converter': 'initialized' if hasattr(self, 'data_converter') else 'not_initialized',
                    'batch_processor': 'initialized' if hasattr(self, 'batch_processor') else 'not_initialized',
                    'error_system': 'initialized' if hasattr(self, 'error_system') else 'not_initialized'
                }
            }
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(comprehensive_report, f, ensure_ascii=False, indent=2, default=str)
            
            logger.info(f"系统报告已导出: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"系统报告导出错误: {e}")
            return False


class ProgressTracker:
    """进度跟踪器"""
    
    def __init__(self, total_tasks: int):
        self.total_tasks = total_tasks
        self.completed_tasks = 0
        self.failed_tasks = 0
        self.start_time = time.time()
    
    def update_progress(self, completed: int = 0, failed: int = 0):
        self.completed_tasks += completed
        self.failed_tasks += failed
        
        total_processed = self.completed_tasks + self.failed_tasks
        progress_percent = (total_processed / self.total_tasks) * 100
        
        elapsed_time = time.time() - self.start_time
        if total_processed > 0:
            estimated_total_time = (elapsed_time / total_processed) * self.total_tasks
            remaining_time = estimated_total_time - elapsed_time
        else:
            remaining_time = 0
        
        print(f"\r进度: {progress_percent:.1f}% ({total_processed}/{self.total_tasks}) "
              f"完成: {self.completed_tasks} 失败: {self.failed_tasks} "
              f"剩余时间: {remaining_time:.0f}s", end='', flush=True)
        
        if total_processed >= self.total_tasks:
            print()  # 换行
            logger.info(f"进度跟踪完成，总耗时：{elapsed_time:.2f}秒")


# 便捷函数
def create_pipeline(config: Optional[ProcessingPipelineConfig] = None) -> PDFProcessingPipeline:
    """创建PDF处理流水线"""
    return PDFProcessingPipeline(config)


def quick_process_pdf(pdf_path: Union[str, Path], 
                     output_dir: Union[str, Path],
                     config: Optional[ProcessingPipelineConfig] = None) -> ProcessingResult:
    """
    快速处理PDF文件
    
    Args:
        pdf_path: PDF文件路径
        output_dir: 输出目录
        config: 处理配置
        
    Returns:
        ProcessingResult: 处理结果
    """
    pipeline = create_pipeline(config)
    return pipeline.process_pdf_file(pdf_path, output_dir)


def batch_process_pdfs(pdf_paths: List[Union[str, Path]], 
                      output_dir: Union[str, Path],
                      config: Optional[ProcessingPipelineConfig] = None) -> List[ProcessingResult]:
    """
    批量处理PDF文件
    
    Args:
        pdf_paths: PDF文件路径列表
        output_dir: 输出目录
        config: 处理配置
        
    Returns:
        List[ProcessingResult]: 处理结果列表
    """
    pipeline = create_pipeline(config)
    return pipeline.process_pdf_batch(pdf_paths, output_dir)


# 使用示例
if __name__ == "__main__":
    # 创建配置
    config = ProcessingPipelineConfig(
        pdf_max_workers=4,
        image_resize_factor=1.5,
        image_denoise_method="bilateral",
        data_output_formats=['json', 'csv', 'excel'],
        data_enable_visualization=True,
        batch_max_workers=4,
        error_auto_recovery=True
    )
    
    # 创建流水线
    pipeline = create_pipeline(config)
    
    # 示例PDF文件路径
    pdf_files = ["document1.pdf", "document2.pdf"]
    
    # 检查文件是否存在
    existing_files = [pdf for pdf in pdf_files if os.path.exists(pdf)]
    
    if existing_files:
        print(f"找到 {len(existing_files)} 个PDF文件")
        
        # 单文件处理示例
        if len(existing_files) == 1:
            result = pipeline.process_pdf_file(existing_files[0], "output_single")
            print(f"单文件处理结果: {'成功' if result.success else '失败'}")
            print(f"处理时间: {result.processing_time:.2f}秒")
            print(f"输出文件: {result.output_files}")
        
        # 批量处理示例
        else:
            results = pipeline.process_pdf_batch(existing_files, "output_batch")
            successful = sum(1 for r in results if r.success)
            print(f"批量处理完成: {successful}/{len(results)} 成功")
            
            for result in results:
                print(f"文档 {result.document_id}: {'成功' if result.success else '失败'}")
        
        # 获取系统状态
        status = pipeline.get_system_status()
        print(f"系统状态: {status['status']}")
        
        # 导出系统报告
        pipeline.export_system_report("system_report.json")
        
    else:
        print("未找到示例PDF文件")
        print("请确保以下文件存在: document1.pdf, document2.pdf")
