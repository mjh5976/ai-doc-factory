#!/usr/bin/env python3
"""
批处理和并行处理优化模块
提供高效的批处理和并行处理能力
"""

import os
import sys
import logging
import json
import traceback
import time
import threading
import queue
import multiprocessing as mp
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from typing import Dict, List, Tuple, Optional, Any, Union, Callable
from dataclasses import dataclass, asdict, field
from pathlib import Path
import psutil
import numpy as np
import cv2
from queue import PriorityQueue
import pickle
import hashlib
from datetime import datetime, timedelta

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@dataclass
class Task:
    """任务数据类"""
    task_id: str
    task_type: str  # 'pdf_parse', 'image_process', 'data_convert'
    input_data: Any
    priority: int = 1  # 1=高, 2=中, 3=低
    retry_count: int = 0
    max_retries: int = 3
    timeout: float = 300.0  # 5分钟超时
    created_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self):
        return {
            'task_id': self.task_id,
            'task_type': self.task_type,
            'priority': self.priority,
            'retry_count': self.retry_count,
            'max_retries': self.max_retries,
            'timeout': self.timeout,
            'created_at': self.created_at.isoformat(),
            'metadata': self.metadata,
            'input_data_type': type(self.input_data).__name__
        }


@dataclass
class TaskResult:
    """任务结果数据类"""
    task_id: str
    success: bool
    result: Any = None
    error: str = ""
    execution_time: float = 0.0
    memory_usage: float = 0.0
    cpu_usage: float = 0.0
    completed_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self):
        return {
            'task_id': self.task_id,
            'success': self.success,
            'error': self.error,
            'execution_time': self.execution_time,
            'memory_usage': self.memory_usage,
            'cpu_usage': self.cpu_usage,
            'completed_at': self.completed_at.isoformat(),
            'result_type': type(self.result).__name__ if self.result is not None else 'None'
        }


@dataclass
class BatchConfig:
    """批处理配置"""
    max_workers: int = 4
    max_queue_size: int = 1000
    chunk_size: int = 10
    retry_delay: float = 1.0
    enable_monitoring: bool = True
    memory_limit_mb: int = 2048
    cpu_limit_percent: int = 80
    enable_progress_tracking: bool = True
    progress_interval: float = 1.0  # 秒
    enable_caching: bool = True
    cache_ttl: int = 3600  # 1小时
    
    def to_dict(self):
        return asdict(self)


class TaskQueue:
    """任务队列"""
    
    def __init__(self, max_size: int = 1000):
        """
        初始化任务队列
        
        Args:
            max_size: 队列最大大小
        """
        self.queue = PriorityQueue(maxsize=max_size)
        self.lock = threading.Lock()
        self.task_registry = {}  # 任务注册表
        self.completed_tasks = {}  # 已完成任务
        self.failed_tasks = {}  # 失败任务
        logger.info(f"任务队列初始化完成，最大大小：{max_size}")
    
    def add_task(self, task: Task) -> bool:
        """
        添加任务
        
        Args:
            task: 任务对象
            
        Returns:
            bool: 是否添加成功
        """
        try:
            with self.lock:
                if task.task_id in self.task_registry:
                    logger.warning(f"任务已存在: {task.task_id}")
                    return False
                
                # 使用负优先级（因为PriorityQueue是最小堆）
                self.queue.put((-task.priority, task.task_id, task))
                self.task_registry[task.task_id] = task
                
                logger.debug(f"添加任务: {task.task_id}, 类型: {task.task_type}, 优先级: {task.priority}")
                return True
                
        except queue.Full:
            logger.error(f"队列已满，无法添加任务: {task.task_id}")
            return False
        except Exception as e:
            logger.error(f"添加任务错误: {e}")
            return False
    
    def get_task(self, timeout: float = None) -> Optional[Task]:
        """
        获取任务
        
        Args:
            timeout: 超时时间
            
        Returns:
            Optional[Task]: 任务对象
        """
        try:
            if timeout is None:
                priority, task_id, task = self.queue.get()
            else:
                priority, task_id, task = self.queue.get(timeout=timeout)
            
            with self.lock:
                # 从注册表中移除
                if task_id in self.task_registry:
                    del self.task_registry[task_id]
            
            logger.debug(f"获取任务: {task_id}")
            return task
            
        except queue.Empty:
            return None
        except Exception as e:
            logger.error(f"获取任务错误: {e}")
            return None
    
    def mark_completed(self, task_id: str, result: TaskResult):
        """标记任务完成"""
        with self.lock:
            self.completed_tasks[task_id] = result
    
    def mark_failed(self, task_id: str, result: TaskResult):
        """标记任务失败"""
        with self.lock:
            self.failed_tasks[task_id] = result
    
    def get_stats(self) -> Dict[str, Any]:
        """获取队列统计信息"""
        with self.lock:
            return {
                'queue_size': self.queue.qsize(),
                'pending_tasks': len(self.task_registry),
                'completed_tasks': len(self.completed_tasks),
                'failed_tasks': len(self.failed_tasks)
            }


class TaskProcessor:
    """任务处理器"""
    
    def __init__(self, config: BatchConfig):
        """
        初始化任务处理器
        
        Args:
            config: 批处理配置
        """
        self.config = config
        self.task_handlers = {
            'pdf_parse': self._handle_pdf_parse,
            'image_process': self._handle_image_process,
            'data_convert': self._handle_data_convert
        }
        self.cache = {}  # 结果缓存
        self.performance_metrics = {
            'total_tasks': 0,
            'completed_tasks': 0,
            'failed_tasks': 0,
            'total_execution_time': 0.0,
            'average_execution_time': 0.0
        }
        logger.info("任务处理器初始化完成")
    
    def process_task(self, task: Task) -> TaskResult:
        """
        处理任务
        
        Args:
            task: 任务对象
            
        Returns:
            TaskResult: 任务结果
        """
        start_time = time.time()
        start_memory = psutil.Process().memory_info().rss / 1024 / 1024  # MB
        
        try:
            # 检查缓存
            if self.config.enable_caching:
                cache_key = self._generate_cache_key(task)
                if cache_key in self.cache:
                    cached_result, cache_time = self.cache[cache_key]
                    if time.time() - cache_time < self.config.cache_ttl:
                        logger.info(f"从缓存返回结果: {task.task_id}")
                        return cached_result
            
            # 检查任务类型
            if task.task_type not in self.task_handlers:
                raise ValueError(f"不支持的任务类型: {task.task_type}")
            
            # 检查资源限制
            self._check_resource_limits()
            
            # 执行任务
            handler = self.task_handlers[task.task_type]
            result = handler(task)
            
            # 创建结果对象
            execution_time = time.time() - start_time
            end_memory = psutil.Process().memory_info().rss / 1024 / 1024  # MB
            memory_usage = end_memory - start_memory
            
            task_result = TaskResult(
                task_id=task.task_id,
                success=True,
                result=result,
                execution_time=execution_time,
                memory_usage=memory_usage,
                cpu_usage=0.0  # 需要更复杂的CPU监控
            )
            
            # 缓存结果
            if self.config.enable_caching:
                self._cache_result(cache_key, task_result)
            
            # 更新性能指标
            self._update_performance_metrics(task_result)
            
            logger.info(f"任务完成: {task.task_id}, 耗时: {execution_time:.2f}秒")
            return task_result
            
        except Exception as e:
            execution_time = time.time() - start_time
            error_msg = str(e)
            
            task_result = TaskResult(
                task_id=task.task_id,
                success=False,
                error=error_msg,
                execution_time=execution_time
            )
            
            # 更新性能指标
            self._update_performance_metrics(task_result)
            
            logger.error(f"任务失败: {task.task_id}, 错误: {error_msg}")
            return task_result
    
    def _handle_pdf_parse(self, task: Task) -> Any:
        """处理PDF解析任务"""
        try:
            # 导入PDF解析器
            from pdf_parser import PDFParser
            
            # 创建解析器
            parser = PDFParser(max_workers=1)  # 单线程解析
            
            # 解析PDF
            pdf_path = task.input_data
            result = parser.parse_pdf(pdf_path)
            
            return result
            
        except Exception as e:
            raise Exception(f"PDF解析错误: {e}")
    
    def _handle_image_process(self, task: Task) -> Any:
        """处理图像处理任务"""
        try:
            # 导入图像预处理器
            from image_preprocessor import ImagePreprocessor, ProcessingConfig
            
            # 获取配置
            config = task.metadata.get('config', ProcessingConfig())
            
            # 创建预处理器
            preprocessor = ImagePreprocessor(config)
            
            # 处理图像
            image = task.input_data
            result = preprocessor.preprocess_image(image)
            
            return result
            
        except Exception as e:
            raise Exception(f"图像处理错误: {e}")
    
    def _handle_data_convert(self, task: Task) -> Any:
        """处理数据转换任务"""
        try:
            # 导入数据转换器
            from data_converter import DataStandardizer
            
            # 获取配置
            output_format = task.metadata.get('output_format', 'json')
            output_path = task.metadata.get('output_path', '')
            
            # 创建转换器
            converter = DataStandardizer()
            
            # 转换数据
            data = task.input_data
            success = converter.convert_to_format(data, output_format, output_path)
            
            return success
            
        except Exception as e:
            raise Exception(f"数据转换错误: {e}")
    
    def _generate_cache_key(self, task: Task) -> str:
        """生成缓存键"""
        try:
            # 基于任务类型和输入数据生成哈希
            if isinstance(task.input_data, str):
                data_str = task.input_data
            else:
                data_str = str(task.input_data)
            
            cache_data = f"{task.task_type}:{data_str}:{json.dumps(task.metadata, sort_keys=True)}"
            return hashlib.md5(cache_data.encode()).hexdigest()
            
        except Exception as e:
            logger.warning(f"缓存键生成错误: {e}")
            return f"cache_{task.task_id}"
    
    def _cache_result(self, cache_key: str, result: TaskResult):
        """缓存结果"""
        try:
            self.cache[cache_key] = (result, time.time())
            
            # 清理过期缓存
            current_time = time.time()
            expired_keys = [key for key, (_, cache_time) in self.cache.items() 
                          if current_time - cache_time > self.config.cache_ttl]
            for key in expired_keys:
                del self.cache[key]
            
        except Exception as e:
            logger.warning(f"缓存结果错误: {e}")
    
    def _check_resource_limits(self):
        """检查资源限制"""
        try:
            # 检查内存使用
            memory_percent = psutil.virtual_memory().percent
            if memory_percent > self.config.cpu_limit_percent:
                logger.warning(f"内存使用率过高: {memory_percent}%")
            
            # 检查CPU使用
            cpu_percent = psutil.cpu_percent(interval=1)
            if cpu_percent > self.config.cpu_limit_percent:
                logger.warning(f"CPU使用率过高: {cpu_percent}%")
            
        except Exception as e:
            logger.warning(f"资源检查错误: {e}")
    
    def _update_performance_metrics(self, result: TaskResult):
        """更新性能指标"""
        try:
            self.performance_metrics['total_tasks'] += 1
            
            if result.success:
                self.performance_metrics['completed_tasks'] += 1
            else:
                self.performance_metrics['failed_tasks'] += 1
            
            self.performance_metrics['total_execution_time'] += result.execution_time
            self.performance_metrics['average_execution_time'] = (
                self.performance_metrics['total_execution_time'] / 
                self.performance_metrics['total_tasks']
            )
            
        except Exception as e:
            logger.warning(f"性能指标更新错误: {e}")
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """获取性能指标"""
        return self.performance_metrics.copy()


class BatchProcessor:
    """批处理器"""
    
    def __init__(self, config: BatchConfig = None):
        """
        初始化批处理器
        
        Args:
            config: 批处理配置
        """
        self.config = config or BatchConfig()
        self.task_queue = TaskQueue(max_size=self.config.max_queue_size)
        self.task_processor = TaskProcessor(self.config)
        self.is_running = False
        self.progress_callback = None
        self.workers = []
        logger.info(f"批处理器初始化完成，配置：{self.config.to_dict()}")
    
    def add_task(self, task: Task) -> bool:
        """添加任务"""
        return self.task_queue.add_task(task)
    
    def add_batch_tasks(self, tasks: List[Task]) -> int:
        """
        批量添加任务
        
        Args:
            tasks: 任务列表
            
        Returns:
            int: 成功添加的任务数
        """
        success_count = 0
        for task in tasks:
            if self.add_task(task):
                success_count += 1
        
        logger.info(f"批量添加任务完成，成功：{success_count}/{len(tasks)}")
        return success_count
    
    def start_processing(self, progress_callback: Optional[Callable] = None):
        """
        开始处理
        
        Args:
            progress_callback: 进度回调函数
        """
        if self.is_running:
            logger.warning("批处理器已在运行")
            return
        
        self.is_running = True
        self.progress_callback = progress_callback
        
        # 创建工作线程
        for i in range(self.config.max_workers):
            worker = threading.Thread(target=self._worker_loop, args=(i,), daemon=True)
            worker.start()
            self.workers.append(worker)
        
        logger.info(f"批处理器启动，工作线程数：{self.config.max_workers}")
    
    def stop_processing(self, wait: bool = True):
        """停止处理"""
        if not self.is_running:
            return
        
        self.is_running = False
        
        # 等待工作线程结束
        if wait:
            for worker in self.workers:
                worker.join(timeout=5.0)
        
        self.workers.clear()
        logger.info("批处理器已停止")
    
    def _worker_loop(self, worker_id: int):
        """工作线程循环"""
        logger.info(f"工作线程 {worker_id} 启动")
        
        try:
            while self.is_running:
                # 获取任务
                task = self.task_queue.get_task(timeout=1.0)
                if task is None:
                    continue
                
                # 检查超时
                if self._is_task_timeout(task):
                    logger.warning(f"任务超时: {task.task_id}")
                    self._handle_task_timeout(task)
                    continue
                
                # 处理任务
                result = self.task_processor.process_task(task)
                
                # 标记结果
                if result.success:
                    self.task_queue.mark_completed(task.task_id, result)
                else:
                    # 处理重试
                    if task.retry_count < task.max_retries:
                        task.retry_count += 1
                        logger.info(f"任务重试: {task.task_id}, 重试次数: {task.retry_count}")
                        
                        # 延迟重试
                        time.sleep(self.config.retry_delay * (2 ** task.retry_count))
                        
                        # 重新加入队列
                        self.add_task(task)
                    else:
                        self.task_queue.mark_failed(task.task_id, result)
                
                # 更新进度
                if self.progress_callback:
                    stats = self.task_queue.get_stats()
                    self.progress_callback(stats)
        
        except Exception as e:
            logger.error(f"工作线程 {worker_id} 错误: {e}")
        
        finally:
            logger.info(f"工作线程 {worker_id} 结束")
    
    def _is_task_timeout(self, task: Task) -> bool:
        """检查任务是否超时"""
        elapsed = (datetime.now() - task.created_at).total_seconds()
        return elapsed > task.timeout
    
    def _handle_task_timeout(self, task: Task):
        """处理任务超时"""
        timeout_result = TaskResult(
            task_id=task.task_id,
            success=False,
            error="任务超时"
        )
        self.task_queue.mark_failed(task.task_id, timeout_result)
    
    def wait_for_completion(self, timeout: float = None) -> Dict[str, Any]:
        """
        等待处理完成
        
        Args:
            timeout: 超时时间
            
        Returns:
            Dict[str, Any]: 处理结果统计
        """
        start_time = time.time()
        
        try:
            while self.is_running:
                stats = self.task_queue.get_stats()
                
                # 检查是否完成
                if stats['queue_size'] == 0 and stats['pending_tasks'] == 0:
                    break
                
                # 检查超时
                if timeout and (time.time() - start_time) > timeout:
                    logger.warning("等待处理完成超时")
                    break
                
                time.sleep(1.0)
            
            # 获取最终统计
            final_stats = self.task_queue.get_stats()
            performance_metrics = self.task_processor.get_performance_metrics()
            
            result = {
                'queue_stats': final_stats,
                'performance_metrics': performance_metrics,
                'total_wait_time': time.time() - start_time
            }
            
            logger.info(f"批处理完成: {result}")
            return result
            
        except Exception as e:
            logger.error(f"等待处理完成错误: {e}")
            return {}
    
    def get_queue_stats(self) -> Dict[str, Any]:
        """获取队列统计"""
        return self.task_queue.get_stats()
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """获取性能指标"""
        return self.task_processor.get_performance_metrics()


class SmartBatchProcessor:
    """智能批处理器"""
    
    def __init__(self, config: BatchConfig = None):
        """
        初始化智能批处理器
        
        Args:
            config: 批处理配置
        """
        self.config = config or BatchConfig()
        self.batch_processor = BatchProcessor(config)
        self.adaptive_config = True
        self.performance_history = []
        logger.info("智能批处理器初始化完成")
    
    def process_pdf_batch(self, pdf_paths: List[str], 
                         output_dir: Union[str, Path],
                         progress_callback: Optional[Callable] = None) -> Dict[str, Any]:
        """
        批量处理PDF文件
        
        Args:
            pdf_paths: PDF文件路径列表
            output_dir: 输出目录
            progress_callback: 进度回调函数
            
        Returns:
            Dict[str, Any]: 处理结果
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # 创建任务
        tasks = []
        for i, pdf_path in enumerate(pdf_paths):
            task = Task(
                task_id=f"pdf_parse_{i:04d}",
                task_type="pdf_parse",
                input_data=pdf_path,
                priority=1,
                metadata={
                    'output_dir': str(output_dir),
                    'pdf_index': i
                }
            )
            tasks.append(task)
        
        # 添加任务
        self.batch_processor.add_batch_tasks(tasks)
        
        # 开始处理
        self.batch_processor.start_processing(progress_callback)
        
        # 等待完成
        result = self.batch_processor.wait_for_completion()
        
        return result
    
    def process_image_batch(self, images: List[np.ndarray],
                           configs: Optional[List[Any]] = None,
                           output_dir: Optional[Union[str, Path]] = None,
                           progress_callback: Optional[Callable] = None) -> Dict[str, Any]:
        """
        批量处理图像
        
        Args:
            images: 图像列表
            configs: 处理配置列表
            output_dir: 输出目录
            progress_callback: 进度回调函数
            
        Returns:
            Dict[str, Any]: 处理结果
        """
        if configs is None:
            configs = [None] * len(images)
        
        if output_dir:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
        
        # 创建任务
        tasks = []
        for i, (image, config) in enumerate(zip(images, configs)):
            task = Task(
                task_id=f"image_process_{i:04d}",
                task_type="image_process",
                input_data=image,
                priority=2,
                metadata={
                    'config': config.to_dict() if config else {},
                    'output_dir': str(output_dir) if output_dir else '',
                    'image_index': i
                }
            )
            tasks.append(task)
        
        # 添加任务
        self.batch_processor.add_batch_tasks(tasks)
        
        # 开始处理
        self.batch_processor.start_processing(progress_callback)
        
        # 等待完成
        result = self.batch_processor.wait_for_completion()
        
        return result
    
    def process_data_conversion_batch(self, data_list: List[Any],
                                    output_formats: List[str],
                                    output_dir: Union[str, Path],
                                    progress_callback: Optional[Callable] = None) -> Dict[str, Any]:
        """
        批量数据转换
        
        Args:
            data_list: 数据列表
            output_formats: 输出格式列表
            output_dir: 输出目录
            progress_callback: 进度回调函数
            
        Returns:
            Dict[str, Any]: 处理结果
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # 创建任务
        tasks = []
        task_index = 0
        
        for data_index, data in enumerate(data_list):
            for format_index, output_format in enumerate(output_formats):
                task = Task(
                    task_id=f"data_convert_{task_index:04d}",
                    task_type="data_convert",
                    input_data=data,
                    priority=3,
                    metadata={
                        'output_format': output_format,
                        'output_dir': str(output_dir),
                        'data_index': data_index,
                        'format_index': format_index
                    }
                )
                tasks.append(task)
                task_index += 1
        
        # 添加任务
        self.batch_processor.add_batch_tasks(tasks)
        
        # 开始处理
        self.batch_processor.start_processing(progress_callback)
        
        # 等待完成
        result = self.batch_processor.wait_for_completion()
        
        return result
    
    def optimize_configuration(self) -> BatchConfig:
        """
        基于历史性能优化配置
        
        Returns:
            BatchConfig: 优化后的配置
        """
        try:
            # 获取性能历史
            metrics = self.batch_processor.get_performance_metrics()
            
            if metrics['total_tasks'] > 10:  # 需要足够的数据点
                avg_time = metrics['average_execution_time']
                
                # 根据平均执行时间调整工作线程数
                if avg_time > 10.0:  # 执行时间较长，增加线程数
                    new_workers = min(self.config.max_workers + 1, mp.cpu_count())
                elif avg_time < 1.0:  # 执行时间较短，减少线程数
                    new_workers = max(self.config.max_workers - 1, 1)
                else:
                    new_workers = self.config.max_workers
                
                # 更新配置
                optimized_config = BatchConfig(
                    max_workers=new_workers,
                    max_queue_size=self.config.max_queue_size,
                    chunk_size=self.config.chunk_size,
                    retry_delay=self.config.retry_delay,
                    enable_monitoring=self.config.enable_monitoring,
                    memory_limit_mb=self.config.memory_limit_mb,
                    cpu_limit_percent=self.config.cpu_limit_percent,
                    enable_progress_tracking=self.config.enable_progress_tracking,
                    progress_interval=self.config.progress_interval,
                    enable_caching=self.config.enable_caching,
                    cache_ttl=self.config.cache_ttl
                )
                
                logger.info(f"配置优化: 工作线程数 {self.config.max_workers} -> {new_workers}")
                return optimized_config
            
            return self.config
            
        except Exception as e:
            logger.warning(f"配置优化错误: {e}")
            return self.config
    
    def get_optimization_report(self) -> Dict[str, Any]:
        """获取优化报告"""
        try:
            metrics = self.batch_processor.get_performance_metrics()
            queue_stats = self.batch_processor.get_queue_stats()
            
            # 计算效率指标
            if metrics['total_tasks'] > 0:
                success_rate = metrics['completed_tasks'] / metrics['total_tasks'] * 100
                throughput = metrics['total_tasks'] / max(metrics['total_execution_time'], 1.0)
            else:
                success_rate = 0
                throughput = 0
            
            report = {
                'performance_metrics': metrics,
                'queue_statistics': queue_stats,
                'efficiency_indicators': {
                    'success_rate': f"{success_rate:.1f}%",
                    'throughput': f"{throughput:.2f} tasks/sec",
                    'average_execution_time': f"{metrics['average_execution_time']:.2f} sec"
                },
                'resource_utilization': {
                    'queue_utilization': f"{queue_stats['queue_size'] / self.config.max_queue_size * 100:.1f}%",
                    'pending_tasks': queue_stats['pending_tasks'],
                    'completed_tasks': queue_stats['completed_tasks'],
                    'failed_tasks': queue_stats['failed_tasks']
                }
            }
            
            return report
            
        except Exception as e:
            logger.error(f"优化报告生成错误: {e}")
            return {}


class ProgressTracker:
    """进度跟踪器"""
    
    def __init__(self, total_tasks: int, update_interval: float = 1.0):
        """
        初始化进度跟踪器
        
        Args:
            total_tasks: 总任务数
            update_interval: 更新间隔（秒）
        """
        self.total_tasks = total_tasks
        self.update_interval = update_interval
        self.completed_tasks = 0
        self.failed_tasks = 0
        self.start_time = time.time()
        self.last_update = self.start_time
        self.lock = threading.Lock()
        logger.info(f"进度跟踪器初始化，总任务数：{total_tasks}")
    
    def update_progress(self, completed: int = 0, failed: int = 0):
        """更新进度"""
        with self.lock:
            self.completed_tasks += completed
            self.failed_tasks += failed
            
            current_time = time.time()
            
            # 检查是否需要更新显示
            if current_time - self.last_update >= self.update_interval:
                self._display_progress()
                self.last_update = current_time
    
    def _display_progress(self):
        """显示进度"""
        try:
            total_processed = self.completed_tasks + self.failed_tasks
            progress_percent = (total_processed / self.total_tasks) * 100 if self.total_tasks > 0 else 0
            
            elapsed_time = time.time() - self.start_time
            if total_processed > 0:
                estimated_total_time = (elapsed_time / total_processed) * self.total_tasks
                remaining_time = estimated_total_time - elapsed_time
            else:
                remaining_time = 0
            
            # 构建进度条
            bar_length = 40
            filled_length = int(bar_length * progress_percent / 100)
            bar = '█' * filled_length + '-' * (bar_length - filled_length)
            
            progress_info = (
                f"\r进度: |{bar}| {progress_percent:.1f}% "
                f"({total_processed}/{self.total_tasks}) "
                f"完成: {self.completed_tasks} 失败: {self.failed_tasks} "
                f"剩余时间: {remaining_time:.0f}s"
            )
            
            print(progress_info, end='', flush=True)
            
            # 如果完成，换行
            if total_processed >= self.total_tasks:
                print()  # 换行
                logger.info(f"进度跟踪完成，总耗时：{elapsed_time:.2f}秒")
            
        except Exception as e:
            logger.warning(f"进度显示错误: {e}")
    
    def get_summary(self) -> Dict[str, Any]:
        """获取进度摘要"""
        with self.lock:
            total_processed = self.completed_tasks + self.failed_tasks
            progress_percent = (total_processed / self.total_tasks) * 100 if self.total_tasks > 0 else 0
            elapsed_time = time.time() - self.start_time
            
            return {
                'total_tasks': self.total_tasks,
                'completed_tasks': self.completed_tasks,
                'failed_tasks': self.failed_tasks,
                'progress_percent': progress_percent,
                'elapsed_time': elapsed_time,
                'success_rate': (self.completed_tasks / max(total_processed, 1)) * 100
            }


# 使用示例
if __name__ == "__main__":
    # 创建配置
    config = BatchConfig(
        max_workers=4,
        max_queue_size=100,
        enable_monitoring=True,
        enable_progress_tracking=True
    )
    
    # 创建智能批处理器
    processor = SmartBatchProcessor(config)
    
    # 示例PDF文件列表
    pdf_files = ["doc1.pdf", "doc2.pdf", "doc3.pdf"]
    
    # 进度回调函数
    def progress_callback(stats):
        print(f"队列统计: {stats}")
    
    # 批量处理PDF
    if all(os.path.exists(pdf) for pdf in pdf_files):
        result = processor.process_pdf_batch(
            pdf_files, 
            "output", 
            progress_callback=progress_callback
        )
        print(f"PDF批处理结果: {result}")
        
        # 获取优化报告
        report = processor.get_optimization_report()
        print(f"优化报告: {report}")
    else:
        print("示例PDF文件不存在")
