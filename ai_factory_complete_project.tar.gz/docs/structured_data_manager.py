"""
结构化数据提取和存储模块
负责管理PDF OCR识别的结构化数据，包括存储、查询、导出等功能
"""

import os
import sys
import logging
import sqlite3
import json
import csv
import xml.etree.ElementTree as ET
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, asdict
from pathlib import Path
import pandas as pd
from datetime import datetime
import threading
from contextlib import contextmanager

# 导入配置
sys.path.append(str(Path(__file__).parent.parent))
from pdf_ocr_config import get_config

# 导入基础模块
from pdf_parser import BoundingBox, TextElement, VectorElement, ImageElement, PageData
from text_recognition import LayoutElement, DimensionAnnotation
from graphics_detection import GeometricElement, SymbolInstance

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class DocumentRecord:
    """文档记录数据类"""
    id: Optional[int] = None
    filename: str = ""
    file_path: str = ""
    pages: int = 0
    file_size: int = 0
    file_hash: str = ""
    created_at: str = ""
    updated_at: str = ""
    processing_status: str = "pending"  # pending, processing, completed, failed
    processing_time: float = 0.0
    error_message: Optional[str] = None
    
    def to_dict(self):
        return asdict(self)

@dataclass
class ProcessingResult:
    """处理结果数据类"""
    document_id: int
    page_number: int
    text_elements: List[Dict[str, Any]]
    graphic_elements: List[Dict[str, Any]]
    layout_elements: List[Dict[str, Any]]
    dimensions: List[Dict[str, Any]]
    symbols: List[Dict[str, Any]]
    metadata: Dict[str, Any]
    confidence_score: float = 0.0
    processing_time: float = 0.0
    
    def to_dict(self):
        return asdict(self)

class DatabaseManager:
    """数据库管理器"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        self.db_config = self.config["data_structure"]["database"]
        self.schema = self.config["data_structure"]["schema"]
        
        # 线程锁
        self._lock = threading.Lock()
        
        # 初始化数据库
        self._init_database()
        
        logger.info("数据库管理器初始化完成")
    
    def _init_database(self):
        """初始化数据库"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # 创建文档表
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS documents (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        filename TEXT NOT NULL,
                        file_path TEXT NOT NULL,
                        pages INTEGER DEFAULT 0,
                        file_size INTEGER DEFAULT 0,
                        file_hash TEXT,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        processing_status TEXT DEFAULT 'pending',
                        processing_time REAL DEFAULT 0.0,
                        error_message TEXT
                    )
                """)
                
                # 创建页面表
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS pages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        document_id INTEGER NOT NULL,
                        page_number INTEGER NOT NULL,
                        width REAL NOT NULL,
                        height REAL NOT NULL,
                        FOREIGN KEY (document_id) REFERENCES documents (id)
                    )
                """)
                
                # 创建文本元素表
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS text_elements (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        page_id INTEGER NOT NULL,
                        content TEXT,
                        bbox TEXT,
                        confidence REAL,
                        font_size REAL,
                        font_name TEXT,
                        color TEXT,
                        ocr_engine TEXT,
                        element_type TEXT DEFAULT 'text',
                        FOREIGN KEY (page_id) REFERENCES pages (id)
                    )
                """)
                
                # 创建图形元素表
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS graphic_elements (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        page_id INTEGER NOT NULL,
                        element_type TEXT NOT NULL,
                        points TEXT,
                        bbox TEXT,
                        properties TEXT,
                        confidence REAL,
                        layer TEXT DEFAULT 'default',
                        FOREIGN KEY (page_id) REFERENCES pages (id)
                    )
                """)
                
                # 创建布局元素表
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS layout_elements (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        page_id INTEGER NOT NULL,
                        element_type TEXT NOT NULL,
                        bbox TEXT,
                        confidence REAL,
                        content TEXT,
                        hierarchy_level INTEGER DEFAULT 0,
                        parent_element TEXT,
                        child_elements TEXT,
                        FOREIGN KEY (page_id) REFERENCES pages (id)
                    )
                """)
                
                # 创建尺寸标注表
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS dimensions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        page_id INTEGER NOT NULL,
                        dimension_value TEXT,
                        dimension_type TEXT,
                        unit TEXT,
                        tolerance TEXT,
                        precision INTEGER DEFAULT 2,
                        bbox TEXT,
                        confidence REAL,
                        FOREIGN KEY (page_id) REFERENCES pages (id)
                    )
                """)
                
                # 创建符号表
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS symbols (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        page_id INTEGER NOT NULL,
                        symbol_type TEXT NOT NULL,
                        bbox TEXT,
                        confidence REAL,
                        properties TEXT,
                        template_id TEXT,
                        FOREIGN KEY (page_id) REFERENCES pages (id)
                    )
                """)
                
                # 创建处理结果表
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS processing_results (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        document_id INTEGER NOT NULL,
                        page_number INTEGER NOT NULL,
                        text_elements TEXT,
                        graphic_elements TEXT,
                        layout_elements TEXT,
                        dimensions TEXT,
                        symbols TEXT,
                        metadata TEXT,
                        confidence_score REAL DEFAULT 0.0,
                        processing_time REAL DEFAULT 0.0,
                        FOREIGN KEY (document_id) REFERENCES documents (id)
                    )
                """)
                
                # 创建索引
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_documents_filename ON documents (filename)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_pages_document_id ON pages (document_id)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_text_elements_page_id ON text_elements (page_id)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_graphic_elements_page_id ON graphic_elements (page_id)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_layout_elements_page_id ON layout_elements (page_id)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_dimensions_page_id ON dimensions (page_id)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_symbols_page_id ON symbols (page_id)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_processing_results_document_id ON processing_results (document_id)")
                
                conn.commit()
                logger.info("数据库初始化完成")
                
        except Exception as e:
            logger.error(f"数据库初始化失败: {e}")
            raise
    
    @contextmanager
    def _get_connection(self):
        """获取数据库连接"""
        conn = sqlite3.connect(self.db_config["path"])
        conn.row_factory = sqlite3.Row  # 允许通过列名访问
        try:
            yield conn
        finally:
            conn.close()
    
    def insert_document(self, document: DocumentRecord) -> int:
        """插入文档记录"""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute("""
                        INSERT INTO documents 
                        (filename, file_path, pages, file_size, file_hash, created_at, updated_at, 
                         processing_status, processing_time, error_message)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        document.filename, document.file_path, document.pages, document.file_size,
                        document.file_hash, document.created_at, document.updated_at,
                        document.processing_status, document.processing_time, document.error_message
                    ))
                    
                    document_id = cursor.lastrowid
                    conn.commit()
                    
                    logger.info(f"文档记录插入成功，ID: {document_id}")
                    return document_id
                    
            except Exception as e:
                logger.error(f"文档记录插入失败: {e}")
                raise
    
    def update_document(self, document_id: int, **kwargs) -> bool:
        """更新文档记录"""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    cursor = conn.cursor()
                    
                    # 构建更新语句
                    set_clauses = []
                    values = []
                    
                    for key, value in kwargs.items():
                        set_clauses.append(f"{key} = ?")
                        values.append(value)
                    
                    if not set_clauses:
                        return False
                    
                    values.append(document_id)
                    
                    cursor.execute(f"""
                        UPDATE documents 
                        SET {', '.join(set_clauses)}, updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    """, values)
                    
                    conn.commit()
                    
                    logger.info(f"文档记录更新成功，ID: {document_id}")
                    return cursor.rowcount > 0
                    
            except Exception as e:
                logger.error(f"文档记录更新失败: {e}")
                return False
    
    def get_document(self, document_id: int) -> Optional[Dict[str, Any]]:
        """获取文档记录"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute("SELECT * FROM documents WHERE id = ?", (document_id,))
                row = cursor.fetchone()
                
                if row:
                    return dict(row)
                return None
                
        except Exception as e:
            logger.error(f"获取文档记录失败: {e}")
            return None
    
    def get_document_by_filename(self, filename: str) -> Optional[Dict[str, Any]]:
        """根据文件名获取文档记录"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute("SELECT * FROM documents WHERE filename = ?", (filename,))
                row = cursor.fetchone()
                
                if row:
                    return dict(row)
                return None
                
        except Exception as e:
            logger.error(f"根据文件名获取文档记录失败: {e}")
            return None
    
    def insert_page(self, document_id: int, page_number: int, width: float, height: float) -> int:
        """插入页面记录"""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute("""
                        INSERT INTO pages (document_id, page_number, width, height)
                        VALUES (?, ?, ?, ?)
                    """, (document_id, page_number, width, height))
                    
                    page_id = cursor.lastrowid
                    conn.commit()
                    
                    logger.debug(f"页面记录插入成功，ID: {page_id}")
                    return page_id
                    
            except Exception as e:
                logger.error(f"页面记录插入失败: {e}")
                raise
    
    def insert_text_elements(self, page_id: int, text_elements: List[TextElement]) -> bool:
        """批量插入文本元素"""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    cursor = conn.cursor()
                    
                    for element in text_elements:
                        cursor.execute("""
                            INSERT INTO text_elements 
                            (page_id, content, bbox, confidence, font_size, font_name, color, ocr_engine, element_type)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """, (
                            page_id, element.text, json.dumps(element.bbox.to_dict()), 
                            element.confidence, element.font_size, element.font_name,
                            json.dumps(element.color), element.ocr_engine, "text"
                        ))
                    
                    conn.commit()
                    
                    logger.debug(f"文本元素批量插入成功，数量: {len(text_elements)}")
                    return True
                    
            except Exception as e:
                logger.error(f"文本元素批量插入失败: {e}")
                return False
    
    def insert_graphic_elements(self, page_id: int, graphic_elements: List[GeometricElement]) -> bool:
        """批量插入图形元素"""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    cursor = conn.cursor()
                    
                    for element in graphic_elements:
                        cursor.execute("""
                            INSERT INTO graphic_elements 
                            (page_id, element_type, points, bbox, properties, confidence, layer)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                        """, (
                            page_id, element.element_type, json.dumps(element.points),
                            json.dumps(element.bbox.to_dict()), json.dumps(element.properties),
                            element.confidence, element.layer
                        ))
                    
                    conn.commit()
                    
                    logger.debug(f"图形元素批量插入成功，数量: {len(graphic_elements)}")
                    return True
                    
            except Exception as e:
                logger.error(f"图形元素批量插入失败: {e}")
                return False
    
    def insert_layout_elements(self, page_id: int, layout_elements: List[LayoutElement]) -> bool:
        """批量插入布局元素"""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    cursor = conn.cursor()
                    
                    for element in layout_elements:
                        cursor.execute("""
                            INSERT INTO layout_elements 
                            (page_id, element_type, bbox, confidence, content, hierarchy_level, parent_element, child_elements)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        """, (
                            page_id, element.element_type, json.dumps(element.bbox.to_dict()),
                            element.confidence, element.content, element.hierarchy_level,
                            element.parent_element.element_type if element.parent_element else None,
                            json.dumps([child.to_dict() for child in element.child_elements])
                        ))
                    
                    conn.commit()
                    
                    logger.debug(f"布局元素批量插入成功，数量: {len(layout_elements)}")
                    return True
                    
            except Exception as e:
                logger.error(f"布局元素批量插入失败: {e}")
                return False
    
    def insert_dimensions(self, page_id: int, dimensions: List[DimensionAnnotation]) -> bool:
        """批量插入尺寸标注"""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    cursor = conn.cursor()
                    
                    for dimension in dimensions:
                        cursor.execute("""
                            INSERT INTO dimensions 
                            (page_id, dimension_value, dimension_type, unit, tolerance, precision, bbox, confidence)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        """, (
                            page_id, dimension.dimension_value, dimension.dimension_type,
                            dimension.unit, dimension.tolerance, dimension.precision,
                            json.dumps(dimension.bbox.to_dict()) if dimension.bbox else None,
                            dimension.confidence
                        ))
                    
                    conn.commit()
                    
                    logger.debug(f"尺寸标注批量插入成功，数量: {len(dimensions)}")
                    return True
                    
            except Exception as e:
                logger.error(f"尺寸标注批量插入失败: {e}")
                return False
    
    def insert_symbols(self, page_id: int, symbols: List[SymbolInstance]) -> bool:
        """批量插入符号"""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    cursor = conn.cursor()
                    
                    for symbol in symbols:
                        cursor.execute("""
                            INSERT INTO symbols 
                            (page_id, symbol_type, bbox, confidence, properties, template_id)
                            VALUES (?, ?, ?, ?, ?, ?)
                        """, (
                            page_id, symbol.symbol_type, json.dumps(symbol.bbox.to_dict()),
                            symbol.confidence, json.dumps(symbol.properties), symbol.template_id
                        ))
                    
                    conn.commit()
                    
                    logger.debug(f"符号批量插入成功，数量: {len(symbols)}")
                    return True
                    
            except Exception as e:
                logger.error(f"符号批量插入失败: {e}")
                return False
    
    def insert_processing_result(self, result: ProcessingResult) -> int:
        """插入处理结果"""
        with self._lock:
            try:
                with self._get_connection() as conn:
                    cursor = conn.cursor()
                    
                    cursor.execute("""
                        INSERT INTO processing_results 
                        (document_id, page_number, text_elements, graphic_elements, layout_elements, 
                         dimensions, symbols, metadata, confidence_score, processing_time)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        result.document_id, result.page_number, json.dumps(result.text_elements),
                        json.dumps(result.graphic_elements), json.dumps(result.layout_elements),
                        json.dumps(result.dimensions), json.dumps(result.symbols),
                        json.dumps(result.metadata), result.confidence_score, result.processing_time
                    ))
                    
                    result_id = cursor.lastrowid
                    conn.commit()
                    
                    logger.debug(f"处理结果插入成功，ID: {result_id}")
                    return result_id
                    
            except Exception as e:
                logger.error(f"处理结果插入失败: {e}")
                raise
    
    def get_document_data(self, document_id: int) -> Dict[str, Any]:
        """获取文档完整数据"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # 获取文档信息
                cursor.execute("SELECT * FROM documents WHERE id = ?", (document_id,))
                document = dict(cursor.fetchone()) if cursor.fetchone() else None
                
                if not document:
                    return {}
                
                # 获取页面数据
                cursor.execute("SELECT * FROM pages WHERE document_id = ? ORDER BY page_number", (document_id,))
                pages = [dict(row) for row in cursor.fetchall()]
                
                # 获取每页的详细数据
                for page in pages:
                    page_id = page["id"]
                    
                    # 获取文本元素
                    cursor.execute("SELECT * FROM text_elements WHERE page_id = ?", (page_id,))
                    page["text_elements"] = [dict(row) for row in cursor.fetchall()]
                    
                    # 获取图形元素
                    cursor.execute("SELECT * FROM graphic_elements WHERE page_id = ?", (page_id,))
                    page["graphic_elements"] = [dict(row) for row in cursor.fetchall()]
                    
                    # 获取布局元素
                    cursor.execute("SELECT * FROM layout_elements WHERE page_id = ?", (page_id,))
                    page["layout_elements"] = [dict(row) for row in cursor.fetchall()]
                    
                    # 获取尺寸标注
                    cursor.execute("SELECT * FROM dimensions WHERE page_id = ?", (page_id,))
                    page["dimensions"] = [dict(row) for row in cursor.fetchall()]
                    
                    # 获取符号
                    cursor.execute("SELECT * FROM symbols WHERE page_id = ?", (page_id,))
                    page["symbols"] = [dict(row) for row in cursor.fetchall()]
                
                return {
                    "document": document,
                    "pages": pages
                }
                
        except Exception as e:
            logger.error(f"获取文档数据失败: {e}")
            return {}
    
    def search_documents(self, **criteria) -> List[Dict[str, Any]]:
        """搜索文档"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # 构建查询条件
                where_clauses = []
                values = []
                
                for key, value in criteria.items():
                    if key == "filename" and value:
                        where_clauses.append("filename LIKE ?")
                        values.append(f"%{value}%")
                    elif key == "processing_status" and value:
                        where_clauses.append("processing_status = ?")
                        values.append(value)
                    elif key == "created_after" and value:
                        where_clauses.append("created_at >= ?")
                        values.append(value)
                    elif key == "created_before" and value:
                        where_clauses.append("created_at <= ?")
                        values.append(value)
                
                where_clause = " AND ".join(where_clauses) if where_clauses else "1=1"
                
                cursor.execute(f"""
                    SELECT * FROM documents 
                    WHERE {where_clause}
                    ORDER BY created_at DESC
                """, values)
                
                return [dict(row) for row in cursor.fetchall()]
                
        except Exception as e:
            logger.error(f"搜索文档失败: {e}")
            return []
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取数据库统计信息"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                stats = {}
                
                # 文档统计
                cursor.execute("SELECT COUNT(*) FROM documents")
                stats["total_documents"] = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM documents WHERE processing_status = 'completed'")
                stats["completed_documents"] = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM documents WHERE processing_status = 'failed'")
                stats["failed_documents"] = cursor.fetchone()[0]
                
                # 页面统计
                cursor.execute("SELECT COUNT(*) FROM pages")
                stats["total_pages"] = cursor.fetchone()[0]
                
                # 元素统计
                cursor.execute("SELECT COUNT(*) FROM text_elements")
                stats["text_elements"] = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM graphic_elements")
                stats["graphic_elements"] = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM layout_elements")
                stats["layout_elements"] = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM dimensions")
                stats["dimensions"] = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM symbols")
                stats["symbols"] = cursor.fetchone()[0]
                
                return stats
                
        except Exception as e:
            logger.error(f"获取统计信息失败: {e}")
            return {}

class DataExporter:
    """数据导出器"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        self.export_config = self.config["export"]
    
    def export_to_json(self, data: Dict[str, Any], output_path: Union[str, Path]) -> bool:
        """导出为JSON格式"""
        try:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2, default=str)
            
            logger.info(f"数据导出为JSON格式: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"JSON导出失败: {e}")
            return False
    
    def export_to_csv(self, data: Dict[str, Any], output_path: Union[str, Path]) -> bool:
        """导出为CSV格式"""
        try:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            
            # 准备CSV数据
            rows = []
            
            # 文档信息
            if "document" in data:
                doc = data["document"]
                rows.append({
                    "type": "document",
                    "id": doc.get("id"),
                    "filename": doc.get("filename"),
                    "pages": doc.get("pages"),
                    "processing_status": doc.get("processing_status")
                })
            
            # 页面数据
            if "pages" in data:
                for page in data["pages"]:
                    # 文本元素
                    for text_elem in page.get("text_elements", []):
                        rows.append({
                            "type": "text_element",
                            "page_number": page.get("page_number"),
                            "content": text_elem.get("content"),
                            "confidence": text_elem.get("confidence"),
                            "bbox": text_elem.get("bbox")
                        })
                    
                    # 图形元素
                    for graphic_elem in page.get("graphic_elements", []):
                        rows.append({
                            "type": "graphic_element",
                            "page_number": page.get("page_number"),
                            "element_type": graphic_elem.get("element_type"),
                            "confidence": graphic_elem.get("confidence"),
                            "bbox": graphic_elem.get("bbox")
                        })
                    
                    # 尺寸标注
                    for dimension in page.get("dimensions", []):
                        rows.append({
                            "type": "dimension",
                            "page_number": page.get("page_number"),
                            "dimension_value": dimension.get("dimension_value"),
                            "dimension_type": dimension.get("dimension_type"),
                            "unit": dimension.get("unit")
                        })
            
            # 写入CSV
            if rows:
                df = pd.DataFrame(rows)
                df.to_csv(output_path, index=False, encoding='utf-8')
            
            logger.info(f"数据导出为CSV格式: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"CSV导出失败: {e}")
            return False
    
    def export_to_xml(self, data: Dict[str, Any], output_path: Union[str, Path]) -> bool:
        """导出为XML格式"""
        try:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            
            # 创建根元素
            root = ET.Element("pdf_ocr_data")
            
            # 添加文档信息
            if "document" in data:
                doc_elem = ET.SubElement(root, "document")
                for key, value in data["document"].items():
                    elem = ET.SubElement(doc_elem, key)
                    elem.text = str(value) if value is not None else ""
            
            # 添加页面数据
            if "pages" in data:
                pages_elem = ET.SubElement(root, "pages")
                for page in data["pages"]:
                    page_elem = ET.SubElement(pages_elem, "page")
                    page_elem.set("number", str(page.get("page_number", "")))
                    
                    # 文本元素
                    for text_elem in page.get("text_elements", []):
                        text_elem_xml = ET.SubElement(page_elem, "text_element")
                        text_elem_xml.set("content", text_elem.get("content", ""))
                        text_elem_xml.set("confidence", str(text_elem.get("confidence", "")))
                    
                    # 图形元素
                    for graphic_elem in page.get("graphic_elements", []):
                        graphic_elem_xml = ET.SubElement(page_elem, "graphic_element")
                        graphic_elem_xml.set("type", graphic_elem.get("element_type", ""))
                        graphic_elem_xml.set("confidence", str(graphic_elem.get("confidence", "")))
            
            # 写入XML文件
            tree = ET.ElementTree(root)
            ET.indent(tree, space="  ", level=0)
            tree.write(output_path, encoding='utf-8', xml_declaration=True)
            
            logger.info(f"数据导出为XML格式: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"XML导出失败: {e}")
            return False
    
    def export_to_excel(self, data: Dict[str, Any], output_path: Union[str, Path]) -> bool:
        """导出为Excel格式"""
        try:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            
            with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                # 文档信息工作表
                if "document" in data:
                    doc_df = pd.DataFrame([data["document"]])
                    doc_df.to_excel(writer, sheet_name='Document', index=False)
                
                # 页面数据工作表
                if "pages" in data:
                    pages_data = []
                    for page in data["pages"]:
                        page_info = page.copy()
                        page_info["text_count"] = len(page.get("text_elements", []))
                        page_info["graphic_count"] = len(page.get("graphic_elements", []))
                        page_info["dimension_count"] = len(page.get("dimensions", []))
                        page_info["symbol_count"] = len(page.get("symbols", []))
                        pages_data.append(page_info)
                    
                    if pages_data:
                        pages_df = pd.DataFrame(pages_data)
                        pages_df.to_excel(writer, sheet_name='Pages', index=False)
                
                # 文本元素工作表
                text_elements = []
                for page in data.get("pages", []):
                    for text_elem in page.get("text_elements", []):
                        text_elem_copy = text_elem.copy()
                        text_elem_copy["page_number"] = page.get("page_number")
                        text_elements.append(text_elem_copy)
                
                if text_elements:
                    text_df = pd.DataFrame(text_elements)
                    text_df.to_excel(writer, sheet_name='Text_Elements', index=False)
                
                # 图形元素工作表
                graphic_elements = []
                for page in data.get("pages", []):
                    for graphic_elem in page.get("graphic_elements", []):
                        graphic_elem_copy = graphic_elem.copy()
                        graphic_elem_copy["page_number"] = page.get("page_number")
                        graphic_elements.append(graphic_elem_copy)
                
                if graphic_elements:
                    graphic_df = pd.DataFrame(graphic_elements)
                    graphic_df.to_excel(writer, sheet_name='Graphic_Elements', index=False)
            
            logger.info(f"数据导出为Excel格式: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Excel导出失败: {e}")
            return False

class StructuredDataManager:
    """结构化数据管理器主类"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        
        # 初始化组件
        self.db_manager = DatabaseManager(self.config)
        self.data_exporter = DataExporter(self.config)
        
        logger.info("结构化数据管理器初始化完成")
    
    def store_processing_result(self, document_record: DocumentRecord, 
                              page_data_list: List[PageData],
                              processing_results: List[ProcessingResult]) -> bool:
        """
        存储处理结果
        
        Args:
            document_record: 文档记录
            page_data_list: 页面数据列表
            processing_results: 处理结果列表
            
        Returns:
            bool: 存储是否成功
        """
        try:
            logger.info(f"开始存储处理结果: {document_record.filename}")
            
            # 1. 插入文档记录
            document_id = self.db_manager.insert_document(document_record)
            
            # 2. 插入页面数据和元素
            for page_data, processing_result in zip(page_data_list, processing_results):
                # 插入页面记录
                page_id = self.db_manager.insert_page(
                    document_id, 
                    page_data.page_number + 1,  # 转换为1-based
                    page_data.width, 
                    page_data.height
                )
                
                # 插入文本元素
                if page_data.text_elements:
                    self.db_manager.insert_text_elements(page_id, page_data.text_elements)
                
                # 插入图形元素
                if page_data.vector_elements:
                    # 转换VectorElement为GeometricElement
                    geometric_elements = self._convert_vector_to_geometric(page_data.vector_elements)
                    self.db_manager.insert_graphic_elements(page_id, geometric_elements)
                
                # 插入布局元素
                if processing_result.layout_elements:
                    layout_elements = [LayoutElement(**elem) for elem in processing_result.layout_elements]
                    self.db_manager.insert_layout_elements(page_id, layout_elements)
                
                # 插入尺寸标注
                if processing_result.dimensions:
                    dimensions = [DimensionAnnotation(**dim) for dim in processing_result.dimensions]
                    self.db_manager.insert_dimensions(page_id, dimensions)
                
                # 插入符号
                if processing_result.symbols:
                    symbols = [SymbolInstance(**sym) for sym in processing_result.symbols]
                    self.db_manager.insert_symbols(page_id, symbols)
                
                # 插入处理结果
                processing_result.document_id = document_id
                self.db_manager.insert_processing_result(processing_result)
            
            # 3. 更新文档状态
            self.db_manager.update_document(document_id, processing_status="completed")
            
            logger.info(f"处理结果存储完成: {document_record.filename}")
            return True
            
        except Exception as e:
            logger.error(f"处理结果存储失败: {e}")
            # 更新文档状态为失败
            if 'document_id' in locals():
                self.db_manager.update_document(
                    document_id, 
                    processing_status="failed", 
                    error_message=str(e)
                )
            return False
    
    def _convert_vector_to_geometric(self, vector_elements: List[VectorElement]) -> List[GeometricElement]:
        """转换VectorElement为GeometricElement"""
        geometric_elements = []
        
        for vector_elem in vector_elements:
            geometric_element = GeometricElement(
                element_type=vector_elem.element_type,
                points=vector_elem.points,
                bbox=vector_elem.bbox,
                confidence=1.0,  # 矢量元素置信度为1
                properties={
                    "stroke_color": vector_elem.stroke_color,
                    "fill_color": vector_elem.fill_color,
                    "stroke_width": vector_elem.stroke_width,
                    "layer": vector_elem.layer
                },
                layer=vector_elem.layer
            )
            geometric_elements.append(geometric_element)
        
        return geometric_elements
    
    def retrieve_document(self, document_id: int) -> Dict[str, Any]:
        """检索文档数据"""
        return self.db_manager.get_document_data(document_id)
    
    def search_documents(self, **criteria) -> List[Dict[str, Any]]:
        """搜索文档"""
        return self.db_manager.search_documents(**criteria)
    
    def export_document(self, document_id: int, output_path: Union[str, Path], 
                       format: str = "json") -> bool:
        """
        导出文档数据
        
        Args:
            document_id: 文档ID
            output_path: 输出路径
            format: 导出格式 (json, csv, xml, excel)
            
        Returns:
            bool: 导出是否成功
        """
        try:
            # 获取文档数据
            data = self.retrieve_document(document_id)
            
            if not data:
                logger.error(f"文档数据不存在: {document_id}")
                return False
            
            # 根据格式导出
            if format.lower() == "json":
                return self.data_exporter.export_to_json(data, output_path)
            elif format.lower() == "csv":
                return self.data_exporter.export_to_csv(data, output_path)
            elif format.lower() == "xml":
                return self.data_exporter.export_to_xml(data, output_path)
            elif format.lower() == "excel":
                return self.data_exporter.export_to_excel(data, output_path)
            else:
                logger.error(f"不支持的导出格式: {format}")
                return False
                
        except Exception as e:
            logger.error(f"文档导出失败: {e}")
            return False
    
    def get_database_statistics(self) -> Dict[str, Any]:
        """获取数据库统计信息"""
        return self.db_manager.get_statistics()
    
    def cleanup_old_documents(self, days: int = 30) -> int:
        """清理旧文档"""
        try:
            with self.db_manager._get_connection() as conn:
                cursor = conn.cursor()
                
                # 计算日期阈值
                cutoff_date = datetime.now().timestamp() - (days * 24 * 60 * 60)
                
                # 删除旧的失败文档
                cursor.execute("""
                    DELETE FROM documents 
                    WHERE processing_status = 'failed' 
                    AND created_at < ?
                """, (cutoff_date,))
                
                deleted_count = cursor.rowcount
                conn.commit()
                
                logger.info(f"清理了 {deleted_count} 个旧文档")
                return deleted_count
                
        except Exception as e:
            logger.error(f"清理旧文档失败: {e}")
            return 0

# 辅助函数
def calculate_confidence_score(processing_result: ProcessingResult) -> float:
    """计算处理结果的置信度分数"""
    scores = []
    
    # 文本元素置信度
    if processing_result.text_elements:
        text_scores = [elem.get("confidence", 0) for elem in processing_result.text_elements]
        scores.append(sum(text_scores) / len(text_scores))
    
    # 图形元素置信度
    if processing_result.graphic_elements:
        graphic_scores = [elem.get("confidence", 0) for elem in processing_result.graphic_elements]
        scores.append(sum(graphic_scores) / len(graphic_scores))
    
    # 布局元素置信度
    if processing_result.layout_elements:
        layout_scores = [elem.get("confidence", 0) for elem in processing_result.layout_elements]
        scores.append(sum(layout_scores) / len(layout_scores))
    
    # 尺寸标注置信度
    if processing_result.dimensions:
        dimension_scores = [elem.get("confidence", 0) for elem in processing_result.dimensions]
        scores.append(sum(dimension_scores) / len(dimension_scores))
    
    # 符号置信度
    if processing_result.symbols:
        symbol_scores = [elem.get("confidence", 0) for elem in processing_result.symbols]
        scores.append(sum(symbol_scores) / len(symbol_scores))
    
    # 计算总体置信度
    if scores:
        return sum(scores) / len(scores)
    else:
        return 0.0

def validate_processing_result(result: ProcessingResult) -> Tuple[bool, List[str]]:
    """验证处理结果的有效性"""
    errors = []
    
    # 检查必要字段
    if not result.document_id:
        errors.append("缺少文档ID")
    
    if result.page_number < 1:
        errors.append("页码无效")
    
    # 检查数据一致性
    if not any([
        result.text_elements,
        result.graphic_elements,
        result.layout_elements,
        result.dimensions,
        result.symbols
    ]):
        errors.append("没有任何识别结果")
    
    # 检查置信度
    if result.confidence_score < 0 or result.confidence_score > 1:
        errors.append("置信度分数超出范围")
    
    return len(errors) == 0, errors

# 使用示例
if __name__ == "__main__":
    # 创建结构化数据管理器
    config = get_config()
    data_manager = StructuredDataManager(config)
    
    # 创建测试文档记录
    doc_record = DocumentRecord(
        filename="test_document.pdf",
        file_path="/path/to/test_document.pdf",
        pages=3,
        file_size=1024000,
        file_hash="abc123def456",
        created_at=datetime.now().isoformat(),
        processing_status="pending"
    )
    
    # 创建测试页面数据
    test_page_data = PageData(
        page_number=0,
        width=800,
        height=600,
        text_elements=[],
        vector_elements=[],
        image_elements=[],
        metadata={}
    )
    
    # 创建测试处理结果
    test_result = ProcessingResult(
        document_id=0,  # 将被更新
        page_number=1,
        text_elements=[],
        graphic_elements=[],
        layout_elements=[],
        dimensions=[],
        symbols=[],
        metadata={}
    )
    
    # 计算置信度分数
    test_result.confidence_score = calculate_confidence_score(test_result)
    
    # 验证处理结果
    is_valid, errors = validate_processing_result(test_result)
    print(f"处理结果验证: {'通过' if is_valid else '失败'}")
    if errors:
        print(f"错误: {errors}")
    
    # 获取数据库统计
    stats = data_manager.get_database_statistics()
    print(f"数据库统计: {stats}")
    
    print("结构化数据管理器测试完成")
