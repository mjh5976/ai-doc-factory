"""
PDF OCR系统配置文件
包含所有模块的配置参数和常量定义
"""

import os
from pathlib import Path

# 项目根目录
PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR = PROJECT_ROOT / "data"
OUTPUT_DIR = PROJECT_ROOT / "output"
MODELS_DIR = PROJECT_ROOT / "models"
LOGS_DIR = PROJECT_ROOT / "logs"
TEMP_DIR = PROJECT_ROOT / "temp"

# 创建目录
for dir_path in [DATA_DIR, OUTPUT_DIR, MODELS_DIR, LOGS_DIR, TEMP_DIR]:
    dir_path.mkdir(exist_ok=True)

# PDF处理配置
PDF_CONFIG = {
    # PDF解析参数
    "parse_dpi": 300,  # PDF解析DPI
    "max_pages": 100,  # 最大处理页数
    "page_rotation": 0,  # 页面旋转角度
    
    # 栅格化参数
    "raster_dpi": 600,  # 栅格化DPI
    "image_format": "PNG",  # 图像格式
    "image_quality": 95,  # 图像质量
    
    # 分块参数
    "tile_size": 1024,  # 分块大小
    "tile_overlap": 128,  # 分块重叠
}

# 文本识别配置
TEXT_RECOGNITION_CONFIG = {
    # OCR模型配置
    "tesseract_config": "--psm 6 -c tessedit_char_whitelist=0123456789.-+*/()abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "paddle_config": {
        "use_angle_cls": True,
        "lang": "ch",
        "det_algorithm": "DB",
        "rec_algorithm": "SVTR_LCNet",
        "use_gpu": True,
    },
    
    # 文本检测参数
    "min_text_size": 8,  # 最小文本尺寸
    "max_text_size": 200,  # 最大文本尺寸
    "text_confidence": 0.7,  # 文本置信度阈值
    
    # 布局分析参数
    "layout_model": "PaddleOCR/layoutparser",  # 布局分析模型
    "layout_threshold": 0.5,  # 布局置信度阈值
}

# 图形检测配置
GRAPHICS_DETECTION_CONFIG = {
    # 线条检测参数
    "line_detection": {
        "hough_lines": {
            "threshold": 100,
            "min_line_length": 50,
            "max_line_gap": 10,
            "rho": 1,
            "theta": "np.pi/180"
        },
        "morphology": {
            "kernel_size": (3, 3),
            "iterations": 2
        }
    },
    
    # 形状检测参数
    "shape_detection": {
        "circle_detection": {
            "param1": 50,
            "param2": 30,
            "min_radius": 10,
            "max_radius": 200
        },
        "rectangle_detection": {
            "min_area": 100,
            "max_area": 10000,
            "aspect_ratio_range": (0.1, 10.0)
        }
    },
    
    # 符号检测参数
    "symbol_detection": {
        "model_path": "models/symbol_detection.pth",
        "confidence_threshold": 0.7,
        "nms_threshold": 0.4,
        "input_size": 512
    }
}

# 尺寸标注识别配置
DIMENSION_RECOGNITION_CONFIG = {
    # 尺寸标注检测参数
    "dimension_detection": {
        "arrow_detection": {
            "min_arrow_length": 20,
            "max_arrow_length": 200,
            "arrow_angle_threshold": 30
        },
        "dimension_line_detection": {
            "min_dimension_length": 30,
            "max_dimension_length": 500,
            "dimension_tolerance": 10
        }
    },
    
    # 尺寸数值提取参数
    "value_extraction": {
        "number_patterns": [
            r"\d+\.?\d*",  # 小数
            r"\d+/\d+",    # 分数
            r"\d+",        # 整数
            r"[+-]?\d+\.?\d*",  # 带符号数字
        ],
        "unit_patterns": [
            "mm", "cm", "m", "inch", "ft", "°", "deg"
        ],
        "tolerance_patterns": [
            r"±\d+\.?\d*",
            r"\+\d+\.?\d*/-\d+\.?\d*"
        ]
    },
    
    # 工程符号识别参数
    "engineering_symbols": {
        "gd_t_symbols": [
            "⌀", "⏤", "∥", "⊥", "∠", "⌭", "⌯", "⌰", "⌱", "⌲", "⌳", "⌴"
        ],
        "surface_finish": ["Ra", "Rz", "Rt"],
        "welding_symbols": ["⏚", "⚡", "⚙"],
        "geometric_tolerance": ["⌀", "⏤", "∥", "⊥", "∠"]
    }
}

# 结构化数据配置
DATA_STRUCTURE_CONFIG = {
    # 数据存储配置
    "database": {
        "type": "sqlite",
        "path": str(DATA_DIR / "pdf_ocr.db"),
        "backup_path": str(DATA_DIR / "pdf_ocr_backup.db")
    },
    
    # 数据模式配置
    "schema": {
        "document": {
            "id": "INTEGER PRIMARY KEY",
            "filename": "TEXT NOT NULL",
            "pages": "INTEGER",
            "created_at": "DATETIME DEFAULT CURRENT_TIMESTAMP",
            "updated_at": "DATETIME DEFAULT CURRENT_TIMESTAMP"
        },
        "page": {
            "id": "INTEGER PRIMARY KEY",
            "document_id": "INTEGER",
            "page_number": "INTEGER",
            "width": "REAL",
            "height": "REAL",
            "FOREIGN KEY (document_id) REFERENCES document (id)"
        },
        "text_element": {
            "id": "INTEGER PRIMARY KEY",
            "page_id": "INTEGER",
            "content": "TEXT",
            "bbox": "TEXT",  # JSON格式存储边界框
            "confidence": "REAL",
            "element_type": "TEXT",
            "FOREIGN KEY (page_id) REFERENCES page (id)"
        },
        "graphic_element": {
            "id": "INTEGER PRIMARY KEY",
            "page_id": "INTEGER",
            "element_type": "TEXT",
            "coordinates": "TEXT",  # JSON格式存储坐标
            "properties": "TEXT",  # JSON格式存储属性
            "confidence": "REAL",
            "FOREIGN KEY (page_id) REFERENCES page (id)"
        },
        "dimension": {
            "id": "INTEGER PRIMARY KEY",
            "page_id": "INTEGER",
            "dimension_value": "TEXT",
            "dimension_type": "TEXT",
            "tolerance": "TEXT",
            "unit": "TEXT",
            "bbox": "TEXT",
            "FOREIGN KEY (page_id) REFERENCES page (id)"
        },
        "symbol": {
            "id": "INTEGER PRIMARY KEY",
            "page_id": "INTEGER",
            "symbol_type": "TEXT",
            "bbox": "TEXT",
            "properties": "TEXT",
            "confidence": "REAL",
            "FOREIGN KEY (page_id) REFERENCES page (id)"
        }
    },
    
    # 导出配置
    "export": {
        "formats": ["json", "csv", "xml", "excel"],
        "include_images": True,
        "include_raw_data": False,
        "compress_output": True
    }
}

# 多模态融合配置
MULTIMODAL_FUSION_CONFIG = {
    # 特征融合参数
    "feature_fusion": {
        "text_weight": 0.3,
        "graphic_weight": 0.4,
        "geometric_weight": 0.3,
        "fusion_method": "weighted_average"  # weighted_average, attention, late_fusion
    },
    
    # 上下文感知参数
    "context_awareness": {
        "neighborhood_radius": 50,
        "context_window": 100,
        "similarity_threshold": 0.8
    },
    
    # 决策融合参数
    "decision_fusion": {
        "voting_strategy": "majority",  # majority, weighted, consensus
        "confidence_threshold": 0.6,
        "conflict_resolution": "high_confidence"  # high_confidence, manual_review, consensus
    }
}

# 验证和校正配置
VALIDATION_CONFIG = {
    # 几何一致性验证
    "geometric_validation": {
        "angle_tolerance": 5,  # 度
        "length_tolerance": 5,  # 像素
        "parallel_tolerance": 2,  # 度
        "perpendicular_tolerance": 2  # 度
    },
    
    # 语义合理性检查
    "semantic_validation": {
        "dimension_range": {
            "min_value": 0.1,
            "max_value": 10000.0
        },
        "symbol_constraints": {
            "arrow_pairs": True,  # 箭头必须成对出现
            "dimension_lines": True,  # 尺寸线必须与箭头关联
            "text_alignment": True  # 文本必须与标注线对齐
        }
    },
    
    # 错误检测参数
    "error_detection": {
        "outlier_detection": {
            "method": "iqr",  # iqr, zscore, isolation_forest
            "threshold": 1.5
        },
        "inconsistency_detection": {
            "duplicate_detection": True,
            "missing_element_detection": True,
            "spatial_conflict_detection": True
        }
    },
    
    # 自动校正参数
    "auto_correction": {
        "enable_geometric_correction": True,
        "enable_semantic_correction": True,
        "correction_confidence_threshold": 0.8,
        "manual_review_threshold": 0.6
    }
}

# 系统性能配置
PERFORMANCE_CONFIG = {
    # 并行处理参数
    "parallel_processing": {
        "max_workers": 4,
        "chunk_size": 10,
        "timeout": 300
    },
    
    # 内存管理参数
    "memory_management": {
        "max_image_size": (4096, 4096),
        "cache_size": 100,
        "gc_threshold": 1000
    },
    
    # 缓存配置
    "caching": {
        "enable_cache": True,
        "cache_ttl": 3600,  # 秒
        "cache_size_limit": 1000  # MB
    }
}

# 日志配置
LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "standard": {
            "format": "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        },
        "detailed": {
            "format": "%(asctime)s [%(levelname)s] %(name)s:%(lineno)d: %(message)s"
        }
    },
    "handlers": {
        "default": {
            "level": "INFO",
            "formatter": "standard",
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stdout"
        },
        "file": {
            "level": "DEBUG",
            "formatter": "detailed",
            "class": "logging.FileHandler",
            "filename": str(LOGS_DIR / "pdf_ocr.log"),
            "mode": "a"
        },
        "error_file": {
            "level": "ERROR",
            "formatter": "detailed",
            "class": "logging.FileHandler",
            "filename": str(LOGS_DIR / "pdf_ocr_error.log"),
            "mode": "a"
        }
    },
    "loggers": {
        "": {
            "handlers": ["default", "file"],
            "level": "DEBUG",
            "propagate": False
        },
        "pdf_ocr.error": {
            "handlers": ["error_file"],
            "level": "ERROR",
            "propagate": False
        }
    }
}

# API配置
API_CONFIG = {
    "host": "0.0.0.0",
    "port": 8000,
    "debug": False,
    "cors_origins": ["*"],
    "rate_limit": "100/minute",
    "max_upload_size": 100 * 1024 * 1024,  # 100MB
    "allowed_extensions": [".pdf"],
    "timeout": 300
}

# 模型配置
MODEL_CONFIG = {
    # 预训练模型路径
    "pretrained_models": {
        "text_detection": "models/text_detection.pth",
        "symbol_detection": "models/symbol_detection.pth",
        "dimension_detection": "models/dimension_detection.pth",
        "layout_analysis": "models/layout_analysis.pth"
    },
    
    # 模型参数
    "model_params": {
        "input_size": 512,
        "num_classes": {
            "text": 1,
            "symbols": 50,
            "dimensions": 10,
            "layouts": 20
        },
        "confidence_threshold": 0.7,
        "nms_threshold": 0.4
    }
}

# 质量控制配置
QUALITY_CONTROL_CONFIG = {
    # 质量评估参数
    "quality_metrics": {
        "text_accuracy": 0.95,
        "symbol_accuracy": 0.90,
        "dimension_accuracy": 0.85,
        "geometric_accuracy": 0.92
    },
    
    # 质量检查规则
    "quality_rules": {
        "min_text_confidence": 0.7,
        "min_symbol_confidence": 0.6,
        "max_dimension_error": 0.05,  # 5%
        "required_elements": ["text", "dimensions", "symbols"]
    },
    
    # 质量报告配置
    "quality_report": {
        "generate_report": True,
        "report_format": "html",
        "include_metrics": True,
        "include_visualizations": True
    }
}

# 导出配置
EXPORT_CONFIG = {
    # 输出格式
    "formats": {
        "json": {
            "indent": 2,
            "ensure_ascii": False,
            "sort_keys": True
        },
        "csv": {
            "encoding": "utf-8",
            "delimiter": ",",
            "quotechar": '"'
        },
        "xml": {
            "pretty_print": True,
            "encoding": "utf-8"
        },
        "excel": {
            "engine": "openpyxl",
            "sheet_name": "PDF_OCR_Results"
        }
    },
    
    # 导出选项
    "options": {
        "include_metadata": True,
        "include_confidence_scores": True,
        "include_bounding_boxes": True,
        "include_raw_ocr_text": False,
        "compress_output": True
    }
}

def get_config():
    """获取完整配置"""
    return {
        "pdf": PDF_CONFIG,
        "text_recognition": TEXT_RECOGNITION_CONFIG,
        "graphics_detection": GRAPHICS_DETECTION_CONFIG,
        "dimension_recognition": DIMENSION_RECOGNITION_CONFIG,
        "data_structure": DATA_STRUCTURE_CONFIG,
        "multimodal_fusion": MULTIMODAL_FUSION_CONFIG,
        "validation": VALIDATION_CONFIG,
        "performance": PERFORMANCE_CONFIG,
        "logging": LOGGING_CONFIG,
        "api": API_CONFIG,
        "model": MODEL_CONFIG,
        "quality_control": QUALITY_CONTROL_CONFIG,
        "export": EXPORT_CONFIG,
        "paths": {
            "project_root": str(PROJECT_ROOT),
            "data_dir": str(DATA_DIR),
            "output_dir": str(OUTPUT_DIR),
            "models_dir": str(MODELS_DIR),
            "logs_dir": str(LOGS_DIR),
            "temp_dir": str(TEMP_DIR)
        }
    }

# 配置验证函数
def validate_config(config):
    """验证配置参数的有效性"""
    errors = []
    
    # 检查必要路径
    for path_key in ["project_root", "data_dir", "output_dir", "models_dir", "logs_dir"]:
        if path_key not in config["paths"]:
            errors.append(f"Missing required path: {path_key}")
    
    # 检查数值范围
    if config["pdf"]["parse_dpi"] < 72 or config["pdf"]["parse_dpi"] > 1200:
        errors.append("PDF parse DPI should be between 72 and 1200")
    
    if config["performance"]["parallel_processing"]["max_workers"] < 1:
        errors.append("Max workers should be at least 1")
    
    # 检查置信度阈值
    for threshold_key in ["text_confidence", "confidence_threshold"]:
        if threshold_key in config["text_recognition"]:
            threshold = config["text_recognition"][threshold_key]
            if not (0 <= threshold <= 1):
                errors.append(f"Confidence threshold {threshold_key} should be between 0 and 1")
    
    return errors

if __name__ == "__main__":
    config = get_config()
    errors = validate_config(config)
    if errors:
        print("Configuration validation errors:")
        for error in errors:
            print(f"  - {error}")
    else:
        print("Configuration validation passed!")
        print(f"Project root: {config['paths']['project_root']}")
        print(f"Data directory: {config['paths']['data_dir']}")
        print(f"Output directory: {config['paths']['output_dir']}")
