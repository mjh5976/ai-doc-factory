# 基于 MLflow + 本地存储的轻量级模型版本管理系统:架构设计与部署指南

## 1. 执行摘要与范围界定

在中小型团队场景中,模型版本管理的核心诉求是“简单、可控、可复现”。引入机器学习运维平台往往意味着额外的基础设施负担,如何在不牺牲治理能力的前提下降低复杂度,是本文要解决的关键问题。本文提出一套以开源 MLflow 为核心、配合本地文件系统作为工件存储的轻量级方案,目标是在单机或小规模部署形态下,实现端到端的模型版本管理、评估比较、部署与回滚,并保留与持续集成/持续交付(CI/CD)对接的扩展能力。

本方案覆盖以下范围:MLflow 服务器与跟踪(Tracking)的配置、模型注册表(Registry)与版本管理策略、本地工件存储的目录结构与优化、模型元数据与评估指标的管理、模型比较与选择机制、自动回滚与恢复策略、CI/CD 集成,以及常见故障的排查与维护。方案以 MLflow 的官方能力为准绳,强调最小可行架构与可落地的操作细节,确保读者可以直接据此搭建并运行一个可治理、可审计、可回滚的模型版本管理系统。[^1][^2]

在叙述中,我们坚持从“是什么”到“怎么做”再到“为何如此”的逻辑展开:先阐明架构与组件职责,再给出配置与操作方法,最后解释背后的权衡与最佳实践。

信息边界与假设:
- 操作系统与文件系统类型(ext4/xfs/NTFS 等)未指定,本文在涉及文件系统特性(如硬链接、挂载)处给出通用建议,具体实现需结合本地环境验证。
- 数据库后端类型与版本未指定,本文默认使用基于数据库的后端存储以支持注册表功能;如采用 SQLite,某些并发与治理能力将受限。
- 生产流量规模、推理延迟与吞吐目标未给出,本文在服务层默认给出轻量级建议;如需高吞吐与弹性扩缩,建议后续迁移至 Kubernetes。
- 合规与安全要求(访问控制、审计保留周期、加密)未明确,本文提供最小可行安全基线,组织级策略需另行补充。
- CI/CD 平台(Jenkins/GitHub Actions)与镜像仓库未指定,本文提供通用流水线模板与注意事项。
- 操作系统配额与磁盘限额策略未给出,本文在清理策略处提供参数化建议,需按本地资源情况进行调整。
- 漂移监控数据源与阈值策略未给出,本文提供方法论与操作位点,阈值需结合业务制定。

以上信息缺口将在相关章节以“需结合本地环境验证”或“需组织补充策略”的方式提示。

[^1]: MLflow:管理机器学习生命周期的工具 | MLflow 平台.  
[^2]: MLflow Model Registry: Guide to Managing the ML Lifecycle.

---

## 2. 架构总览与组件职责

本方案由以下核心组件构成:MLflow Tracking Server、基于数据库的后端存储(Backend Store)、本地文件系统工件存储(Artifact Store)、模型注册表(Registry)、评估服务(基于 mlflow.evaluate 的评估与可视化)、以及可选的轻量级推理服务。MLflow 的组件协同围绕“实验—运行—工件—注册—评估—部署”的链路展开,形成从训练到发布的闭环。[^3][^4][^5]

数据流主线如下:训练脚本通过 Tracking API 记录参数、指标与工件;运行结束后将模型注册到 Registry;评估服务对模型进行系统化评测并产出可视化与诊断;在推广至生产前,设定别名与标签以稳定指向;部署时从 Registry 解析模型 URI 并加载推理。治理信息(运行、评估、阶段转换、别名与标签变更)形成审计轨迹,支撑可追溯与合规。

为帮助读者快速把握职责边界,下表给出组件与职责映射。

表 1 组件与职责映射表
| 组件 | 核心职责 | 关键能力 | 与其他组件的接口 |
|---|---|---|---|
| MLflow Tracking Server | 记录与查询实验、运行、参数、指标与工件 | 提供 REST/Python API 与 UI | 与 Backend Store 交互存储元数据;从 Artifact Store 读取工件 |
| Backend Store(数据库) | 存储实验、运行、注册表等元数据 | 支持注册表工作流与查询 | 由 Tracking Server 读写;与 Registry 协同 |
| Artifact Store(本地FS) | 存储大体积工件(模型权重、图像、评估结果等) | 目录管理、压缩/归档、清理 | Tracking 写入工件;评估与部署读取工件 |
| Model Registry | 集中管理模型版本、别名、标签、阶段 | 版本控制、阶段转换、审批与审计 | 与 Tracking 关联运行;与评估与部署协作 |
| 评估服务(mlflow.evaluate) | 自动化指标计算与可视化诊断 | 内置与自定义指标、解释性图表 | 消费模型与数据,产出评估结果与工件 |
| 推理服务(可选轻量级) | 本地测试与预生产验证 | 快速加载指定模型版本 | 从 Registry/Artifact 解析模型 URI 并加载 |

在轻量级形态下,Tracking 与 Registry 通常由同一 MLflow 服务器提供;Backend Store 采用数据库(如 PostgreSQL/MySQL/SQLite),Artifact Store 采用本地文件系统。评估服务与推理服务按需部署,既可与 Tracking 共机,也可独立部署以隔离负载。[^3][^4][^5]

### 2.1 轻量级部署形态

对于单机或小团队场景,推荐将 MLflow Tracking 与 Registry 部署在同一服务器进程,Backend Store 使用数据库,Artifact Store 使用本地磁盘卷。此形态的优势在于:配置简单、维护成本低、足以支撑小规模并发与实验治理。局限在于:水平扩展能力有限、吞吐与可用性受主机资源约束;当团队规模或生产流量增长时,应评估迁移至 Kubernetes 或外部对象存储以获得弹性与高可用。[^3]

---

## 3. MLflow 配置与自定义扩展

要让系统“可落地”,首先要正确配置 MLflow 的后端与工件存储,明确可观测性与可复现性边界;其次要善用插件与自定义模型风味(flavor),在不牺牲轻量性的前提下扩展生态。

### 3.1 环境与依赖

建议使用 Python 3.8 及以上版本,并将 MLflow 安装在独立虚拟环境中,避免与系统包冲突。训练与评估脚本通过 mlflow.start_run() 管理运行上下文,确保参数、指标与工件记录在同一运行之下。依赖管理方面,推荐在训练时记录 requirements.txt 或 environment.yml,以及关键数据的摘要(如数据版本或哈希),为复现与审计提供必要线索。[^3]

### 3.2 服务器配置

MLflow Tracking Server 的核心环境变量与配置项如下:

- MLFLOW_BACKEND_STORE_URI:指定后端数据库连接串(如 postgresql+psycopg2://user:pass@host:5432/db)。
- MLFLOW_DEFAULT_ARTIFACT_ROOT:指定工件根目录(本地路径或挂载点)。
- MLFLOW_TRACKING_URI:客户端用于指向 Tracking Server 的 URI(本地文件或 http/https)。

在轻量级形态下,推荐使用本地路径作为默认工件根目录,并将数据库部署为本地服务或容器化服务。UI 访问应配置反向代理与基础认证,确保治理与安全。

为便于部署与排错,下表给出关键配置项清单。

表 2 关键配置项清单(环境变量/配置文件)
| 配置项 | 作用 | 示例值 | 注意事项 |
|---|---|---|---|
| MLFLOW_BACKEND_STORE_URI | 指定后端数据库 | postgresql+psycopg2://user:pass@host:5432/db | 确保数据库驱动可用;连接池与超时合理 |
| MLFLOW_DEFAULT_ARTIFACT_ROOT | 指定工件根目录 | /data/mlflow/artifacts | 目录权限与磁盘配额需提前评估 |
| MLFLOW_TRACKING_URI | 客户端跟踪地址 | http://mlflow.example.com | 客户端与服务端网络可达性 |
| server.artifact_repository | 服务端工件后端 | file:/data/mlflow/artifacts | 轻量级推荐使用本地文件系统 |
| server.backend_store | 后端存储类型 | sql | 支持注册表工作流 |
| HTTP 代理与认证 | 访问控制 | Nginx + Basic Auth | 记录访问日志,便于审计 |

上述配置确保 Tracking 与 Registry 正常工作,并将工件落地至本地文件系统,满足轻量部署的可控性与成本优势。[^3]

### 3.3 插件与自定义扩展

MLflow 提供插件架构,支持在不修改核心代码的情况下扩展存储、评估与部署能力。对于本地轻量场景,常见扩展包括:自定义工件仓库(将工件落地至特定目录或带压缩策略)、自定义评估器(实现领域指标或特殊数据格式的评分器)、以及自定义模型风味(flavor)。对于尚无内置风味支持的框架,可以通过 pyfunc 机制封装 Python 函数式模型,统一保存、加载与评估接口。[^6][^7][^8]

在选择是否自研 flavor 时,应权衡维护成本与收益:当团队内多个项目复用同一框架模型,且需要统一的保存/加载/部署体验时,自研 flavor 的长期收益显著;否则优先使用 pyfunc 简化实现与升级成本。

---

## 4. 模型注册与版本管理策略

模型注册表是本方案的中枢。合理的命名、别名与标签策略,配合清晰的阶段转换与审批流程,可以在不引入复杂平台的情况下,获得稳定的版本治理与可审计的推广路径。[^9][^10][^11]

### 4.1 命名与版本策略

命名规范建议采用“业务域/模型名”的层级结构,例如“recommendation/user_profile”。版本号由注册表自动递增,避免手工冲突。别名(如 @champion、@challenger)用于稳定指向生产或候选版本,标签用于业务维度分类(如“dataset:v2025.09”、“risk:low”)。在推广前,确保模型与运行(Run)之间的溯源链接完整,以便复现与审计。[^9]

### 4.2 阶段转换与审批

MLflow 支持将模型版本在阶段间转换(如 Staging 与 Production),并可结合审批工作流实现受控推广。建议在 Staging 阶段完成评估与可视化诊断,设定准入阈值;在 Production 阶段通过别名(如 @champion)稳定指向当前生产版本。阶段转换应有记录与注释,形成审计轨迹。

为便于团队协作与合规,下表给出阶段与准入条件模板。

表 3 模型阶段与准入条件模板
| 阶段 | 准入条件 | 审批人 | 审计记录 |
|---|---|---|---|
| Development | 训练完成并记录必要元数据 | 开发者 | 运行记录、依赖列表 |
| Staging | 评估指标达标;诊断图表无异常;资源占用评估 | 评审委员会 | 评估结果、比较报告 |
| Production | 灰度或 A/B 验证通过;回滚预案已确认 | 变更委员会 | 阶段转换记录、别名设定 |

上述模板为最小可行治理,组织可根据实际补充更细粒度的审批与审计要求。[^10]

---

## 5. 本地存储优化方案

在轻量级形态下,本地文件系统是工件存储的首选。合理的目录结构、压缩与归档策略、清理与保留策略以及性能优化,将直接影响系统的可维护性与成本。[^12]

### 5.1 目录结构设计

建议采用如下目录约定:
- artifacts/models:模型权重与打包产物
- artifacts/metrics:评估指标与汇总结果
- artifacts/plots:评估图表与诊断图像
- artifacts/data:数据快照或样本(可选)
- artifacts/logs:训练与评估日志

为便于权限管理与清理策略执行,按模型与日期分层组织目录,并使用只读挂载或访问控制列表(ACL)限制非必要写入。[^12]

### 5.2 压缩与归档

对于历史评估结果与大型工件,建议按运行或模型版本归档并压缩,减少存储占用。归档命名应包含模型名、版本与时间戳,便于检索与清理。

### 5.3 清理与保留策略

在资源有限的环境下,清理与保留策略尤为关键。建议以“最新 N 个版本保留”为默认策略,并对未注册运行工件设定较短保留期。清理应区分“删除”与“归档”,并确保 Registry 指向的版本不被误删。

表 4 清理与保留策略模板
| 规则类别 | 规则说明 | 参数示例 | 风险控制 |
|---|---|---|---|
| 版本保留 | 保留每模型最新 N 个注册版本 | N=5 | Registry 保护;删除前校验别名指向 |
| 运行工件清理 | 未注册运行工件保留 T 天 | T=14 | 任务计划执行;记录清理日志 |
| 评估结果归档 | 评估结果压缩归档 | 压缩率≥60% | 归档命名规范;保留摘要与索引 |
| 大文件策略 | 超大文件单独归档 | >1GB | 目录级权限控制;限速与校验 |

上述策略需结合本地磁盘配额与组织保留周期进行参数化调整。[^12]

### 5.4 性能优化

在轻量场景下,性能优化聚焦于减少小文件 I/O 与网络代理开销:
- 批量写入与缓存:将小型指标文件合并写入,减少频繁的磁盘操作。
- 直接访问:在某些部署形态下,可配置客户端直接访问工件存储,避免通过 Tracking Server 代理带来的额外开销。
- 并发控制:限制并发写入与读取的峰值,避免磁盘或数据库成为瓶颈。[^5]

---

## 6. 模型元数据管理

完善的元数据是“可复现、可审计、可比较”的基石。建议在训练与评估时,规范记录参数、指标、依赖与数据版本,并将评估结果与可视化工件统一管理。[^3][^13]

### 6.1 运行与实验元数据

每次训练使用 mlflow.start_run() 创建运行上下文,记录:
- 参数:超参数、特征集版本、随机种子等。
- 指标:训练与验证指标;评估阶段新增业务指标。
- 工件:模型权重、评估图表、依赖列表与数据摘要。

为确保完整性,建议在训练结束时统一写入 requirements 与 environment 文件,并在评估阶段生成汇总报告,便于后续比较与审计。[^3]

### 6.2 评估与可视化

MLflow 评估框架支持分类、回归等经典任务的自动化指标计算与可视化诊断,包括 ROC 曲线、混淆矩阵、校准图、SHAP 值与排列重要性等。对于特定领域指标,可以使用自定义函数扩展评估器,并将结果与模型版本关联保存,形成可追溯的评估历史。[^13][^14]

---

## 7. 模型比较与选择机制

模型选择不仅是技术指标的比较,更是治理流程的体现。建议在 Staging 阶段进行系统化评估与比较,结合业务准入阈值与风险容忍度,形成可解释的决策记录。[^13][^15]

### 7.1 评估与比较

通过 mlflow.evaluate 对候选模型与生产基线进行对比,关注主指标(如 AUC、RMSE)与关键业务指标(如转化率、召回率),并结合可视化诊断(校准、残差、SHAP)识别潜在问题。对于 GenAI/LLM 场景,使用专门的评估接口与指标集,并注意与传统评估框架的兼容性边界。[^13][^15]

### 7.2 A/B 测试与推广

在预生产或低流量环境进行 A/B 测试,将候选模型与生产基线对比,设定流量比例与观察窗口,明确成功标准与回滚条件。推广时通过别名(如 @champion)稳定指向新版本,确保服务配置与 Registry 一致,避免“版本漂移”。[^13]

为便于决策,下表给出模型比较报告模板。

表 5 模型比较报告模板
| 模型版本 | 主指标 | 业务指标 | 诊断结论 | 风险评估 | 决策 |
|---|---|---|---|---|---|
| v003 | AUC=0.87 | 转化率+2.1% | 校准良好;SHAP 无异常 | 低 | 推广至 Production |
| v002(基线) | AUC=0.85 | 转化率基准 | 稳定 | 低 | 保持 @champion |

---

## 8. 自动回滚与恢复策略

生产环境不可避免会遇到模型退化、异常或故障。自动回滚与恢复策略是降低风险的最后防线,应明确触发条件、动作与验证步骤,并形成审计记录。[^16][^17][^18]

### 8.1 触发与动作

常见触发条件包括:指标跌破阈值(如 AUC 下降超过 Δ)、错误率或延迟显著上升、数据分布漂移检测触发、线上业务指标异常。回滚动作应将别名(如 @champion)重新指向稳定版本,并在服务层执行版本切换。恢复后进行验证与观察,确保系统稳定。

表 6 回滚触发条件与动作清单
| 触发条件 | 阈值示例 | 回滚动作 | 验证步骤 | 审计记录 |
|---|---|---|---|---|
| 主指标退化 | AUC 下降≥0.03 | 将 @champion 指回 v002 | 重跑评估;比对诊断图 | 记录触发、回滚与验证日志 |
| 错误率上升 | 5xx 比例≥1% | 切换至稳定版本 | 检查服务健康与日志 | 事件时间线与影响范围 |
| 延迟上升 | P95 延迟≥+30% | 降级或回滚 | 压测与监控确认 | 性能指标与变更记录 |
| 漂移触发 | PSI≥0.25 | 回滚并触发再训练 | 数据分布复核 | 漂移报告与处置动作 |

上述策略强调“先稳定、后分析”的原则:快速恢复服务,再进行根因分析与流程改进。[^16][^17][^18]

---

## 9. 与 CI/CD 集成方案

在持续集成/持续交付(CI/CD)中纳入模型训练、评估、注册与部署环节,可以将模型治理与软件工程流程统一起来。轻量级形态下,推荐在预生产环境进行自动评估与注册,再由人工审批推广至生产;如需更高弹性与可扩展性,可将部署迁移至 Kubernetes。[^19][^20][^21]

### 9.1 GitHub Actions 流水线模板

流水线 stages 建议如下:代码与数据检出 → 依赖安装 → 训练与记录 → 评估与比较 → 注册模型(满足阈值则注册)→ 部署预生产 →(审批)→ 生产发布。关键在于将评估阈值与准入条件参数化,并在 UI 与日志中保留完整审计轨迹。[^19]

### 9.2 Jenkins 流水线模板

Jenkins 同样遵循上述 stages,结合 Jenkinsfile 与共享库实现参数化构建。需注意凭据管理与构建日志归档,确保审计与安全。在轻量场景下,部署环节可使用本地推理服务进行验证;如需弹性与扩缩,再迁移至 Kubernetes。[^20]

为便于落地,下表给出 CI/CD 阶段与准入条件模板。

表 7 CI/CD 阶段与准入条件模板
| 阶段 | 目标 | 准入条件 | 失败处理 |
|---|---|---|---|
| 训练与记录 | 生成可复现运行 | 参数与依赖完整记录 | 中止并通知 |
| 评估与比较 | 与基线比较 | 主指标与业务指标达标 | 回退至上次稳定版本 |
| 注册模型 | 入库与标注 | 通过审批工作流 | 记录拒绝原因 |
| 预生产部署 | 灰度验证 | 健康检查通过 | 自动回滚 |
| 生产发布 | 切换别名与流量 | 审批通过;监控稳定 | 立即回滚并告警 |

如需迁移至 Kubernetes,MLflow 提供了构建镜像与部署至 KServe/Seldon 的官方指南,可作为扩展路径。[^21]

---

## 10. 配置与部署指南(本地)

本节给出端到端的部署步骤与验证方法,帮助读者快速上线并运行。

### 10.1 安装与配置

步骤概述:
1. 安装 MLflow 与数据库驱动(如 psycopg2 for PostgreSQL)。
2. 配置 Backend Store(MLFLOW_BACKEND_STORE_URI)与 Artifact Root(MLFLOW_DEFAULT_ARTIFACT_ROOT)。
3. 启动 Tracking Server,验证 UI 与 API 可用。
4. 配置反向代理与基础认证,启用访问日志。
5. 训练、记录与注册模型,完成端到端验证。[^3][^22]

为便于运维,下表列出部署清单与端口/目录配置模板。

表 8 部署清单与端口/目录配置模板
| 项目 | 配置 | 说明 |
|---|---|---|
| Tracking Server 端口 | 5000(默认) | 可通过配置修改 |
| 数据库端口 | 5432(PostgreSQL) | 确保网络可达与凭据安全 |
| 工件根目录 | /data/mlflow/artifacts | 权限与磁盘配额预检 |
| 代理与认证 | Nginx + Basic Auth | 记录访问日志 |
| 日志目录 | /var/log/mlflow | 轮转与保留策略 |

### 10.2 验证与测试

- 记录模型:在训练脚本中调用 mlflow.log_model 与 mlflow.register_model,指定 registered_model_name。
- 加载模型:使用 mlflow.mlflow.load_model 或模型 URI(如 models://model_name@alias)加载。
- 本地推理:使用官方本地部署指南进行快速测试,验证输入输出与性能基线。[^22]

常见问题与排查:
- 权限错误:检查工件目录权限与数据库用户权限。
- 连接失败:检查 Tracking URI、网络代理与数据库连接串。
- 端口占用:确认端口未被其他进程占用。
- 驱动缺失:安装对应数据库驱动与 Python 依赖。

---

## 11. 运维、监控与故障排除

运维工作的重点在于保持系统稳定、数据完整与治理有效。建议建立例行任务与监控指标,形成闭环维护。[^12]

### 11.1 监控与告警

关键指标包括:磁盘占用与增长趋势、数据库连接数与慢查询、工件读写错误率、注册表操作失败次数、评估失败与阈值触发次数。告警应结合阈值与趋势,避免误报与漏报。

表 9 运维检查清单
| 检查项 | 频率 | 工具/方法 | 阈值/告警条件 |
|---|---|---|---|
| 磁盘占用与增长 | 每日 | df/du + 脚本 | 连续 3 天增长≥10% |
| 数据库连接与慢查询 | 每周 | 数据库监控 | 慢查询≥100 次/周 |
| 工件读写错误率 | 每日 | 日志分析 | 错误率≥0.5% |
| 注册表操作失败 | 每日 | 应用日志 | 失败≥5 次/日 |
| 评估失败与阈值触发 | 每日 | 评估日志 | 连续触发≥2 次/日 |

### 11.2 故障场景与排查

表 10 故障场景-症状-排查-解决方案
| 场景 | 症状 | 排查步骤 | 解决方案 |
|---|---|---|---|
| 工件写入失败 | 训练中断 | 检查目录权限与磁盘空间 | 修复权限、清理空间、续写 |
| 数据库不可用 | UI 与 API 异常 | 检查连接与驱动 | 恢复服务、更新驱动与重试 |
| 模型加载失败 | 推理报错 | 检查 URI 与依赖 | 修正 URI、补齐依赖与验证 |
| 评估失败 | 指标缺失 | 检查数据与评估器 | 修复数据或更新评估器 |
| 回滚异常 | 别名未更新 | 检查服务配置与别名指向 | 手动修正并记录审计 |

清理与保留策略在运维中至关重要,应结合组织的安全与合规要求执行。[^12]

---

## 12. 附录:术语、API 与参考

术语简释:
- Experiment(实验):运行的集合,用于组织与查询。
- Run(运行):一次训练或评估过程的记录单元。
- Artifact(工件):运行过程中产生的大文件或目录,如模型权重与图表。
- Stage(阶段):模型版本所处的治理阶段,如 Staging、Production。
- Alias(别名):对模型版本的稳定引用,如 @champion。
- Flavor(风味):模型保存与加载的框架特定接口或自定义封装。
- PyFunc(Python Function 模型):MLflow 的通用 Python 模型封装机制。

常用 API 与示例:
- 记录与注册:mlflow.start_run、mlflow.log_param、mlflow.log_metric、mlflow.log_artifact、mlflow.log_model、mlflow.register_model。
- 加载与评估:mlflow.load_model、mlflow.evaluate、mlflow.genai.evaluate(用于 LLM)。
- 模型 URI:models://<model_name>/<version> 与 models://<model_name>@<alias>。

信息缺口说明:
- 操作系统与文件系统类型、数据库类型与版本、生产流量规模、合规要求、CI/CD 平台与镜像仓库、磁盘配额与限额、漂移监控阈值等未在本文中明确,需结合本地环境与组织策略补充与验证。

---

## 参考文献

[^1]: MLflow:管理机器学习生命周期的工具 | MLflow 平台. https://mlflow.org.cn/docs/latest/ml/  
[^2]: MLflow Model Registry: Guide to Managing the ML Lifecycle. https://mljourney.com/mlflow-model-registry-guide-to-managing-the-ml-lifecycle/  
[^3]: MLflow Tracking | MLflow. https://mlflow.org/docs/latest/ml/tracking/  
[^4]: Artifact Stores - MLflow. https://mlflow.org/docs/latest/self-hosting/architecture/artifact-store/  
[^5]: 工件存储 | MLflow 平台. https://mlflow.org.cn/docs/latest/tracking/artifacts-stores  
[^6]: MLflow 插件 | MLflow 平台. https://mlflow.org.cn/docs/latest/plugins  
[^7]: Custom MLflow Models with mlflow.pyfunc. https://mlflow.org/blog/custom-pyfunc  
[^8]: 社区模型风味 | MLflow 平台. https://mlflow.org.cn/docs/latest/ml/community-model-flavors/  
[^9]: MLflow 模型注册表 | MLflow 平台. https://mlflow.org.cn/docs/latest/ml/model-registry/  
[^10]: 模型注册表工作流 | MLflow 平台. https://mlflow.org.cn/docs/latest/ml/model-registry/workflow/  
[^11]: 模型注册表教程 | MLflow 平台. https://mlflow.org.cn/docs/latest/ml/model-registry/tutorial/  
[^12]: 清理 MLflow 资源 - 亚马逊 SageMaker AI. https://docs.amazonaws.cn/sagemaker/latest/dg/mlflow-cleanup.html  
[^13]: MLflow 评估 | MLflow 平台. https://mlflow.org.cn/docs/latest/ml/evaluation/  
[^14]: Model Evaluation | MLflow. https://mlflow.org/docs/latest/ml/evaluation/model-eval  
[^15]: How to Evaluate Models Using MLflow - The Databricks Blog. https://www.databricks.com/blog/2022/04/19/model-evaluation-in-mlflow.html  
[^16]: Automated Rollback for ML Models - apxml.com. https://apxml.com/courses/monitoring-managing-ml-models-production/chapter-4-automated-retraining-updates/automated-rollback  
[^17]: SE-ML | Enable Automatic Roll Backs for Production Models. https://se-ml.github.io/best_practices/04-rollback_models_prod/  
[^18]: ML Model Rollback Strategies After Failed Deployment. https://mljourney.com/ml-model-rollback-strategies-after-failed-deployment/  
[^19]: Streamlining CI/CD Pipelines for ML Models Using GitHub Actions and Jenkins (2025). https://johal.in/streamlining-ci-cd-pipelines-for-ml-models-using-github-actions-and-jenkins-2025/  
[^20]: CI/CD for ML Models: Automate Deployment with Jenkins and MLflow. https://codezup.com/ci-cd-for-ml-models-jenkins-mlflow/  
[^21]: 将 MLflow 模型部署到 Kubernetes | MLflow 平台. https://mlflow.org.cn/docs/latest/ml/deployment/deploy-model-to-kubernetes/  
[^22]: Deploy MLflow Model as a Local Inference Server | MLflow. https://mlflow.org/docs/latest/ml/deployment/deploy-model-locally/