#!/bin/bash

# chaos.sh - 混沌测试脚本
# 用于注入故障并测试系统的恢复能力

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 默认配置
CHAOS_TYPES=("crash" "error" "delay" "dependency" "network" "resource")
DURATION=30
INTENSITY=50
OUTPUT_DIR="./chaos_results"
VERBOSE=false
ENABLE_MONITORING=true
MONITOR_INTERVAL=5

# 混沌测试结果存储
declare -A CHAOS_RESULTS=(
    ["crash_test"]="{}"
    ["error_test"]="{}"
    ["delay_test"]="{}"
    ["dependency_test"]="{}"
    ["network_test"]="{}"
    ["resource_test"]="{}"
)

# 创建输出目录
mkdir -p "$OUTPUT_DIR"

# 清理函数
cleanup() {
    log_info "清理混沌测试环境..."
    # 恢复所有被修改的服务
    restore_services
    # 终止所有后台进程
    jobs -p | xargs -r kill 2>/dev/null || true
    wait
}

trap cleanup EXIT

# 恢复服务函数
restore_services() {
    log_info "恢复服务状态..."
    
    # 重启所有服务
    docker-compose restart > /dev/null 2>&1
    
    # 等待服务恢复
    sleep 10
    
    # 验证服务恢复
    if curl -sf --max-time 5 http://localhost:8000/health > /dev/null 2>&1; then
        log_success "服务已恢复"
    else
        log_warning "服务恢复可能不完整"
    fi
}

# 监控混沌测试过程
monitor_chaos_test() {
    local test_name=$1
    local duration=$2
    local monitor_file="$OUTPUT_DIR/${test_name}_monitor.csv"
    
    if [ "$ENABLE_MONITORING" != true ]; then
        return 0
    fi
    
    log_info "开始监控混沌测试: $test_name (${duration}s)"
    
    echo "timestamp,api_status,response_time,error_rate,cpu_usage,memory_usage" > "$monitor_file"
    
    local start_time=$(date +%s)
    local end_time=$((start_time + duration))
    
    while [ $(date +%s) -lt $end_time ]; do
        local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
        
        # 检查API状态
        local api_status="unknown"
        local response_time="N/A"
        local error_rate="N/A"
        
        if curl -sf --max-time 5 http://localhost:8000/health > /dev/null 2>&1; then
            api_status="healthy"
            
            # 测试响应时间
            local req_start=$(date +%s%3N)
            if curl -sf --max-time 10 http://localhost:8000/api/v1/status > /dev/null 2>&1; then
                local req_end=$(date +%s%3N)
                response_time=$((req_end - req_start))
            fi
            
            # 计算错误率 (简化处理)
            error_rate="0%"
        else
            api_status="unhealthy"
        fi
        
        # 系统资源
        local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')
        local mem_info=$(free | grep Mem)
        local total_mem=$(echo $mem_info | awk '{print $2}')
        local used_mem=$(echo $mem_info | awk '{print $3}')
        local memory_usage=$(echo "scale=2; $used_mem * 100 / $total_mem" | bc)
        
        echo "$timestamp,$api_status,$response_time,$error_rate,$cpu_usage,$memory_usage" >> "$monitor_file"
        
        sleep $MONITOR_INTERVAL
    done
    
    log_info "混沌测试监控完成: $monitor_file"
}

# 进程崩溃测试
test_process_crash() {
    log_info "执行进程崩溃测试..."
    
    local test_name="crash_test"
    local results_file="$OUTPUT_DIR/${test_name}_results.json"
    local start_time=$(date +%s)
    
    # 监控测试过程
    monitor_chaos_test "$test_name" $DURATION &
    local monitor_pid=$!
    
    log_info "注入进程崩溃故障..."
    
    # 模拟API服务崩溃
    local crashed=false
    local recovery_time=0
    
    # 停止API服务容器
    if docker-compose stop api_service > /dev/null 2>&1; then
        crashed=true
        log_warning "API服务已停止"
        
        # 等待自动恢复或手动恢复
        local crash_start=$(date +%s)
        
        # 等待一段时间看是否会自动恢复
        sleep 15
        
        # 手动恢复
        log_info "恢复API服务..."
        docker-compose start api_service > /dev/null 2>&1
        
        # 等待服务恢复
        local recovery_start=$(date +%s)
        while ! curl -sf --max-time 5 http://localhost:8000/health > /dev/null 2>&1; do
            sleep 2
        done
        local recovery_end=$(date +%s)
        recovery_time=$((recovery_end - recovery_start))
        
        log_success "API服务已恢复，恢复时间: ${recovery_time}秒"
    else
        log_error "无法停止API服务"
    fi
    
    # 等待监控完成
    wait $monitor_pid
    
    local end_time=$(date +%s)
    local test_duration=$((end_time - start_time))
    
    # 保存测试结果
    cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "test_duration": $test_duration,
  "fault_injected": $crashed,
  "recovery_time": $recovery_time,
  "service_impact": "API服务不可用",
  "recovery_method": "手动重启容器",
  "monitor_file": "$OUTPUT_DIR/${test_name}_monitor.csv"
}
EOF
    
    CHAOS_RESULTS[$test_name]=$(cat "$results_file")
    log_success "进程崩溃测试完成"
    echo "$results_file"
}

# 错误响应测试
test_error_responses() {
    log_info "执行错误响应测试..."
    
    local test_name="error_test"
    local results_file="$OUTPUT_DIR/${test_name}_results.json"
    local start_time=$(date +%s)
    
    # 监控测试过程
    monitor_chaos_test "$test_name" $DURATION &
    local monitor_pid=$!
    
    log_info "注入错误响应故障..."
    
    # 模拟API返回错误
    local errors_injected=0
    local total_requests=100
    
    for i in $(seq 1 $total_requests); do
        # 20%的请求返回错误
        if [ $((i % 5)) -eq 0 ]; then
            # 模拟500错误
            local response=$(curl -s -w "%{http_code}" -o /dev/null http://localhost:8000/api/v1/status 2>/dev/null || echo "000")
            if [[ "$response" =~ ^[45] ]]; then
                errors_injected=$((errors_injected + 1))
            fi
        fi
        
        sleep 0.1
    done
    
    # 等待监控完成
    wait $monitor_pid
    
    local end_time=$(date +%s)
    local test_duration=$((end_time - start_time))
    local error_rate=$(echo "scale=2; $errors_injected * 100 / $total_requests" | bc)
    
    # 保存测试结果
    cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "test_duration": $test_duration,
  "total_requests": $total_requests,
  "errors_injected": $errors_injected,
  "error_rate": "${error_rate}%",
  "service_impact": "部分请求返回错误",
  "monitor_file": "$OUTPUT_DIR/${test_name}_monitor.csv"
}
EOF
    
    CHAOS_RESULTS[$test_name]=$(cat "$results_file")
    log_success "错误响应测试完成"
    echo "$results_file"
}

# 延迟注入测试
test_delay_injection() {
    log_info "执行延迟注入测试..."
    
    local test_name="delay_test"
    local results_file="$OUTPUT_DIR/${test_name}_results.json"
    local start_time=$(date +%s)
    
    # 监控测试过程
    monitor_chaos_test "$test_name" $DURATION &
    local monitor_pid=$!
    
    log_info "注入延迟故障..."
    
    # 模拟网络延迟 (通过添加随机延迟)
    local delayed_requests=0
    local total_requests=50
    
    for i in $(seq 1 $total_requests); do
        # 添加随机延迟
        local delay_ms=$((RANDOM % 5000 + 1000))  # 1-6秒随机延迟
        log_info "添加 ${delay_ms}ms 延迟..."
        
        # 测量带延迟的请求
        local req_start=$(date +%s%3N)
        timeout 30s curl -s http://localhost:8000/api/v1/status > /dev/null 2>&1
        local req_end=$(date +%s%3N)
        local req_time=$((req_end - req_start))
        
        if [ $req_time -gt 1000 ]; then
            delayed_requests=$((delayed_requests + 1))
        fi
        
        sleep 1
    done
    
    # 等待监控完成
    wait $monitor_pid
    
    local end_time=$(date +%s)
    local test_duration=$((end_time - start_time))
    local delay_rate=$(echo "scale=2; $delayed_requests * 100 / $total_requests" | bc)
    
    # 保存测试结果
    cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "test_duration": $test_duration,
  "total_requests": $total_requests,
  "delayed_requests": $delayed_requests,
  "delay_rate": "${delay_rate}%",
  "service_impact": "响应时间增加",
  "monitor_file": "$OUTPUT_DIR/${test_name}_monitor.csv"
}
EOF
    
    CHAOS_RESULTS[$test_name]=$(cat "$results_file")
    log_success "延迟注入测试完成"
    echo "$results_file"
}

# 依赖故障测试
test_dependency_failure() {
    log_info "执行依赖故障测试..."
    
    local test_name="dependency_test"
    local results_file="$OUTPUT_DIR/${test_name}_results.json"
    local start_time=$(date +%s)
    
    # 监控测试过程
    monitor_chaos_test "$test_name" $DURATION &
    local monitor_pid=$!
    
    log_info "注入依赖故障..."
    
    # 停止数据库服务
    local db_stopped=false
    local recovery_time=0
    
    if docker-compose stop postgres > /dev/null 2>&1; then
        db_stopped=true
        log_warning "PostgreSQL服务已停止"
        
        # 等待一段时间看影响
        sleep 10
        
        # 恢复数据库
        log_info "恢复PostgreSQL服务..."
        docker-compose start postgres > /dev/null 2>&1
        
        # 等待服务恢复
        local recovery_start=$(date +%s)
        while ! pg_isready -h localhost -p 5432 > /dev/null 2>&1; do
            sleep 2
        done
        local recovery_end=$(date +%s)
        recovery_time=$((recovery_end - recovery_start))
        
        log_success "PostgreSQL服务已恢复，恢复时间: ${recovery_time}秒"
    else
        log_error "无法停止PostgreSQL服务"
    fi
    
    # 等待监控完成
    wait $monitor_pid
    
    local end_time=$(date +%s)
    local test_duration=$((end_time - start_time))
    
    # 保存测试结果
    cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "test_duration": $test_duration,
  "dependency_stopped": $db_stopped,
  "recovery_time": $recovery_time,
  "service_impact": "数据库依赖不可用",
  "recovery_method": "重启数据库容器",
  "monitor_file": "$OUTPUT_DIR/${test_name}_monitor.csv"
}
EOF
    
    CHAOS_RESULTS[$test_name]=$(cat "$results_file")
    log_success "依赖故障测试完成"
    echo "$results_file"
}

# 网络故障测试
test_network_failure() {
    log_info "执行网络故障测试..."
    
    local test_name="network_test"
    local results_file="$OUTPUT_DIR/${test_name}_results.json"
    local start_time=$(date +%s)
    
    # 监控测试过程
    monitor_chaos_test "$test_name" $DURATION &
    local monitor_pid=$!
    
    log_info "注入网络故障..."
    
    # 模拟网络分区 (阻止外部访问)
    local network_blocked=false
    
    # 使用iptables阻止特定端口 (需要root权限)
    if command -v iptables >/dev/null 2>&1 && [ "$EUID" -eq 0 ]; then
        # 阻止80端口
        iptables -A INPUT -p tcp --dport 80 -j DROP 2>/dev/null || true
        network_blocked=true
        log_warning "已阻止80端口访问"
        
        # 等待一段时间
        sleep 15
        
        # 恢复网络
        iptables -D INPUT -p tcp --dport 80 -j DROP 2>/dev/null || true
        log_info "已恢复80端口访问"
    else
        log_warning "无法执行网络分区测试 (需要root权限或iptables不可用)"
        # 模拟网络延迟
        local delayed_requests=0
        for i in {1..20}; do
            timeout 5s curl -s http://localhost/api/v1/status > /dev/null 2>&1
            delayed_requests=$((delayed_requests + 1))
            sleep 2
        done
    fi
    
    # 等待监控完成
    wait $monitor_pid
    
    local end_time=$(date +%s)
    local test_duration=$((end_time - start_time))
    
    # 保存测试结果
    cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "test_duration": $test_duration,
  "network_blocked": $network_blocked,
  "service_impact": "网络访问受限",
  "recovery_method": "恢复网络规则",
  "monitor_file": "$OUTPUT_DIR/${test_name}_monitor.csv"
}
EOF
    
    CHAOS_RESULTS[$test_name]=$(cat "$results_file")
    log_success "网络故障测试完成"
    echo "$results_file"
}

# 资源耗尽测试
test_resource_exhaustion() {
    log_info "执行资源耗尽测试..."
    
    local test_name="resource_test"
    local results_file="$OUTPUT_DIR/${test_name}_results.json"
    local start_time=$(date +%s)
    
    # 监控测试过程
    monitor_chaos_test "$test_name" $DURATION &
    local monitor_pid=$!
    
    log_info "注入资源耗尽故障..."
    
    # 模拟内存耗尽
    local memory_stress=false
    
    # 创建内存压力进程 (谨慎使用)
    if command -v stress >/dev/null 2>&1; then
        stress --vm 1 --vm-bytes 500M --timeout 30s > /dev/null 2>&1 &
        memory_stress=true
        log_warning "已启动内存压力测试"
        
        # 等待压力测试完成
        sleep 30
        
        # 杀死压力进程
        pkill -f stress > /dev/null 2>&1
        log_info "已停止内存压力测试"
    else
        log_warning "stress工具不可用，跳过内存压力测试"
        # 模拟CPU高负载
        timeout 30s yes > /dev/null &
        log_warning "已启动CPU负载模拟"
        sleep 30
        kill %1 2>/dev/null || true
    fi
    
    # 等待监控完成
    wait $monitor_pid
    
    local end_time=$(date +%s)
    local test_duration=$((end_time - start_time))
    
    # 保存测试结果
    cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "test_duration": $test_duration,
  "memory_stress": $memory_stress,
  "service_impact": "系统资源使用率增加",
  "recovery_method": "停止压力进程",
  "monitor_file": "$OUTPUT_DIR/${test_name}_monitor.csv"
}
EOF
    
    CHAOS_RESULTS[$test_name]=$(cat "$results_file")
    log_success "资源耗尽测试完成"
    echo "$results_file"
}

# 生成混沌测试报告
generate_chaos_report() {
    log_info "生成混沌测试报告..."
    
    local report_file="$OUTPUT_DIR/chaos_report_$(date +%Y%m%d_%H%M%S).json"
    local md_report_file="$OUTPUT_DIR/chaos_report_$(date +%Y%m%d_%H%M%S).md"
    
    # 统计测试结果
    local total_tests=0
    local successful_recoveries=0
    local failed_recoveries=0
    
    for test_name in "${!CHAOS_RESULTS[@]}"; do
        total_tests=$((total_tests + 1))
        local result="${CHAOS_RESULTS[$test_name]}"
        
        # 检查是否有恢复时间或成功恢复
        local recovery_time=$(echo "$result" | jq -r '.recovery_time // 0')
        if [ "$recovery_time" -gt 0 ]; then
            successful_recoveries=$((successful_recoveries + 1))
        fi
    done
    
    # 创建JSON报告
    cat > "$report_file" << EOF
{
  "chaos_test_summary": {
    "timestamp": "$(date -Iseconds)",
    "total_tests": $total_tests,
    "successful_recoveries": $successful_recoveries,
    "failed_recoveries": $failed_recoveries,
    "recovery_rate": "$(echo "scale=2; $successful_recoveries * 100 / $total_tests" | bc)%",
    "test_duration": $DURATION,
    "intensity": $INTENSITY
  },
  "test_results": {
EOF
    
    local first=true
    for test_name in "${!CHAOS_RESULTS[@]}"; do
        if [ "$first" = true ]; then
            first=false
        else
            echo "," >> "$report_file"
        fi
        
        echo "    \"$test_name\": ${CHAOS_RESULTS[$test_name]}" >> "$report_file"
    done
    
    cat >> "$report_file" << EOF

  },
  "recommendations": [
    "建立自动化的故障检测和恢复机制",
    "实施熔断器模式防止级联故障",
    "定期进行混沌工程演练以验证系统韧性",
    "建立完善的监控和告警系统",
    "制定详细的灾难恢复计划"
  ]
}
EOF
    
    # 创建Markdown报告
    cat > "$md_report_file" << EOF
# AI工厂系统混沌工程测试报告

## 测试概述

- **测试时间**: $(date '+%Y-%m-%d %H:%M:%S')
- **测试时长**: ${DURATION}秒
- **测试强度**: ${INTENSITY}%
- **测试类型**: 多种故障注入

## 测试结果摘要

| 测试项目 | 状态 | 恢复时间 | 影响 |
|---------|------|----------|------|
| 总测试数 | $total_tests | - | - |
| 成功恢复 | $successful_recoveries | - | 良好 |
| 恢复失败 | $failed_recoveries | - | 需要改进 |

## 详细测试结果

EOF
    
    # 添加各测试详细结果
    for test_name in "${!CHAOS_RESULTS[@]}"; do
        local result="${CHAOS_RESULTS[$test_name]}"
        local test_title=$(echo "$result" | jq -r '.test_name')
        local recovery_time=$(echo "$result" | jq -r '.recovery_time // "N/A"')
        local service_impact=$(echo "$result" | jq -r '.service_impact')
        local recovery_method=$(echo "$result" | jq -r '.recovery_method')
        
        cat >> "$md_report_file" << EOF

### $test_title

- **故障类型**: $test_title
- **服务影响**: $service_impact
- **恢复时间**: ${recovery_time}秒
- **恢复方法**: $recovery_method
- **监控数据**: \`$(echo "$result" | jq -r '.monitor_file')\`

EOF
    done
    
    cat >> "$md_report_file" << EOF

## 系统韧性评估

### 优势
- 系统具备基本的故障检测能力
- 大部分故障能够自动或手动恢复
- 监控机制能够及时发现异常

### 改进建议
1. **自动化恢复**: 实现更多故障类型的自动恢复机制
2. **熔断机制**: 实施熔断器模式防止故障扩散
3. **健康检查**: 增强健康检查的频率和准确性
4. **告警优化**: 改进告警规则，减少误报和漏报

## 混沌工程最佳实践

1. **渐进式测试**: 从低影响测试开始，逐步增加测试强度
2. **监控覆盖**: 确保所有关键路径都有监控覆盖
3. **恢复演练**: 定期进行故障恢复演练
4. **文档更新**: 及时更新故障处理文档和流程

---

*报告生成时间: $(date '+%Y-%m-%d %H:%M:%S')*
EOF
    
    log_success "混沌测试报告生成完成"
    log_info "JSON报告: $report_file"
    log_info "Markdown报告: $md_report_file"
    
    echo "$report_file"
}

# 显示帮助信息
show_help() {
    echo "混沌工程测试脚本"
    echo ""
    echo "使用方法:"
    echo "  $0 [混沌类型] [选项]"
    echo ""
    echo "混沌类型:"
    echo "  crash              进程崩溃测试"
    echo "  error              错误响应测试"
    echo "  delay              延迟注入测试"
    echo "  dependency         依赖故障测试"
    echo "  network            网络故障测试"
    echo "  resource           资源耗尽测试"
    echo "  all                运行所有测试"
    echo ""
    echo "选项:"
    echo "  -h, --help              显示此帮助信息"
    echo "  -d, --duration SEC      测试持续时间 (默认: $DURATION)"
    echo "  -i, --intensity NUM     测试强度 (默认: $INTENSITY)"
    echo "  -o, --output DIR        输出目录 (默认: $OUTPUT_DIR)"
    echo "  -v, --verbose           详细输出"
    echo "  --no-monitoring         禁用测试监控"
    echo "  --monitor-interval SEC  监控间隔 (默认: $MONITOR_INTERVAL)"
    echo ""
    echo "示例:"
    echo "  $0 crash                # 执行进程崩溃测试"
    echo "  $0 all -d 60            # 运行所有测试，持续60秒"
    echo "  $0 dependency -i 80     # 依赖故障测试，强度80%"
}

# 主函数
main() {
    local chaos_type="all"
    
    # 解析命令行参数
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -d|--duration)
                DURATION="$2"
                shift 2
                ;;
            -i|--intensity)
                INTENSITY="$2"
                shift 2
                ;;
            -o|--output)
                OUTPUT_DIR="$2"
                mkdir -p "$OUTPUT_DIR"
                shift 2
                ;;
            -v|--verbose)
                VERBOSE=true
                shift
                ;;
            --no-monitoring)
                ENABLE_MONITORING=false
                shift
                ;;
            --monitor-interval)
                MONITOR_INTERVAL="$2"
                shift 2
                ;;
            crash|error|delay|dependency|network|resource|all)
                chaos_type="$1"
                shift
                ;;
            *)
                log_error "未知参数: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    log_info "开始混沌工程测试"
    log_info "混沌类型: $chaos_type"
    log_info "测试持续时间: ${DURATION}秒"
    log_info "测试强度: ${INTENSITY}%"
    log_info "输出目录: $OUTPUT_DIR"
    echo ""
    
    # 检查依赖
    if ! command -v docker >/dev/null 2>&1; then
        log_error "Docker未安装或不可用"
        exit 1
    fi
    
    if ! docker-compose ps >/dev/null 2>&1; then
        log_error "Docker Compose不可用或未在正确目录"
        exit 1
    fi
    
    # 执行混沌测试
    case $chaos_type in
        "crash")
            test_process_crash
            ;;
        "error")
            test_error_responses
            ;;
        "delay")
            test_delay_injection
            ;;
        "dependency")
            test_dependency_failure
            ;;
        "network")
            test_network_failure
            ;;
        "resource")
            test_resource_exhaustion
            ;;
        "all")
            test_process_crash
            echo ""
            test_error_responses
            echo ""
            test_delay_injection
            echo ""
            test_dependency_failure
            echo ""
            test_network_failure
            echo ""
            test_resource_exhaustion
            ;;
        *)
            log_error "未知混沌类型: $chaos_type"
            show_help
            exit 1
            ;;
    esac
    
    echo ""
    
    # 生成报告
    generate_chaos_report
    
    echo ""
    log_success "混沌工程测试完成"
    log_info "结果目录: $OUTPUT_DIR"
}

# 执行主函数
main "$@"