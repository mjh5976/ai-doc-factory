#!/bin/bash

# healthcheck.sh - 系统健康检查脚本
# 用于检测AI工厂系统中所有服务的健康状态

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 默认配置
SERVICE_TIMEOUT=30
MAX_RETRIES=3
OUTPUT_FORMAT="json"
VERBOSE=false

# 服务配置
declare -A SERVICES=(
    ["prometheus"]="http://localhost:9090/-/healthy"
    ["grafana"]="http://localhost:3000/api/health"
    ["alertmanager"]="http://localhost:9093/-/healthy"
    ["node_exporter"]="http://localhost:9100/metrics"
    ["cadvisor"]="http://localhost:8080/healthz"
    ["api_service"]="http://localhost:8000/health"
    ["vllm_service"]="http://localhost:8001/v1/models"
    ["nginx"]="http://localhost/health"
    ["postgres"]="localhost:5432"
    ["redis"]="localhost:6379"
)

# 端口检测函数
check_port() {
    local host=$1
    local port=$2
    local timeout=${3:-$SERVICE_TIMEOUT}
    
    if timeout $timeout bash -c "</dev/tcp/$host/$port" 2>/dev/null; then
        return 0
    else
        return 1
    fi
}

# HTTP检测函数
check_http() {
    local url=$1
    local timeout=${2:-$SERVICE_TIMEOUT}
    
    if curl -sf --max-time $timeout "$url" > /dev/null 2>&1; then
        return 0
    else
        return 1
    fi
}

# 服务健康检查
check_service() {
    local service_name=$1
    local service_url=$2
    
    log_info "检查服务: $service_name"
    
    local retry_count=0
    local success=false
    
    while [ $retry_count -lt $MAX_RETRIES ]; do
        if check_http "$service_url" $SERVICE_TIMEOUT; then
            success=true
            break
        fi
        
        retry_count=$((retry_count + 1))
        if [ $retry_count -lt $MAX_RETRIES ]; then
            log_warning "服务 $service_name 检查失败，重试中... ($retry_count/$MAX_RETRIES)"
            sleep 2
        fi
    done
    
    if [ "$success" = true ]; then
        log_success "服务 $service_name 健康"
        echo "$service_name:healthy"
        return 0
    else
        log_error "服务 $service_name 不健康"
        echo "$service_name:unhealthy"
        return 1
    fi
}

# Docker容器检查
check_docker_containers() {
    log_info "检查Docker容器状态..."
    
    local containers=("prometheus" "grafana" "alertmanager" "node_exporter" "cadvisor" 
                     "api_service" "vllm_service" "nginx")
    
    for container in "${containers[@]}"; do
        if docker-compose ps $container 2>/dev/null | grep -q "Up"; then
            log_success "容器 $container 运行中"
            echo "container_$container:running"
        else
            log_error "容器 $container 未运行"
            echo "container_$container:stopped"
        fi
    done
}

# 系统资源检查
check_system_resources() {
    log_info "检查系统资源..."
    
    # CPU使用率
    local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')
    echo "cpu_usage:${cpu_usage}%"
    
    # 内存使用率
    local mem_info=$(free | grep Mem)
    local total_mem=$(echo $mem_info | awk '{print $2}')
    local used_mem=$(echo $mem_info | awk '{print $3}')
    local mem_usage=$(echo "scale=2; $used_mem * 100 / $total_mem" | bc)
    echo "memory_usage:${mem_usage}%"
    
    # 磁盘使用率
    local disk_usage=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
    echo "disk_usage:${disk_usage}%"
    
    # 负载平均值
    local load_avg=$(uptime | awk -F'load average:' '{print $2}')
    echo "load_average:$load_avg"
}

# 网络连接检查
check_network() {
    log_info "检查网络连接..."
    
    local ports=(80 443 3000 8080 9090 9093 9100 9121 9187)
    
    for port in "${ports[@]}"; do
        if netstat -tuln 2>/dev/null | grep -q ":$port "; then
            log_success "端口 $port 监听中"
            echo "port_$port:listening"
        else
            log_warning "端口 $port 未监听"
            echo "port_$port:not_listening"
        fi
    done
}

# 数据库连接检查
check_databases() {
    log_info "检查数据库连接..."
    
    # PostgreSQL连接检查
    if check_port "localhost" "5432" 5; then
        log_success "PostgreSQL端口可访问"
        echo "postgres:accessible"
    else
        log_error "PostgreSQL端口不可访问"
        echo "postgres:not_accessible"
    fi
    
    # Redis连接检查
    if check_port "localhost" "6379" 5; then
        log_success "Redis端口可访问"
        echo "redis:accessible"
    else
        log_error "Redis端口不可访问"
        echo "redis:not_accessible"
    fi
}

# 性能指标检查
check_performance_metrics() {
    log_info "检查性能指标..."
    
    # Prometheus指标收集检查
    if check_http "http://localhost:9090/api/v1/query?query=up" 10; then
        log_success "Prometheus指标收集正常"
        echo "prometheus_metrics:normal"
    else
        log_error "Prometheus指标收集异常"
        echo "prometheus_metrics:error"
    fi
    
    # Grafana数据源检查
    if check_http "http://localhost:3000/api/datasources" 10; then
        log_success "Grafana数据源正常"
        echo "grafana_datasources:normal"
    else
        log_error "Grafana数据源异常"
        echo "grafana_datasources:error"
    fi
}

# 生成健康报告
generate_health_report() {
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local report_file="health_report_$(date +%Y%m%d_%H%M%S).json"
    
    log_info "生成健康报告: $report_file"
    
    cat > "$report_file" << EOF
{
  "timestamp": "$timestamp",
  "overall_status": "healthy",
  "services": {
    "monitoring": {
      "prometheus": "$(check_http 'http://localhost:9090/-/healthy' >/dev/null 2>&1 && echo 'healthy' || echo 'unhealthy')",
      "grafana": "$(check_http 'http://localhost:3000/api/health' >/dev/null 2>&1 && echo 'healthy' || echo 'unhealthy')",
      "alertmanager": "$(check_http 'http://localhost:9093/-/healthy' >/dev/null 2>&1 && echo 'healthy' || echo 'unhealthy')"
    },
    "infrastructure": {
      "node_exporter": "$(check_http 'http://localhost:9100/metrics' >/dev/null 2>&1 && echo 'healthy' || echo 'unhealthy')",
      "cadvisor": "$(check_http 'http://localhost:8080/healthz' >/dev/null 2>&1 && echo 'healthy' || echo 'unhealthy')",
      "nginx": "$(check_http 'http://localhost/health' >/dev/null 2>&1 && echo 'healthy' || echo 'unhealthy')"
    },
    "application": {
      "api_service": "$(check_http 'http://localhost:8000/health' >/dev/null 2>&1 && echo 'healthy' || echo 'unhealthy')",
      "vllm_service": "$(check_http 'http://localhost:8001/v1/models' >/dev/null 2>&1 && echo 'healthy' || echo 'unhealthy')"
    },
    "databases": {
      "postgresql": "$(check_port 'localhost' '5432' >/dev/null 2>&1 && echo 'healthy' || echo 'unhealthy')",
      "redis": "$(check_port 'localhost' '6379' >/dev/null 2>&1 && echo 'healthy' || echo 'unhealthy')"
    }
  },
  "resources": {
    "cpu_usage": "$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')%",
    "memory_usage": "$(free | grep Mem | awk '{printf "%.2f", $3*100/$2}')%",
    "disk_usage": "$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')%"
  }
}
EOF
    
    echo "健康报告已保存到: $report_file"
    echo "$report_file"
}

# 显示帮助信息
show_help() {
    echo "AI工厂系统健康检查脚本"
    echo ""
    echo "使用方法:"
    echo "  $0 [选项] [服务名]"
    echo ""
    echo "选项:"
    echo "  -h, --help          显示此帮助信息"
    echo "  -v, --verbose       详细输出"
    echo "  -f, --format FORMAT 输出格式 (json|text)"
    echo "  -t, --timeout SEC   服务检查超时时间"
    echo "  -r, --retries NUM   重试次数"
    echo "  -o, --output FILE   输出文件"
    echo "  --all               检查所有服务"
    echo "  --services          仅检查服务"
    echo "  --resources         仅检查资源"
    echo "  --network           仅检查网络"
    echo "  --databases         仅检查数据库"
    echo "  --performance       仅检查性能指标"
    echo ""
    echo "示例:"
    echo "  $0 --all                    # 检查所有组件"
    echo "  $0 --services               # 仅检查服务"
    echo "  $0 --resources              # 仅检查资源"
    echo "  $0 -v prometheus grafana    # 详细检查指定服务"
    echo "  $0 -f json --output report.json # JSON格式输出"
}

# 主函数
main() {
    local check_all=false
    local check_services=false
    local check_resources=false
    local check_network=false
    local check_databases=false
    local check_performance=false
    local output_file=""
    
    # 解析命令行参数
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -v|--verbose)
                VERBOSE=true
                shift
                ;;
            -f|--format)
                OUTPUT_FORMAT="$2"
                shift 2
                ;;
            -t|--timeout)
                SERVICE_TIMEOUT="$2"
                shift 2
                ;;
            -r|--retries)
                MAX_RETRIES="$2"
                shift 2
                ;;
            -o|--output)
                output_file="$2"
                shift 2
                ;;
            --all)
                check_all=true
                shift
                ;;
            --services)
                check_services=true
                shift
                ;;
            --resources)
                check_resources=true
                shift
                ;;
            --network)
                check_network=true
                shift
                ;;
            --databases)
                check_databases=true
                shift
                ;;
            --performance)
                check_performance=true
                shift
                ;;
            *)
                # 检查指定服务
                if [[ -n "${SERVICES[$1]}" ]]; then
                    check_service "$1" "${SERVICES[$1]}"
                else
                    log_error "未知服务: $1"
                    show_help
                    exit 1
                fi
                shift
                ;;
        esac
    done
    
    # 默认检查所有
    if [ "$check_all" = false ] && [ "$check_services" = false ] && 
       [ "$check_resources" = false ] && [ "$check_network" = false ] && 
       [ "$check_databases" = false ] && [ "$check_performance" = false ] && 
       [ $# -eq 0 ]; then
        check_all=true
    fi
    
    log_info "开始AI工厂系统健康检查..."
    echo ""
    
    local exit_code=0
    
    # 执行检查
    if [ "$check_all" = true ] || [ "$check_services" = true ]; then
        echo "=== 服务健康检查 ==="
        for service in "${!SERVICES[@]}"; do
            if ! check_service "$service" "${SERVICES[$service]}"; then
                exit_code=1
            fi
        done
        echo ""
    fi
    
    if [ "$check_all" = true ] || [ "$check_resources" = true ]; then
        echo "=== 系统资源检查 ==="
        check_system_resources
        echo ""
    fi
    
    if [ "$check_all" = true ] || [ "$check_network" = true ]; then
        echo "=== 网络连接检查 ==="
        check_network
        echo ""
    fi
    
    if [ "$check_all" = true ] || [ "$check_databases" = true ]; then
        echo "=== 数据库连接检查 ==="
        check_databases
        echo ""
    fi
    
    if [ "$check_all" = true ] || [ "$check_performance" = true ]; then
        echo "=== 性能指标检查 ==="
        check_performance_metrics
        echo ""
    fi
    
    # 生成报告
    if [ -n "$output_file" ]; then
        generate_health_report > "$output_file"
    else
        generate_health_report
    fi
    
    if [ $exit_code -eq 0 ]; then
        log_success "健康检查完成 - 所有组件正常"
    else
        log_warning "健康检查完成 - 部分组件异常，请查看日志"
    fi
    
    exit $exit_code
}

# 执行主函数
main "$@"