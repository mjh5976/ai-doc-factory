# PDF图纸识别性能监控和评估体系使用指南

## 概述

本文档详细说明如何使用PDF图纸识别性能监控和评估体系，包括系统安装、配置、使用和维护。

## 目录

1. [系统架构](#系统架构)
2. [安装部署](#安装部署)
3. [配置说明](#配置说明)
4. [使用指南](#使用指南)
5. [监控指标](#监控指标)
6. [告警配置](#告警配置)
7. [性能评估](#性能评估)
8. [A/B测试](#ab测试)
9. [报告生成](#报告生成)
10. [故障排除](#故障排除)
11. [最佳实践](#最佳实践)

## 系统架构

### 组件架构

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   PDF识别服务    │    │   性能评估服务   │    │   A/B测试服务    │
│                 │    │                 │    │                 │
│ • 识别处理      │───▶│ • 指标计算      │───▶│ • 实验管理      │
│ • 指标收集      │    │ • 性能对比      │    │ • 结果分析      │
│ • 错误统计      │    │ • 质量评估      │    │ • 统计检验      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                        监控数据层                                │
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────┐ │
│  │  Prometheus │  │   Grafana   │  │AlertManager │  │ 报告生成 │ │
│  │             │  │             │  │             │  │         │ │
│  │ • 指标存储  │  │ • 可视化    │  │ • 告警管理  │  │ • 报告   │ │
│  │ • 查询服务  │  │ • 仪表板    │  │ • 通知发送  │  │ • 导出   │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

### 技术栈

- **监控收集**: Prometheus Client (Python)
- **时序数据库**: Prometheus
- **可视化**: Grafana
- **告警管理**: AlertManager
- **系统监控**: Node Exporter
- **性能评估**: scikit-learn, pandas, numpy
- **报告生成**: matplotlib, seaborn, Jinja2
- **A/B测试**: scipy.stats

## 安装部署

### 系统要求

- **操作系统**: Linux/macOS/Windows
- **Docker**: >= 20.0
- **Docker Compose**: >= 2.0
- **Python**: >= 3.8
- **内存**: >= 4GB
- **存储**: >= 10GB

### 快速部署

1. **克隆项目文件**
   ```bash
   # 确保所有文件都在当前目录下
   ls -la
   # 应该看到: config/, code/, deploy.sh 等文件
   ```

2. **运行部署脚本**
   ```bash
   chmod +x deploy.sh
   ./deploy.sh
   ```

3. **验证部署**
   ```bash
   ./test_monitoring.sh
   ```

### 手动部署

如果自动部署失败，可以手动执行以下步骤：

1. **创建目录结构**
   ```bash
   mkdir -p data/{prometheus,grafana,alertmanager}
   mkdir -p logs reports
   ```

2. **复制配置文件**
   ```bash
   cp config/prometheus.yml data/prometheus/
   cp config/alertmanager.yml data/alertmanager/
   cp config/grafana_dashboard.json data/grafana/
   ```

3. **启动服务**
   ```bash
   docker-compose up -d
   ```

## 配置说明

### Prometheus配置

配置文件: `config/prometheus.yml`

```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'pdf-recognition-service'
    static_configs:
      - targets: ['pdf-service:8080']
    metrics_path: '/metrics'
    scrape_interval: 10s
```

**关键配置项说明**:
- `scrape_interval`: 指标采集间隔
- `evaluation_interval`: 告警规则评估间隔
- `targets`: 监控目标地址

### AlertManager配置

配置文件: `config/alertmanager.yml`

```yaml
route:
  group_by: ['alertname', 'cluster']
  receiver: 'default-receiver'

receivers:
  - name: 'default-receiver'
    email_configs:
      - to: 'ops-team@company.com'
```

**关键配置项说明**:
- `group_by`: 告警分组字段
- `receiver`: 告警接收者
- `email_configs`: 邮件通知配置

### Grafana配置

仪表板配置文件: `config/grafana_dashboard.json`

包含以下面板:
- PDF识别准确率/召回率/F1-score
- 处理时间趋势
- 系统资源使用率
- 错误统计

## 使用指南

### 启动监控服务

1. **启动所有服务**
   ```bash
   docker-compose up -d
   ```

2. **查看服务状态**
   ```bash
   docker-compose ps
   ```

3. **查看服务日志**
   ```bash
   docker-compose logs -f [service_name]
   ```

### 访问监控界面

- **Grafana仪表板**: http://localhost:3000
  - 用户名: admin
  - 密码: admin123

- **Prometheus查询**: http://localhost:9090

- **AlertManager**: http://localhost:9093

### 集成到现有系统

1. **添加监控指标收集**
   ```python
   from monitoring_sdk import PDFRecognitionMonitor, MonitoringConfig
   
   # 创建监控器
   config = MonitoringConfig(
       service_name="your-service-name",
       environment="production"
   )
   monitor = PDFRecognitionMonitor(config)
   monitor.start()
   
   # 记录识别结果
   monitor.record_recognition_result(
       blueprint_type="architectural",
       model_version="v1.0",
       accuracy=0.85,
       recall=0.80,
       f1_score=0.82,
       precision=0.83,
       processing_time=25.5
   )
   ```

2. **使用性能评估工具**
   ```python
   from performance_evaluator import PDFBlueprintEvaluator, BlueprintEvaluationConfig
   
   # 创建评估器
   config = BlueprintEvaluationConfig()
   evaluator = PDFBlueprintEvaluator(config)
   
   # 评估模型性能
   result = evaluator.evaluate_model_performance(
       predictions=predictions,
       ground_truth=ground_truth,
       blueprint_type="architectural",
       model_version="v1.0"
   )
   ```

## 监控指标

### 核心性能指标

#### 识别性能指标
- `pdf_blueprint_recognition_accuracy`: 识别准确率
- `pdf_blueprint_recognition_recall`: 识别召回率
- `pdf_blueprint_recognition_f1_score`: F1-score
- `pdf_blueprint_recognition_precision`: 精确率

#### 处理性能指标
- `pdf_blueprint_recognition_processing_time_seconds`: 处理时间
- `pdf_blueprint_recognition_total`: 总请求数
- `pdf_blueprint_recognition_errors_total`: 错误总数

#### 系统资源指标
- `pdf_model_memory_usage_bytes`: 内存使用量
- `pdf_model_cpu_usage_percent`: CPU使用率
- `node_cpu_usage_percent`: 系统CPU使用率
- `node_memory_usage_percent`: 系统内存使用率

### 图纸类型特定指标

- **建筑图纸**: architectural_blueprint_accuracy
- **机械图纸**: mechanical_blueprint_accuracy  
- **电气图纸**: electrical_blueprint_accuracy
- **P&ID图纸**: pid_blueprint_accuracy

### A/B测试指标

- `pdf_ab_test_accuracy`: A/B测试准确率
- `pdf_ab_test_samples_total`: A/B测试样本数
- `pdf_ab_test_processing_time`: A/B测试处理时间

## 告警配置

### 告警规则

配置文件: `config/alert_rules.yml`

#### 性能告警
```yaml
- alert: PDFRecognitionAccuracyLow
  expr: pdf_blueprint_recognition_accuracy < 0.85
  for: 5m
  labels:
    severity: warning
  annotations:
    summary: "PDF识别准确率过低"
```

#### 系统资源告警
```yaml
- alert: HighCPUUsage
  expr: node_cpu_usage_percent > 80
  for: 5m
  labels:
    severity: warning
  annotations:
    summary: "CPU使用率过高"
```

### 告警级别

- **P1 (Critical)**: 系统不可用或严重性能问题
- **P2 (Warning)**: 性能指标异常，需要关注
- **P3 (Info)**: 信息性通知

### 通知配置

支持以下通知方式:
- 邮件通知
- Slack通知
- 企业微信通知
- 钉钉通知

## 性能评估

### 评估指标

#### 基础指标
- **准确率 (Accuracy)**: 正确识别的比例
- **召回率 (Recall)**: 实际正样本被正确识别的比例
- **精确率 (Precision)**: 预测为正样本中实际为正的比例
- **F1-score**: 精确率和召回率的调和平均

#### 图纸特定指标
- **结构保真度**: 几何重建质量
- **拓扑一致性**: 连接关系正确性
- **尺寸链闭合**: 工程约束满足度

### 评估配置

```python
config = BlueprintEvaluationConfig(
    accuracy_weight=0.25,
    recall_weight=0.25,
    f1_score_weight=0.25,
    processing_time_weight=0.15,
    memory_efficiency_weight=0.10,
    accuracy_threshold=0.85,
    recall_threshold=0.80,
    f1_score_threshold=0.82
)
```

### 使用示例

```python
from performance_evaluator import PDFBlueprintEvaluator

# 创建评估器
evaluator = PDFBlueprintEvaluator()

# 评估模型性能
result = evaluator.evaluate_model_performance(
    predictions=model_predictions,
    ground_truth=true_labels,
    blueprint_type="architectural",
    model_version="v1.0",
    processing_time=25.5,
    memory_usage=2048
)

# 计算综合评分
composite_score = evaluator.calculate_composite_score(result)
print(f"综合评分: {composite_score:.3f}")

# 比较两个模型
comparison = evaluator.compare_models(result_a, result_b)
print("模型比较结果:", comparison)
```

## A/B测试

### 测试配置

```python
from ab_testing_framework import ABTestFramework, ABTestConfig

config = ABTestConfig(
    test_name="模型版本比较测试",
    model_version_a="v1.0",
    model_version_b="v1.1",
    blueprint_types=["architectural", "mechanical"],
    sample_size_per_group=1000,
    confidence_level=0.95,
    minimum_effect_size=0.02
)

framework = ABTestFramework(config)
```

### 测试流程

1. **开始测试**
   ```python
   test_id = framework.start_test("test_001")
   ```

2. **分配用户到组**
   ```python
   group = framework.assign_user_to_group(test_id, user_id)
   ```

3. **记录测试结果**
   ```python
   framework.record_test_result(
       test_id=test_id,
       user_id=user_id,
       blueprint_type="architectural",
       model_version=model_version,
       group=group,
       accuracy=accuracy,
       f1_score=f1_score,
       processing_time=processing_time
   )
   ```

4. **结束测试并分析**
   ```python
   result = framework.conclude_test(test_id)
   print("测试结论:", result.conclusion)
   print("建议:", result.recommendation)
   ```

### 统计检验

支持以下统计检验方法:
- **t检验**: 比较两组均值差异
- **Mann-Whitney U检验**: 非参数检验
- **效应大小**: Cohen's d
- **置信区间**: 指标的可信度范围

## 报告生成

### 报告类型

- **日报**: 每日性能汇总
- **周报**: 周度性能分析
- **月报**: 月度性能趋势
- **专项报告**: A/B测试、模型对比等

### 生成报告

```python
from report_generator import PerformanceReportGenerator

generator = PerformanceReportGenerator()

# 生成日报
daily_report = generator.generate_daily_report(
    metrics_data,
    "reports/daily_report.html"
)

# 生成PDF报告
pdf_report = generator.generate_pdf_report(
    metrics_data,
    "reports/performance_report.pdf"
)
```

### 报告内容

报告包含以下章节:
1. **执行摘要**: 关键指标概览
2. **性能趋势**: 指标变化趋势
3. **详细分析**: 各维度性能分析
4. **告警汇总**: 告警事件统计
5. **建议行动**: 优化建议和行动计划

## 故障排除

### 常见问题

#### 1. 服务启动失败
```bash
# 检查Docker服务
docker-compose ps

# 查看错误日志
docker-compose logs [service_name]

# 重启服务
docker-compose restart [service_name]
```

#### 2. 指标数据缺失
```bash
# 检查Prometheus目标状态
curl http://localhost:9090/api/v1/targets

# 检查应用指标端点
curl http://localhost:8080/metrics
```

#### 3. Grafana仪表板无数据
```bash
# 检查数据源配置
curl http://localhost:3000/api/datasources

# 重新导入仪表板
curl -X POST -H "Content-Type: application/json" \
  -d @config/grafana_dashboard.json \
  http://admin:admin123@localhost:3000/api/dashboards/db
```

#### 4. 告警不触发
```bash
# 检查告警规则
curl http://localhost:9090/api/v1/rules

# 检查AlertManager状态
curl http://localhost:9093/api/v1/status
```

### 日志分析

#### 应用日志
```bash
# 查看应用日志
docker-compose logs -f pdf-recognition-service

# 查看评估服务日志
docker-compose logs -f evaluation-service
```

#### 监控系统日志
```bash
# Prometheus日志
docker-compose logs -f prometheus

# Grafana日志
docker-compose logs -f grafana

# AlertManager日志
docker-compose logs -f alertmanager
```

### 性能优化

#### 1. 内存优化
- 调整Prometheus数据保留时间
- 优化Grafana查询性能
- 减少不必要的指标收集

#### 2. 存储优化
- 配置数据压缩
- 定期清理历史数据
- 使用外部存储

#### 3. 网络优化
- 调整采集间隔
- 使用指标下采样
- 优化告警规则

## 最佳实践

### 监控配置

1. **合理设置采集间隔**
   - 生产环境: 15-30秒
   - 测试环境: 5-10秒

2. **告警阈值设置**
   - 基于历史数据设定
   - 考虑业务影响程度
   - 设置合理的告警延迟

3. **指标命名规范**
   - 使用清晰的命名约定
   - 包含业务含义
   - 避免重复指标

### 性能评估

1. **评估频率**
   - 每日: 核心指标
   - 每周: 详细分析
   - 每月: 趋势分析

2. **评估数据**
   - 使用真实业务数据
   - 保证数据质量
   - 定期更新基准

3. **结果分析**
   - 多维度对比
   - 考虑统计显著性
   - 结合业务场景

### A/B测试

1. **测试设计**
   - 明确测试目标
   - 合理分配流量
   - 控制测试时间

2. **数据收集**
   - 确保数据完整性
   - 避免选择偏差
   - 记录测试上下文

3. **结果分析**
   - 使用适当的统计方法
   - 考虑实际业务影响
   - 制定后续行动计划

### 报告生成

1. **报告频率**
   - 实时: 关键指标监控
   - 日报: 日常运营报告
   - 周报/月报: 管理层报告

2. **报告内容**
   - 突出关键信息
   - 提供可执行的建议
   - 包含图表可视化

3. **分发策略**
   - 面向不同受众
   - 控制分发频率
   - 确保信息安全

## 扩展开发

### 添加新的监控指标

1. **在监控SDK中添加指标定义**
   ```python
   # 在monitoring_sdk.py中添加
   self.new_metric = Gauge(
       'pdf_new_metric',
       '新指标描述',
       ['service_name', 'dimension']
   )
   ```

2. **在配置文件中添加采集规则**
   ```yaml
   # 在prometheus.yml中添加
   - job_name: 'new-metrics'
     static_configs:
       - targets: ['new-service:8080']
   ```

### 添加新的评估指标

1. **扩展评估器类**
   ```python
   # 在performance_evaluator.py中添加
   def evaluate_custom_metric(self, predictions, ground_truth):
       # 自定义指标计算逻辑
       return custom_score
   ```

2. **更新配置**
   ```python
   # 在BlueprintEvaluationConfig中添加
   custom_weight: float = 0.10
   ```

### 集成外部系统

1. **数据库集成**
   ```python
   # 连接外部数据库存储历史数据
   import psycopg2
   
   def save_metrics_to_db(metrics_data):
       # 数据库存储逻辑
       pass
   ```

2. **消息队列集成**
   ```python
   # 使用消息队列处理大量指标数据
   import pika
   
   def publish_metrics(message):
       # 消息发布逻辑
       pass
   ```

## 维护指南

### 日常维护

1. **检查服务状态**
   ```bash
   # 每日检查脚本
   ./scripts/daily_check.sh
   ```

2. **清理历史数据**
   ```bash
   # 每周清理脚本
   ./scripts/cleanup.sh
   ```

3. **备份配置**
   ```bash
   # 每月备份脚本
   ./scripts/backup.sh
   ```

### 升级维护

1. **版本升级**
   ```bash
   # 升级脚本
   ./scripts/upgrade.sh
   ```

2. **配置迁移**
   ```bash
   # 配置迁移脚本
   ./scripts/migrate_config.sh
   ```

3. **数据迁移**
   ```bash
   # 数据迁移脚本
   ./scripts/migrate_data.sh
   ```

## 联系支持

如有问题或需要技术支持，请联系:

- **技术支持邮箱**: tech-support@company.com
- **系统管理员**: admin@company.com
- **项目负责人**: pm@company.com

---

*最后更新时间: 2025-11-06*