#!/bin/bash

# loadtest-model.sh - 模型服务负载测试脚本
# 用于对AI工厂系统的模型服务(vLLM/Ollama)进行负载和压力测试

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 默认配置
MODEL_URL="http://localhost:8001"
MODEL_NAME="llama-2-7b-chat"
CONCURRENT_REQUESTS=8
TEST_DURATION=120
RAMP_UP_TIME=60
OUTPUT_DIR="./model_loadtest_results"
REPORT_FILE=""
VERBOSE=false
ENABLE_MONITORING=true
MONITOR_INTERVAL=5
MAX_TOKENS=512
TEMPERATURE=0.7

# 测试场景配置
declare -A TEST_SCENARIOS=(
    ["chat_completion"]="POST /v1/chat/completions"
    ["text_completion"]="POST /v1/completions"
    ["embeddings"]="POST /v1/embeddings"
    ["models_list"]="GET /v1/models"
    ["token_count"]="POST /v1/tokenize"
)

# 模型类型检测
MODEL_TYPE="openai"  # openai 或 ollama

# 性能指标存储
declare -A METRICS=(
    ["total_requests"]=0
    ["successful_requests"]=0
    ["failed_requests"]=0
    ["total_response_time"]=0
    ["total_tokens_generated"]=0
    ["min_response_time"]=999999
    ["max_response_time"]=0
    ["tokens_per_second"]=0
)

# 创建输出目录
mkdir -p "$OUTPUT_DIR"

# 清理函数
cleanup() {
    log_info "清理测试环境..."
    # 终止所有后台进程
    jobs -p | xargs -r kill 2>/dev/null || true
    wait
}

trap cleanup EXIT

# 检测模型服务类型
detect_model_type() {
    log_info "检测模型服务类型..."
    
    if curl -sf --max-time 5 "$MODEL_URL/v1/models" > /dev/null 2>&1; then
        MODEL_TYPE="openai"
        log_success "检测到OpenAI兼容API (vLLM)"
    elif curl -sf --max-time 5 "$MODEL_URL/api/tags" > /dev/null 2>&1; then
        MODEL_TYPE="ollama"
        log_success "检测到Ollama API"
    else
        log_warning "无法确定模型服务类型，尝试默认OpenAI兼容模式"
        MODEL_TYPE="openai"
    fi
}

# 生成测试提示
generate_prompt() {
    local prompt_type=$1
    local max_length=${2:-200}
    
    case $prompt_type in
        "simple")
            echo "请解释什么是人工智能。"
            ;;
        "complex")
            cat << EOF
请详细分析以下问题：
1. 机器学习在自然语言处理中的应用
2. 深度学习与传统算法的区别
3. 当前AI技术面临的主要挑战

请用专业的语言回答，每个部分至少100字。
EOF
            ;;
        "code")
            echo "请编写一个Python函数，实现快速排序算法。"
            ;;
        "creative")
            echo "请写一个关于未来科技发展的短故事，大约200字。"
            ;;
        "technical")
            echo "解释Transformer架构的工作原理，包括注意力机制和位置编码。"
            ;;
        *)
            echo "请简单介绍一下深度学习的基本概念。"
            ;;
    esac
}

# 生成嵌入测试数据
generate_embedding_data() {
    cat << EOF
{
  "input": [
    "人工智能是计算机科学的一个分支",
    "机器学习是AI的核心技术之一",
    "深度学习使用神经网络进行学习",
    "自然语言处理使计算机能够理解人类语言",
    "计算机视觉让机器能够看懂图像"
  ],
  "model": "$MODEL_NAME"
}
EOF
}

# HTTP请求函数
make_model_request() {
    local method=$1
    local endpoint=$2
    local payload=$3
    local start_time=$(date +%s%3N)
    
    local curl_opts="--max-time 120 --connect-timeout 30 --retry 3 --retry-delay 2"
    
    if [ "$VERBOSE" = true ]; then
        curl_opts="$curl_opts -v"
    fi
    
    local response
    local http_code
    
    response=$(curl -w "%{http_code}" -X "$method" \
        -H "Content-Type: application/json" \
        -H "X-LoadTest: true" \
        -d "$payload" \
        $curl_opts "$MODEL_URL$endpoint" 2>/dev/null)
    
    local end_time=$(date +%s%3N)
    local response_time=$((end_time - start_time))
    
    http_code="${response: -3}"
    response="${response%???}"
    
    # 更新指标
    METRICS["total_requests"]=$((METRICS["total_requests"] + 1))
    METRICS["total_response_time"]=$((METRICS["total_response_time"] + response_time))
    
    if [ "$response_time" -lt "${METRICS["min_response_time"]}" ]; then
        METRICS["min_response_time"]=$response_time
    fi
    
    if [ "$response_time" -gt "${METRICS["max_response_time"]}" ]; then
        METRICS["max_response_time"]=$response_time
    fi
    
    if [[ "$http_code" =~ ^[23] ]]; then
        METRICS["successful_requests"]=$((METRICS["successful_requests"] + 1))
        
        # 提取生成的token数量
        local tokens_generated=0
        if [[ "$response" =~ \"total_tokens\":[[:space:]]*([0-9]+) ]]; then
            tokens_generated=${BASH_REMATCH[1]}
        elif [[ "$response" =~ \"usage\":.*\"completion_tokens\":[[:space:]]*([0-9]+) ]]; then
            tokens_generated=${BASH_REMATCH[1]}
        fi
        
        METRICS["total_tokens_generated"]=$((METRICS["total_tokens_generated"] + tokens_generated))
        
        if [ "$VERBOSE" = true ]; then
            log_success "请求成功: ${response_time}ms, $http_code, $tokens_generated tokens"
        fi
    else
        METRICS["failed_requests"]=$((METRICS["failed_requests"] + 1))
        log_warning "请求失败: ${response_time}ms, $http_code"
        if [ "$VERBOSE" = true ]; then
            echo "Response: $response"
        fi
    fi
    
    echo "$response_time|$http_code|$tokens_generated"
}

# 单请求负载测试
single_request_load() {
    local scenario=$1
    local duration=$2
    local prompt_type=$3
    
    log_info "开始单请求负载测试: $scenario (${duration}s, $prompt_type)"
    
    local endpoint_info=${TEST_SCENARIOS[$scenario]}
    local method=$(echo "$endpoint_info" | awk '{print $1}')
    local endpoint=$(echo "$endpoint_info" | awk '{print $2}')
    
    local payload=""
    case $scenario in
        "chat_completion")
            local prompt=$(generate_prompt "$prompt_type")
            payload=$(cat << EOF
{
  "model": "$MODEL_NAME",
  "messages": [
    {"role": "user", "content": "$prompt"}
  ],
  "max_tokens": $MAX_TOKENS,
  "temperature": $TEMPERATURE
}
EOF
)
            ;;
        "text_completion")
            local prompt=$(generate_prompt "$prompt_type")
            payload=$(cat << EOF
{
  "model": "$MODEL_NAME",
  "prompt": "$prompt",
  "max_tokens": $MAX_TOKENS,
  "temperature": $TEMPERATURE
}
EOF
)
            ;;
        "embeddings")
            payload=$(generate_embedding_data)
            ;;
        "models_list")
            payload="{}"
            ;;
        "token_count")
            local prompt=$(generate_prompt "$prompt_type")
            payload=$(cat << EOF
{
  "model": "$MODEL_NAME",
  "input": "$prompt"
}
EOF
)
            ;;
    esac
    
    local start_time=$(date +%s)
    local end_time=$((start_time + duration))
    local request_count=0
    
    while [ $(date +%s) -lt $end_time ]; do
        make_model_request "$method" "$endpoint" "$payload"
        request_count=$((request_count + 1))
        
        # 随机延迟 0.5-3秒
        sleep $(echo "scale=3; ($RANDOM % 2500 + 500) / 1000" | bc)
    done
    
    log_info "单请求测试完成: $request_count 次请求"
}

# 并发请求负载测试
concurrent_request_load() {
    local num_requests=$1
    local duration=$2
    local scenario=$3
    local prompt_type=$4
    
    log_info "开始并发请求负载测试: $num_requests 并发, $scenario (${duration}s)"
    
    local pids=()
    local endpoint_info=${TEST_SCENARIOS[$scenario]}
    local method=$(echo "$endpoint_info" | awk '{print $1}')
    local endpoint=$(echo "$endpoint_info" | awk '{print $2}')
    
    # 启动并发请求
    for ((i=1; i<=num_requests; i++)); do
        {
            local payload=""
            case $scenario in
                "chat_completion")
                    local prompt=$(generate_prompt "$prompt_type")
                    payload=$(cat << EOF
{
  "model": "$MODEL_NAME",
  "messages": [
    {"role": "user", "content": "$prompt"}
  ],
  "max_tokens": $MAX_TOKENS,
  "temperature": $TEMPERATURE
}
EOF
)
                    ;;
                "text_completion")
                    local prompt=$(generate_prompt "$prompt_type")
                    payload=$(cat << EOF
{
  "model": "$MODEL_NAME",
  "prompt": "$prompt",
  "max_tokens": $MAX_TOKENS,
  "temperature": $TEMPERATURE
}
EOF
)
                    ;;
                "embeddings")
                    payload=$(generate_embedding_data)
                    ;;
                "models_list")
                    payload="{}"
                    ;;
                "token_count")
                    local prompt=$(generate_prompt "$prompt_type")
                    payload=$(cat << EOF
{
  "model": "$MODEL_NAME",
  "input": "$prompt"
}
EOF
)
                    ;;
            esac
            
            local start_time=$(date +%s)
            local end_time=$((start_time + duration))
            local request_count=0
            
            while [ $(date +%s) -lt $end_time ]; do
                make_model_request "$method" "$endpoint" "$payload"
                request_count=$((request_count + 1))
                sleep $(echo "scale=3; ($RANDOM % 2000 + 500) / 1000" | bc)
            done
            
            log_info "请求线程 $i 完成: $request_count 次请求"
        } &
        pids+=($!)
    done
    
    # 等待所有请求完成
    for pid in "${pids[@]}"; do
        wait "$pid"
    done
    
    log_info "并发请求测试完成"
}

# 阶梯负载测试
ramp_up_load() {
    local max_requests=$1
    local step_duration=$2
    local scenario=$3
    local prompt_type=$4
    
    log_info "开始阶梯负载测试: 最大 $max_requests 并发, $scenario"
    
    local current_requests=1
    local step_size=$((max_requests / 8))
    [ $step_size -lt 1 ] && step_size=1
    
    while [ $current_requests -le $max_requests ]; do
        log_info "阶梯测试: $current_requests 并发 (${step_duration}s)"
        concurrent_request_load "$current_requests" "$step_duration" "$scenario" "$prompt_type"
        
        current_requests=$((current_requests + step_size))
        [ $current_requests -gt $max_requests ] && current_requests=$max_requests
    done
}

# 模型服务监控
monitor_model_service() {
    local duration=$1
    local interval=${2:-$MONITOR_INTERVAL}
    
    log_info "开始模型服务监控 (${duration}s, ${interval}s间隔)"
    
    local monitor_file="$OUTPUT_DIR/model_monitor_$(date +%Y%m%d_%H%M%S).csv"
    
    echo "timestamp,cpu_usage,memory_usage,gpu_utilization,gpu_memory,active_requests,queue_length" > "$monitor_file"
    
    local start_time=$(date +%s)
    local end_time=$((start_time + duration))
    
    while [ $(date +%s) -lt $end_time ]; do
        local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
        local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')
        local mem_info=$(free | grep Mem)
        local total_mem=$(echo $mem_info | awk '{print $2}')
        local used_mem=$(echo $mem_info | awk '{print $3}')
        local mem_usage=$(echo "scale=2; $used_mem * 100 / $total_mem" | bc)
        
        # GPU监控 (如果可用)
        local gpu_util="N/A"
        local gpu_mem="N/A"
        if command -v nvidia-smi >/dev/null 2>&1; then
            gpu_util=$(nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits 2>/dev/null | head -1)
            gpu_mem=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits 2>/dev/null | head -1)
        fi
        
        # 活跃请求数
        local active_requests=$(curl -sf "$MODEL_URL/v1/models" 2>/dev/null | grep -o '"total"' | wc -l)
        
        # 队列长度 (通过API状态获取)
        local queue_length=0
        if curl -sf "$MODEL_URL/v1/models" >/dev/null 2>&1; then
            queue_length=0  # 简化处理
        fi
        
        echo "$timestamp,$cpu_usage,$mem_usage,$gpu_util,$gpu_mem,$active_requests,$queue_length" >> "$monitor_file"
        
        sleep $interval
    done
    
    log_info "模型服务监控完成: $monitor_file"
}

# 计算性能统计
calculate_statistics() {
    local total_requests=${METRICS["total_requests"]}
    local successful_requests=${METRICS["successful_requests"]}
    local failed_requests=${METRICS["failed_requests"]}
    local total_response_time=${METRICS["total_response_time"]}
    local total_tokens=${METRICS["total_tokens_generated"]}
    local min_response_time=${METRICS["min_response_time"]}
    local max_response_time=${METRICS["max_response_time"]}
    
    if [ $total_requests -eq 0 ]; then
        log_error "没有请求数据"
        return 1
    fi
    
    local avg_response_time=$(echo "scale=2; $total_response_time / $total_requests" | bc)
    local success_rate=$(echo "scale=2; $successful_requests * 100 / $total_requests" | bc)
    local error_rate=$(echo "scale=2; $failed_requests * 100 / $total_requests" | bc)
    local throughput=$(echo "scale=2; $total_requests / $TEST_DURATION" | bc)
    local tokens_per_second=$(echo "scale=2; $total_tokens / $TEST_DURATION" | bc)
    
    echo "=== 模型服务负载测试结果 ==="
    echo "总请求数: $total_requests"
    echo "成功请求: $successful_requests"
    echo "失败请求: $failed_requests"
    echo "成功率: ${success_rate}%"
    echo "错误率: ${error_rate}%"
    echo "平均响应时间: ${avg_response_time}ms"
    echo "最小响应时间: ${min_response_time}ms"
    echo "最大响应时间: ${max_response_time}ms"
    echo "吞吐量: ${throughput} 请求/秒"
    echo "总生成token数: $total_tokens"
    echo "Token生成速率: ${tokens_per_second} tokens/秒"
    echo "测试时长: ${TEST_DURATION}秒"
    echo "并发请求数: $CONCURRENT_REQUESTS"
    echo "模型类型: $MODEL_TYPE"
    
    # 生成详细报告
    local report_file="${REPORT_FILE:-model_loadtest_report_$(date +%Y%m%d_%H%M%S).json}"
    
    cat > "$report_file" << EOF
{
  "test_info": {
    "timestamp": "$(date -Iseconds)",
    "model_url": "$MODEL_URL",
    "model_name": "$MODEL_NAME",
    "model_type": "$MODEL_TYPE",
    "concurrent_requests": $CONCURRENT_REQUESTS,
    "test_duration": $TEST_DURATION,
    "ramp_up_time": $RAMP_UP_TIME,
    "max_tokens": $MAX_TOKENS,
    "temperature": $TEMPERATURE
  },
  "results": {
    "total_requests": $total_requests,
    "successful_requests": $successful_requests,
    "failed_requests": $failed_requests,
    "success_rate": $success_rate,
    "error_rate": $error_rate,
    "avg_response_time": $avg_response_time,
    "min_response_time": $min_response_time,
    "max_response_time": $max_response_time,
    "throughput": $throughput,
    "total_tokens_generated": $total_tokens,
    "tokens_per_second": $tokens_per_second
  },
  "resources": {
    "cpu_usage": "$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')%",
    "memory_usage": "$(free | grep Mem | awk '{printf "%.2f", $3*100/$2}')%",
    "gpu_utilization": "$(nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits 2>/dev/null | head -1 || echo 'N/A')%",
    "gpu_memory": "$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits 2>/dev/null | head -1 || echo 'N/A')MB"
  }
}
EOF
    
    log_success "详细报告已保存到: $report_file"
    echo "$report_file"
}

# 显示帮助信息
show_help() {
    echo "模型服务负载测试脚本"
    echo ""
    echo "使用方法:"
    echo "  $0 [选项] [测试场景] [提示类型]"
    echo ""
    echo "测试场景:"
    echo "  chat_completion    聊天补全测试"
    echo "  text_completion    文本补全测试"
    echo "  embeddings         嵌入向量测试"
    echo "  models_list        模型列表测试"
    echo "  token_count        Token计数测试"
    echo ""
    echo "提示类型:"
    echo "  simple             简单提示"
    echo "  complex            复杂提示"
    echo "  code               代码提示"
    echo "  creative           创意提示"
    echo "  technical          技术提示"
    echo ""
    echo "选项:"
    echo "  -h, --help              显示此帮助信息"
    echo "  -u, --url URL           模型服务地址 (默认: $MODEL_URL)"
    echo "  -m, --model NAME        模型名称 (默认: $MODEL_NAME)"
    echo "  -c, --concurrent NUM    并发请求数 (默认: $CONCURRENT_REQUESTS)"
    echo "  -d, --duration SEC      测试持续时间 (默认: $TEST_DURATION)"
    echo "  -r, --ramp-up SEC       阶梯加载时间 (默认: $RAMP_UP_TIME)"
    echo "  -o, --output DIR        输出目录 (默认: $OUTPUT_DIR)"
    echo "  -f, --report FILE       报告文件名"
    echo "  -v, --verbose           详细输出"
    echo "  --no-monitoring         禁用系统监控"
    echo "  --max-tokens NUM        最大token数 (默认: $MAX_TOKENS)"
    echo "  --temperature NUM       温度参数 (默认: $TEMPERATURE)"
    echo ""
    echo "示例:"
    echo "  $0 chat_completion simple              # 简单聊天测试"
    echo "  $0 -c 16 -d 300 chat_completion complex # 16并发复杂聊天测试"
    echo "  $0 --ramp-up 120 embeddings            # 阶梯加载嵌入测试"
    echo "  $0 -u http://model.example.com text_completion technical  # 指定服务地址"
}

# 主函数
main() {
    local test_scenario="chat_completion"
    local prompt_type="simple"
    
    # 解析命令行参数
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -u|--url)
                MODEL_URL="$2"
                shift 2
                ;;
            -m|--model)
                MODEL_NAME="$2"
                shift 2
                ;;
            -c|--concurrent)
                CONCURRENT_REQUESTS="$2"
                shift 2
                ;;
            -d|--duration)
                TEST_DURATION="$2"
                shift 2
                ;;
            -r|--ramp-up)
                RAMP_UP_TIME="$2"
                shift 2
                ;;
            -o|--output)
                OUTPUT_DIR="$2"
                mkdir -p "$OUTPUT_DIR"
                shift 2
                ;;
            -f|--report)
                REPORT_FILE="$2"
                shift 2
                ;;
            -v|--verbose)
                VERBOSE=true
                shift
                ;;
            --no-monitoring)
                ENABLE_MONITORING=false
                shift
                ;;
            --max-tokens)
                MAX_TOKENS="$2"
                shift 2
                ;;
            --temperature)
                TEMPERATURE="$2"
                shift 2
                ;;
            chat_completion|text_completion|embeddings|models_list|token_count)
                test_scenario="$1"
                shift
                ;;
            simple|complex|code|creative|technical)
                prompt_type="$1"
                shift
                ;;
            *)
                log_error "未知参数: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    log_info "开始模型服务负载测试"
    log_info "模型服务地址: $MODEL_URL"
    log_info "模型名称: $MODEL_NAME"
    log_info "测试场景: $test_scenario"
    log_info "提示类型: $prompt_type"
    log_info "并发请求: $CONCURRENT_REQUESTS"
    log_info "测试时长: ${TEST_DURATION}秒"
    echo ""
    
    # 检测模型服务类型
    detect_model_type
    
    # 检查模型服务可用性
    log_info "检查模型服务可用性..."
    if ! curl -sf --max-time 10 "$MODEL_URL/v1/models" > /dev/null 2>&1; then
        log_error "模型服务不可用: $MODEL_URL"
        exit 1
    fi
    log_success "模型服务可用"
    echo ""
    
    # 开始监控
    if [ "$ENABLE_MONITORING" = true ]; then
        monitor_model_service $TEST_DURATION $MONITOR_INTERVAL &
        local monitor_pid=$!
    fi
    
    # 执行负载测试
    case $test_scenario in
        chat_completion)
            concurrent_request_load $CONCURRENT_REQUESTS $TEST_DURATION "chat_completion" "$prompt_type"
            ;;
        text_completion)
            concurrent_request_load $CONCURRENT_REQUESTS $TEST_DURATION "text_completion" "$prompt_type"
            ;;
        embeddings)
            concurrent_request_load $CONCURRENT_REQUESTS $TEST_DURATION "embeddings" "$prompt_type"
            ;;
        models_list)
            concurrent_request_load $CONCURRENT_REQUESTS $TEST_DURATION "models_list" "$prompt_type"
            ;;
        token_count)
            concurrent_request_load $CONCURRENT_REQUESTS $TEST_DURATION "token_count" "$prompt_type"
            ;;
        ramp_up)
            ramp_up_load $CONCURRENT_REQUESTS 60 "chat_completion" "$prompt_type"
            ;;
        *)
            log_error "未知测试场景: $test_scenario"
            exit 1
            ;;
    esac
    
    # 等待监控完成
    if [ "$ENABLE_MONITORING" = true ]; then
        wait $monitor_pid
    fi
    
    echo ""
    calculate_statistics
    
    log_success "模型服务负载测试完成"
}

# 执行主函数
main "$@"