"""
多模态信息融合模块
负责融合文本、图形、几何等多模态信息，提高识别准确性
"""

import os
import sys
import logging
import numpy as np
import cv2
import math
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, asdict
from pathlib import Path
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
from scipy.spatial.distance import euclidean
from sklearn.cluster import DBSCAN
from sklearn.metrics.pairwise import cosine_similarity
import networkx as nx

# 导入配置
sys.path.append(str(Path(__file__).parent.parent))
from pdf_ocr_config import get_config

# 导入基础模块
from pdf_parser import BoundingBox, TextElement, VectorElement, ImageElement, PageData
from text_recognition import LayoutElement, DimensionAnnotation
from graphics_detection import GeometricElement, SymbolInstance

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class FusedElement:
    """融合元素数据类"""
    element_type: str  # fused_text, fused_dimension, fused_symbol, fused_layout
    bbox: BoundingBox
    confidence: float
    source_elements: List[str]  # 源元素ID列表
    properties: Dict[str, Any]
    fusion_method: str
    created_at: str
    
    def to_dict(self):
        return {
            'element_type': self.element_type,
            'bbox': self.bbox.to_dict(),
            'confidence': self.confidence,
            'source_elements': self.source_elements,
            'properties': self.properties,
            'fusion_method': self.fusion_method,
            'created_at': self.created_at
        }

@dataclass
class ContextualRelationship:
    """上下文关系数据类"""
    relationship_type: str  # proximity, alignment, containment, association
    source_element: str
    target_element: str
    strength: float
    properties: Dict[str, Any]
    
    def to_dict(self):
        return {
            'relationship_type': self.relationship_type,
            'source_element': self.source_element,
            'target_element': self.target_element,
            'strength': self.strength,
            'properties': self.properties
        }

class SpatialAnalyzer:
    """空间分析器"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        self.fusion_config = self.config["multimodal_fusion"]
    
    def analyze_spatial_relationships(self, elements: List[Any]) -> List[ContextualRelationship]:
        """
        分析空间关系
        
        Args:
            elements: 元素列表（文本、图形、尺寸等）
            
        Returns:
            List[ContextualRelationship]: 空间关系列表
        """
        try:
            relationships = []
            
            # 分析邻近关系
            proximity_relations = self._find_proximity_relations(elements)
            relationships.extend(proximity_relations)
            
            # 分析对齐关系
            alignment_relations = self._find_alignment_relations(elements)
            relationships.extend(alignment_relations)
            
            # 分析包含关系
            containment_relations = self._find_containment_relations(elements)
            relationships.extend(containment_relations)
            
            # 分析关联关系
            association_relations = self._find_association_relations(elements)
            relationships.extend(association_relations)
            
            logger.debug(f"空间关系分析完成，发现 {len(relationships)} 个关系")
            return relationships
            
        except Exception as e:
            logger.error(f"空间关系分析失败: {e}")
            return []
    
    def _find_proximity_relations(self, elements: List[Any]) -> List[ContextualRelationship]:
        """查找邻近关系"""
        relations = []
        proximity_radius = self.fusion_config["context_awareness"]["neighborhood_radius"]
        
        for i, elem1 in enumerate(elements):
            for j, elem2 in enumerate(elements):
                if i >= j:  # 避免重复
                    continue
                
                # 计算中心点距离
                center1 = self._get_element_center(elem1)
                center2 = self._get_element_center(elem2)
                
                if center1 and center2:
                    distance = euclidean(center1, center2)
                    
                    if distance <= proximity_radius:
                        # 计算关系强度（距离越近，强度越高）
                        strength = 1.0 - (distance / proximity_radius)
                        
                        relation = ContextualRelationship(
                            relationship_type="proximity",
                            source_element=str(i),
                            target_element=str(j),
                            strength=strength,
                            properties={
                                "distance": distance,
                                "center1": center1,
                                "center2": center2
                            }
                        )
                        relations.append(relation)
        
        return relations
    
    def _find_alignment_relations(self, elements: List[Any]) -> List[ContextualRelationship]:
        """查找对齐关系"""
        relations = []
        
        # 按元素类型分组
        text_elements = [elem for elem in elements if hasattr(elem, 'text')]
        graphic_elements = [elem for elem in elements if hasattr(elem, 'element_type')]
        
        # 文本水平对齐
        for i, text1 in enumerate(text_elements):
            for j, text2 in enumerate(text_elements):
                if i >= j:
                    continue
                
                # 检查水平对齐
                if self._are_horizontally_aligned(text1, text2):
                    relation = ContextualRelationship(
                        relationship_type="horizontal_alignment",
                        source_element=str(elements.index(text1)),
                        target_element=str(elements.index(text2)),
                        strength=0.8,
                        properties={"alignment_type": "horizontal"}
                    )
                    relations.append(relation)
                
                # 检查垂直对齐
                if self._are_vertically_aligned(text1, text2):
                    relation = ContextualRelationship(
                        relationship_type="vertical_alignment",
                        source_element=str(elements.index(text1)),
                        target_element=str(elements.index(text2)),
                        strength=0.8,
                        properties={"alignment_type": "vertical"}
                    )
                    relations.append(relation)
        
        return relations
    
    def _find_containment_relations(self, elements: List[Any]) -> List[ContextualRelationship]:
        """查找包含关系"""
        relations = []
        
        for i, elem1 in enumerate(elements):
            for j, elem2 in enumerate(elements):
                if i == j:
                    continue
                
                # 检查elem1是否包含elem2
                if self._is_contained(elem1, elem2):
                    relation = ContextualRelationship(
                        relationship_type="containment",
                        source_element=str(i),
                        target_element=str(j),
                        strength=0.9,
                        properties={
                            "container": str(i),
                            "contained": str(j)
                        }
                    )
                    relations.append(relation)
        
        return relations
    
    def _find_association_relations(self, elements: List[Any]) -> List[ContextualRelationship]:
        """查找关联关系"""
        relations = []
        
        # 文本与尺寸标注的关联
        text_elements = [elem for elem in elements if hasattr(elem, 'text')]
        dimension_elements = [elem for elem in elements if hasattr(elem, 'dimension_value')]
        
        for text_elem in text_elements:
            for dim_elem in dimension_elements:
                if self._are_associated(text_elem, dim_elem):
                    relation = ContextualRelationship(
                        relationship_type="text_dimension_association",
                        source_element=str(elements.index(text_elem)),
                        target_element=str(elements.index(dim_elem)),
                        strength=0.7,
                        properties={
                            "association_type": "text_dimension"
                        }
                    )
                    relations.append(relation)
        
        # 符号与尺寸标注的关联
        symbol_elements = [elem for elem in elements if hasattr(elem, 'symbol_type')]
        
        for symbol_elem in symbol_elements:
            for dim_elem in dimension_elements:
                if self._are_associated(symbol_elem, dim_elem):
                    relation = ContextualRelationship(
                        relationship_type="symbol_dimension_association",
                        source_element=str(elements.index(symbol_elem)),
                        target_element=str(elements.index(dim_elem)),
                        strength=0.7,
                        properties={
                            "association_type": "symbol_dimension"
                        }
                    )
                    relations.append(relation)
        
        return relations
    
    def _get_element_center(self, element: Any) -> Optional[Tuple[float, float]]:
        """获取元素中心点"""
        if hasattr(element, 'bbox'):
            bbox = element.bbox
            return (bbox.x + bbox.width / 2, bbox.y + bbox.height / 2)
        elif hasattr(element, 'points') and element.points:
            points = element.points
            if len(points) >= 2:
                # 使用前两个点的中点作为中心
                return ((points[0][0] + points[1][0]) / 2, (points[0][1] + points[1][1]) / 2)
        return None
    
    def _are_horizontally_aligned(self, elem1: Any, elem2: Any, tolerance: float = 10.0) -> bool:
        """检查两个元素是否水平对齐"""
        if not (hasattr(elem1, 'bbox') and hasattr(elem2, 'bbox')):
            return False
        
        y1 = elem1.bbox.y + elem1.bbox.height / 2
        y2 = elem2.bbox.y + elem2.bbox.height / 2
        
        return abs(y1 - y2) <= tolerance
    
    def _are_vertically_aligned(self, elem1: Any, elem2: Any, tolerance: float = 10.0) -> bool:
        """检查两个元素是否垂直对齐"""
        if not (hasattr(elem1, 'bbox') and hasattr(elem2, 'bbox')):
            return False
        
        x1 = elem1.bbox.x + elem1.bbox.width / 2
        x2 = elem2.bbox.x + elem2.bbox.width / 2
        
        return abs(x1 - x2) <= tolerance
    
    def _is_contained(self, container: Any, contained: Any) -> bool:
        """检查一个元素是否包含另一个元素"""
        if not (hasattr(container, 'bbox') and hasattr(contained, 'bbox')):
            return False
        
        cont_bbox = container.bbox
        contd_bbox = contained.bbox
        
        return (cont_bbox.x <= contd_bbox.x and
                cont_bbox.y <= contd_bbox.y and
                cont_bbox.x + cont_bbox.width >= contd_bbox.x + contd_bbox.width and
                cont_bbox.y + cont_bbox.height >= contd_bbox.y + contd_bbox.height)
    
    def _are_associated(self, elem1: Any, elem2: Any) -> bool:
        """检查两个元素是否关联"""
        # 基于距离和类型的关联判断
        center1 = self._get_element_center(elem1)
        center2 = self._get_element_center(elem2)
        
        if not center1 or not center2:
            return False
        
        distance = euclidean(center1, center2)
        max_distance = 100  # 最大关联距离
        
        return distance <= max_distance

class FeatureExtractor:
    """特征提取器"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
    
    def extract_features(self, element: Any) -> Dict[str, Any]:
        """
        提取元素特征
        
        Args:
            element: 元素对象
            
        Returns:
            Dict[str, Any]: 特征字典
        """
        try:
            features = {}
            
            # 基础几何特征
            if hasattr(element, 'bbox'):
                bbox = element.bbox
                features.update({
                    'bbox_x': bbox.x,
                    'bbox_y': bbox.y,
                    'bbox_width': bbox.width,
                    'bbox_height': bbox.height,
                    'bbox_area': bbox.area(),
                    'bbox_aspect_ratio': bbox.width / bbox.height if bbox.height > 0 else 0,
                    'bbox_center_x': bbox.x + bbox.width / 2,
                    'bbox_center_y': bbox.y + bbox.height / 2
                })
            
            # 文本特征
            if hasattr(element, 'text'):
                text = element.text
                features.update({
                    'text_content': text,
                    'text_length': len(text),
                    'text_has_numbers': bool(re.search(r'\d', text)),
                    'text_has_letters': bool(re.search(r'[a-zA-Z]', text)),
                    'text_has_special_chars': bool(re.search(r'[^\w\s]', text)),
                    'text_is_dimension': self._is_dimension_text(text),
                    'text_is_annotation': self._is_annotation_text(text)
                })
            
            # 图形特征
            if hasattr(element, 'element_type'):
                features['element_type'] = element.element_type
                
                if element.element_type == 'line':
                    features.update(self._extract_line_features(element))
                elif element.element_type == 'circle':
                    features.update(self._extract_circle_features(element))
                elif element.element_type == 'rectangle':
                    features.update(self._extract_rectangle_features(element))
            
            # 尺寸特征
            if hasattr(element, 'dimension_value'):
                features.update({
                    'dimension_value': element.dimension_value,
                    'dimension_type': element.dimension_type,
                    'dimension_unit': element.unit,
                    'dimension_has_tolerance': element.tolerance is not None
                })
            
            # 符号特征
            if hasattr(element, 'symbol_type'):
                features.update({
                    'symbol_type': element.symbol_type,
                    'symbol_confidence': element.confidence
                })
            
            # 布局特征
            if hasattr(element, 'element_type') and element.element_type in ['title', 'paragraph', 'table']:
                features.update({
                    'layout_type': element.element_type,
                    'hierarchy_level': getattr(element, 'hierarchy_level', 0),
                    'has_children': len(getattr(element, 'child_elements', [])) > 0
                })
            
            return features
            
        except Exception as e:
            logger.error(f"特征提取失败: {e}")
            return {}
    
    def _extract_line_features(self, element: GeometricElement) -> Dict[str, Any]:
        """提取线条特征"""
        properties = element.properties
        return {
            'line_length': properties.get('length', 0),
            'line_angle': properties.get('angle', 0),
            'line_direction': 'horizontal' if abs(properties.get('angle', 0)) < 45 else 'vertical'
        }
    
    def _extract_circle_features(self, element: GeometricElement) -> Dict[str, Any]:
        """提取圆形特征"""
        properties = element.properties
        return {
            'circle_radius': properties.get('radius', 0),
            'circle_area': properties.get('area', 0),
            'circle_center': properties.get('center', (0, 0))
        }
    
    def _extract_rectangle_features(self, element: GeometricElement) -> Dict[str, Any]:
        """提取矩形特征"""
        properties = element.properties
        return {
            'rectangle_width': properties.get('width', 0),
            'rectangle_height': properties.get('height', 0),
            'rectangle_area': properties.get('area', 0),
            'rectangle_aspect_ratio': properties.get('aspect_ratio', 0)
        }
    
    def _is_dimension_text(self, text: str) -> bool:
        """判断是否为尺寸文本"""
        dimension_patterns = [
            r'^\d+\.?\d*\s*(mm|cm|m|inch|ft|°|deg)$',
            r'^⌀\s*\d+\.?\d*$',
            r'^±\s*\d+\.?\d*$',
            r'^\d+\.?\d*\s*±\s*\d+\.?\d*$'
        ]
        
        for pattern in dimension_patterns:
            if re.search(pattern, text.strip(), re.IGNORECASE):
                return True
        
        return False
    
    def _is_annotation_text(self, text: str) -> bool:
        """判断是否为注释文本"""
        annotation_patterns = [
            r'^[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*$',  # 大写开头的单词
            r'^NOTE[:\s]',  # NOTE开头
            r'^REMARK[:\s]',  # REMARK开头
            r'^CAUTION[:\s]'  # CAUTION开头
        ]
        
        for pattern in annotation_patterns:
            if re.search(pattern, text.strip(), re.IGNORECASE):
                return True
        
        return False

class SimilarityCalculator:
    """相似度计算器"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
    
    def calculate_similarity(self, elem1: Any, elem2: Any) -> float:
        """
        计算两个元素的相似度
        
        Args:
            elem1: 元素1
            elem2: 元素2
            
        Returns:
            float: 相似度分数 (0-1)
        """
        try:
            # 获取特征
            feature_extractor = FeatureExtractor(self.config)
            features1 = feature_extractor.extract_features(elem1)
            features2 = feature_extractor.extract_features(elem2)
            
            if not features1 or not features2:
                return 0.0
            
            # 计算不同类型的相似度
            similarities = []
            
            # 几何相似度
            geometric_sim = self._calculate_geometric_similarity(features1, features2)
            similarities.append(geometric_sim)
            
            # 语义相似度
            semantic_sim = self._calculate_semantic_similarity(features1, features2)
            similarities.append(semantic_sim)
            
            # 类型相似度
            type_sim = self._calculate_type_similarity(elem1, elem2)
            similarities.append(type_sim)
            
            # 计算加权平均
            weights = [0.4, 0.4, 0.2]  # 几何、语义、类型权重
            weighted_sim = sum(w * s for w, s in zip(weights, similarities))
            
            return min(1.0, max(0.0, weighted_sim))
            
        except Exception as e:
            logger.error(f"相似度计算失败: {e}")
            return 0.0
    
    def _calculate_geometric_similarity(self, features1: Dict[str, Any], 
                                      features2: Dict[str, Any]) -> float:
        """计算几何相似度"""
        geometric_features = ['bbox_area', 'bbox_aspect_ratio', 'bbox_center_x', 'bbox_center_y']
        
        similarities = []
        for feature in geometric_features:
            if feature in features1 and feature in features2:
                val1 = features1[feature]
                val2 = features2[feature]
                
                if val1 == 0 and val2 == 0:
                    similarity = 1.0
                elif val1 == 0 or val2 == 0:
                    similarity = 0.0
                else:
                    # 归一化差异
                    diff = abs(val1 - val2) / max(abs(val1), abs(val2))
                    similarity = 1.0 - diff
                
                similarities.append(similarity)
        
        return sum(similarities) / len(similarities) if similarities else 0.0
    
    def _calculate_semantic_similarity(self, features1: Dict[str, Any], 
                                     features2: Dict[str, Any]) -> float:
        """计算语义相似度"""
        # 文本相似度
        if 'text_content' in features1 and 'text_content' in features2:
            text1 = features1['text_content'].lower()
            text2 = features2['text_content'].lower()
            
            # 简单的文本相似度计算
            if text1 == text2:
                text_sim = 1.0
            else:
                # 计算公共子串比例
                common_chars = sum(1 for c in text1 if c in text2)
                text_sim = common_chars / max(len(text1), len(text2))
        else:
            text_sim = 0.0
        
        # 尺寸相似度
        if 'dimension_value' in features1 and 'dimension_value' in features2:
            dim1 = features1['dimension_value']
            dim2 = features2['dimension_value']
            
            try:
                val1 = float(re.findall(r'\d+\.?\d*', dim1)[0]) if re.findall(r'\d+\.?\d*', dim1) else 0
                val2 = float(re.findall(r'\d+\.?\d*', dim2)[0]) if re.findall(r'\d+\.?\d*', dim2) else 0
                
                if val1 == 0 and val2 == 0:
                    dim_sim = 1.0
                elif val1 == 0 or val2 == 0:
                    dim_sim = 0.0
                else:
                    diff = abs(val1 - val2) / max(val1, val2)
                    dim_sim = 1.0 - diff
            except:
                dim_sim = 0.0
        else:
            dim_sim = 0.0
        
        return (text_sim + dim_sim) / 2
    
    def _calculate_type_similarity(self, elem1: Any, elem2: Any) -> float:
        """计算类型相似度"""
        # 检查元素类型
        type1 = self._get_element_type(elem1)
        type2 = self._get_element_type(elem2)
        
        if type1 == type2:
            return 1.0
        elif self._are_compatible_types(type1, type2):
            return 0.7
        else:
            return 0.0
    
    def _get_element_type(self, element: Any) -> str:
        """获取元素类型"""
        if hasattr(element, 'text'):
            return 'text'
        elif hasattr(element, 'dimension_value'):
            return 'dimension'
        elif hasattr(element, 'symbol_type'):
            return 'symbol'
        elif hasattr(element, 'element_type'):
            return f"graphic_{element.element_type}"
        elif hasattr(element, 'element_type') and element.element_type in ['title', 'paragraph', 'table']:
            return 'layout'
        else:
            return 'unknown'
    
    def _are_compatible_types(self, type1: str, type2: str) -> bool:
        """检查类型是否兼容"""
        compatible_pairs = [
            ('text', 'dimension'),
            ('text', 'layout'),
            ('dimension', 'symbol'),
            ('graphic_line', 'graphic_rectangle'),
            ('graphic_circle', 'graphic_circle')
        ]
        
        return (type1, type2) in compatible_pairs or (type2, type1) in compatible_pairs

class MultimodalFusionEngine:
    """多模态融合引擎"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        self.fusion_config = self.config["multimodal_fusion"]
        
        # 初始化组件
        self.spatial_analyzer = SpatialAnalyzer(self.config)
        self.feature_extractor = FeatureExtractor(self.config)
        self.similarity_calculator = SimilarityCalculator(self.config)
        
        logger.info("多模态融合引擎初始化完成")
    
    def fuse_multimodal_data(self, text_elements: List[TextElement],
                           graphic_elements: List[GeometricElement],
                           layout_elements: List[LayoutElement],
                           dimensions: List[DimensionAnnotation],
                           symbols: List[SymbolInstance]) -> Dict[str, Any]:
        """
        融合多模态数据
        
        Args:
            text_elements: 文本元素列表
            graphic_elements: 图形元素列表
            layout_elements: 布局元素列表
            dimensions: 尺寸标注列表
            symbols: 符号列表
            
        Returns:
            Dict: 融合结果
        """
        try:
            logger.info("开始多模态数据融合")
            
            # 1. 收集所有元素
            all_elements = []
            all_elements.extend(text_elements)
            all_elements.extend(graphic_elements)
            all_elements.extend(layout_elements)
            all_elements.extend(dimensions)
            all_elements.extend(symbols)
            
            # 2. 空间关系分析
            spatial_relations = self.spatial_analyzer.analyze_spatial_relationships(all_elements)
            
            # 3. 特征提取
            element_features = {}
            for i, element in enumerate(all_elements):
                features = self.feature_extractor.extract_features(element)
                element_features[str(i)] = features
            
            # 4. 相似度计算
            similarity_matrix = self._calculate_similarity_matrix(all_elements)
            
            # 5. 聚类融合
            fused_elements = self._cluster_and_fuse_elements(all_elements, similarity_matrix)
            
            # 6. 上下文感知融合
            contextual_fused_elements = self._apply_contextual_fusion(
                fused_elements, spatial_relations
            )
            
            # 7. 决策融合
            final_fused_elements = self._decision_fusion(contextual_fused_elements)
            
            # 8. 组合结果
            result = {
                "fused_elements": [elem.to_dict() for elem in final_fused_elements],
                "spatial_relations": [rel.to_dict() for rel in spatial_relations],
                "element_features": element_features,
                "similarity_matrix": similarity_matrix.tolist() if hasattr(similarity_matrix, 'tolist') else similarity_matrix,
                "fusion_statistics": {
                    "total_elements": len(all_elements),
                    "fused_elements": len(final_fused_elements),
                    "spatial_relations": len(spatial_relations),
                    "fusion_ratio": len(final_fused_elements) / len(all_elements) if all_elements else 0
                }
            }
            
            logger.info(f"多模态融合完成：{len(all_elements)} -> {len(final_fused_elements)} 个元素")
            
            return result
            
        except Exception as e:
            logger.error(f"多模态融合失败: {e}")
            return {
                "fused_elements": [],
                "spatial_relations": [],
                "element_features": {},
                "error": str(e)
            }
    
    def _calculate_similarity_matrix(self, elements: List[Any]) -> np.ndarray:
        """计算相似度矩阵"""
        n = len(elements)
        similarity_matrix = np.zeros((n, n))
        
        for i in range(n):
            for j in range(n):
                if i == j:
                    similarity_matrix[i][j] = 1.0
                else:
                    similarity = self.similarity_calculator.calculate_similarity(elements[i], elements[j])
                    similarity_matrix[i][j] = similarity
        
        return similarity_matrix
    
    def _cluster_and_fuse_elements(self, elements: List[Any], 
                                  similarity_matrix: np.ndarray) -> List[FusedElement]:
        """聚类融合元素"""
        try:
            # 使用DBSCAN进行聚类
            # 将相似度转换为距离
            distance_matrix = 1.0 - similarity_matrix
            
            # DBSCAN聚类
            clustering = DBSCAN(eps=0.5, min_samples=2, metric='precomputed')
            cluster_labels = clustering.fit_predict(distance_matrix)
            
            # 融合每个聚类
            fused_elements = []
            clusters = {}
            
            # 按聚类标签分组
            for i, label in enumerate(cluster_labels):
                if label not in clusters:
                    clusters[label] = []
                clusters[label].append(i)
            
            # 为每个聚类创建融合元素
            for cluster_id, indices in clusters.items():
                if cluster_id == -1:  # 噪声点
                    continue
                
                # 选择聚类中心元素
                center_index = self._find_cluster_center(indices, similarity_matrix)
                center_element = elements[center_index]
                
                # 计算融合边界框
                fused_bbox = self._fuse_bboxes([elements[i].bbox for i in indices])
                
                # 计算融合置信度
                fused_confidence = self._fuse_confidence([elements[i].confidence for i in indices])
                
                # 创建融合元素
                fused_element = FusedElement(
                    element_type="fused_element",
                    bbox=fused_bbox,
                    confidence=fused_confidence,
                    source_elements=[str(i) for i in indices],
                    properties={
                        "cluster_id": cluster_id,
                        "center_element_index": center_index,
                        "cluster_size": len(indices)
                    },
                    fusion_method="clustering",
                    created_at=time.strftime("%Y-%m-%d %H:%M:%S")
                )
                
                fused_elements.append(fused_element)
            
            # 处理噪声点（单独的元素）
            for i, label in enumerate(cluster_labels):
                if label == -1:  # 噪声点
                    element = elements[i]
                    fused_element = FusedElement(
                        element_type="fused_element",
                        bbox=element.bbox,
                        confidence=element.confidence,
                        source_elements=[str(i)],
                        properties={"noise_point": True},
                        fusion_method="noise",
                        created_at=time.strftime("%Y-%m-%d %H:%M:%S")
                    )
                    fused_elements.append(fused_element)
            
            return fused_elements
            
        except Exception as e:
            logger.error(f"聚类融合失败: {e}")
            # 如果聚类失败，返回原始元素
            return [
                FusedElement(
                    element_type="fused_element",
                    bbox=element.bbox,
                    confidence=element.confidence,
                    source_elements=[str(i)],
                    properties={},
                    fusion_method="no_fusion",
                    created_at=time.strftime("%Y-%m-%d %H:%M:%S")
                )
                for i, element in enumerate(elements)
            ]
    
    def _find_cluster_center(self, indices: List[int], similarity_matrix: np.ndarray) -> int:
        """找到聚类中心元素"""
        if len(indices) == 1:
            return indices[0]
        
        # 计算每个元素与其他元素的平均相似度
        avg_similarities = []
        for i in indices:
            sim_sum = sum(similarity_matrix[i][j] for j in indices if i != j)
            avg_sim = sim_sum / (len(indices) - 1) if len(indices) > 1 else 0
            avg_similarities.append((i, avg_sim))
        
        # 选择平均相似度最高的元素作为中心
        center_index, _ = max(avg_similarities, key=lambda x: x[1])
        return center_index
    
    def _fuse_bboxes(self, bboxes: List[BoundingBox]) -> BoundingBox:
        """融合边界框"""
        if not bboxes:
            return BoundingBox(0, 0, 0, 0)
        
        x = min(bbox.x for bbox in bboxes)
        y = min(bbox.y for bbox in bboxes)
        width = max(bbox.x + bbox.width for bbox in bboxes) - x
        height = max(bbox.y + bbox.height for bbox in bboxes) - y
        
        return BoundingBox(x, y, width, height)
    
    def _fuse_confidence(self, confidences: List[float]) -> float:
        """融合置信度"""
        if not confidences:
            return 0.0
        
        # 使用加权平均，权重基于置信度本身
        weights = [conf for conf in confidences]
        total_weight = sum(weights)
        
        if total_weight == 0:
            return sum(confidences) / len(confidences)
        
        weighted_sum = sum(conf * weight for conf, weight in zip(confidences, weights))
        return weighted_sum / total_weight
    
    def _apply_contextual_fusion(self, fused_elements: List[FusedElement], 
                               spatial_relations: List[ContextualRelationship]) -> List[FusedElement]:
        """应用上下文感知融合"""
        try:
            # 构建元素关系图
            G = nx.Graph()
            
            # 添加节点
            for i, element in enumerate(fused_elements):
                G.add_node(i, element=element)
            
            # 添加边（基于空间关系）
            for relation in spatial_relations:
                source_idx = int(relation.source_element)
                target_idx = int(relation.target_element)
                
                if source_idx < len(fused_elements) and target_idx < len(fused_elements):
                    G.add_edge(source_idx, target_idx, weight=relation.strength)
            
            # 查找连通分量进行进一步融合
            connected_components = list(nx.connected_components(G))
            
            contextual_fused = []
            
            for component in connected_components:
                if len(component) > 1:
                    # 融合连通分量中的元素
                    component_elements = [fused_elements[i] for i in component]
                    fused_element = self._fuse_connected_component(component_elements)
                    contextual_fused.append(fused_element)
                else:
                    # 单个元素直接保留
                    idx = list(component)[0]
                    contextual_fused.append(fused_elements[idx])
            
            return contextual_fused
            
        except Exception as e:
            logger.warning(f"上下文感知融合失败: {e}")
            return fused_elements
    
    def _fuse_connected_component(self, elements: List[FusedElement]) -> FusedElement:
        """融合连通分量"""
        # 融合边界框
        fused_bbox = self._fuse_bboxes([elem.bbox for elem in elements])
        
        # 融合置信度
        fused_confidence = self._fuse_confidence([elem.confidence for elem in elements])
        
        # 合并源元素
        all_source_elements = []
        for elem in elements:
            all_source_elements.extend(elem.source_elements)
        
        # 合并属性
        merged_properties = {}
        for elem in elements:
            for key, value in elem.properties.items():
                if key not in merged_properties:
                    merged_properties[key] = []
                merged_properties[key].append(value)
        
        return FusedElement(
            element_type="contextual_fused",
            bbox=fused_bbox,
            confidence=fused_confidence,
            source_elements=all_source_elements,
            properties=merged_properties,
            fusion_method="contextual",
            created_at=time.strftime("%Y-%m-%d %H:%M:%S")
        )
    
    def _decision_fusion(self, fused_elements: List[FusedElement]) -> List[FusedElement]:
        """决策融合"""
        try:
            fusion_method = self.fusion_config["decision_fusion"]["voting_strategy"]
            
            if fusion_method == "majority":
                return self._majority_voting_fusion(fused_elements)
            elif fusion_method == "weighted":
                return self._weighted_voting_fusion(fused_elements)
            elif fusion_method == "consensus":
                return self._consensus_fusion(fused_elements)
            else:
                logger.warning(f"未知的决策融合方法: {fusion_method}")
                return fused_elements
                
        except Exception as e:
            logger.error(f"决策融合失败: {e}")
            return fused_elements
    
    def _majority_voting_fusion(self, elements: List[FusedElement]) -> List[FusedElement]:
        """多数投票融合"""
        # 这里可以实现多数投票逻辑
        # 由于我们的元素已经是融合后的，这里直接返回
        return elements
    
    def _weighted_voting_fusion(self, elements: List[FusedElement]) -> List[FusedElement]:
        """加权投票融合"""
        # 这里可以实现加权投票逻辑
        # 由于我们的元素已经是融合后的，这里直接返回
        return elements
    
    def _consensus_fusion(self, elements: List[FusedElement]) -> List[FusedElement]:
        """共识融合"""
        # 这里可以实现共识融合逻辑
        # 由于我们的元素已经是融合后的，这里直接返回
        return elements

# 辅助函数
def calculate_fusion_quality_score(fused_elements: List[FusedElement], 
                                 original_elements: List[Any]) -> float:
    """计算融合质量分数"""
    if not original_elements:
        return 0.0
    
    # 计算融合率
    fusion_ratio = len(fused_elements) / len(original_elements)
    
    # 计算平均置信度
    avg_confidence = sum(elem.confidence for elem in fused_elements) / len(fused_elements) if fused_elements else 0
    
    # 计算质量分数
    quality_score = (fusion_ratio * 0.3 + avg_confidence * 0.7)
    
    return min(1.0, max(0.0, quality_score))

def validate_fusion_result(fusion_result: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """验证融合结果"""
    errors = []
    
    # 检查必要字段
    if "fused_elements" not in fusion_result:
        errors.append("缺少融合元素")
    
    if "spatial_relations" not in fusion_result:
        errors.append("缺少空间关系")
    
    # 检查融合元素
    if "fused_elements" in fusion_result:
        for element in fusion_result["fused_elements"]:
            if "bbox" not in element:
                errors.append("融合元素缺少边界框")
            if "confidence" not in element:
                errors.append("融合元素缺少置信度")
            if "source_elements" not in element:
                errors.append("融合元素缺少源元素信息")
    
    return len(errors) == 0, errors

# 使用示例
if __name__ == "__main__":
    # 创建多模态融合引擎
    config = get_config()
    fusion_engine = MultimodalFusionEngine(config)
    
    # 创建测试数据
    test_text_elements = [
        TextElement(
            text="100",
            bbox=BoundingBox(100, 100, 50, 20),
            confidence=0.9,
            font_size=12,
            font_name="Arial"
        )
    ]
    
    test_graphic_elements = [
        GeometricElement(
            element_type="line",
            points=[(100, 110), (150, 110)],
            bbox=BoundingBox(100, 105, 50, 10),
            confidence=0.8,
            properties={"length": 50, "angle": 0}
        )
    ]
    
    test_dimensions = [
        DimensionAnnotation(
            dimension_value="100",
            dimension_type="length",
            unit="mm",
            bbox=BoundingBox(120, 95, 30, 15),
            confidence=0.85
        )
    ]
    
    # 执行融合
    result = fusion_engine.fuse_multimodal_data(
        test_text_elements,
        test_graphic_elements,
        [],  # layout_elements
        test_dimensions,
        []   # symbols
    )
    
    print("多模态融合结果:")
    print(f"融合元素数量: {len(result['fused_elements'])}")
    print(f"空间关系数量: {len(result['spatial_relations'])}")
    print(f"融合统计: {result['fusion_statistics']}")
    
    # 验证结果
    is_valid, errors = validate_fusion_result(result)
    print(f"融合结果验证: {'通过' if is_valid else '失败'}")
    if errors:
        print(f"错误: {errors}")
    
    # 计算质量分数
    quality_score = calculate_fusion_quality_score(
        [FusedElement(**elem) for elem in result['fused_elements']],
        test_text_elements + test_graphic_elements + test_dimensions
    )
    print(f"融合质量分数: {quality_score:.3f}")
    
    # 保存结果
    with open("multimodal_fusion_result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    print("结果已保存到 multimodal_fusion_result.json")
