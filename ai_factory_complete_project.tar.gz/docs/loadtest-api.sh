#!/bin/bash

# loadtest-api.sh - API服务负载测试脚本
# 用于对AI工厂系统的API服务进行负载和压力测试

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 默认配置
API_URL="http://localhost:8000"
CONCURRENT_USERS=10
TEST_DURATION=60
RAMP_UP_TIME=30
OUTPUT_DIR="./loadtest_results"
REPORT_FILE=""
VERBOSE=false
ENABLE_MONITORING=true
MONITOR_INTERVAL=5

# 测试场景配置
declare -A TEST_SCENARIOS=(
    ["health_check"]="GET /health"
    ["api_basic"]="GET /api/v1/status"
    ["api_complex"]="POST /api/v1/process"
    ["api_upload"]="POST /api/v1/upload"
    ["api_query"]="GET /api/v1/query"
)

# 性能指标存储
declare -A METRICS=(
    ["total_requests"]=0
    ["successful_requests"]=0
    ["failed_requests"]=0
    ["total_response_time"]=0
    ["min_response_time"]=999999
    ["max_response_time"]=0
)

# 创建输出目录
mkdir -p "$OUTPUT_DIR"

# 清理函数
cleanup() {
    log_info "清理测试环境..."
    # 终止所有后台进程
    jobs -p | xargs -r kill 2>/dev/null || true
    wait
}

trap cleanup EXIT

# 生成测试数据
generate_test_data() {
    local size=$1
    local data_file="$OUTPUT_DIR/test_data.json"
    
    cat > "$data_file" << EOF
{
  "test_id": "$(date +%s)",
  "timestamp": "$(date -Iseconds)",
  "data": "$(head -c $size /dev/urandom | base64)",
  "metadata": {
    "source": "loadtest",
    "version": "1.0"
  }
}
EOF
    
    echo "$data_file"
}

# HTTP请求函数
make_request() {
    local method=$1
    local endpoint=$2
    local data_file=$3
    local start_time=$(date +%s%3N)
    
    local curl_opts="--max-time 30 --connect-timeout 10 --retry 3 --retry-delay 1"
    
    if [ "$VERBOSE" = true ]; then
        curl_opts="$curl_opts -v"
    fi
    
    local response
    local http_code
    
    if [ -n "$data_file" ]; then
        response=$(curl -w "%{http_code}" -X "$method" \
            -H "Content-Type: application/json" \
            -H "X-LoadTest: true" \
            -d @"$data_file" \
            $curl_opts "$API_URL$endpoint" 2>/dev/null)
    else
        response=$(curl -w "%{http_code}" -X "$method" \
            -H "X-LoadTest: true" \
            $curl_opts "$API_URL$endpoint" 2>/dev/null)
    fi
    
    local end_time=$(date +%s%3N)
    local response_time=$((end_time - start_time))
    
    http_code="${response: -3}"
    response="${response%???}"
    
    # 更新指标
    METRICS["total_requests"]=$((METRICS["total_requests"] + 1))
    METRICS["total_response_time"]=$((METRICS["total_response_time"] + response_time))
    
    if [ "$response_time" -lt "${METRICS["min_response_time"]}" ]; then
        METRICS["min_response_time"]=$response_time
    fi
    
    if [ "$response_time" -gt "${METRICS["max_response_time"]}" ]; then
        METRICS["max_response_time"]=$response_time
    fi
    
    if [[ "$http_code" =~ ^[23] ]]; then
        METRICS["successful_requests"]=$((METRICS["successful_requests"] + 1))
        if [ "$VERBOSE" = true ]; then
            log_success "请求成功: $method $endpoint (${response_time}ms, $http_code)"
        fi
    else
        METRICS["failed_requests"]=$((METRICS["failed_requests"] + 1))
        log_warning "请求失败: $method $endpoint (${response_time}ms, $http_code)"
        if [ "$VERBOSE" = true ]; then
            echo "Response: $response"
        fi
    fi
    
    echo "$response_time|$http_code"
}

# 单用户负载测试
single_user_load() {
    local scenario=$1
    local duration=$2
    local endpoint_info=${TEST_SCENARIOS[$scenario]}
    
    log_info "开始单用户负载测试: $scenario (${duration}s)"
    
    local method=$(echo "$endpoint_info" | awk '{print $1}')
    local endpoint=$(echo "$endpoint_info" | awk '{print $2}')
    
    local data_file=""
    if [[ "$method" == "POST" ]]; then
        data_file=$(generate_test_data 1024)
    fi
    
    local start_time=$(date +%s)
    local end_time=$((start_time + duration))
    local request_count=0
    
    while [ $(date +%s) -lt $end_time ]; do
        make_request "$method" "$endpoint" "$data_file"
        request_count=$((request_count + 1))
        
        # 随机延迟 0.1-1秒
        sleep $(echo "scale=3; $RANDOM / 32767" | bc)
    done
    
    log_info "单用户测试完成: $request_count 次请求"
}

# 并发用户负载测试
concurrent_user_load() {
    local num_users=$1
    local duration=$2
    local scenario=$3
    
    log_info "开始并发用户负载测试: $num_users 用户, $scenario (${duration}s)"
    
    local pids=()
    local endpoint_info=${TEST_SCENARIOS[$scenario]}
    local method=$(echo "$endpoint_info" | awk '{print $1}')
    local endpoint=$(echo "$endpoint_info" | awk '{print $2}')
    
    # 启动并发用户
    for ((i=1; i<=num_users; i++)); do
        {
            local data_file=""
            if [[ "$method" == "POST" ]]; then
                data_file=$(generate_test_data 1024)
            fi
            
            local start_time=$(date +%s)
            local end_time=$((start_time + duration))
            local request_count=0
            
            while [ $(date +%s) -lt $end_time ]; do
                make_request "$method" "$endpoint" "$data_file"
                request_count=$((request_count + 1))
                sleep $(echo "scale=3; $RANDOM / 32767" | bc)
            done
            
            log_info "用户 $i 完成: $request_count 次请求"
        } &
        pids+=($!)
    done
    
    # 等待所有用户完成
    for pid in "${pids[@]}"; do
        wait "$pid"
    done
    
    log_info "并发用户测试完成"
}

# 阶梯负载测试
ramp_up_load() {
    local max_users=$1
    local step_duration=$2
    local scenario=$3
    
    log_info "开始阶梯负载测试: 最大 $max_users 用户, $scenario"
    
    local current_users=1
    local step_size=$((max_users / 10))
    [ $step_size -lt 1 ] && step_size=1
    
    while [ $current_users -le $max_users ]; do
        log_info "阶梯测试: $current_users 用户 (${step_duration}s)"
        concurrent_user_load "$current_users" "$step_duration" "$scenario"
        
        current_users=$((current_users + step_size))
        [ $current_users -gt $max_users ] && current_users=$max_users
    done
}

# 系统监控
monitor_system() {
    local duration=$1
    local interval=${2:-$MONITOR_INTERVAL}
    
    log_info "开始系统监控 (${duration}s, ${interval}s间隔)"
    
    local monitor_file="$OUTPUT_DIR/system_monitor_$(date +%Y%m%d_%H%M%S).csv"
    
    echo "timestamp,cpu_usage,memory_usage,disk_usage,load_avg,active_connections" > "$monitor_file"
    
    local start_time=$(date +%s)
    local end_time=$((start_time + duration))
    
    while [ $(date +%s) -lt $end_time ]; do
        local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
        local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')
        local mem_info=$(free | grep Mem)
        local total_mem=$(echo $mem_info | awk '{print $2}')
        local used_mem=$(echo $mem_info | awk '{print $3}')
        local mem_usage=$(echo "scale=2; $used_mem * 100 / $total_mem" | bc)
        local disk_usage=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
        local load_avg=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
        local active_connections=$(netstat -an | grep :8000 | grep ESTABLISHED | wc -l)
        
        echo "$timestamp,$cpu_usage,$mem_usage,$disk_usage,$load_avg,$active_connections" >> "$monitor_file"
        
        sleep $interval
    done
    
    log_info "系统监控完成: $monitor_file"
}

# 计算性能统计
calculate_statistics() {
    local total_requests=${METRICS["total_requests"]}
    local successful_requests=${METRICS["successful_requests"]}
    local failed_requests=${METRICS["failed_requests"]}
    local total_response_time=${METRICS["total_response_time"]}
    local min_response_time=${METRICS["min_response_time"]}
    local max_response_time=${METRICS["max_response_time"]}
    
    if [ $total_requests -eq 0 ]; then
        log_error "没有请求数据"
        return 1
    fi
    
    local avg_response_time=$(echo "scale=2; $total_response_time / $total_requests" | bc)
    local success_rate=$(echo "scale=2; $successful_requests * 100 / $total_requests" | bc)
    local error_rate=$(echo "scale=2; $failed_requests * 100 / $total_requests" | bc)
    local throughput=$(echo "scale=2; $total_requests / $TEST_DURATION" | bc)
    
    echo "=== 负载测试结果统计 ==="
    echo "总请求数: $total_requests"
    echo "成功请求: $successful_requests"
    echo "失败请求: $failed_requests"
    echo "成功率: ${success_rate}%"
    echo "错误率: ${error_rate}%"
    echo "平均响应时间: ${avg_response_time}ms"
    echo "最小响应时间: ${min_response_time}ms"
    echo "最大响应时间: ${max_response_time}ms"
    echo "吞吐量: ${throughput} 请求/秒"
    echo "测试时长: ${TEST_DURATION}秒"
    echo "并发用户数: $CONCURRENT_USERS"
    
    # 生成详细报告
    local report_file="${REPORT_FILE:-loadtest_report_$(date +%Y%m%d_%H%M%S).json}"
    
    cat > "$report_file" << EOF
{
  "test_info": {
    "timestamp": "$(date -Iseconds)",
    "api_url": "$API_URL",
    "concurrent_users": $CONCURRENT_USERS,
    "test_duration": $TEST_DURATION,
    "ramp_up_time": $RAMP_UP_TIME
  },
  "results": {
    "total_requests": $total_requests,
    "successful_requests": $successful_requests,
    "failed_requests": $failed_requests,
    "success_rate": $success_rate,
    "error_rate": $error_rate,
    "avg_response_time": $avg_response_time,
    "min_response_time": $min_response_time,
    "max_response_time": $max_response_time,
    "throughput": $throughput
  },
  "metrics": {
    "cpu_usage": "$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')%",
    "memory_usage": "$(free | grep Mem | awk '{printf "%.2f", $3*100/$2}')%",
    "disk_usage": "$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')%"
  }
}
EOF
    
    log_success "详细报告已保存到: $report_file"
    echo "$report_file"
}

# 显示帮助信息
show_help() {
    echo "API服务负载测试脚本"
    echo ""
    echo "使用方法:"
    echo "  $0 [选项] [测试场景]"
    echo ""
    echo "测试场景:"
    echo "  health_check    健康检查接口测试"
    echo "  api_basic       基本API接口测试"
    echo "  api_complex     复杂API接口测试"
    echo "  api_upload      文件上传接口测试"
    echo "  api_query       查询接口测试"
    echo ""
    echo "选项:"
    echo "  -h, --help              显示此帮助信息"
    echo "  -u, --url URL           API服务地址 (默认: $API_URL)"
    echo "  -c, --concurrent NUM    并发用户数 (默认: $CONCURRENT_USERS)"
    echo "  -d, --duration SEC      测试持续时间 (默认: $TEST_DURATION)"
    echo "  -r, --ramp-up SEC       阶梯加载时间 (默认: $RAMP_UP_TIME)"
    echo "  -o, --output DIR        输出目录 (默认: $OUTPUT_DIR)"
    echo "  -f, --report FILE       报告文件名"
    echo "  -v, --verbose           详细输出"
    echo "  --no-monitoring         禁用系统监控"
    echo "  --step-duration SEC     阶梯测试步长 (默认: 60)"
    echo ""
    echo "示例:"
    echo "  $0 api_basic                    # 基本API测试"
    echo "  $0 -c 50 -d 300 api_complex     # 50并发300秒复杂API测试"
    echo "  $0 --ramp-up 120 api_upload     # 阶梯加载上传测试"
    echo "  $0 -u http://api.example.com health_check  # 指定API地址"
}

# 主函数
main() {
    local test_scenario="api_basic"
    
    # 解析命令行参数
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -u|--url)
                API_URL="$2"
                shift 2
                ;;
            -c|--concurrent)
                CONCURRENT_USERS="$2"
                shift 2
                ;;
            -d|--duration)
                TEST_DURATION="$2"
                shift 2
                ;;
            -r|--ramp-up)
                RAMP_UP_TIME="$2"
                shift 2
                ;;
            -o|--output)
                OUTPUT_DIR="$2"
                mkdir -p "$OUTPUT_DIR"
                shift 2
                ;;
            -f|--report)
                REPORT_FILE="$2"
                shift 2
                ;;
            -v|--verbose)
                VERBOSE=true
                shift
                ;;
            --no-monitoring)
                ENABLE_MONITORING=false
                shift
                ;;
            --step-duration)
                local step_duration="$2"
                shift 2
                ;;
            health_check|api_basic|api_complex|api_upload|api_query)
                test_scenario="$1"
                shift
                ;;
            *)
                log_error "未知参数: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    log_info "开始API负载测试"
    log_info "API地址: $API_URL"
    log_info "测试场景: $test_scenario"
    log_info "并发用户: $CONCURRENT_USERS"
    log_info "测试时长: ${TEST_DURATION}秒"
    echo ""
    
    # 检查API服务可用性
    log_info "检查API服务可用性..."
    if ! curl -sf --max-time 10 "$API_URL/health" > /dev/null 2>&1; then
        log_error "API服务不可用: $API_URL"
        exit 1
    fi
    log_success "API服务可用"
    echo ""
    
    # 开始监控
    if [ "$ENABLE_MONITORING" = true ]; then
        monitor_system $TEST_DURATION $MONITOR_INTERVAL &
        local monitor_pid=$!
    fi
    
    # 执行负载测试
    case $test_scenario in
        health_check)
            concurrent_user_load $CONCURRENT_USERS $TEST_DURATION "health_check"
            ;;
        api_basic)
            concurrent_user_load $CONCURRENT_USERS $TEST_DURATION "api_basic"
            ;;
        api_complex)
            concurrent_user_load $CONCURRENT_USERS $TEST_DURATION "api_complex"
            ;;
        api_upload)
            concurrent_user_load $CONCURRENT_USERS $TEST_DURATION "api_upload"
            ;;
        api_query)
            concurrent_user_load $CONCURRENT_USERS $TEST_DURATION "api_query"
            ;;
        ramp_up)
            if [ -n "$step_duration" ]; then
                ramp_up_load $CONCURRENT_USERS $step_duration "api_basic"
            else
                ramp_up_load $CONCURRENT_USERS 60 "api_basic"
            fi
            ;;
        *)
            log_error "未知测试场景: $test_scenario"
            exit 1
            ;;
    esac
    
    # 等待监控完成
    if [ "$ENABLE_MONITORING" = true ]; then
        wait $monitor_pid
    fi
    
    echo ""
    calculate_statistics
    
    log_success "API负载测试完成"
}

# 执行主函数
main "$@"