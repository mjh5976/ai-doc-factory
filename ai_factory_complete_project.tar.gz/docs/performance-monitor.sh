#!/bin/bash

# performance-monitor.sh - 性能监控脚本
# 用于实时监控AI工厂系统的性能指标

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 默认配置
MONITOR_INTERVAL=10
DURATION=0  # 0表示无限监控
OUTPUT_DIR="./performance_monitoring"
ALERT_THRESHOLDS_FILE=""
VERBOSE=false
REAL_TIME_DISPLAY=true
SAVE_DATA=true
GRAPHICS_GENERATION=true

# 监控数据存储
MONITOR_DATA_FILE=""
ALERTS_FILE=""

# 创建输出目录
mkdir -p "$OUTPUT_DIR"

# 清理函数
cleanup() {
    log_info "停止性能监控..."
    # 终止所有后台进程
    jobs -p | xargs -r kill 2>/dev/null || true
    wait
}

trap cleanup EXIT

# 初始化监控
initialize_monitoring() {
    local timestamp=$(date +%Y%m%d_%H%M%S)
    MONITOR_DATA_FILE="$OUTPUT_DIR/performance_data_$timestamp.csv"
    ALERTS_FILE="$OUTPUT_DIR/alerts_$timestamp.json"
    
    # 创建CSV头部
    cat > "$MONITOR_DATA_FILE" << EOF
timestamp,cpu_usage,memory_usage,disk_usage,load_avg,api_response_time,api_status,db_connections,cache_hit_rate,gpu_utilization,gpu_memory,network_io,disk_io,active_connections
EOF
    
    # 创建告警JSON头部
    cat > "$ALERTS_FILE" << EOF
{
  "monitoring_session": {
    "start_time": "$(date -Iseconds)",
    "duration": $DURATION,
    "interval": $MONITOR_INTERVAL
  },
  "alerts": []
}
EOF
    
    log_info "监控初始化完成"
    log_info "数据文件: $MONITOR_DATA_FILE"
    log_info "告警文件: $ALERTS_FILE"
}

# 获取系统指标
get_system_metrics() {
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    # CPU使用率
    local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')
    
    # 内存使用率
    local mem_info=$(free | grep Mem)
    local total_mem=$(echo $mem_info | awk '{print $2}')
    local used_mem=$(echo $mem_info | awk '{print $3}')
    local memory_usage=$(echo "scale=2; $used_mem * 100 / $total_mem" | bc)
    
    # 磁盘使用率
    local disk_usage=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
    
    # 负载平均值
    local load_avg=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
    
    # 网络IO
    local network_io=$(cat /proc/net/dev | grep eth0 | awk '{print $3 + $11}' | head -1)
    
    # 磁盘IO
    local disk_io=$(iostat -d 1 1 2>/dev/null | tail -n +4 | awk '{print $4}' | head -1)
    
    echo "$timestamp,$cpu_usage,$memory_usage,$disk_usage,$load_avg,$network_io,$disk_io"
}

# 获取API性能指标
get_api_metrics() {
    local response_time="N/A"
    local api_status="unknown"
    
    # 检查API健康状态
    if curl -sf --max-time 5 http://localhost:8000/health > /dev/null 2>&1; then
        api_status="healthy"
        
        # 测试响应时间
        local req_start=$(date +%s%3N)
        if curl -sf --max-time 10 http://localhost:8000/api/v1/status > /dev/null 2>&1; then
            local req_end=$(date +%s%3N)
            response_time=$((req_end - req_start))
        fi
    else
        api_status="unhealthy"
    fi
    
    # 活跃连接数
    local active_connections=$(netstat -an | grep :8000 | grep ESTABLISHED | wc -l)
    
    echo "$response_time,$api_status,$active_connections"
}

# 获取数据库指标
get_database_metrics() {
    local db_connections="N/A"
    
    # PostgreSQL连接数
    if command -v psql >/dev/null 2>&1; then
        db_connections=$(psql -h localhost -U postgres -d postgres -t -c "SELECT count(*) FROM pg_stat_activity;" 2>/dev/null | tr -d ' ')
    fi
    
    echo "$db_connections"
}

# 获取缓存指标
get_cache_metrics() {
    local cache_hit_rate="N/A"
    
    # Redis缓存命中率
    if command -v redis-cli >/dev/null 2>&1; then
        local info_output=$(redis-cli info stats 2>/dev/null)
        if [ -n "$info_output" ]; then
            local keyspace_hits=$(echo "$info_output" | grep "keyspace_hits" | cut -d: -f2)
            local keyspace_misses=$(echo "$info_output" | grep "keyspace_misses" | cut -d: -f2)
            
            if [ -n "$keyspace_hits" ] && [ -n "$keyspace_misses" ]; then
                local total_requests=$((keyspace_hits + keyspace_misses))
                if [ $total_requests -gt 0 ]; then
                    cache_hit_rate=$(echo "scale=2; $keyspace_hits * 100 / $total_requests" | bc)
                fi
            fi
        fi
    fi
    
    echo "$cache_hit_rate"
}

# 获取GPU指标
get_gpu_metrics() {
    local gpu_utilization="N/A"
    local gpu_memory="N/A"
    
    # GPU监控 (如果可用)
    if command -v nvidia-smi >/dev/null 2>&1; then
        gpu_utilization=$(nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits 2>/dev/null | head -1)
        gpu_memory=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits 2>/dev/null | head -1)
    fi
    
    echo "$gpu_utilization,$gpu_memory"
}

# 检查告警阈值
check_alert_thresholds() {
    local cpu_usage=$1
    local memory_usage=$2
    local api_status=$3
    local response_time=$4
    
    local alerts=()
    
    # CPU使用率告警
    if (( $(echo "$cpu_usage > 80" | bc -l) )); then
        alerts+=("{\"type\": \"cpu_high\", \"value\": \"$cpu_usage%\", \"threshold\": \"80%\", \"severity\": \"warning\"}")
    fi
    
    # 内存使用率告警
    if (( $(echo "$memory_usage > 85" | bc -l) )); then
        alerts+=("{\"type\": \"memory_high\", \"value\": \"$memory_usage%\", \"threshold\": \"85%\", \"severity\": \"warning\"}")
    fi
    
    # API状态告警
    if [ "$api_status" = "unhealthy" ]; then
        alerts+=("{\"type\": \"api_down\", \"value\": \"unhealthy\", \"threshold\": \"healthy\", \"severity\": \"critical\"}")
    fi
    
    # API响应时间告警
    if [ "$response_time" != "N/A" ] && [ $response_time -gt 5000 ]; then
        alerts+=("{\"type\": \"api_slow\", \"value\": \"${response_time}ms\", \"threshold\": \"5000ms\", \"severity\": \"warning\"}")
    fi
    
    # 记录告警
    for alert in "${alerts[@]}"; do
        local alert_entry="{
    \"timestamp\": \"$(date -Iseconds)\",
    \"alert\": $alert
}"
        
        # 将告警添加到JSON文件
        local temp_file=$(mktemp)
        jq ".alerts += [$alert_entry]" "$ALERTS_FILE" > "$temp_file" 2>/dev/null || true
        mv "$temp_file" "$ALERTS_FILE"
        
        # 显示告警
        local severity=$(echo "$alert" | jq -r '.severity')
        local alert_type=$(echo "$alert" | jq -r '.type')
        local value=$(echo "$alert" | jq -r '.value')
        
        case $severity in
            "critical")
                log_error "CRITICAL告警: $alert_type = $value"
                ;;
            "warning")
                log_warning "WARNING告警: $alert_type = $value"
                ;;
        esac
    done
}

# 实时显示监控数据
display_realtime_data() {
    local timestamp=$(date '+%H:%M:%S')
    
    # 清除屏幕并显示表头
    clear
    echo -e "${BLUE}=== AI工厂系统性能监控 ===${NC}"
    echo -e "${BLUE}时间: $timestamp${NC}"
    echo ""
    printf "%-15s %-10s %-12s %-10s %-12s %-15s %-10s\n" "时间" "CPU%" "内存%" "磁盘%" "负载" "API响应" "状态"
    echo "--------------------------------------------------------------------------------------------"
}

# 生成性能图表
generate_performance_graphs() {
    if [ "$GRAPHICS_GENERATION" != true ]; then
        return 0
    fi
    
    log_info "生成性能图表..."
    
    # 检查Python和matplotlib
    if ! command -v python3 >/dev/null 2>&1; then
        log_warning "Python3未安装，跳过图表生成"
        return 1
    fi
    
    # 创建Python脚本
    cat > "$OUTPUT_DIR/generate_performance_graphs.py" << 'EOF'
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import os

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'SimHei']
plt.rcParams['axes.unicode_minus'] = False

def load_monitoring_data():
    """加载监控数据"""
    csv_files = [f for f in os.listdir('.') if f.startswith('performance_data_') and f.endswith('.csv')]
    if not csv_files:
        print("No monitoring data files found")
        return None
    
    # 使用最新的文件
    latest_file = sorted(csv_files)[-1]
    print(f"Loading data from: {latest_file}")
    
    try:
        df = pd.read_csv(latest_file)
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        return df
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

def create_system_performance_chart(df):
    """创建系统性能图表"""
    if df is None or df.empty:
        return
    
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
    fig.suptitle('System Performance Monitoring', fontsize=16)
    
    # CPU使用率
    ax1.plot(df['timestamp'], df['cpu_usage'], label='CPU Usage', color='red', linewidth=2)
    ax1.set_title('CPU Usage Over Time')
    ax1.set_ylabel('CPU Usage (%)')
    ax1.grid(True, alpha=0.3)
    ax1.legend()
    ax1.set_ylim([0, 100])
    
    # 内存使用率
    ax2.plot(df['timestamp'], df['memory_usage'], label='Memory Usage', color='blue', linewidth=2)
    ax2.set_title('Memory Usage Over Time')
    ax2.set_ylabel('Memory Usage (%)')
    ax2.grid(True, alpha=0.3)
    ax2.legend()
    ax2.set_ylim([0, 100])
    
    # 磁盘使用率
    ax3.plot(df['timestamp'], df['disk_usage'], label='Disk Usage', color='green', linewidth=2)
    ax3.set_title('Disk Usage Over Time')
    ax3.set_ylabel('Disk Usage (%)')
    ax3.grid(True, alpha=0.3)
    ax3.legend()
    ax3.set_ylim([0, 100])
    
    # 负载平均值
    ax4.plot(df['timestamp'], df['load_avg'], label='Load Average', color='orange', linewidth=2)
    ax4.set_title('System Load Average')
    ax4.set_ylabel('Load Average')
    ax4.grid(True, alpha=0.3)
    ax4.legend()
    
    # 格式化x轴
    for ax in [ax1, ax2, ax3, ax4]:
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
        ax.xaxis.set_major_locator(mdates.MinuteLocator(interval=5))
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=45)
    
    plt.tight_layout()
    plt.savefig('system_performance.png', dpi=300, bbox_inches='tight')
    plt.close()

def create_api_performance_chart(df):
    """创建API性能图表"""
    if df is None or df.empty:
        return
    
    # 过滤有效数据
    valid_data = df[df['api_response_time'] != 'N/A'].copy()
    if valid_data.empty:
        print("No valid API response time data")
        return
    
    valid_data['api_response_time'] = pd.to_numeric(valid_data['api_response_time'])
    
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
    fig.suptitle('API Performance Monitoring', fontsize=16)
    
    # API响应时间
    ax1.plot(valid_data['timestamp'], valid_data['api_response_time'], 
             label='Response Time', color='purple', linewidth=2)
    ax1.set_title('API Response Time')
    ax1.set_ylabel('Response Time (ms)')
    ax1.grid(True, alpha=0.3)
    ax1.legend()
    
    # API状态
    status_colors = {'healthy': 'green', 'unhealthy': 'red'}
    for status in valid_data['api_status'].unique():
        status_data = valid_data[valid_data['api_status'] == status]
        y_values = [1 if status == 'healthy' else 0] * len(status_data)
        ax2.scatter(status_data['timestamp'], y_values, 
                   label=f'API {status}', color=status_colors.get(status, 'gray'), 
                   alpha=0.7, s=50)
    
    ax2.set_title('API Status')
    ax2.set_ylabel('Status')
    ax2.set_yticks([0, 1])
    ax2.set_yticklabels(['Unhealthy', 'Healthy'])
    ax2.grid(True, alpha=0.3)
    ax2.legend()
    
    # 格式化x轴
    for ax in [ax1, ax2]:
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
        ax.xaxis.set_major_locator(mdates.MinuteLocator(interval=5))
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=45)
    
    plt.tight_layout()
    plt.savefig('api_performance.png', dpi=300, bbox_inches='tight')
    plt.close()

def create_resource_utilization_chart(df):
    """创建资源利用率图表"""
    if df is None or df.empty:
        return
    
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
    fig.suptitle('Resource Utilization Monitoring', fontsize=16)
    
    # GPU利用率 (如果数据可用)
    gpu_data = df[df['gpu_utilization'] != 'N/A']
    if not gpu_data.empty:
        gpu_data['gpu_utilization'] = pd.to_numeric(gpu_data['gpu_utilization'])
        ax1.plot(gpu_data['timestamp'], gpu_data['gpu_utilization'], 
                label='GPU Utilization', color='cyan', linewidth=2)
        ax1.set_title('GPU Utilization')
        ax1.set_ylabel('GPU Utilization (%)')
        ax1.grid(True, alpha=0.3)
        ax1.legend()
        ax1.set_ylim([0, 100])
    else:
        ax1.text(0.5, 0.5, 'No GPU data available', 
                transform=ax1.transAxes, ha='center', va='center')
        ax1.set_title('GPU Utilization')
    
    # 网络IO
    network_data = df[df['network_io'] != 'N/A']
    if not network_data.empty:
        network_data['network_io'] = pd.to_numeric(network_data['network_io'])
        ax2.plot(network_data['timestamp'], network_data['network_io'], 
                label='Network I/O', color='brown', linewidth=2)
        ax2.set_title('Network I/O')
        ax2.set_ylabel('Bytes/sec')
        ax2.grid(True, alpha=0.3)
        ax2.legend()
    else:
        ax2.text(0.5, 0.5, 'No network data available', 
                transform=ax2.transAxes, ha='center', va='center')
        ax2.set_title('Network I/O')
    
    # 磁盘IO
    disk_data = df[df['disk_io'] != 'N/A']
    if not disk_data.empty:
        disk_data['disk_io'] = pd.to_numeric(disk_data['disk_io'])
        ax3.plot(disk_data['timestamp'], disk_data['disk_io'], 
                label='Disk I/O', color='magenta', linewidth=2)
        ax3.set_title('Disk I/O')
        ax3.set_ylabel('Blocks/sec')
        ax3.grid(True, alpha=0.3)
        ax3.legend()
    else:
        ax3.text(0.5, 0.5, 'No disk I/O data available', 
                transform=ax3.transAxes, ha='center', va='center')
        ax3.set_title('Disk I/O')
    
    # 活跃连接数
    conn_data = df[df['active_connections'] != 'N/A']
    if not conn_data.empty:
        conn_data['active_connections'] = pd.to_numeric(conn_data['active_connections'])
        ax4.plot(conn_data['timestamp'], conn_data['active_connections'], 
                label='Active Connections', color='teal', linewidth=2)
        ax4.set_title('Active API Connections')
        ax4.set_ylabel('Connection Count')
        ax4.grid(True, alpha=0.3)
        ax4.legend()
    else:
        ax4.text(0.5, 0.5, 'No connection data available', 
                transform=ax4.transAxes, ha='center', va='center')
        ax4.set_title('Active API Connections')
    
    # 格式化x轴
    for ax in [ax1, ax2, ax3, ax4]:
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
        ax.xaxis.set_major_locator(mdates.MinuteLocator(interval=5))
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=45)
    
    plt.tight_layout()
    plt.savefig('resource_utilization.png', dpi=300, bbox_inches='tight')
    plt.close()

def main():
    df = load_monitoring_data()
    
    if df is None:
        return
    
    print(f"Data shape: {df.shape}")
    print(f"Columns: {list(df.columns)}")
    
    # 生成图表
    create_system_performance_chart(df)
    create_api_performance_chart(df)
    create_resource_utilization_chart(df)
    
    print("Performance graphs generated successfully")

if __name__ == "__main__":
    main()
EOF
    
    # 运行Python脚本生成图表
    cd "$OUTPUT_DIR"
    python3 generate_performance_graphs.py
    cd - > /dev/null
    
    log_success "性能图表生成完成"
}

# 性能监控循环
monitoring_loop() {
    local start_time=$(date +%s)
    local iteration=0
    
    while true; do
        iteration=$((iteration + 1))
        
        # 检查是否达到持续时间
        if [ $DURATION -gt 0 ]; then
            local current_time=$(date +%s)
            local elapsed=$((current_time - start_time))
            if [ $elapsed -ge $DURATION ]; then
                log_info "监控时间达到限制，停止监控"
                break
            fi
        fi
        
        # 获取各项指标
        local system_metrics=$(get_system_metrics)
        local api_metrics=$(get_api_metrics)
        local db_metrics=$(get_database_metrics)
        local cache_metrics=$(get_cache_metrics)
        local gpu_metrics=$(get_gpu_metrics)
        
        # 解析指标
        local timestamp=$(echo "$system_metrics" | cut -d',' -f1)
        local cpu_usage=$(echo "$system_metrics" | cut -d',' -f2)
        local memory_usage=$(echo "$system_metrics" | cut -d',' -f3)
        local disk_usage=$(echo "$system_metrics" | cut -d',' -f4)
        local load_avg=$(echo "$system_metrics" | cut -d',' -f5)
        local network_io=$(echo "$system_metrics" | cut -d',' -f6)
        local disk_io=$(echo "$system_metrics" | cut -d',' -f7)
        
        local response_time=$(echo "$api_metrics" | cut -d',' -f1)
        local api_status=$(echo "$api_metrics" | cut -d',' -f2)
        local active_connections=$(echo "$api_metrics" | cut -d',' -f3)
        
        local db_connections=$(echo "$db_metrics")
        local cache_hit_rate=$(echo "$cache_metrics")
        
        local gpu_utilization=$(echo "$gpu_metrics" | cut -d',' -f1)
        local gpu_memory=$(echo "$gpu_metrics" | cut -d',' -f2)
        
        # 记录数据
        if [ "$SAVE_DATA" = true ]; then
            echo "$timestamp,$cpu_usage,$memory_usage,$disk_usage,$load_avg,$response_time,$api_status,$db_connections,$cache_hit_rate,$gpu_utilization,$gpu_memory,$network_io,$disk_io,$active_connections" >> "$MONITOR_DATA_FILE"
        fi
        
        # 检查告警阈值
        check_alert_thresholds "$cpu_usage" "$memory_usage" "$api_status" "$response_time"
        
        # 实时显示
        if [ "$REAL_TIME_DISPLAY" = true ]; then
            display_realtime_data
            
            # 显示当前数据
            printf "%-15s %-10s %-12s %-10s %-12s %-15s %-10s\n" \
                "$timestamp" \
                "${cpu_usage}%" \
                "${memory_usage}%" \
                "${disk_usage}%" \
                "$load_avg" \
                "${response_time}ms" \
                "$api_status"
        else
            log_info "监控数据: CPU ${cpu_usage}%, 内存 ${memory_usage}%, API ${api_status}, 响应时间 ${response_time}ms"
        fi
        
        sleep $MONITOR_INTERVAL
    done
}

# 生成监控报告
generate_monitoring_report() {
    log_info "生成监控报告..."
    
    local report_file="$OUTPUT_DIR/monitoring_report_$(date +%Y%m%d_%H%M%S).md"
    
    # 分析数据
    local total_records=0
    local avg_cpu=0
    local avg_memory=0
    local max_cpu=0
    local max_memory=0
    local api_downtime=0
    local total_downtime=0
    
    if [ -f "$MONITOR_DATA_FILE" ] && [ "$SAVE_DATA" = true ]; then
        # 计算统计数据
        total_records=$(tail -n +2 "$MONITOR_DATA_FILE" | wc -l)
        
        if [ $total_records -gt 0 ]; then
            avg_cpu=$(awk -F',' 'NR>1 {sum+=$2; count++} END {printf "%.2f", sum/count}' "$MONITOR_DATA_FILE")
            avg_memory=$(awk -F',' 'NR>1 {sum+=$3; count++} END {printf "%.2f", sum/count}' "$MONITOR_DATA_FILE")
            max_cpu=$(awk -F',' 'NR>1 {if($2>max) max=$2} END {printf "%.2f", max}' "$MONITOR_DATA_FILE")
            max_memory=$(awk -F',' 'NR>1 {if($3>max) max=$3} END {printf "%.2f", max}' "$MONITOR_DATA_FILE")
            
            # 计算API downtime
            api_downtime=$(awk -F',' 'NR>1 && $7=="unhealthy" {count++} END {print count}' "$MONITOR_DATA_FILE")
            total_downtime=$(echo "scale=2; $api_downtime * $MONITOR_INTERVAL / 60" | bc)
        fi
    fi
    
    # 生成报告
    cat > "$report_file" << EOF
# AI工厂系统性能监控报告

## 监控概述

- **监控时间**: $(date '+%Y-%m-%d %H:%M:%S')
- **监控间隔**: ${MONITOR_INTERVAL}秒
- **监控时长**: $([ $DURATION -eq 0 ] && echo "无限" || echo "${DURATION}秒")
- **数据文件**: $MONITOR_DATA_FILE
- **告警文件**: $ALERTS_FILE

## 性能统计

### 系统资源
- **总记录数**: $total_records
- **平均CPU使用率**: ${avg_cpu}%
- **最大CPU使用率**: ${max_cpu}%
- **平均内存使用率**: ${avg_memory}%
- **最大内存使用率**: ${max_memory}%

### API服务
- **API故障次数**: $api_downtime
- **总故障时长**: ${total_downtime}分钟

## 告警记录

EOF
    
    # 添加告警记录
    if [ -f "$ALERTS_FILE" ]; then
        local alert_count=$(jq '.alerts | length' "$ALERTS_FILE" 2>/dev/null || echo "0")
        echo "- **告警总数**: $alert_count" >> "$report_file"
        
        if [ "$alert_count" -gt 0 ]; then
            echo "" >> "$report_file"
            echo "### 告警详情" >> "$report_file"
            echo "" >> "$report_file"
            
            jq -r '.alerts[] | "- **\(.alert.type)**: \(.alert.value) (阈值: \(.alert.threshold), 严重程度: \(.alert.severity))"' "$ALERTS_FILE" >> "$report_file" 2>/dev/null || true
        fi
    fi
    
    cat >> "$report_file" << EOF

## 图表文件

- 系统性能图表: \`system_performance.png\`
- API性能图表: \`api_performance.png\`
- 资源利用率图表: \`resource_utilization.png\`

## 建议

1. **资源监控**: 持续监控系统资源使用情况，及时发现性能瓶颈
2. **告警优化**: 根据实际运行情况调整告警阈值，减少误报
3. **性能调优**: 针对高资源使用率的情况进行性能优化
4. **容量规划**: 基于监控数据进行容量规划和扩容决策

---

*报告生成时间: $(date '+%Y-%m-%d %H:%M:%S')*
EOF
    
    log_success "监控报告生成完成: $report_file"
    echo "$report_file"
}

# 显示帮助信息
show_help() {
    echo "性能监控脚本"
    echo ""
    echo "使用方法:"
    echo "  $0 [选项]"
    echo ""
    echo "选项:"
    echo "  -h, --help              显示此帮助信息"
    echo "  -i, --interval SEC      监控间隔 (默认: $MONITOR_INTERVAL)"
    echo "  -d, --duration SEC      监控持续时间 (默认: 无限)"
    echo "  -o, --output DIR        输出目录 (默认: $OUTPUT_DIR)"
    echo "  -v, --verbose           详细输出"
    echo "  --no-realtime           禁用实时显示"
    echo "  --no-save               不保存数据"
    echo "  --no-graphics           不生成图表"
    echo ""
    echo "示例:"
    echo "  $0                      # 实时监控"
    echo "  $0 -i 30 -d 3600        # 30秒间隔，监控1小时"
    echo "  $0 --no-realtime        # 静默监控"
}

# 主函数
main() {
    # 解析命令行参数
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -i|--interval)
                MONITOR_INTERVAL="$2"
                shift 2
                ;;
            -d|--duration)
                DURATION="$2"
                shift 2
                ;;
            -o|--output)
                OUTPUT_DIR="$2"
                mkdir -p "$OUTPUT_DIR"
                shift 2
                ;;
            -v|--verbose)
                VERBOSE=true
                shift
                ;;
            --no-realtime)
                REAL_TIME_DISPLAY=false
                shift
                ;;
            --no-save)
                SAVE_DATA=false
                shift
                ;;
            --no-graphics)
                GRAPHICS_GENERATION=false
                shift
                ;;
            *)
                log_error "未知参数: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    log_info "开始性能监控"
    log_info "监控间隔: ${MONITOR_INTERVAL}秒"
    log_info "监控时长: $([ $DURATION -eq 0 ] && echo "无限" || echo "${DURATION}秒")"
    log_info "输出目录: $OUTPUT_DIR"
    echo ""
    
    # 初始化监控
    initialize_monitoring
    
    # 开始监控
    monitoring_loop
    
    echo ""
    
    # 生成图表和报告
    generate_performance_graphs
    generate_monitoring_report
    
    echo ""
    log_success "性能监控完成"
    log_info "监控数据: $MONITOR_DATA_FILE"
    log_info "告警记录: $ALERTS_FILE"
}

# 执行主函数
main "$@"