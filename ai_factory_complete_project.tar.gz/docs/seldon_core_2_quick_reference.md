# Seldon Core 2 快速参考指南

## 安装命令

### 使用Helm安装
```bash
# 添加Seldon Helm仓库
helm repo add seldon https://helm.seldon.io/

# 更新Helm仓库
helm repo update

# 安装Seldon Core
helm install seldon-core seldon/seldon-core \
  --namespace seldon-mlops \
  --create-namespace \
  --version 2.10.1
```

### 验证安装
```bash
# 检查Pod状态
kubectl get pods -n seldon-mlops

# 检查服务
kubectl get svc -n seldon-mlops

# 检查CRD
kubectl get crd | grep seldon
```

## 常用kubectl命令

### 查看资源
```bash
# 查看所有Seldon资源
kubectl get models,pipelines,experiments -A

# 查看特定命名空间的资源
kubectl get models -n <namespace>
kubectl get pipelines -n <namespace>
kubectl get experiments -n <namespace>
```

### 描述资源
```bash
# 查看模型详情
kubectl describe model <model-name> -n <namespace>

# 查看管道详情
kubectl describe pipeline <pipeline-name> -n <namespace>

# 查看实验详情
kubectl describe experiment <experiment-name> -n <namespace>
```

### 删除资源
```bash
# 删除模型
kubectl delete model <model-name> -n <namespace>

# 删除管道
kubectl delete pipeline <pipeline-name> -n <namespace>

# 删除实验
kubectl delete experiment <experiment-name> -n <namespace>
```

## 常用YAML配置示例

### 基础模型部署
```yaml
apiVersion: mlops.seldon.io/v1alpha1
kind: Model
metadata:
  name: sklearn-iris
  namespace: seldon-mlops
spec:
  model:
    name: iris
    uri: gs://seldon-models/sklearn/iris
    server: sklearn
    storageInitializerImage: seldonio/storage-initializer:latest
    resources:
      requests:
        cpu: "0.5"
        memory: "1Gi"
      limits:
        cpu: "1"
        memory: "2Gi"
```

### 带有自动扩展的模型
```yaml
apiVersion: mlops.seldon.io/v1alpha1
kind: Model
metadata:
  name: auto-scaling-model
  namespace: seldon-mlops
spec:
  model:
    name: tensorflow-model
    uri: gs://seldon-models/tensorflow/iris
    server: tensorflow
  scale:
    replicas:
      min: 1
      max: 10
    metrics:
      - type: Resource
        resource:
          name: cpu
          target:
            type: Utilization
            averageUtilization: 70
```

### 管道配置
```yaml
apiVersion: mlops.seldon.io/v1alpha1
kind: Pipeline
metadata:
  name: ml-pipeline
  namespace: seldon-mlops
spec:
  steps:
    - name: preprocessing
      component:
        uri: docker://seldonio/preprocessor:latest
        inputs:
          - name: input_data
    - name: inference
      component:
        uri: docker://seldonio/sklearn-model:latest
        inputs:
          - name: processed_data
        outputs:
          - name: predictions
  output:
    steps:
      - inference
```

### A/B测试实验
```yaml
apiVersion: mlops.seldon.io/v1alpha1
kind: Experiment
metadata:
  name: model-comparison
  namespace: seldon-mlops
spec:
  candidates:
    - name: model-v1
      weight: 50
    - name: model-v2
      weight: 50
  trafficSplit: 0.5
  duration: 3600  # 1小时
```

### 多模型服务配置
```yaml
apiVersion: mlops.seldon.io/v1alpha1
kind: Model
metadata:
  name: mms-model
  namespace: seldon-mlops
spec:
  model:
    name: multi-model
    uri: gs://seldon-models/mms/
    server: sklearn
    modelMapping:
      - modelName: model1
        modelURI: gs://seldon-models/model1/
      - modelName: model2
        modelURI: gs://seldon-models/model2/
```

## 监控命令

### 查看日志
```bash
# 查看模型Pod日志
kubectl logs -f deployment/seldon-model-<model-name> -n <namespace>

# 查看管道Pod日志
kubectl logs -f deployment/seldon-pipeline-<pipeline-name> -n <namespace>
```

### 性能监控
```bash
# 查看资源使用情况
kubectl top pods -n <namespace>

# 查看节点资源使用情况
kubectl top nodes

# 查看HPA状态
kubectl get hpa -n <namespace>
```

### Prometheus查询
```bash
# 模型推理请求数
seldon_model_invocations_total

# 模型推理延迟
seldon_model_inference_latency_seconds

# 模型错误率
seldon_model_inference_errors_total

# 队列长度
seldon_model_queue_length
```

## 故障排除

### 常见问题

#### 1. 模型Pod启动失败
```bash
# 检查Pod状态
kubectl get pods -n <namespace>

# 查看事件
kubectl get events -n <namespace> --sort-by='.lastTimestamp'

# 查看详细错误信息
kubectl describe pod <pod-name> -n <namespace>
```

#### 2. 内存不足
```bash
# 检查资源限制
kubectl describe model <model-name> -n <namespace>

# 查看节点资源
kubectl describe nodes

# 调整资源分配
kubectl patch model <model-name> -n <namespace> -p '{"spec":{"model":{"resources":{"limits":{"memory":"4Gi"}}}}}'
```

#### 3. 网络连接问题
```bash
# 检查服务状态
kubectl get svc -n <namespace>

# 测试服务连通性
kubectl run test-pod --image=curlimages/curl --rm -it -- sh
curl http://<service-name>.<namespace>.svc.cluster.local:8080/v2/models/<model-name>/infer
```

## API调用示例

### 模型推理
```bash
# 使用curl调用模型
curl -X POST http://<gateway-url>/v2/models/<model-name>/infer \
  -H 'Content-Type: application/json' \
  -d '{
    "inputs": [
      {
        "name": "input",
        "datatype": "FP32",
        "shape": [1, 4],
        "data": [5.1, 3.5, 1.4, 0.2]
      }
    ]
  }'
```

### 批量推理
```bash
# 批量推理请求
curl -X POST http://<gateway-url>/v2/models/<model-name>/infer \
  -H 'Content-Type: application/json' \
  -d '{
    "batch": {
      "size": 10
    },
    "inputs": [
      {
        "name": "input",
        "datatype": "FP32",
        "shape": [10, 4],
        "data": [5.1, 3.5, 1.4, 0.2, ...]
      }
    ]
  }'
```

## 性能调优

### 批处理配置
```yaml
spec:
  model:
    batch:
      maxBatchSize: 100
      maxLatency: 100  # 毫秒
      preferredBatchSize: [10, 50]
```

### 缓存配置
```yaml
spec:
  model:
    cache:
      enabled: true
      maxSize: 1000
      ttl: 3600  # 秒
```

### 并发配置
```yaml
spec:
  model:
    server: tensorflow
    resources:
      requests:
        cpu: "2"
        memory: "4Gi"
    replicas: 3
    maxReplicas: 10
```

## 最佳实践

### 1. 资源规划
- 根据模型大小和预期负载设置适当的资源限制
- 考虑峰值负载和自动扩展策略
- 监控资源使用情况并定期调整

### 2. 模型版本管理
- 使用语义化版本控制
- 保留历史版本以支持回滚
- 在生产环境中谨慎更新模型

### 3. 监控和告警
- 设置适当的监控阈值
- 配置告警规则
- 定期检查系统健康状态

### 4. 安全考虑
- 使用RBAC限制访问权限
- 启用网络策略
- 定期更新依赖项

### 5. 备份和恢复
- 定期备份配置和模型
- 测试恢复流程
- 保持灾难恢复计划

---
*快速参考指南 v2.10.1*
*最后更新: 2025-11-06*