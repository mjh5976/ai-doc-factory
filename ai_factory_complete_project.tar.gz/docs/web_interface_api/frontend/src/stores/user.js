import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { login as loginApi, getCurrentUser } from '@/api/auth'
import { getToken, setToken, removeToken } from '@/utils/auth'

export const useUserStore = defineStore('user', () => {
  const user = ref(null)
  const token = ref(getToken())
  
  const isAuthenticated = computed(() => !!token.value && !!user.value)
  const isSuperuser = computed(() => user.value?.is_superuser || false)
  const userRole = computed(() => user.value?.role || 'user')
  
  async function login(username, password) {
    try {
      const response = await loginApi(username, password)
      const { access_token, user: userInfo } = response
      
      token.value = access_token
      user.value = userInfo
      setToken(access_token)
      
      return { success: true }
    } catch (error) {
      console.error('登录失败:', error)
      return { 
        success: false, 
        message: error.response?.data?.detail || '登录失败' 
      }
    }
  }
  
  async function fetchCurrentUser() {
    try {
      const userInfo = await getCurrentUser()
      user.value = userInfo
      return userInfo
    } catch (error) {
      console.error('获取用户信息失败:', error)
      logout()
      throw error
    }
  }
  
  function logout() {
    token.value = null
    user.value = null
    removeToken()
  }
  
  function initializeAuth() {
    if (token.value) {
      fetchCurrentUser().catch(() => {
        logout()
      })
    }
  }
  
  return {
    user,
    token,
    isAuthenticated,
    isSuperuser,
    userRole,
    login,
    logout,
    fetchCurrentUser,
    initializeAuth
  }
})
