<template>
  <div class="dashboard">
    <!-- 欢迎信息 -->
    <div class="welcome-section">
      <el-card class="welcome-card">
        <div class="welcome-content">
          <div class="welcome-text">
            <h2>欢迎回来，{{ userStore.user?.full_name || userStore.user?.username }}</h2>
            <p>今天是 {{ currentDate }}，让我们开始新的工作吧！</p>
          </div>
          <div class="welcome-stats">
            <div class="stat-item">
              <div class="stat-number">{{ stats.totalTasks }}</div>
              <div class="stat-label">总任务数</div>
            </div>
            <div class="stat-item">
              <div class="stat-number">{{ stats.activeTasks }}</div>
              <div class="stat-label">进行中</div>
            </div>
            <div class="stat-item">
              <div class="stat-number">{{ stats.completedTasks }}</div>
              <div class="stat-label">已完成</div>
            </div>
          </div>
        </div>
      </el-card>
    </div>
    
    <!-- 快捷操作 -->
    <div class="quick-actions">
      <h3>快捷操作</h3>
      <div class="action-grid">
        <el-card class="action-card" @click="$router.push('/tasks')">
          <div class="action-content">
            <el-icon size="32" color="#409EFF"><Plus /></el-icon>
            <span>创建任务</span>
          </div>
        </el-card>
        
        <el-card class="action-card" @click="$router.push('/uploads')">
          <div class="action-content">
            <el-icon size="32" color="#67C23A"><Upload /></el-icon>
            <span>上传文件</span>
          </div>
        </el-card>
        
        <el-card class="action-card" @click="$router.push('/results')">
          <div class="action-content">
            <el-icon size="32" color="#E6A23C"><Document /></el-icon>
            <span>查看结果</span>
          </div>
        </el-card>
        
        <el-card class="action-card" v-if="userStore.isSuperuser" @click="$router.push('/configs')">
          <div class="action-content">
            <el-icon size="32" color="#F56C6C"><Setting /></el-icon>
            <span>系统配置</span>
          </div>
        </el-card>
      </div>
    </div>
    
    <!-- 数据图表 -->
    <div class="charts-section">
      <div class="chart-row">
        <el-card class="chart-card">
          <template #header>
            <span>任务状态分布</span>
          </template>
          <div ref="taskStatusChart" class="chart-container"></div>
        </el-card>
        
        <el-card class="chart-card">
          <template #header>
            <span>最近7天任务趋势</span>
          </template>
          <div ref="taskTrendChart" class="chart-container"></div>
        </el-card>
      </div>
    </div>
    
    <!-- 最近任务 -->
    <div class="recent-tasks">
      <h3>最近任务</h3>
      <el-card>
        <el-table :data="recentTasks" style="width: 100%">
          <el-table-column prop="title" label="任务名称" />
          <el-table-column prop="task_type" label="类型" width="120">
            <template #default="{ row }">
              <el-tag :type="getTaskTypeColor(row.task_type)">
                {{ getTaskTypeLabel(row.task_type) }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="status" label="状态" width="120">
            <template #default="{ row }">
              <el-tag :type="getStatusColor(row.status)">
                {{ getStatusLabel(row.status) }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="progress" label="进度" width="150">
            <template #default="{ row }">
              <el-progress 
                :percentage="row.progress" 
                :status="row.status === 'completed' ? 'success' : (row.status === 'failed' ? 'exception' : '')"
              />
            </template>
          </el-table-column>
          <el-table-column prop="created_at" label="创建时间" width="180">
            <template #default="{ row }">
              {{ formatDate(row.created_at) }}
            </template>
          </el-table-column>
          <el-table-column label="操作" width="120">
            <template #default="{ row }">
              <el-button 
                type="primary" 
                size="small" 
                @click="viewTask(row.id)"
              >
                查看
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-card>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { getTasks } from '@/api'
import { formatDate } from '@/utils'
import * as echarts from 'echarts'

const router = useRouter()
const userStore = useUserStore()

const currentDate = ref('')
const recentTasks = ref([])
const stats = ref({
  totalTasks: 0,
  activeTasks: 0,
  completedTasks: 0
})

const taskStatusChart = ref(null)
const taskTrendChart = ref(null)

// 初始化数据
onMounted(async () => {
  currentDate.value = new Date().toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    weekday: 'long'
  })
  
  await loadDashboardData()
  await nextTick()
  initCharts()
})

// 加载仪表板数据
const loadDashboardData = async () => {
  try {
    // 加载最近任务
    const tasksResponse = await getTasks({ limit: 5 })
    recentTasks.value = tasksResponse
    
    // 计算统计数据
    const allTasksResponse = await getTasks({ limit: 1000 })
    const allTasks = allTasksResponse
    
    stats.value = {
      totalTasks: allTasks.length,
      activeTasks: allTasks.filter(t => ['pending', 'processing'].includes(t.status)).length,
      completedTasks: allTasks.filter(t => t.status === 'completed').length
    }
  } catch (error) {
    console.error('加载仪表板数据失败:', error)
  }
}

// 初始化图表
const initCharts = () => {
  // 任务状态分布图
  if (taskStatusChart.value) {
    const chart = echarts.init(taskStatusChart.value)
    chart.setOption({
      tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b}: {c} ({d}%)'
      },
      legend: {
        orient: 'vertical',
        left: 'left'
      },
      series: [
        {
          name: '任务状态',
          type: 'pie',
          radius: '50%',
          data: [
            { value: stats.value.completedTasks, name: '已完成' },
            { value: stats.value.activeTasks, name: '进行中' },
            { value: Math.max(0, stats.value.totalTasks - stats.value.completedTasks - stats.value.activeTasks), name: '其他' }
          ],
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
      ]
    })
  }
  
  // 任务趋势图（模拟数据）
  if (taskTrendChart.value) {
    const chart = echarts.init(taskTrendChart.value)
    chart.setOption({
      tooltip: {
        trigger: 'axis'
      },
      xAxis: {
        type: 'category',
        data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
      },
      yAxis: {
        type: 'value'
      },
      series: [
        {
          name: '任务数',
          type: 'line',
          smooth: true,
          data: [12, 15, 8, 20, 18, 25, 22],
          itemStyle: {
            color: '#409EFF'
          },
          areaStyle: {
            color: {
              type: 'linear',
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [
                { offset: 0, color: 'rgba(64, 158, 255, 0.3)' },
                { offset: 1, color: 'rgba(64, 158, 255, 0.1)' }
              ]
            }
          }
        }
      ]
    })
  }
}

// 查看任务
const viewTask = (taskId) => {
  router.push(`/tasks?id=${taskId}`)
}

// 获取任务类型标签
const getTaskTypeLabel = (type) => {
  const labels = {
    'general': '通用',
    'data_processing': '数据处理',
    'model_training': '模型训练',
    'analysis': '分析',
    'report': '报告'
  }
  return labels[type] || type
}

// 获取任务类型颜色
const getTaskTypeColor = (type) => {
  const colors = {
    'general': '',
    'data_processing': 'success',
    'model_training': 'warning',
    'analysis': 'info',
    'report': 'primary'
  }
  return colors[type] || ''
}

// 获取状态标签
const getStatusLabel = (status) => {
  const labels = {
    'pending': '待处理',
    'processing': '处理中',
    'completed': '已完成',
    'failed': '失败',
    'cancelled': '已取消'
  }
  return labels[status] || status
}

// 获取状态颜色
const getStatusColor = (status) => {
  const colors = {
    'pending': 'info',
    'processing': 'warning',
    'completed': 'success',
    'failed': 'danger',
    'cancelled': 'info'
  }
  return colors[status] || ''
}
</script>

<style scoped>
.dashboard {
  max-width: 1200px;
  margin: 0 auto;
}

.welcome-section {
  margin-bottom: 24px;
}

.welcome-card {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
}

.welcome-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: white;
}

.welcome-text h2 {
  margin: 0 0 8px 0;
  font-size: 24px;
}

.welcome-text p {
  margin: 0;
  opacity: 0.9;
}

.welcome-stats {
  display: flex;
  gap: 32px;
}

.stat-item {
  text-align: center;
}

.stat-number {
  font-size: 28px;
  font-weight: bold;
  margin-bottom: 4px;
}

.stat-label {
  font-size: 14px;
  opacity: 0.9;
}

.quick-actions {
  margin-bottom: 24px;
}

.quick-actions h3 {
  margin-bottom: 16px;
  color: #333;
}

.action-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
}

.action-card {
  cursor: pointer;
  transition: all 0.3s;
  border: 1px solid #e8e8e8;
}

.action-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.action-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 16px;
}

.action-content span {
  font-size: 14px;
  color: #333;
}

.charts-section {
  margin-bottom: 24px;
}

.chart-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.chart-card {
  height: 400px;
}

.chart-container {
  width: 100%;
  height: 300px;
}

.recent-tasks h3 {
  margin-bottom: 16px;
  color: #333;
}

@media (max-width: 768px) {
  .welcome-content {
    flex-direction: column;
    gap: 16px;
    text-align: center;
  }
  
  .welcome-stats {
    gap: 16px;
  }
  
  .chart-row {
    grid-template-columns: 1fr;
  }
}
</style>
