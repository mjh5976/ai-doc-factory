<template>
  <div class="uploads-page">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="header-left">
        <h2>文件上传</h2>
        <p>上传和管理您的文件资源</p>
      </div>
      <div class="header-right">
        <el-button type="primary" @click="showUploadDialog = true">
          <el-icon><Upload /></el-icon>
          上传文件
        </el-button>
      </div>
    </div>

    <!-- 上传区域 -->
    <el-card class="upload-card">
      <div 
        class="upload-area"
        :class="{ 'drag-over': isDragOver }"
        @dragover.prevent="handleDragOver"
        @dragleave.prevent="handleDragLeave"
        @drop.prevent="handleDrop"
        @click="triggerFileInput"
      >
        <div class="upload-content">
          <el-icon size="48" color="#409EFF"><UploadFilled /></el-icon>
          <h3>拖拽文件到此处或点击上传</h3>
          <p>支持的文件类型: {{ allowedExtensions.join(', ') }}</p>
          <p>最大文件大小: {{ formatFileSize(maxFileSize) }}</p>
        </div>
        <input
          ref="fileInputRef"
          type="file"
          multiple
          :accept="allowedExtensions.join(',')"
          style="display: none"
          @change="handleFileSelect"
        />
      </div>
    </el-card>

    <!-- 搜索和筛选 -->
    <el-card class="filter-card">
      <el-row :gutter="16">
        <el-col :span="6">
          <el-input
            v-model="searchForm.keyword"
            placeholder="搜索文件名"
            clearable
            @input="handleSearch"
          >
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
          </el-input>
        </el-col>
        <el-col :span="4">
          <el-select
            v-model="searchForm.status"
            placeholder="文件状态"
            clearable
            @change="handleSearch"
          >
            <el-option label="已上传" value="uploaded" />
            <el-option label="处理中" value="processing" />
            <el-option label="已处理" value="processed" />
            <el-option label="失败" value="failed" />
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-button @click="resetSearch">重置</el-button>
        </el-col>
      </el-row>
    </el-card>

    <!-- 文件列表 -->
    <el-card class="table-card">
      <el-table
        v-loading="loading"
        :data="uploads"
        style="width: 100%"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column prop="original_filename" label="文件名" min-width="250">
          <template #default="{ row }">
            <div class="file-info">
              <el-icon :size="20">
                <Document v-if="isImageFile(row.file_type)" />
                <Picture v-else-if="isImageFile(row.file_type)" />
                <VideoCamera v-else-if="row.file_type?.includes('video')" />
                <Headset v-else-if="row.file_type?.includes('audio')" />
                <Folder v-else />
              </el-icon>
              <div class="file-details">
                <span class="file-name">{{ row.original_filename }}</span>
                <span class="file-type">{{ row.file_type }}</span>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="file_size" label="大小" width="120">
          <template #default="{ row }">
            {{ formatFileSize(row.file_size) }}
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="120">
          <template #default="{ row }">
            <el-tag :type="getStatusColor(row.status)">
              {{ getStatusLabel(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="created_at" label="上传时间" width="180">
          <template #default="{ row }">
            {{ formatDate(row.created_at) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button 
              type="primary" 
              size="small" 
              @click="viewFile(row)"
            >
              查看
            </el-button>
            <el-button 
              type="success" 
              size="small" 
              @click="downloadFile(row)"
              :disabled="row.status !== 'processed'"
            >
              下载
            </el-button>
            <el-button 
              type="danger" 
              size="small" 
              @click="deleteFile(row)"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.size"
          :page-sizes="[10, 20, 50, 100]"
          :total="pagination.total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 上传进度对话框 -->
    <el-dialog
      v-model="showUploadDialog"
      title="上传文件"
      width="500px"
      @close="resetUpload"
    >
      <div class="upload-progress">
        <div v-if="uploadingFiles.length === 0" class="empty-state">
          <el-icon size="48" color="#909399"><DocumentCopy /></el-icon>
          <p>暂无上传文件</p>
        </div>
        <div v-else class="file-list">
          <div 
            v-for="file in uploadingFiles" 
            :key="file.id"
            class="file-item"
          >
            <div class="file-info">
              <el-icon><Document /></el-icon>
              <span class="file-name">{{ file.name }}</span>
              <span class="file-size">{{ formatFileSize(file.size) }}</span>
            </div>
            <div class="upload-status">
              <el-progress 
                :percentage="file.progress" 
                :status="file.status === 'success' ? 'success' : (file.status === 'error' ? 'exception' : '')"
              />
              <span class="status-text">{{ getUploadStatusText(file.status) }}</span>
            </div>
          </div>
        </div>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showUploadDialog = false">关闭</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getUploads, uploadFile, deleteUpload } from '@/api'
import { formatDate, formatFileSize, debounce } from '@/utils'

const loading = ref(false)
const showUploadDialog = ref(false)
const isDragOver = ref(false)
const fileInputRef = ref()

// 上传文件列表
const uploadingFiles = ref([])

// 搜索表单
const searchForm = reactive({
  keyword: '',
  status: ''
})

// 分页
const pagination = reactive({
  page: 1,
  size: 20,
  total: 0
})

// 文件列表
const uploads = ref([])

// 配置
const maxFileSize = 50 * 1024 * 1024 // 50MB
const allowedExtensions = ['.txt', '.csv', '.json', '.xlsx', '.pdf', '.png', '.jpg', '.jpeg', '.gif']

// 初始化
onMounted(() => {
  loadUploads()
})

// 加载文件列表
const loadUploads = async () => {
  try {
    loading.value = true
    const params = {
      skip: (pagination.page - 1) * pagination.size,
      limit: pagination.size
    }
    
    if (searchForm.keyword) params.keyword = searchForm.keyword
    if (searchForm.status) params.status = searchForm.status
    
    const response = await getUploads(params)
    uploads.value = response
    
    // 模拟总数
    pagination.total = response.length + Math.floor(Math.random() * 100)
  } catch (error) {
    console.error('加载文件列表失败:', error)
    ElMessage.error('加载文件列表失败')
  } finally {
    loading.value = false
  }
}

// 搜索处理
const handleSearch = debounce(() => {
  pagination.page = 1
  loadUploads()
}, 500)

// 重置搜索
const resetSearch = () => {
  searchForm.keyword = ''
  searchForm.status = ''
  pagination.page = 1
  loadUploads()
}

// 分页处理
const handleSizeChange = (size) => {
  pagination.size = size
  pagination.page = 1
  loadUploads()
}

const handleCurrentChange = (page) => {
  pagination.page = page
  loadUploads()
}

// 选择处理
const handleSelectionChange = (selection) => {
  console.log('选择变化:', selection)
}

// 拖拽处理
const handleDragOver = (e) => {
  e.dataTransfer.dropEffect = 'copy'
  isDragOver.value = true
}

const handleDragLeave = (e) => {
  if (!e.currentTarget.contains(e.relatedTarget)) {
    isDragOver.value = false
  }
}

const handleDrop = (e) => {
  isDragOver.value = false
  const files = Array.from(e.dataTransfer.files)
  handleFiles(files)
}

const triggerFileInput = () => {
  fileInputRef.value?.click()
}

const handleFileSelect = (e) => {
  const files = Array.from(e.target.files)
  handleFiles(files)
  e.target.value = '' // 清空input
}

// 处理文件
const handleFiles = (files) => {
  const validFiles = files.filter(file => {
    const extension = '.' + file.name.split('.').pop().toLowerCase()
    if (!allowedExtensions.includes(extension)) {
      ElMessage.warning(`文件 ${file.name} 类型不支持`)
      return false
    }
    if (file.size > maxFileSize) {
      ElMessage.warning(`文件 ${file.name} 超过大小限制`)
      return false
    }
    return true
  })

  validFiles.forEach(file => {
    const uploadFileItem = {
      id: Date.now() + Math.random(),
      name: file.name,
      size: file.size,
      type: file.type,
      file: file,
      progress: 0,
      status: 'pending'
    }
    uploadingFiles.value.push(uploadFileItem)
    uploadSingleFile(uploadFileItem)
  })

  showUploadDialog.value = true
}

// 上传单个文件
const uploadSingleFile = async (fileItem) => {
  try {
    fileItem.status = 'uploading'
    
    const formData = new FormData()
    formData.append('file', fileItem.file)
    
    // 模拟上传进度
    const progressInterval = setInterval(() => {
      if (fileItem.progress < 90) {
        fileItem.progress += Math.random() * 10
      }
    }, 200)
    
    const response = await uploadFile(fileItem.file)
    
    clearInterval(progressInterval)
    fileItem.progress = 100
    fileItem.status = 'success'
    
    ElMessage.success(`文件 ${fileItem.name} 上传成功`)
    loadUploads() // 刷新列表
    
  } catch (error) {
    console.error('文件上传失败:', error)
    fileItem.status = 'error'
    ElMessage.error(`文件 ${fileItem.name} 上传失败`)
  }
}

// 重置上传
const resetUpload = () => {
  uploadingFiles.value = []
}

// 查看文件
const viewFile = (file) => {
  // 这里可以实现文件预览功能
  ElMessage.info('文件预览功能开发中...')
}

// 下载文件
const downloadFile = async (file) => {
  try {
    const response = await fetch(`/api/uploads/${file.id}/download`, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    })
    
    if (!response.ok) {
      throw new Error('下载失败')
    }
    
    const blob = await response.blob()
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = file.original_filename
    document.body.appendChild(a)
    a.click()
    window.URL.revokeObjectURL(url)
    document.body.removeChild(a)
    
    ElMessage.success('文件下载成功')
  } catch (error) {
    console.error('文件下载失败:', error)
    ElMessage.error('文件下载失败')
  }
}

// 删除文件
const deleteFile = async (file) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除文件"${file.original_filename}"吗？此操作不可恢复！`,
      '警告',
      {
        confirmButtonText: '确定删除',
        cancelButtonText: '取消',
        type: 'error'
      }
    )
    
    await deleteUpload(file.id)
    ElMessage.success('文件删除成功')
    loadUploads()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除文件失败:', error)
      ElMessage.error('删除文件失败')
    }
  }
}

// 获取状态标签
const getStatusLabel = (status) => {
  const labels = {
    'uploaded': '已上传',
    'processing': '处理中',
    'processed': '已处理',
    'failed': '失败'
  }
  return labels[status] || status
}

// 获取状态颜色
const getStatusColor = (status) => {
  const colors = {
    'uploaded': 'info',
    'processing': 'warning',
    'processed': 'success',
    'failed': 'danger'
  }
  return colors[status] || ''
}

// 获取上传状态文本
const getUploadStatusText = (status) => {
  const texts = {
    'pending': '等待中',
    'uploading': '上传中',
    'success': '上传成功',
    'error': '上传失败'
  }
  return texts[status] || status
}

// 判断是否为图片文件
const isImageFile = (fileType) => {
  return fileType?.startsWith('image/')
}
</script>

<style scoped>
.uploads-page {
  max-width: 1400px;
  margin: 0 auto;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
}

.header-left h2 {
  margin: 0 0 8px 0;
  color: #333;
}

.header-left p {
  margin: 0;
  color: #666;
  font-size: 14px;
}

.upload-card {
  margin-bottom: 16px;
}

.upload-area {
  border: 2px dashed #d9d9d9;
  border-radius: 8px;
  padding: 40px 20px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s;
}

.upload-area:hover {
  border-color: #409EFF;
  background-color: #f0f9ff;
}

.upload-area.drag-over {
  border-color: #409EFF;
  background-color: #f0f9ff;
}

.upload-content h3 {
  margin: 16px 0 8px 0;
  color: #333;
}

.upload-content p {
  margin: 4px 0;
  color: #666;
  font-size: 14px;
}

.filter-card {
  margin-bottom: 16px;
}

.table-card {
  margin-bottom: 16px;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 16px;
}

.file-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.file-details {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.file-name {
  font-weight: 500;
  color: #333;
}

.file-type {
  font-size: 12px;
  color: #666;
}

.upload-progress {
  max-height: 400px;
  overflow-y: auto;
}

.empty-state {
  text-align: center;
  padding: 40px 20px;
  color: #909399;
}

.file-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.file-item {
  border: 1px solid #e8e8e8;
  border-radius: 6px;
  padding: 12px;
}

.file-item .file-info {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

.file-item .file-name {
  flex: 1;
  font-weight: 500;
}

.file-item .file-size {
  font-size: 12px;
  color: #666;
}

.upload-status {
  display: flex;
  align-items: center;
  gap: 12px;
}

.status-text {
  font-size: 12px;
  color: #666;
  min-width: 60px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
}
</style>
