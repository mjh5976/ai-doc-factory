<template>
  <div class="tasks-page">
    <!-- 页面头部 -->
    <div class="page-header">
      <div class="header-left">
        <h2>任务管理</h2>
        <p>创建、管理和监控AI任务执行</p>
      </div>
      <div class="header-right">
        <el-button type="primary" @click="showCreateDialog = true">
          <el-icon><Plus /></el-icon>
          创建任务
        </el-button>
      </div>
    </div>

    <!-- 搜索和筛选 -->
    <el-card class="filter-card">
      <el-row :gutter="16">
        <el-col :span="6">
          <el-input
            v-model="searchForm.keyword"
            placeholder="搜索任务名称"
            clearable
            @input="handleSearch"
          >
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
          </el-input>
        </el-col>
        <el-col :span="4">
          <el-select
            v-model="searchForm.status"
            placeholder="任务状态"
            clearable
            @change="handleSearch"
          >
            <el-option label="待处理" value="pending" />
            <el-option label="处理中" value="processing" />
            <el-option label="已完成" value="completed" />
            <el-option label="失败" value="failed" />
            <el-option label="已取消" value="cancelled" />
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-select
            v-model="searchForm.task_type"
            placeholder="任务类型"
            clearable
            @change="handleSearch"
          >
            <el-option label="通用" value="general" />
            <el-option label="数据处理" value="data_processing" />
            <el-option label="模型训练" value="model_training" />
            <el-option label="分析" value="analysis" />
            <el-option label="报告" value="report" />
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-button @click="resetSearch">重置</el-button>
        </el-col>
      </el-row>
    </el-card>

    <!-- 任务列表 -->
    <el-card class="table-card">
      <el-table
        v-loading="loading"
        :data="tasks"
        style="width: 100%"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column prop="title" label="任务名称" min-width="200">
          <template #default="{ row }">
            <div class="task-title">
              <span class="title-text">{{ row.title }}</span>
              <el-tag 
                v-if="row.description" 
                size="small" 
                type="info"
                class="description-tag"
              >
                {{ row.description }}
              </el-tag>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="task_type" label="类型" width="120">
          <template #default="{ row }">
            <el-tag :type="getTaskTypeColor(row.task_type)">
              {{ getTaskTypeLabel(row.task_type) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="120">
          <template #default="{ row }">
            <el-tag :type="getStatusColor(row.status)">
              {{ getStatusLabel(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="progress" label="进度" width="150">
          <template #default="{ row }">
            <el-progress 
              :percentage="row.progress" 
              :status="row.status === 'completed' ? 'success' : (row.status === 'failed' ? 'exception' : '')"
            />
          </template>
        </el-table-column>
        <el-table-column prop="created_at" label="创建时间" width="180">
          <template #default="{ row }">
            {{ formatDate(row.created_at) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <el-button 
              type="primary" 
              size="small" 
              @click="viewTask(row)"
            >
              查看
            </el-button>
            <el-button 
              v-if="row.status === 'pending' || row.status === 'processing'"
              type="warning" 
              size="small" 
              @click="cancelTask(row)"
            >
              取消
            </el-button>
            <el-button 
              type="danger" 
              size="small" 
              @click="deleteTask(row)"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.size"
          :page-sizes="[10, 20, 50, 100]"
          :total="pagination.total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 创建任务对话框 -->
    <el-dialog
      v-model="showCreateDialog"
      title="创建任务"
      width="600px"
      @close="resetCreateForm"
    >
      <el-form
        ref="createFormRef"
        :model="createForm"
        :rules="createRules"
        label-width="100px"
      >
        <el-form-item label="任务名称" prop="title">
          <el-input v-model="createForm.title" placeholder="请输入任务名称" />
        </el-form-item>
        <el-form-item label="任务描述" prop="description">
          <el-input 
            v-model="createForm.description" 
            type="textarea" 
            :rows="3"
            placeholder="请输入任务描述" 
          />
        </el-form-item>
        <el-form-item label="任务类型" prop="task_type">
          <el-select v-model="createForm.task_type" placeholder="请选择任务类型">
            <el-option label="通用" value="general" />
            <el-option label="数据处理" value="data_processing" />
            <el-option label="模型训练" value="model_training" />
            <el-option label="分析" value="analysis" />
            <el-option label="报告" value="report" />
          </el-select>
        </el-form-item>
        <el-form-item label="任务配置">
          <el-input 
            v-model="createForm.configText" 
            type="textarea" 
            :rows="4"
            placeholder='请输入JSON格式的配置信息，如: {"param1": "value1"}' 
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showCreateDialog = false">取消</el-button>
          <el-button type="primary" @click="createTask" :loading="creating">
            创建
          </el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 任务详情对话框 -->
    <el-dialog
      v-model="showDetailDialog"
      title="任务详情"
      width="800px"
    >
      <div v-if="currentTask" class="task-detail">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="任务名称">
            {{ currentTask.title }}
          </el-descriptions-item>
          <el-descriptions-item label="任务类型">
            <el-tag :type="getTaskTypeColor(currentTask.task_type)">
              {{ getTaskTypeLabel(currentTask.task_type) }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="任务状态">
            <el-tag :type="getStatusColor(currentTask.status)">
              {{ getStatusLabel(currentTask.status) }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="执行进度">
            <el-progress 
              :percentage="currentTask.progress" 
              :status="currentTask.status === 'completed' ? 'success' : (currentTask.status === 'failed' ? 'exception' : '')"
            />
          </el-descriptions-item>
          <el-descriptions-item label="创建时间">
            {{ formatDate(currentTask.created_at) }}
          </el-descriptions-item>
          <el-descriptions-item label="更新时间">
            {{ formatDate(currentTask.updated_at) }}
          </el-descriptions-item>
          <el-descriptions-item label="完成时间" v-if="currentTask.completed_at">
            {{ formatDate(currentTask.completed_at) }}
          </el-descriptions-item>
          <el-descriptions-item label="任务描述" v-if="currentTask.description">
            {{ currentTask.description }}
          </el-descriptions-item>
        </el-descriptions>

        <div v-if="currentTask.config" class="config-section">
          <h4>任务配置</h4>
          <pre>{{ JSON.stringify(currentTask.config, null, 2) }}</pre>
        </div>

        <div v-if="currentTask.result" class="result-section">
          <h4>任务结果</h4>
          <pre>{{ JSON.stringify(currentTask.result, null, 2) }}</pre>
        </div>

        <div v-if="currentTask.error_message" class="error-section">
          <h4>错误信息</h4>
          <el-alert
            :title="currentTask.error_message"
            type="error"
            :closable="false"
          />
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { getTasks, createTask, cancelTask as cancelTaskApi, deleteTask as deleteTaskApi, getTask } from '@/api'
import { formatDate, debounce } from '@/utils'

const loading = ref(false)
const creating = ref(false)
const showCreateDialog = ref(false)
const showDetailDialog = ref(false)
const currentTask = ref(null)

// 搜索表单
const searchForm = reactive({
  keyword: '',
  status: '',
  task_type: ''
})

// 分页
const pagination = reactive({
  page: 1,
  size: 20,
  total: 0
})

// 任务列表
const tasks = ref([])

// 创建表单
const createForm = reactive({
  title: '',
  description: '',
  task_type: 'general',
  configText: ''
})

const createFormRef = ref()

// 表单验证规则
const createRules = {
  title: [
    { required: true, message: '请输入任务名称', trigger: 'blur' },
    { min: 2, max: 100, message: '任务名称长度在 2 到 100 个字符', trigger: 'blur' }
  ],
  task_type: [
    { required: true, message: '请选择任务类型', trigger: 'change' }
  ]
}

// 初始化
onMounted(() => {
  loadTasks()
})

// 加载任务列表
const loadTasks = async () => {
  try {
    loading.value = true
    const params = {
      skip: (pagination.page - 1) * pagination.size,
      limit: pagination.size
    }
    
    if (searchForm.keyword) params.keyword = searchForm.keyword
    if (searchForm.status) params.status = searchForm.status
    if (searchForm.task_type) params.task_type = searchForm.task_type
    
    const response = await getTasks(params)
    tasks.value = response
    
    // 模拟总数（实际应该从API获取）
    pagination.total = response.length + Math.floor(Math.random() * 100)
  } catch (error) {
    console.error('加载任务列表失败:', error)
    ElMessage.error('加载任务列表失败')
  } finally {
    loading.value = false
  }
}

// 搜索处理
const handleSearch = debounce(() => {
  pagination.page = 1
  loadTasks()
}, 500)

// 重置搜索
const resetSearch = () => {
  searchForm.keyword = ''
  searchForm.status = ''
  searchForm.task_type = ''
  pagination.page = 1
  loadTasks()
}

// 分页处理
const handleSizeChange = (size) => {
  pagination.size = size
  pagination.page = 1
  loadTasks()
}

const handleCurrentChange = (page) => {
  pagination.page = page
  loadTasks()
}

// 选择处理
const handleSelectionChange = (selection) => {
  console.log('选择变化:', selection)
}

// 创建任务
const createTask = async () => {
  try {
    await createFormRef.value.validate()
    
    creating.value = true
    
    let config = {}
    if (createForm.configText.trim()) {
      try {
        config = JSON.parse(createForm.configText)
      } catch (error) {
        ElMessage.error('配置信息格式错误，请输入有效的JSON')
        return
      }
    }
    
    const taskData = {
      title: createForm.title,
      description: createForm.description,
      task_type: createForm.task_type,
      config
    }
    
    await createTask(taskData)
    
    ElMessage.success('任务创建成功')
    showCreateDialog.value = false
    resetCreateForm()
    loadTasks()
  } catch (error) {
    console.error('创建任务失败:', error)
    ElMessage.error('创建任务失败')
  } finally {
    creating.value = false
  }
}

// 重置创建表单
const resetCreateForm = () => {
  createForm.title = ''
  createForm.description = ''
  createForm.task_type = 'general'
  createForm.configText = ''
  createFormRef.value?.clearValidate()
}

// 查看任务
const viewTask = async (task) => {
  try {
    const response = await getTask(task.id)
    currentTask.value = response
    showDetailDialog.value = true
  } catch (error) {
    console.error('获取任务详情失败:', error)
    ElMessage.error('获取任务详情失败')
  }
}

// 取消任务
const cancelTask = async (task) => {
  try {
    await ElMessageBox.confirm(
      `确定要取消任务"${task.title}"吗？`,
      '提示',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    await cancelTaskApi(task.id)
    ElMessage.success('任务已取消')
    loadTasks()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('取消任务失败:', error)
      ElMessage.error('取消任务失败')
    }
  }
}

// 删除任务
const deleteTask = async (task) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除任务"${task.title}"吗？此操作不可恢复！`,
      '警告',
      {
        confirmButtonText: '确定删除',
        cancelButtonText: '取消',
        type: 'error'
      }
    )
    
    await deleteTaskApi(task.id)
    ElMessage.success('任务删除成功')
    loadTasks()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除任务失败:', error)
      ElMessage.error('删除任务失败')
    }
  }
}

// 获取任务类型标签
const getTaskTypeLabel = (type) => {
  const labels = {
    'general': '通用',
    'data_processing': '数据处理',
    'model_training': '模型训练',
    'analysis': '分析',
    'report': '报告'
  }
  return labels[type] || type
}

// 获取任务类型颜色
const getTaskTypeColor = (type) => {
  const colors = {
    'general': '',
    'data_processing': 'success',
    'model_training': 'warning',
    'analysis': 'info',
    'report': 'primary'
  }
  return colors[type] || ''
}

// 获取状态标签
const getStatusLabel = (status) => {
  const labels = {
    'pending': '待处理',
    'processing': '处理中',
    'completed': '已完成',
    'failed': '失败',
    'cancelled': '已取消'
  }
  return labels[status] || status
}

// 获取状态颜色
const getStatusColor = (status) => {
  const colors = {
    'pending': 'info',
    'processing': 'warning',
    'completed': 'success',
    'failed': 'danger',
    'cancelled': 'info'
  }
  return colors[status] || ''
}
</script>

<style scoped>
.tasks-page {
  max-width: 1400px;
  margin: 0 auto;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 24px;
}

.header-left h2 {
  margin: 0 0 8px 0;
  color: #333;
}

.header-left p {
  margin: 0;
  color: #666;
  font-size: 14px;
}

.filter-card {
  margin-bottom: 16px;
}

.table-card {
  margin-bottom: 16px;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 16px;
}

.task-title {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.title-text {
  font-weight: 500;
}

.description-tag {
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.task-detail {
  max-height: 600px;
  overflow-y: auto;
}

.config-section,
.result-section,
.error-section {
  margin-top: 24px;
}

.config-section h4,
.result-section h4,
.error-section h4 {
  margin: 0 0 12px 0;
  color: #333;
  font-size: 16px;
}

.config-section pre,
.result-section pre {
  background: #f5f5f5;
  padding: 12px;
  border-radius: 4px;
  font-size: 12px;
  line-height: 1.4;
  overflow-x: auto;
}

.dark .config-section pre,
.dark .result-section pre {
  background: #2d2d2d;
  color: #e8e8e8;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}
</style>
