import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '@/stores/user'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'Layout',
      component: () => import('@/layouts/Layout.vue'),
      redirect: '/dashboard',
      children: [
        {
          path: '/dashboard',
          name: 'Dashboard',
          component: () => import('@/views/Dashboard.vue'),
          meta: { title: '仪表板', icon: 'Monitor' }
        },
        {
          path: '/tasks',
          name: 'Tasks',
          component: () => import('@/views/Tasks.vue'),
          meta: { title: '任务管理', icon: 'List' }
        },
        {
          path: '/uploads',
          name: 'Uploads',
          component: () => import('@/views/Uploads.vue'),
          meta: { title: '文件上传', icon: 'Upload' }
        },
        {
          path: '/results',
          name: 'Results',
          component: () => import('@/views/Results.vue'),
          meta: { title: '结果管理', icon: 'Document' }
        },
        {
          path: '/configs',
          name: 'Configs',
          component: () => import('@/views/Configs.vue'),
          meta: { title: '系统配置', icon: 'Setting', requiresAuth: true, requiresSuperuser: true }
        },
        {
          path: '/users',
          name: 'Users',
          component: () => import('@/views/Users.vue'),
          meta: { title: '用户管理', icon: 'User', requiresAuth: true, requiresSuperuser: true }
        },
        {
          path: '/audit',
          name: 'Audit',
          component: () => import('@/views/Audit.vue'),
          meta: { title: '审计日志', icon: 'Document', requiresAuth: true, requiresSuperuser: true }
        },
        {
          path: '/profile',
          name: 'Profile',
          component: () => import('@/views/Profile.vue'),
          meta: { title: '个人中心', icon: 'UserFilled' }
        }
      ]
    },
    {
      path: '/login',
      name: 'Login',
      component: () => import('@/views/Login.vue'),
      meta: { title: '登录', hideInMenu: true }
    },
    {
      path: '/:pathMatch(.*)*',
      name: 'NotFound',
      component: () => import('@/views/NotFound.vue'),
      meta: { title: '页面未找到', hideInMenu: true }
    }
  ]
})

// 路由守卫
router.beforeEach((to, from, next) => {
  const userStore = useUserStore()
  
  // 设置页面标题
  if (to.meta.title) {
    document.title = `${to.meta.title} - AI工厂系统`
  }
  
  // 检查登录状态
  if (to.meta.requiresAuth && !userStore.isAuthenticated) {
    next('/login')
    return
  }
  
  // 检查超级用户权限
  if (to.meta.requiresSuperuser && !userStore.isSuperuser) {
    next('/dashboard')
    return
  }
  
  // 已登录用户访问登录页，重定向到仪表板
  if (to.name === 'Login' && userStore.isAuthenticated) {
    next('/dashboard')
    return
  }
  
  next()
})

export default router
