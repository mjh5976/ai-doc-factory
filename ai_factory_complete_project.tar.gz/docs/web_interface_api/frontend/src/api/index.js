import api from '@/utils/request'

// 认证相关API
export const login = (username, password) => {
  const formData = new FormData()
  formData.append('username', username)
  formData.append('password', password)
  
  return api.post('/auth/login', formData, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  })
}

export const getCurrentUser = () => {
  return api.get('/users/me')
}

// 任务相关API
export const getTasks = (params = {}) => {
  return api.get('/tasks', { params })
}

export const getTask = (id) => {
  return api.get(`/tasks/${id}`)
}

export const createTask = (data) => {
  return api.post('/tasks', data)
}

export const updateTask = (id, data) => {
  return api.put(`/tasks/${id}`, data)
}

export const deleteTask = (id) => {
  return api.delete(`/tasks/${id}`)
}

export const cancelTask = (id) => {
  return api.post(`/tasks/${id}/cancel`)
}

// 上传相关API
export const getUploads = (params = {}) => {
  return api.get('/uploads', { params })
}

export const getUpload = (id) => {
  return api.get(`/uploads/${id}`)
}

export const uploadFile = (file, taskId = null) => {
  const formData = new FormData()
  formData.append('file', file)
  if (taskId) {
    formData.append('task_id', taskId)
  }
  
  return api.post('/uploads', formData, {
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  })
}

export const processUpload = (id) => {
  return api.post(`/uploads/${id}/process`)
}

export const downloadUpload = (id) => {
  return api.get(`/uploads/${id}/download`, {
    responseType: 'blob'
  })
}

export const deleteUpload = (id) => {
  return api.delete(`/uploads/${id}`)
}

// 结果相关API
export const getResults = (params = {}) => {
  return api.get('/results', { params })
}

export const getResult = (id) => {
  return api.get(`/results/${id}`)
}

export const createResult = (data) => {
  return api.post('/results', data)
}

export const downloadResult = (id) => {
  return api.get(`/results/${id}/download`, {
    responseType: 'blob'
  })
}

export const deleteResult = (id) => {
  return api.delete(`/results/${id}`)
}

export const generateResult = (taskId, resultType = 'summary') => {
  return api.post(`/results/generate/${taskId}`, null, {
    params: { result_type: resultType }
  })
}

// 配置相关API
export const getConfigs = (params = {}) => {
  return api.get('/configs', { params })
}

export const getConfig = (key) => {
  return api.get(`/configs/${key}`)
}

export const createConfig = (data) => {
  return api.post('/configs', data)
}

export const updateConfig = (key, data) => {
  return api.put(`/configs/${key}`, data)
}

export const deleteConfig = (key) => {
  return api.delete(`/configs/${key}`)
}

export const getPublicConfigs = () => {
  return api.get('/configs/public/')
}

export const initializeDefaultConfigs = () => {
  return api.post('/configs/init-defaults')
}

// 用户相关API（仅超级用户）
export const getUsers = (params = {}) => {
  return api.get('/users', { params })
}

export const getUser = (id) => {
  return api.get(`/users/${id}`)
}

export const updateUser = (id, data) => {
  return api.put(`/users/${id}`, data)
}

export const deleteUser = (id) => {
  return api.delete(`/users/${id}`)
}

// 审计相关API
export const getAuditLogs = (params = {}) => {
  return api.get('/audit', { params })
}

export const getAuditLog = (id) => {
  return api.get(`/audit/${id}`)
}

export const getActionStats = (days = 30) => {
  return api.get('/audit/stats/actions', {
    params: { days }
  })
}

export const getTimelineStats = (days = 7) => {
  return api.get('/audit/stats/timeline', {
    params: { days }
  })
}

export const cleanupOldLogs = (daysToKeep = 90) => {
  return api.delete('/audit/cleanup', {
    params: { days_to_keep: daysToKeep }
  })
}

export const exportAuditLogs = (startDate, endDate, format = 'json') => {
  return api.post('/audit/export', null, {
    params: {
      start_date: startDate,
      end_date: endDate,
      format
    }
  })
}
