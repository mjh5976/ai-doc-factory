#!/bin/bash

# AI工厂Web界面系统快速启动脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 显示欢迎信息
show_welcome() {
    echo ""
    echo "=========================================="
    echo "    AI工厂Web界面系统快速启动"
    echo "=========================================="
    echo ""
}

# 检查Docker
check_docker() {
    log_info "检查Docker环境..."
    
    if ! command -v docker &> /dev/null; then
        log_error "Docker未安装，请先安装Docker"
        exit 1
    fi
    
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose未安装，请先安装Docker Compose"
        exit 1
    fi
    
    log_success "Docker环境检查通过"
}

# 创建必要目录
create_directories() {
    log_info "创建必要目录..."
    
    mkdir -p nginx/ssl
    mkdir -p uploads
    mkdir -p results
    mkdir -p logs
    
    log_success "目录创建完成"
}

# 复制环境配置
setup_env() {
    log_info "设置环境配置..."
    
    if [ ! -f .env ]; then
        if [ -f .env.example ]; then
            cp .env.example .env
            log_warning "已复制.env.example到.env"
            log_warning "请根据需要修改.env文件中的配置"
        else
            log_error ".env.example文件不存在"
            exit 1
        fi
    else
        log_info ".env文件已存在"
    fi
}

# 启动服务
start_services() {
    log_info "启动服务..."
    
    # 启动数据库和缓存
    log_info "启动基础服务 (PostgreSQL, Redis, MinIO)..."
    docker-compose up -d postgres redis minio
    
    # 等待服务就绪
    log_info "等待基础服务就绪..."
    sleep 30
    
    # 启动应用服务
    log_info "启动应用服务..."
    docker-compose up -d --build
    
    log_success "服务启动完成"
}

# 显示访问信息
show_access_info() {
    echo ""
    echo "=========================================="
    echo "              访问地址"
    echo "=========================================="
    echo "🌐 Web界面:        http://localhost"
    echo "🔧 API文档:        http://localhost:8000/docs"
    echo "📊 监控面板:       http://localhost:3001"
    echo "💾 MinIO控制台:    http://localhost:9001"
    echo ""
    echo "默认管理员账号:"
    echo "👤 用户名: admin"
    echo "🔑 密码: admin123"
    echo ""
    log_warning "生产环境请立即修改默认密码！"
    echo ""
}

# 显示服务状态
show_status() {
    log_info "服务状态:"
    docker-compose ps
    
    echo ""
    log_info "查看日志: docker-compose logs -f"
    log_info "停止服务: docker-compose down"
    log_info "重启服务: docker-compose restart"
}

# 主函数
main() {
    show_welcome
    check_docker
    create_directories
    setup_env
    start_services
    show_access_info
    show_status
    log_success "启动完成！"
}

# 解析命令行参数
case "${1:-}" in
    -h|--help)
        echo "AI工厂Web界面系统快速启动脚本"
        echo ""
        echo "用法: $0 [选项]"
        echo ""
        echo "选项:"
        echo "  -h, --help     显示此帮助信息"
        echo "  -c, --clean    清理并重新启动"
        echo "  -s, --stop     停止所有服务"
        echo "  -r, --restart  重启所有服务"
        echo "  -l, --logs     查看服务日志"
        echo "  --status       显示服务状态"
        echo ""
        exit 0
        ;;
    -c|--clean)
        log_info "清理并重新启动..."
        docker-compose down -v --remove-orphans
        docker system prune -f
        main
        ;;
    -s|--stop)
        log_info "停止所有服务..."
        docker-compose down
        log_success "服务已停止"
        exit 0
        ;;
    -r|--restart)
        log_info "重启所有服务..."
        docker-compose restart
        log_success "服务已重启"
        exit 0
        ;;
    -l|--logs)
        log_info "查看服务日志..."
        docker-compose logs -f
        exit 0
        ;;
    --status)
        log_info "服务状态:"
        docker-compose ps
        exit 0
        ;;
    "")
        main
        ;;
    *)
        log_error "未知选项: $1"
        echo "使用 $0 --help 查看帮助信息"
        exit 1
        ;;
esac
