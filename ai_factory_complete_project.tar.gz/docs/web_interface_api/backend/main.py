from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from contextlib import asynccontextmanager
import os
import logging
from dotenv import load_dotenv

from database import engine, Base
from routers import auth, users, tasks, uploads, results, configs, audit
from utils.auth import get_current_user

# 加载环境变量
load_dotenv()

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # 启动时创建数据库表
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database tables created successfully")
    yield
    # 关闭时的清理工作
    logger.info("Application shutdown")

# 创建FastAPI应用
app = FastAPI(
    title="AI工厂Web界面API",
    description="简洁的Web界面和本地API接口系统",
    version="1.0.0",
    lifespan=lifespan
)

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 在生产环境中应该限制具体的域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(auth.router, prefix="/api/v1/auth", tags=["认证"])
app.include_router(users.router, prefix="/api/v1/users", tags=["用户"])
app.include_router(tasks.router, prefix="/api/v1/tasks", tags=["任务"])
app.include_router(uploads.router, prefix="/api/v1/uploads", tags=["上传"])
app.include_router(results.router, prefix="/api/v1/results", tags=["结果"])
app.include_router(configs.router, prefix="/api/v1/configs", tags=["配置"])
app.include_router(audit.router, prefix="/api/v1/audit", tags=["审计"])

# 静态文件服务
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

@app.get("/")
async def root():
    """根路径"""
    return {"message": "AI工厂Web界面API服务", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    """健康检查"""
    return {"status": "healthy", "service": "ai_factory_api"}

@app.get("/api/v1/info")
async def api_info(current_user = Depends(get_current_user)):
    """API信息"""
    return {
        "api_version": "1.0.0",
        "service_name": "AI工厂Web界面API",
        "user": current_user.email if current_user else None
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
