from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import desc
from datetime import datetime, timedelta
from database.config import get_db
from database.models import AuditLog, User
from utils.auth import get_current_active_user, get_current_superuser

router = APIRouter()

@router.get("/", response_model=List[dict])
async def get_audit_logs(
    skip: int = 0,
    limit: int = 100,
    user_id: Optional[int] = None,
    action: Optional[str] = None,
    resource_type: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """获取审计日志列表"""
    query = db.query(AuditLog)
    
    # 非超级用户只能查看自己的审计日志
    if not current_user.is_superuser:
        query = query.filter(AuditLog.user_id == current_user.id)
    
    # 应用过滤条件
    if user_id and current_user.is_superuser:
        query = query.filter(AuditLog.user_id == user_id)
    if action:
        query = query.filter(AuditLog.action == action)
    if resource_type:
        query = query.filter(AuditLog.resource_type == resource_type)
    
    # 日期范围过滤
    if start_date:
        try:
            start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            query = query.filter(AuditLog.created_at >= start_dt)
        except ValueError:
            raise HTTPException(status_code=400, detail="无效的开始日期格式")
    
    if end_date:
        try:
            end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            query = query.filter(AuditLog.created_at <= end_dt)
        except ValueError:
            raise HTTPException(status_code=400, detail="无效的结束日期格式")
    
    audit_logs = query.order_by(desc(AuditLog.created_at)).offset(skip).limit(limit).all()
    
    return [
        {
            "id": log.id,
            "user_id": log.user_id,
            "action": log.action,
            "resource_type": log.resource_type,
            "resource_id": log.resource_id,
            "details": log.details,
            "ip_address": log.ip_address,
            "user_agent": log.user_agent,
            "created_at": log.created_at,
            "username": log.user.username if log.user else None
        }
        for log in audit_logs
    ]

@router.get("/{log_id}", response_model=dict)
async def get_audit_log(
    log_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """获取特定审计日志详情"""
    log = db.query(AuditLog).filter(AuditLog.id == log_id).first()
    if not log:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="审计日志不存在"
        )
    
    # 检查权限
    if not current_user.is_superuser and log.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限访问该审计日志"
        )
    
    return {
        "id": log.id,
        "user_id": log.user_id,
        "action": log.action,
        "resource_type": log.resource_type,
        "resource_id": log.resource_id,
        "details": log.details,
        "ip_address": log.ip_address,
        "user_agent": log.user_agent,
        "created_at": log.created_at,
        "username": log.user.username if log.user else None
    }

@router.get("/stats/actions")
async def get_action_stats(
    days: int = 30,
    current_user: User = Depends(get_current_superuser),
    db: Session = Depends(get_db)
):
    """获取操作统计"""
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # 获取操作统计
    action_stats = db.query(
        AuditLog.action,
        db.func.count(AuditLog.id).label('count')
    ).filter(
        AuditLog.created_at >= start_date
    ).group_by(AuditLog.action).all()
    
    # 获取用户统计
    user_stats = db.query(
        AuditLog.user_id,
        db.func.count(AuditLog.id).label('count')
    ).filter(
        AuditLog.created_at >= start_date
    ).group_by(AuditLog.user_id).all()
    
    # 获取资源类型统计
    resource_stats = db.query(
        AuditLog.resource_type,
        db.func.count(AuditLog.id).label('count')
    ).filter(
        AuditLog.created_at >= start_date
    ).group_by(AuditLog.resource_type).all()
    
    return {
        "period_days": days,
        "actions": [{"action": action, "count": count} for action, count in action_stats],
        "users": [{"user_id": user_id, "count": count} for user_id, count in user_stats],
        "resources": [{"resource_type": resource_type, "count": count} for resource_type, count in resource_stats]
    }

@router.get("/stats/timeline")
async def get_timeline_stats(
    days: int = 7,
    current_user: User = Depends(get_current_superuser),
    db: Session = Depends(get_db)
):
    """获取时间线统计"""
    start_date = datetime.utcnow() - timedelta(days=days)
    
    # 按日期统计操作数量
    timeline_stats = db.query(
        db.func.date(AuditLog.created_at).label('date'),
        db.func.count(AuditLog.id).label('count')
    ).filter(
        AuditLog.created_at >= start_date
    ).group_by(
        db.func.date(AuditLog.created_at)
    ).order_by('date').all()
    
    return {
        "period_days": days,
        "timeline": [{"date": str(date), "count": count} for date, count in timeline_stats]
    }

@router.get("/actions/list")
async def get_available_actions(
    current_user: User = Depends(get_current_superuser),
    db: Session = Depends(get_db)
):
    """获取所有可用的操作类型"""
    actions = db.query(AuditLog.action).distinct().all()
    return [action[0] for action in actions]

@router.get("/resources/list")
async def get_available_resources(
    current_user: User = Depends(get_current_superuser),
    db: Session = Depends(get_db)
):
    """获取所有可用的资源类型"""
    resources = db.query(AuditLog.resource_type).distinct().all()
    return [resource[0] for resource in resources if resource[0] is not None]

@router.delete("/cleanup")
async def cleanup_old_logs(
    days_to_keep: int = 90,
    current_user: User = Depends(get_current_superuser),
    db: Session = Depends(get_db)
):
    """清理旧的审计日志"""
    cutoff_date = datetime.utcnow() - timedelta(days=days_to_keep)
    
    # 删除指定日期之前的日志
    deleted_count = db.query(AuditLog).filter(
        AuditLog.created_at < cutoff_date
    ).delete(synchronize_session=False)
    
    db.commit()
    
    return {
        "message": f"清理完成，删除了 {deleted_count} 条超过 {days_to_keep} 天的审计日志"
    }

@router.post("/export")
async def export_audit_logs(
    start_date: str,
    end_date: str,
    format: str = "json",
    current_user: User = Depends(get_current_superuser),
    db: Session = Depends(get_db)
):
    """导出审计日志"""
    try:
        start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
    except ValueError:
        raise HTTPException(status_code=400, detail="无效的日期格式")
    
    # 获取指定时间范围的日志
    logs = db.query(AuditLog).filter(
        AuditLog.created_at >= start_dt,
        AuditLog.created_at <= end_dt
    ).order_by(desc(AuditLog.created_at)).all()
    
    # 准备导出数据
    export_data = [
        {
            "id": log.id,
            "user_id": log.user_id,
            "username": log.user.username if log.user else None,
            "action": log.action,
            "resource_type": log.resource_type,
            "resource_id": log.resource_id,
            "details": log.details,
            "ip_address": log.ip_address,
            "user_agent": log.user_agent,
            "created_at": log.created_at.isoformat()
        }
        for log in logs
    ]
    
    return {
        "export_info": {
            "start_date": start_date,
            "end_date": end_date,
            "total_records": len(export_data),
            "format": format,
            "exported_at": datetime.utcnow().isoformat()
        },
        "data": export_data
    }
