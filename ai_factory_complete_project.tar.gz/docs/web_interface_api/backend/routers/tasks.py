from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from sqlalchemy.orm import Session
from datetime import datetime
from database.config import get_db
from database.models import Task, User
from utils.auth import get_current_active_user
import json
import asyncio

router = APIRouter()

@router.get("/", response_model=List[dict])
async def get_tasks(
    skip: int = 0,
    limit: int = 100,
    status: Optional[str] = None,
    task_type: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """获取任务列表"""
    query = db.query(Task)
    
    # 非超级用户只能查看自己的任务
    if not current_user.is_superuser:
        query = query.filter(Task.user_id == current_user.id)
    
    if status:
        query = query.filter(Task.status == status)
    if task_type:
        query = query.filter(Task.task_type == task_type)
    
    tasks = query.order_by(Task.created_at.desc()).offset(skip).limit(limit).all()
    
    return [
        {
            "id": task.id,
            "title": task.title,
            "description": task.description,
            "status": task.status,
            "task_type": task.task_type,
            "progress": task.progress,
            "error_message": task.error_message,
            "created_at": task.created_at,
            "updated_at": task.updated_at,
            "completed_at": task.completed_at
        }
        for task in tasks
    ]

@router.get("/{task_id}", response_model=dict)
async def get_task(
    task_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """获取特定任务详情"""
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="任务不存在"
        )
    
    # 检查权限
    if not current_user.is_superuser and task.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限访问该任务"
        )
    
    return {
        "id": task.id,
        "title": task.title,
        "description": task.description,
        "status": task.status,
        "task_type": task.task_type,
        "config": task.config,
        "result": task.result,
        "progress": task.progress,
        "error_message": task.error_message,
        "created_at": task.created_at,
        "updated_at": task.updated_at,
        "completed_at": task.completed_at,
        "user_id": task.user_id
    }

@router.post("/", response_model=dict)
async def create_task(
    title: str,
    description: str = None,
    task_type: str = "general",
    config: dict = None,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """创建新任务"""
    task = Task(
        title=title,
        description=description,
        task_type=task_type,
        config=config or {},
        user_id=current_user.id,
        status="pending"
    )
    
    db.add(task)
    db.commit()
    db.refresh(task)
    
    # 异步处理任务
    background_tasks.add_task(process_task, task.id, db)
    
    return {
        "id": task.id,
        "title": task.title,
        "description": task.description,
        "status": task.status,
        "task_type": task.task_type,
        "created_at": task.created_at
    }

@router.put("/{task_id}", response_model=dict)
async def update_task(
    task_id: int,
    title: Optional[str] = None,
    description: Optional[str] = None,
    config: Optional[dict] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """更新任务信息"""
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="任务不存在"
        )
    
    # 检查权限
    if not current_user.is_superuser and task.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限修改该任务"
        )
    
    # 不能修改已完成的任务
    if task.status in ["completed", "failed"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="不能修改已完成的任务"
        )
    
    # 更新字段
    if title is not None:
        task.title = title
    if description is not None:
        task.description = description
    if config is not None:
        task.config = config
    
    task.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(task)
    
    return {"message": "任务更新成功", "task_id": task.id}

@router.delete("/{task_id}")
async def delete_task(
    task_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """删除任务"""
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="任务不存在"
        )
    
    # 检查权限
    if not current_user.is_superuser and task.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限删除该任务"
        )
    
    # 不能删除正在运行的任务
    if task.status == "processing":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="不能删除正在处理的任务"
        )
    
    db.delete(task)
    db.commit()
    
    return {"message": "任务删除成功"}

@router.post("/{task_id}/cancel")
async def cancel_task(
    task_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """取消任务"""
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="任务不存在"
        )
    
    # 检查权限
    if not current_user.is_superuser and task.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限取消该任务"
        )
    
    # 只有pending或processing状态的任务可以取消
    if task.status not in ["pending", "processing"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="任务当前状态不允许取消"
        )
    
    task.status = "cancelled"
    task.updated_at = datetime.utcnow()
    db.commit()
    
    return {"message": "任务已取消"}

async def process_task(task_id: int, db: Session):
    """异步处理任务"""
    try:
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            return
        
        # 更新任务状态为处理中
        task.status = "processing"
        task.progress = 0.0
        db.commit()
        
        # 模拟任务处理过程
        for i in range(11):
            await asyncio.sleep(1)  # 模拟处理时间
            task.progress = i * 10.0
            db.commit()
        
        # 任务完成
        task.status = "completed"
        task.result = {"message": "任务处理完成", "output": f"Task {task_id} result"}
        task.completed_at = datetime.utcnow()
        db.commit()
        
    except Exception as e:
        # 任务失败
        task.status = "failed"
        task.error_message = str(e)
        db.commit()
