from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.config import get_db
from database.models import Config, User
from utils.auth import get_current_active_user, get_current_superuser

router = APIRouter()

@router.get("/", response_model=List[dict])
async def get_configs(
    config_type: Optional[str] = None,
    is_public: Optional[bool] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """获取配置列表"""
    query = db.query(Config)
    
    # 非超级用户只能查看公开配置
    if not current_user.is_superuser:
        query = query.filter(Config.is_public == True)
    
    if config_type:
        query = query.filter(Config.config_type == config_type)
    if is_public is not None:
        query = query.filter(Config.is_public == is_public)
    
    configs = query.order_by(Config.config_key).all()
    
    return [
        {
            "id": config.id,
            "config_key": config.config_key,
            "config_value": config.config_value,
            "description": config.description,
            "config_type": config.config_type,
            "is_public": config.is_public,
            "created_at": config.created_at,
            "updated_at": config.updated_at
        }
        for config in configs
    ]

@router.get("/{config_key}", response_model=dict)
async def get_config(
    config_key: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """获取特定配置"""
    config = db.query(Config).filter(Config.config_key == config_key).first()
    if not config:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="配置不存在"
        )
    
    # 检查权限
    if not config.is_public and not current_user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限访问该配置"
        )
    
    return {
        "id": config.id,
        "config_key": config.config_key,
        "config_value": config.config_value,
        "description": config.description,
        "config_type": config.config_type,
        "is_public": config.is_public,
        "created_at": config.created_at,
        "updated_at": config.updated_at
    }

@router.post("/", response_model=dict)
async def create_config(
    config_key: str,
    config_value: Any,
    description: str = None,
    config_type: str = "system",
    is_public: bool = False,
    current_user: User = Depends(get_current_superuser),
    db: Session = Depends(get_db)
):
    """创建配置（仅超级用户）"""
    # 检查配置键是否已存在
    existing_config = db.query(Config).filter(Config.config_key == config_key).first()
    if existing_config:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="配置键已存在"
        )
    
    config = Config(
        config_key=config_key,
        config_value=config_value,
        description=description,
        config_type=config_type,
        is_public=is_public
    )
    
    db.add(config)
    db.commit()
    db.refresh(config)
    
    return {
        "id": config.id,
        "config_key": config.config_key,
        "config_value": config.config_value,
        "message": "配置创建成功"
    }

@router.put("/{config_key}", response_model=dict)
async def update_config(
    config_key: str,
    config_value: Optional[Any] = None,
    description: Optional[str] = None,
    is_public: Optional[bool] = None,
    current_user: User = Depends(get_current_superuser),
    db: Session = Depends(get_db)
):
    """更新配置（仅超级用户）"""
    config = db.query(Config).filter(Config.config_key == config_key).first()
    if not config:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="配置不存在"
        )
    
    # 更新字段
    if config_value is not None:
        config.config_value = config_value
    if description is not None:
        config.description = description
    if is_public is not None:
        config.is_public = is_public
    
    db.commit()
    db.refresh(config)
    
    return {
        "id": config.id,
        "config_key": config.config_key,
        "config_value": config.config_value,
        "message": "配置更新成功"
    }

@router.delete("/{config_key}")
async def delete_config(
    config_key: str,
    current_user: User = Depends(get_current_superuser),
    db: Session = Depends(get_db)
):
    """删除配置（仅超级用户）"""
    config = db.query(Config).filter(Config.config_key == config_key).first()
    if not config:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="配置不存在"
        )
    
    db.delete(config)
    db.commit()
    
    return {"message": "配置删除成功"}

@router.get("/types/list", response_model=List[str])
async def get_config_types(
    current_user: User = Depends(get_current_superuser),
    db: Session = Depends(get_db)
):
    """获取所有配置类型"""
    config_types = db.query(Config.config_type).distinct().all()
    return [ct[0] for ct in config_types]

@router.get("/public/", response_model=List[dict])
async def get_public_configs(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """获取公开配置"""
    configs = db.query(Config).filter(Config.is_public == True).all()
    
    return [
        {
            "config_key": config.config_key,
            "config_value": config.config_value,
            "description": config.description
        }
        for config in configs
    ]

# 预设的系统配置
DEFAULT_CONFIGS = {
    "system.name": {
        "value": "AI工厂Web界面系统",
        "description": "系统名称",
        "type": "system",
        "public": True
    },
    "system.version": {
        "value": "1.0.0",
        "description": "系统版本",
        "type": "system",
        "public": True
    },
    "upload.max_file_size": {
        "value": 52428800,  # 50MB
        "description": "最大文件上传大小（字节）",
        "type": "upload",
        "public": False
    },
    "upload.allowed_extensions": {
        "value": [".txt", ".csv", ".json", ".xlsx", ".pdf", ".png", ".jpg"],
        "description": "允许的文件扩展名",
        "type": "upload",
        "public": False
    },
    "task.default_timeout": {
        "value": 3600,  # 1小时
        "description": "任务默认超时时间（秒）",
        "type": "task",
        "public": False
    },
    "ui.theme": {
        "value": "light",
        "description": "UI主题",
        "type": "ui",
        "public": True
    },
    "ui.language": {
        "value": "zh-CN",
        "description": "界面语言",
        "type": "ui",
        "public": True
    }
}

@router.post("/init-defaults")
async def initialize_default_configs(
    current_user: User = Depends(get_current_superuser),
    db: Session = Depends(get_db)
):
    """初始化默认配置"""
    created_count = 0
    
    for key, config_info in DEFAULT_CONFIGS.items():
        # 检查配置是否已存在
        existing = db.query(Config).filter(Config.config_key == key).first()
        if not existing:
            config = Config(
                config_key=key,
                config_value=config_info["value"],
                description=config_info["description"],
                config_type=config_info["type"],
                is_public=config_info["public"]
            )
            db.add(config)
            created_count += 1
    
    db.commit()
    
    return {
        "message": f"默认配置初始化完成，创建了 {created_count} 个新配置",
        "total_configs": len(DEFAULT_CONFIGS)
    }
