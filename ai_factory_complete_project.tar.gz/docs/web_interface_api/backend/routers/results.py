from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
import os
import json
from datetime import datetime
from database.config import get_db
from database.models import Result, Task, User
from utils.auth import get_current_active_user

router = APIRouter()

# 结果文件目录
RESULTS_DIR = "results"
os.makedirs(RESULTS_DIR, exist_ok=True)

@router.get("/", response_model=List[dict])
async def get_results(
    skip: int = 0,
    limit: int = 100,
    task_id: Optional[int] = None,
    result_type: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """获取结果列表"""
    query = db.query(Result)
    
    # 如果指定了任务ID，需要检查权限
    if task_id:
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="关联的任务不存在"
            )
        
        # 非超级用户只能查看自己任务的结果
        if not current_user.is_superuser and task.user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="没有权限访问该任务的结果"
            )
        
        query = query.filter(Result.task_id == task_id)
    
    # 如果没有指定任务ID，非超级用户只能查看自己任务的结果
    elif not current_user.is_superuser:
        # 获取用户的所有任务ID
        user_tasks = db.query(Task.id).filter(Task.user_id == current_user.id).all()
        task_ids = [task.id for task in user_tasks]
        if task_ids:
            query = query.filter(Result.task_id.in_(task_ids))
        else:
            return []  # 用户没有任务，返回空列表
    
    if result_type:
        query = query.filter(Result.result_type == result_type)
    
    results = query.order_by(Result.created_at.desc()).offset(skip).limit(limit).all()
    
    return [
        {
            "id": result.id,
            "task_id": result.task_id,
            "result_type": result.result_type,
            "file_path": result.file_path,
            "file_size": result.file_size,
            "created_at": result.created_at
        }
        for result in results
    ]

@router.get("/{result_id}", response_model=dict)
async def get_result(
    result_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """获取特定结果详情"""
    result = db.query(Result).filter(Result.id == result_id).first()
    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="结果不存在"
        )
    
    # 检查权限
    task = db.query(Task).filter(Task.id == result.task_id).first()
    if not current_user.is_superuser and task.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限访问该结果"
        )
    
    return {
        "id": result.id,
        "task_id": result.task_id,
        "result_type": result.result_type,
        "result_data": result.result_data,
        "file_path": result.file_path,
        "file_size": result.file_size,
        "created_at": result.created_at
    }

@router.post("/", response_model=dict)
async def create_result(
    task_id: int,
    result_type: str,
    result_data: dict = None,
    file_path: str = None,
    file_size: int = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """创建结果记录"""
    # 检查任务是否存在
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="关联的任务不存在"
        )
    
    # 检查权限
    if not current_user.is_superuser and task.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限为该任务创建结果"
        )
    
    result = Result(
        task_id=task_id,
        result_type=result_type,
        result_data=result_data or {},
        file_path=file_path,
        file_size=file_size
    )
    
    db.add(result)
    db.commit()
    db.refresh(result)
    
    return {
        "id": result.id,
        "task_id": result.task_id,
        "result_type": result.result_type,
        "created_at": result.created_at
    }

@router.get("/{result_id}/download")
async def download_result(
    result_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """下载结果文件"""
    result = db.query(Result).filter(Result.id == result_id).first()
    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="结果不存在"
        )
    
    # 检查权限
    task = db.query(Task).filter(Task.id == result.task_id).first()
    if not current_user.is_superuser and task.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限下载该结果"
        )
    
    # 检查文件是否存在
    if not result.file_path or not os.path.exists(result.file_path):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="结果文件不存在"
        )
    
    # 根据文件类型返回响应
    file_extension = os.path.splitext(result.file_path)[1].lower()
    media_types = {
        '.json': 'application/json',
        '.csv': 'text/csv',
        '.txt': 'text/plain',
        '.pdf': 'application/pdf',
        '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        '.xls': 'application/vnd.ms-excel'
    }
    
    media_type = media_types.get(file_extension, 'application/octet-stream')
    
    return FileResponse(
        path=result.file_path,
        filename=os.path.basename(result.file_path),
        media_type=media_type
    )

@router.delete("/{result_id}")
async def delete_result(
    result_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """删除结果"""
    result = db.query(Result).filter(Result.id == result_id).first()
    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="结果不存在"
        )
    
    # 检查权限
    task = db.query(Task).filter(Task.id == result.task_id).first()
    if not current_user.is_superuser and task.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限删除该结果"
        )
    
    # 删除物理文件
    try:
        if result.file_path and os.path.exists(result.file_path):
            os.remove(result.file_path)
    except Exception as e:
        print(f"删除结果文件失败: {e}")
    
    # 删除数据库记录
    db.delete(result)
    db.commit()
    
    return {"message": "结果删除成功"}

@router.post("/generate/{task_id}")
async def generate_result(
    task_id: int,
    result_type: str = "summary",
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """为任务生成结果"""
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="任务不存在"
        )
    
    # 检查权限
    if not current_user.is_superuser and task.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限为该任务生成结果"
        )
    
    # 检查任务状态
    if task.status != "completed":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="只能为已完成的任务生成结果"
        )
    
    # 生成结果数据
    result_data = {
        "task_id": task.id,
        "task_title": task.title,
        "task_type": task.task_type,
        "completed_at": task.completed_at.isoformat() if task.completed_at else None,
        "summary": f"任务 '{task.title}' 已成功完成",
        "details": {
            "processing_time": "计算中",
            "output_files": [],
            "metrics": {}
        }
    }
    
    # 根据结果类型生成不同的数据
    if result_type == "summary":
        result_data["details"]["summary_text"] = f"任务 {task.id} 摘要报告"
    elif result_type == "report":
        result_data["details"]["report_content"] = f"任务 {task.id} 详细报告"
    elif result_type == "data":
        result_data["details"]["data"] = {"sample_data": [1, 2, 3, 4, 5]}
    
    # 保存结果到文件（可选）
    result_filename = f"result_{task_id}_{result_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    result_path = os.path.join(RESULTS_DIR, result_filename)
    
    with open(result_path, 'w', encoding='utf-8') as f:
        json.dump(result_data, f, ensure_ascii=False, indent=2)
    
    # 创建数据库记录
    result = Result(
        task_id=task_id,
        result_type=result_type,
        result_data=result_data,
        file_path=result_path,
        file_size=os.path.getsize(result_path)
    )
    
    db.add(result)
    db.commit()
    db.refresh(result)
    
    return {
        "message": "结果生成成功",
        "result_id": result.id,
        "result_type": result_type,
        "file_path": result.file_path
    }
