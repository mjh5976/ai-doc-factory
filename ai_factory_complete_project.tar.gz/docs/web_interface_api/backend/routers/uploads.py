from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
import os
import shutil
import uuid
from datetime import datetime
from database.config import get_db
from database.models import Upload, Task, User
from utils.auth import get_current_active_user
import magic

router = APIRouter()

# 上传目录
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# 允许的文件类型
ALLOWED_EXTENSIONS = {'.txt', '.csv', '.json', '.xlsx', '.xls', '.pdf', '.doc', '.docx', '.png', '.jpg', '.jpeg', '.gif'}
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB

@router.get("/", response_model=List[dict])
async def get_uploads(
    skip: int = 0,
    limit: int = 100,
    status: Optional[str] = None,
    task_id: Optional[int] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """获取上传文件列表"""
    query = db.query(Upload)
    
    # 非超级用户只能查看自己的上传
    if not current_user.is_superuser:
        query = query.filter(Upload.user_id == current_user.id)
    
    if status:
        query = query.filter(Upload.status == status)
    if task_id:
        query = query.filter(Upload.task_id == task_id)
    
    uploads = query.order_by(Upload.created_at.desc()).offset(skip).limit(limit).all()
    
    return [
        {
            "id": upload.id,
            "filename": upload.filename,
            "original_filename": upload.original_filename,
            "file_size": upload.file_size,
            "file_type": upload.file_type,
            "status": upload.status,
            "task_id": upload.task_id,
            "created_at": upload.created_at
        }
        for upload in uploads
    ]

@router.get("/{upload_id}", response_model=dict)
async def get_upload(
    upload_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """获取特定上传文件详情"""
    upload = db.query(Upload).filter(Upload.id == upload_id).first()
    if not upload:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="上传文件不存在"
        )
    
    # 检查权限
    if not current_user.is_superuser and upload.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限访问该上传文件"
        )
    
    return {
        "id": upload.id,
        "filename": upload.filename,
        "original_filename": upload.original_filename,
        "file_path": upload.file_path,
        "file_size": upload.file_size,
        "file_type": upload.file_type,
        "mime_type": upload.mime_type,
        "status": upload.status,
        "metadata": upload.metadata,
        "task_id": upload.task_id,
        "created_at": upload.created_at,
        "updated_at": upload.updated_at
    }

@router.post("/", response_model=dict)
async def upload_file(
    file: UploadFile = File(...),
    task_id: Optional[int] = Form(None),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """上传文件"""
    # 验证文件
    if not file.filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="文件名不能为空"
        )
    
    # 检查文件扩展名
    file_extension = os.path.splitext(file.filename)[1].lower()
    if file_extension not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"不支持的文件类型: {file_extension}"
        )
    
    # 检查文件大小
    content = await file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"文件大小超过限制 ({MAX_FILE_SIZE // 1024 // 1024}MB)"
        )
    
    # 检查任务权限（如果指定了task_id）
    if task_id:
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="关联的任务不存在"
            )
        
        if not current_user.is_superuser and task.user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="没有权限上传到该任务"
            )
    
    # 生成唯一文件名
    unique_filename = f"{uuid.uuid4()}{file_extension}"
    file_path = os.path.join(UPLOAD_DIR, unique_filename)
    
    # 保存文件
    with open(file_path, "wb") as buffer:
        buffer.write(content)
    
    # 获取文件类型
    file_type = file_extension[1:]  # 去掉点号
    
    # 创建数据库记录
    upload = Upload(
        filename=unique_filename,
        original_filename=file.filename,
        file_path=file_path,
        file_size=len(content),
        file_type=file_type,
        mime_type=file.content_type,
        user_id=current_user.id,
        task_id=task_id,
        status="uploaded"
    )
    
    db.add(upload)
    db.commit()
    db.refresh(upload)
    
    return {
        "id": upload.id,
        "filename": upload.filename,
        "original_filename": upload.original_filename,
        "file_size": upload.file_size,
        "file_type": upload.file_type,
        "status": upload.status,
        "message": "文件上传成功"
    }

@router.post("/{upload_id}/process")
async def process_upload(
    upload_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """处理上传的文件"""
    upload = db.query(Upload).filter(Upload.id == upload_id).first()
    if not upload:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="上传文件不存在"
        )
    
    # 检查权限
    if not current_user.is_superuser and upload.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限处理该上传文件"
        )
    
    # 检查文件状态
    if upload.status != "uploaded":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="文件当前状态不允许处理"
        )
    
    # 更新状态为处理中
    upload.status = "processing"
    db.commit()
    
    try:
        # 这里可以添加文件处理逻辑
        # 例如：解析CSV、提取文本、分析图片等
        
        # 模拟处理过程
        import time
        time.sleep(2)
        
        # 处理完成
        upload.status = "processed"
        upload.metadata = {"processed_at": datetime.utcnow().isoformat()}
        db.commit()
        
        return {"message": "文件处理成功", "upload_id": upload.id}
        
    except Exception as e:
        upload.status = "failed"
        upload.metadata = {"error": str(e)}
        db.commit()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"文件处理失败: {str(e)}"
        )

@router.get("/{upload_id}/download")
async def download_upload(
    upload_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """下载上传的文件"""
    upload = db.query(Upload).filter(Upload.id == upload_id).first()
    if not upload:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="上传文件不存在"
        )
    
    # 检查权限
    if not current_user.is_superuser and upload.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限下载该文件"
        )
    
    # 检查文件是否存在
    if not os.path.exists(upload.file_path):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="文件不存在"
        )
    
    return FileResponse(
        path=upload.file_path,
        filename=upload.original_filename,
        media_type=upload.mime_type
    )

@router.delete("/{upload_id}")
async def delete_upload(
    upload_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """删除上传文件"""
    upload = db.query(Upload).filter(Upload.id == upload_id).first()
    if not upload:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="上传文件不存在"
        )
    
    # 检查权限
    if not current_user.is_superuser and upload.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="没有权限删除该上传文件"
        )
    
    # 删除物理文件
    try:
        if os.path.exists(upload.file_path):
            os.remove(upload.file_path)
    except Exception as e:
        print(f"删除文件失败: {e}")
    
    # 删除数据库记录
    db.delete(upload)
    db.commit()
    
    return {"message": "上传文件删除成功"}
