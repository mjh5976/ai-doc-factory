-- 创建数据库和用户
CREATE DATABASE ai_factory;
CREATE USER postgres WITH PASSWORD 'postgres123';
GRANT ALL PRIVILEGES ON DATABASE ai_factory TO postgres;

-- 连接到ai_factory数据库
\c ai_factory;

-- 创建扩展
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
