# AI工厂Web界面和本地API接口系统

一个简洁、功能完整的Web界面和本地API接口系统，支持文件上传、任务处理、结果展示、用户管理等核心功能。

## 🌟 主要特性

### 前端特性
- **现代化界面**: 基于Vue 3 + Element Plus构建的响应式Web界面
- **主题支持**: 支持明暗主题切换
- **实时更新**: WebSocket连接支持实时状态更新
- **文件上传**: 拖拽上传、进度显示、文件类型验证
- **数据可视化**: 集成ECharts图表库
- **用户体验**: 骨架屏、加载动画、错误提示

### 后端特性
- **高性能API**: 基于FastAPI构建的异步API服务
- **用户认证**: JWT令牌认证、角色权限控制
- **文件处理**: 支持多种文件格式的上传和处理
- **任务管理**: 异步任务处理、状态跟踪、进度监控
- **结果管理**: 结果存储、下载、导出功能
- **系统配置**: 灵活的配置管理系统
- **审计日志**: 完整的操作日志记录

### 部署特性
- **容器化**: 完整的Docker容器化方案
- **监控集成**: Prometheus + Grafana监控面板
- **负载均衡**: Nginx反向代理配置
- **数据持久化**: PostgreSQL + Redis + MinIO
- **一键部署**: 自动化部署脚本

## 🏗️ 系统架构

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Nginx         │    │   Vue Frontend  │    │   FastAPI       │
│   (反向代理)     │◄──►│   (用户界面)     │◄──►│   (后端API)     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                        │
                                                        ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   PostgreSQL    │    │     Redis       │    │     MinIO       │
│   (主数据库)     │    │   (缓存/队列)    │    │  (文件存储)      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                        │
                                                        ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Prometheus    │    │    Grafana      │    │   监控告警       │
│   (指标收集)     │    │   (可视化)       │    │   (系统监控)     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 🚀 快速开始

### 系统要求

- Docker 20.10+
- Docker Compose 2.0+
- 至少4GB内存
- 至少10GB磁盘空间

### 一键部署

1. **克隆项目**
   ```bash
   git clone <repository-url>
   cd web_interface_api
   ```

2. **配置环境变量**
   ```bash
   cp .env.example .env
   # 根据需要修改.env文件中的配置
   ```

3. **运行部署脚本**
   ```bash
   chmod +x scripts/deploy.sh
   ./scripts/deploy.sh
   ```

4. **访问系统**
   - 前端界面: http://localhost
   - 后端API: http://localhost:8000
   - API文档: http://localhost:8000/docs
   - 监控面板: http://localhost:3001

### 手动部署

如果需要手动控制部署过程：

1. **启动基础服务**
   ```bash
   docker-compose up -d postgres redis minio
   ```

2. **构建并启动应用**
   ```bash
   docker-compose up -d --build
   ```

3. **检查服务状态**
   ```bash
   docker-compose ps
   ```

## 📋 默认账号

部署完成后，系统会创建默认管理员账号：

- **用户名**: admin
- **密码**: admin123

⚠️ **安全提醒**: 生产环境请立即修改默认密码！

## 🔧 配置说明

### 环境变量配置

主要配置项说明：

```bash
# 数据库配置
DB_PASSWORD=postgres123

# Redis配置  
REDIS_PASSWORD=redis123

# MinIO配置
MINIO_ROOT_USER=minioadmin
MINIO_ROOT_PASSWORD=minio123

# 应用密钥（生产环境必须修改）
SECRET_KEY=your-secret-key-change-in-production
JWT_SECRET_KEY=your-jwt-secret-key-change-in-production

# 文件上传限制
UPLOAD_MAX_SIZE=52428800  # 50MB
UPLOAD_ALLOWED_EXTENSIONS=.txt,.csv,.json,.xlsx,.pdf,.png,.jpg
```

### 端口配置

| 服务 | 端口 | 说明 |
|------|------|------|
| Nginx | 80, 443 | Web入口 |
| 后端API | 8000 | API服务 |
| 前端 | 3000 | 开发模式端口 |
| PostgreSQL | 5432 | 数据库 |
| Redis | 6379 | 缓存 |
| MinIO | 9000, 9001 | 文件存储 |
| Prometheus | 9090 | 监控 |
| Grafana | 3001 | 可视化 |

## 📚 API文档

系统提供完整的RESTful API，主要端点包括：

### 认证相关
- `POST /api/v1/auth/login` - 用户登录
- `POST /api/v1/auth/register` - 用户注册

### 任务管理
- `GET /api/v1/tasks` - 获取任务列表
- `POST /api/v1/tasks` - 创建任务
- `GET /api/v1/tasks/{id}` - 获取任务详情
- `PUT /api/v1/tasks/{id}` - 更新任务
- `DELETE /api/v1/tasks/{id}` - 删除任务

### 文件上传
- `GET /api/v1/uploads` - 获取上传文件列表
- `POST /api/v1/uploads` - 上传文件
- `GET /api/v1/uploads/{id}` - 获取文件详情
- `DELETE /api/v1/uploads/{id}` - 删除文件

### 结果管理
- `GET /api/v1/results` - 获取结果列表
- `POST /api/v1/results` - 创建结果
- `GET /api/v1/results/{id}` - 获取结果详情
- `GET /api/v1/results/{id}/download` - 下载结果

完整的API文档可在 http://localhost:8000/docs 查看。

## 🛠️ 开发指南

### 本地开发环境

1. **后端开发**
   ```bash
   cd backend
   pip install -r requirements.txt
   uvicorn main:app --reload --host 0.0.0.0 --port 8000
   ```

2. **前端开发**
   ```bash
   cd frontend
   npm install
   npm run dev
   ```

### 代码结构

```
web_interface_api/
├── backend/                 # 后端代码
│   ├── main.py             # 应用入口
│   ├── database/           # 数据库配置
│   ├── routers/            # API路由
│   ├── utils/              # 工具函数
│   └── requirements.txt    # Python依赖
├── frontend/               # 前端代码
│   ├── src/               # 源代码
│   ├── public/            # 静态资源
│   ├── package.json       # Node.js依赖
│   └── vite.config.js     # Vite配置
├── nginx/                  # Nginx配置
├── monitoring/             # 监控配置
├── scripts/                # 部署脚本
├── docker-compose.yml      # Docker Compose配置
└── .env.example           # 环境变量模板
```

### 添加新功能

1. **后端API**: 在 `backend/routers/` 目录下创建新的路由文件
2. **前端页面**: 在 `frontend/src/views/` 目录下创建新的页面组件
3. **数据库模型**: 在 `backend/database/models.py` 中定义数据模型
4. **API接口**: 在 `frontend/src/api/index.js` 中定义前端API调用

## 📊 监控和日志

### 监控面板

- **Grafana**: http://localhost:3001
  - 默认账号: admin / admin123
  - 包含系统性能、API调用、任务状态等监控面板

### 日志查看

```bash
# 查看所有服务日志
docker-compose logs -f

# 查看特定服务日志
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f nginx
```

### 性能监控

- API响应时间
- 任务处理时间
- 系统资源使用情况
- 数据库性能指标

## 🔒 安全特性

### 认证和授权
- JWT令牌认证
- 基于角色的访问控制(RBAC)
- 会话管理
- 密码加密存储

### 安全措施
- CORS跨域保护
- SQL注入防护
- XSS攻击防护
- 文件上传安全验证
- API限流保护

### 审计日志
- 用户登录记录
- 操作行为追踪
- 系统变更日志
- 访问日志记录

## 🐛 故障排除

### 常见问题

1. **服务启动失败**
   ```bash
   # 检查端口占用
   netstat -tlnp | grep :8000
   
   # 检查Docker状态
   docker-compose ps
   docker-compose logs
   ```

2. **数据库连接失败**
   ```bash
   # 重启数据库服务
   docker-compose restart postgres
   
   # 检查数据库日志
   docker-compose logs postgres
   ```

3. **文件上传失败**
   - 检查MinIO服务状态
   - 确认文件大小限制
   - 验证文件类型权限

### 日志分析

关键日志位置：
- 应用日志: `docker-compose logs backend`
- Nginx日志: `docker-compose logs nginx`
- 数据库日志: `docker-compose logs postgres`

## 📈 性能优化

### 数据库优化
- 连接池配置
- 索引优化
- 查询性能调优

### 缓存策略
- Redis缓存配置
- 前端静态资源缓存
- API响应缓存

### 负载均衡
- Nginx负载均衡配置
- 水平扩展支持

## 🤝 贡献指南

1. Fork项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启Pull Request

## 📄 许可证

本项目采用MIT许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 📞 支持

如有问题或建议，请：

1. 查看文档和FAQ
2. 搜索已有的Issues
3. 创建新的Issue
4. 联系开发团队

## 🔄 更新日志

### v1.0.0 (2024-01-01)
- 初始版本发布
- 基础功能实现
- 容器化部署支持
- 监控集成

---

**AI工厂Web界面系统** - 让AI应用开发更简单、更高效！
