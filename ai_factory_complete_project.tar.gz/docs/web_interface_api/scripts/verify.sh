#!/bin/bash

# AI工厂Web界面系统部署验证脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查服务状态
check_service() {
    local service_name=$1
    local url=$2
    local expected_status=$3
    
    log_info "检查 $service_name..."
    
    if curl -f -s -o /dev/null -w "%{http_code}" "$url" | grep -q "$expected_status"; then
        log_success "$service_name 运行正常"
        return 0
    else
        log_error "$service_name 不可访问"
        return 1
    fi
}

# 检查数据库连接
check_database() {
    log_info "检查数据库连接..."
    
    if docker-compose exec -T postgres pg_isready -U postgres &> /dev/null; then
        log_success "PostgreSQL 连接正常"
        return 0
    else
        log_error "PostgreSQL 连接失败"
        return 1
    fi
}

# 检查Redis连接
check_redis() {
    log_info "检查Redis连接..."
    
    if docker-compose exec -T redis redis-cli ping | grep -q PONG; then
        log_success "Redis 连接正常"
        return 0
    else
        log_error "Redis 连接失败"
        return 1
    fi
}

# 检查容器状态
check_containers() {
    log_info "检查容器状态..."
    
    local failed_containers=0
    
    while IFS= read -r line; do
        container_name=$(echo "$line" | awk '{print $1}')
        container_status=$(echo "$line" | awk '{print $NF}')
        
        if [ "$container_status" != "Up" ]; then
            log_error "容器 $container_name 状态异常: $container_status"
            failed_containers=$((failed_containers + 1))
        fi
    done < <(docker-compose ps --services --filter "status=running" || true)
    
    if [ $failed_containers -eq 0 ]; then
        log_success "所有容器运行正常"
        return 0
    else
        log_error "$failed_containers 个容器状态异常"
        return 1
    fi
}

# 检查端口占用
check_ports() {
    log_info "检查端口占用..."
    
    local ports=(80 8000 5432 6379 9000 9090 3001)
    local occupied_ports=()
    
    for port in "${ports[@]}"; do
        if netstat -tlnp 2>/dev/null | grep -q ":$port "; then
            log_success "端口 $port 占用正常"
        else
            log_warning "端口 $port 未占用"
            occupied_ports+=("$port")
        fi
    done
    
    if [ ${#occupied_ports[@]} -gt 0 ]; then
        log_warning "未占用的端口: ${occupied_ports[*]}"
    fi
    
    return 0
}

# 检查磁盘空间
check_disk_space() {
    log_info "检查磁盘空间..."
    
    local available_space=$(df -BG . | awk 'NR==2 {print $4}' | sed 's/G//')
    
    if [ "$available_space" -gt 5 ]; then
        log_success "磁盘空间充足: ${available_space}GB"
        return 0
    else
        log_warning "磁盘空间不足: ${available_space}GB"
        return 1
    fi
}

# 检查内存使用
check_memory() {
    log_info "检查内存使用..."
    
    local memory_usage=$(free | grep Mem | awk '{printf("%.1f", $3/$2 * 100.0)}')
    local memory_total=$(free -h | grep Mem | awk '{print $2}')
    
    if (( $(echo "$memory_usage < 90" | bc -l) )); then
        log_success "内存使用正常: ${memory_usage}% / ${memory_total}"
        return 0
    else
        log_warning "内存使用过高: ${memory_usage}% / ${memory_total}"
        return 1
    fi
}

# 检查日志错误
check_logs() {
    log_info "检查应用日志..."
    
    local error_count=0
    
    # 检查后端日志
    if docker-compose logs backend 2>/dev/null | grep -i error | tail -5 | grep -q .; then
        log_warning "后端日志中发现错误"
        error_count=$((error_count + 1))
    fi
    
    # 检查Nginx日志
    if docker-compose logs nginx 2>/dev/null | grep -i error | tail -5 | grep -q .; then
        log_warning "Nginx日志中发现错误"
        error_count=$((error_count + 1))
    fi
    
    if [ $error_count -eq 0 ]; then
        log_success "应用日志检查通过"
        return 0
    else
        log_warning "发现 $error_count 个服务存在错误日志"
        return 1
    fi
}

# 性能测试
performance_test() {
    log_info "执行性能测试..."
    
    # 测试API响应时间
    local response_time=$(curl -o /dev/null -s -w "%{time_total}" http://localhost:8000/health)
    
    if (( $(echo "$response_time < 2.0" | bc -l) )); then
        log_success "API响应时间正常: ${response_time}s"
        return 0
    else
        log_warning "API响应时间较慢: ${response_time}s"
        return 1
    fi
}

# 生成报告
generate_report() {
    local report_file="deployment_report_$(date +%Y%m%d_%H%M%S).txt"
    
    log_info "生成部署报告: $report_file"
    
    {
        echo "AI工厂Web界面系统部署验证报告"
        echo "================================"
        echo "生成时间: $(date)"
        echo ""
        
        echo "服务状态:"
        docker-compose ps
        echo ""
        
        echo "资源使用:"
        echo "CPU使用率:"
        top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}' | xargs -I {} echo "  {}%"
        echo ""
        
        echo "内存使用:"
        free -h
        echo ""
        
        echo "磁盘使用:"
        df -h
        echo ""
        
        echo "网络连接:"
        netstat -tlnp 2>/dev/null | grep -E ':(80|8000|5432|6379|9000|9090|3001) '
        echo ""
        
        echo "容器资源使用:"
        docker stats --no-stream --format "table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.NetIO}}\t{{.BlockIO}}"
        
    } > "$report_file"
    
    log_success "报告已保存到: $report_file"
}

# 主函数
main() {
    echo ""
    echo "=========================================="
    echo "    AI工厂Web界面系统部署验证"
    echo "=========================================="
    echo ""
    
    local failed_checks=0
    
    # 基础检查
    check_containers || failed_checks=$((failed_checks + 1))
    check_database || failed_checks=$((failed_checks + 1))
    check_redis || failed_checks=$((failed_checks + 1))
    
    # 服务检查
    check_service "Web界面" "http://localhost" "200" || failed_checks=$((failed_checks + 1))
    check_service "API服务" "http://localhost:8000/health" "200" || failed_checks=$((failed_checks + 1))
    check_service "API文档" "http://localhost:8000/docs" "200" || failed_checks=$((failed_checks + 1))
    check_service "监控面板" "http://localhost:3001" "200" || failed_checks=$((failed_checks + 1))
    
    # 资源检查
    check_ports
    check_disk_space
    check_memory
    
    # 应用检查
    check_logs
    performance_test
    
    # 生成报告
    generate_report
    
    echo ""
    echo "=========================================="
    if [ $failed_checks -eq 0 ]; then
        log_success "部署验证完成 - 所有检查通过！"
    else
        log_warning "部署验证完成 - $failed_checks 个检查失败"
        log_info "请查看日志排查问题"
    fi
    echo "=========================================="
    echo ""
}

# 显示帮助
show_help() {
    echo "AI工厂Web界面系统部署验证脚本"
    echo ""
    echo "用法: $0 [选项]"
    echo ""
    echo "选项:"
    echo "  -h, --help     显示此帮助信息"
    echo "  --quick        快速检查(仅基础服务)"
    echo "  --full         完整检查(默认)"
    echo "  --report       仅生成报告"
    echo ""
}

# 解析命令行参数
case "${1:-}" in
    -h|--help)
        show_help
        exit 0
        ;;
    --quick)
        log_info "执行快速检查..."
        check_containers
        check_database
        check_redis
        check_service "Web界面" "http://localhost" "200"
        check_service "API服务" "http://localhost:8000/health" "200"
        ;;
    --report)
        generate_report
        exit 0
        ;;
    --full|"")
        main
        ;;
    *)
        log_error "未知选项: $1"
        show_help
        exit 1
        ;;
esac
