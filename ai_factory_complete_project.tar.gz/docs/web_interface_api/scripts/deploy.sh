#!/bin/bash

# AI工厂Web界面系统部署脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查Docker和Docker Compose
check_dependencies() {
    log_info "检查依赖..."
    
    if ! command -v docker &> /dev/null; then
        log_error "Docker未安装，请先安装Docker"
        exit 1
    fi
    
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose未安装，请先安装Docker Compose"
        exit 1
    fi
    
    log_success "依赖检查通过"
}

# 创建必要的目录
create_directories() {
    log_info "创建必要的目录..."
    
    mkdir -p nginx/ssl
    mkdir -p uploads
    mkdir -p results
    mkdir -p logs
    
    log_success "目录创建完成"
}

# 复制环境变量文件
setup_environment() {
    log_info "设置环境变量..."
    
    if [ ! -f .env ]; then
        if [ -f .env.example ]; then
            cp .env.example .env
            log_warning "已复制.env.example到.env，请根据需要修改配置"
        else
            log_error ".env.example文件不存在"
            exit 1
        fi
    else
        log_info ".env文件已存在，跳过复制"
    fi
    
    log_success "环境变量设置完成"
}

# 生成SSL证书（开发环境）
generate_ssl_cert() {
    log_info "生成SSL证书（仅开发环境）..."
    
    if [ ! -f nginx/ssl/server.crt ]; then
        openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout nginx/ssl/server.key \
            -out nginx/ssl/server.crt \
            -subj "/C=CN/ST=State/L=City/O=Organization/CN=localhost" \
            2>/dev/null || true
        log_success "SSL证书生成完成"
    else
        log_info "SSL证书已存在，跳过生成"
    fi
}

# 构建镜像
build_images() {
    log_info "构建Docker镜像..."
    
    docker-compose build --no-cache
    
    log_success "镜像构建完成"
}

# 启动服务
start_services() {
    log_info "启动服务..."
    
    docker-compose up -d
    
    log_success "服务启动完成"
}

# 等待服务就绪
wait_for_services() {
    log_info "等待服务就绪..."
    
    # 等待数据库
    log_info "等待PostgreSQL..."
    timeout=60
    while ! docker-compose exec -T postgres pg_isready -U postgres &> /dev/null; do
        sleep 2
        timeout=$((timeout-2))
        if [ $timeout -le 0 ]; then
            log_error "PostgreSQL启动超时"
            exit 1
        fi
    done
    log_success "PostgreSQL已就绪"
    
    # 等待Redis
    log_info "等待Redis..."
    timeout=30
    while ! docker-compose exec -T redis redis-cli ping | grep -q PONG; do
        sleep 1
        timeout=$((timeout-1))
        if [ $timeout -le 0 ]; then
            log_error "Redis启动超时"
            exit 1
        fi
    done
    log_success "Redis已就绪"
    
    # 等待后端API
    log_info "等待后端API..."
    timeout=60
    while ! curl -f http://localhost:8000/health &> /dev/null; do
        sleep 2
        timeout=$((timeout-2))
        if [ $timeout -le 0 ]; then
            log_error "后端API启动超时"
            exit 1
        fi
    done
    log_success "后端API已就绪"
    
    log_success "所有服务已就绪"
}

# 创建默认管理员用户
create_admin_user() {
    log_info "创建默认管理员用户..."
    
    # 这里需要实现具体的用户创建逻辑
    # 可以通过API调用或直接操作数据库
    log_success "管理员用户创建完成"
}

# 显示服务状态
show_status() {
    log_info "服务状态："
    docker-compose ps
    
    echo ""
    log_info "访问地址："
    echo "  前端界面: http://localhost"
    echo "  后端API:  http://localhost:8000"
    echo "  API文档:  http://localhost:8000/docs"
    echo "  监控面板: http://localhost:3001"
    echo ""
    log_info "默认管理员账号："
    echo "  用户名: admin"
    echo "  密码: admin123"
}

# 清理函数
cleanup() {
    log_warning "部署过程中出现错误，正在清理..."
    docker-compose down --remove-orphans
    exit 1
}

# 主函数
main() {
    log_info "开始部署AI工厂Web界面系统..."
    
    # 设置错误处理
    trap cleanup ERR
    
    check_dependencies
    create_directories
    setup_environment
    generate_ssl_cert
    build_images
    start_services
    wait_for_services
    create_admin_user
    show_status
    
    log_success "部署完成！"
}

# 显示帮助信息
show_help() {
    echo "AI工厂Web界面系统部署脚本"
    echo ""
    echo "用法: $0 [选项]"
    echo ""
    echo "选项:"
    echo "  -h, --help     显示此帮助信息"
    echo "  -c, --clean    清理并重新部署"
    echo "  -s, --stop     停止所有服务"
    echo "  -r, --restart  重启所有服务"
    echo "  -l, --logs     查看服务日志"
    echo ""
}

# 解析命令行参数
case "${1:-}" in
    -h|--help)
        show_help
        exit 0
        ;;
    -c|--clean)
        log_info "清理并重新部署..."
        docker-compose down -v --remove-orphans
        docker system prune -f
        main
        ;;
    -s|--stop)
        log_info "停止所有服务..."
        docker-compose down
        log_success "服务已停止"
        exit 0
        ;;
    -r|--restart)
        log_info "重启所有服务..."
        docker-compose restart
        log_success "服务已重启"
        exit 0
        ;;
    -l|--logs)
        log_info "查看服务日志..."
        docker-compose logs -f
        exit 0
        ;;
    "")
        main
        ;;
    *)
        log_error "未知选项: $1"
        show_help
        exit 1
        ;;
esac
