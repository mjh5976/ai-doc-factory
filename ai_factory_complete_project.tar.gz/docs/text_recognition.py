"""
文本识别和布局分析模块
负责OCR文本检测、识别和布局分析
"""

import os
import sys
import logging
import numpy as np
import cv2
import re
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, asdict
from pathlib import Path
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# 导入配置
sys.path.append(str(Path(__file__).parent.parent))
from pdf_ocr_config import get_config

# 导入基础模块
from pdf_parser import BoundingBox, TextElement

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class LayoutElement:
    """布局元素数据类"""
    element_type: str  # title, subtitle, paragraph, table, figure, caption, dimension, annotation
    bbox: BoundingBox
    confidence: float
    content: str
    hierarchy_level: int = 0
    parent_element: Optional['LayoutElement'] = None
    child_elements: List['LayoutElement'] = None
    
    def __post_init__(self):
        if self.child_elements is None:
            self.child_elements = []
    
    def to_dict(self):
        return {
            'element_type': self.element_type,
            'bbox': self.bbox.to_dict(),
            'confidence': self.confidence,
            'content': self.content,
            'hierarchy_level': self.hierarchy_level,
            'parent_element': self.parent_element.element_type if self.parent_element else None,
            'child_elements': [child.to_dict() for child in self.child_elements]
        }

@dataclass
class DimensionAnnotation:
    """尺寸标注数据类"""
    dimension_value: str
    dimension_type: str  # length, angle, radius, diameter, area, volume
    unit: str
    tolerance: Optional[str] = None
    precision: int = 2
    bbox: Optional[BoundingBox] = None
    confidence: float = 1.0
    
    def to_dict(self):
        return {
            'dimension_value': self.dimension_value,
            'dimension_type': self.dimension_type,
            'unit': self.unit,
            'tolerance': self.tolerance,
            'precision': self.precision,
            'bbox': self.bbox.to_dict() if self.bbox else None,
            'confidence': self.confidence
        }

class TextPreprocessor:
    """文本预处理类"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        self.text_config = self.config["text_recognition"]
    
    def enhance_image_for_ocr(self, image: np.ndarray) -> np.ndarray:
        """
        增强图像以提高OCR精度
        
        Args:
            image: 输入图像
            
        Returns:
            np.ndarray: 增强后的图像
        """
        try:
            # 转换为灰度图
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
            
            # 去噪
            denoised = cv2.medianBlur(gray, 3)
            
            # 对比度增强
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
            enhanced = clahe.apply(denoised)
            
            # 二值化
            _, binary = cv2.threshold(enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # 形态学操作
            kernel = np.ones((2, 2), np.uint8)
            cleaned = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
            
            logger.debug("图像预处理完成")
            return cleaned
            
        except Exception as e:
            logger.error(f"图像预处理失败: {e}")
            return image
    
    def detect_text_regions(self, image: np.ndarray) -> List[BoundingBox]:
        """
        检测文本区域
        
        Args:
            image: 输入图像
            
        Returns:
            List[BoundingBox]: 文本区域边界框列表
        """
        try:
            # 转换为灰度图
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()
            
            # 使用MSER检测文本区域
            mser = cv2.MSER_create()
            regions, _ = mser.detectRegions(gray)
            
            # 过滤和合并区域
            bboxes = []
            for region in regions:
                x, y, w, h = cv2.boundingRect(region)
                
                # 过滤太小或太大的区域
                if (w > 5 and h > 5 and 
                    w < image.shape[1] * 0.8 and 
                    h < image.shape[0] * 0.8):
                    bboxes.append(BoundingBox(x, y, w, h))
            
            # 合并重叠的区域
            merged_bboxes = self._merge_overlapping_bboxes(bboxes)
            
            logger.debug(f"检测到 {len(merged_bboxes)} 个文本区域")
            return merged_bboxes
            
        except Exception as e:
            logger.error(f"文本区域检测失败: {e}")
            return []
    
    def _merge_overlapping_bboxes(self, bboxes: List[BoundingBox], 
                                 overlap_threshold: float = 0.3) -> List[BoundingBox]:
        """
        合并重叠的边界框
        
        Args:
            bboxes: 边界框列表
            overlap_threshold: 重叠阈值
            
        Returns:
            List[BoundingBox]: 合并后的边界框列表
        """
        if not bboxes:
            return []
        
        # 按面积排序
        sorted_bboxes = sorted(bboxes, key=lambda x: x.area(), reverse=True)
        merged = []
        
        for bbox in sorted_bboxes:
            is_merged = False
            for i, existing in enumerate(merged):
                if self._calculate_overlap_ratio(bbox, existing) > overlap_threshold:
                    # 合并边界框
                    merged[i] = self._merge_bboxes(bbox, existing)
                    is_merged = True
                    break
            
            if not is_merged:
                merged.append(bbox)
        
        return merged
    
    def _calculate_overlap_ratio(self, bbox1: BoundingBox, bbox2: BoundingBox) -> float:
        """计算两个边界框的重叠比例"""
        if not bbox1.intersects(bbox2):
            return 0.0
        
        intersection_x = max(0, min(bbox1.x + bbox1.width, bbox2.x + bbox2.width) - max(bbox1.x, bbox2.x))
        intersection_y = max(0, min(bbox1.y + bbox1.height, bbox2.y + bbox2.height) - max(bbox1.y, bbox2.y))
        intersection_area = intersection_x * intersection_y
        
        union_area = bbox1.area() + bbox2.area() - intersection_area
        return intersection_area / union_area if union_area > 0 else 0.0
    
    def _merge_bboxes(self, bbox1: BoundingBox, bbox2: BoundingBox) -> BoundingBox:
        """合并两个边界框"""
        x = min(bbox1.x, bbox2.x)
        y = min(bbox1.y, bbox2.y)
        width = max(bbox1.x + bbox1.width, bbox2.x + bbox2.width) - x
        height = max(bbox1.y + bbox1.height, bbox2.y + bbox2.height) - y
        
        return BoundingBox(x, y, width, height)

class LayoutAnalyzer:
    """布局分析类"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        self.layout_config = self.config.get("layout_analysis", {})
    
    def analyze_layout(self, text_elements: List[TextElement], 
                      image_shape: Tuple[int, int]) -> List[LayoutElement]:
        """
        分析文档布局
        
        Args:
            text_elements: 文本元素列表
            image_shape: 图像形状 (height, width)
            
        Returns:
            List[LayoutElement]: 布局元素列表
        """
        try:
            layout_elements = []
            
            # 按行分组文本元素
            lines = self._group_text_into_lines(text_elements)
            
            # 分析页面结构
            title_elements = self._detect_titles(lines)
            paragraph_elements = self._detect_paragraphs(lines)
            table_elements = self._detect_tables(text_elements)
            dimension_elements = self._detect_dimensions(text_elements)
            
            # 合并所有布局元素
            layout_elements.extend(title_elements)
            layout_elements.extend(paragraph_elements)
            layout_elements.extend(table_elements)
            layout_elements.extend(dimension_elements)
            
            # 建立层次关系
            self._build_hierarchy(layout_elements)
            
            logger.debug(f"布局分析完成，识别到 {len(layout_elements)} 个布局元素")
            return layout_elements
            
        except Exception as e:
            logger.error(f"布局分析失败: {e}")
            return []
    
    def _group_text_into_lines(self, text_elements: List[TextElement]) -> List[List[TextElement]]:
        """将文本元素按行分组"""
        if not text_elements:
            return []
        
        # 按Y坐标排序
        sorted_elements = sorted(text_elements, key=lambda x: x.bbox.y)
        
        lines = []
        current_line = []
        line_threshold = 10  # Y坐标阈值
        
        for element in sorted_elements:
            if not current_line:
                current_line = [element]
            else:
                # 检查是否属于同一行
                last_element = current_line[-1]
                if abs(element.bbox.y - last_element.bbox.y) <= line_threshold:
                    current_line.append(element)
                else:
                    lines.append(current_line)
                    current_line = [element]
        
        if current_line:
            lines.append(current_line)
        
        return lines
    
    def _detect_titles(self, lines: List[List[TextElement]]) -> List[LayoutElement]:
        """检测标题"""
        title_elements = []
        
        for line in lines:
            if not line:
                continue
            
            # 计算行的特征
            total_width = sum(elem.bbox.width for elem in line)
            avg_font_size = np.mean([elem.font_size for elem in line])
            text_content = ' '.join(elem.text for elem in line)
            
            # 标题特征：大字体、居中或靠左、较短文本
            if (avg_font_size > 16 and 
                total_width > 0 and 
                len(text_content) < 100):
                
                # 计算边界框
                x = min(elem.bbox.x for elem in line)
                y = min(elem.bbox.y for elem in line)
                width = max(elem.bbox.x + elem.bbox.width for elem in line) - x
                height = max(elem.bbox.y + elem.bbox.height for elem in line) - y
                
                bbox = BoundingBox(x, y, width, height)
                
                title_element = LayoutElement(
                    element_type="title",
                    bbox=bbox,
                    confidence=0.8,
                    content=text_content,
                    hierarchy_level=1
                )
                title_elements.append(title_element)
        
        return title_elements
    
    def _detect_paragraphs(self, lines: List[List[TextElement]]) -> List[LayoutElement]:
        """检测段落"""
        paragraph_elements = []
        
        for line in lines:
            if not line:
                continue
            
            text_content = ' '.join(elem.text for elem in line)
            
            # 段落特征：中等字体、较长文本
            if len(text_content) > 10:
                # 计算边界框
                x = min(elem.bbox.x for elem in line)
                y = min(elem.bbox.y for elem in line)
                width = max(elem.bbox.x + elem.bbox.width for elem in line) - x
                height = max(elem.bbox.y + elem.bbox.height for elem in line) - y
                
                bbox = BoundingBox(x, y, width, height)
                
                paragraph_element = LayoutElement(
                    element_type="paragraph",
                    bbox=bbox,
                    confidence=0.7,
                    content=text_content,
                    hierarchy_level=2
                )
                paragraph_elements.append(paragraph_element)
        
        return paragraph_elements
    
    def _detect_tables(self, text_elements: List[TextElement]) -> List[LayoutElement]:
        """检测表格"""
        table_elements = []
        
        try:
            # 按Y坐标分组
            sorted_elements = sorted(text_elements, key=lambda x: x.bbox.y)
            rows = []
            current_row = []
            row_threshold = 15
            
            for element in sorted_elements:
                if not current_row:
                    current_row = [element]
                else:
                    last_element = current_row[-1]
                    if abs(element.bbox.y - last_element.bbox.y) <= row_threshold:
                        current_row.append(element)
                    else:
                        rows.append(current_row)
                        current_row = [element]
            
            if current_row:
                rows.append(current_row)
            
            # 检测表格模式：多行、多列、规则排列
            if len(rows) >= 3:  # 至少3行
                table_detected = True
                for row in rows:
                    if len(row) < 2:  # 每行至少2列
                        table_detected = False
                        break
                
                if table_detected:
                    # 计算表格边界框
                    all_elements = [elem for row in rows for elem in row]
                    x = min(elem.bbox.x for elem in all_elements)
                    y = min(elem.bbox.y for elem in all_elements)
                    width = max(elem.bbox.x + elem.bbox.width for elem in all_elements) - x
                    height = max(elem.bbox.y + elem.bbox.height for elem in all_elements) - y
                    
                    bbox = BoundingBox(x, y, width, height)
                    
                    table_content = '\n'.join([' '.join(elem.text for elem in row) for row in rows])
                    
                    table_element = LayoutElement(
                        element_type="table",
                        bbox=bbox,
                        confidence=0.8,
                        content=table_content,
                        hierarchy_level=2
                    )
                    table_elements.append(table_element)
        
        except Exception as e:
            logger.warning(f"表格检测失败: {e}")
        
        return table_elements
    
    def _detect_dimensions(self, text_elements: List[TextElement]) -> List[LayoutElement]:
        """检测尺寸标注"""
        dimension_elements = []
        
        for element in text_elements:
            text = element.text.strip()
            
            # 检测尺寸模式
            dimension_patterns = [
                r'\d+\.?\d*\s*(mm|cm|m|inch|ft|°|deg)',
                r'⌀\s*\d+\.?\d*',
                r'±\s*\d+\.?\d*',
                r'\d+\.?\d*\s*±\s*\d+\.?\d*',
                r'⏤\s*\d+\.?\d*',
                r'∥\s*\d+\.?\d*',
                r'⊥\s*\d+\.?\d*'
            ]
            
            for pattern in dimension_patterns:
                if re.search(pattern, text, re.IGNORECASE):
                    dimension_element = LayoutElement(
                        element_type="dimension",
                        bbox=element.bbox,
                        confidence=0.9,
                        content=text,
                        hierarchy_level=3
                    )
                    dimension_elements.append(dimension_element)
                    break
        
        return dimension_elements
    
    def _build_hierarchy(self, layout_elements: List[LayoutElement]):
        """建立布局元素的层次关系"""
        # 简单的层次关系建立：标题包含段落
        for i, element in enumerate(layout_elements):
            if element.element_type == "title":
                for j, other in enumerate(layout_elements):
                    if (i != j and other.element_type == "paragraph" and
                        self._is_contained(element.bbox, other.bbox)):
                        element.child_elements.append(other)
                        other.parent_element = element

class DimensionExtractor:
    """尺寸标注提取器"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        self.dimension_config = self.config["dimension_recognition"]
    
    def extract_dimensions(self, text_elements: List[TextElement]) -> List[DimensionAnnotation]:
        """
        提取尺寸标注
        
        Args:
            text_elements: 文本元素列表
            
        Returns:
            List[DimensionAnnotation]: 尺寸标注列表
        """
        try:
            dimensions = []
            
            for element in text_elements:
                text = element.text.strip()
                
                # 检测不同类型的尺寸
                length_dim = self._extract_length_dimension(text)
                if length_dim:
                    length_dim.bbox = element.bbox
                    length_dim.confidence = element.confidence
                    dimensions.append(length_dim)
                
                angle_dim = self._extract_angle_dimension(text)
                if angle_dim:
                    angle_dim.bbox = element.bbox
                    angle_dim.confidence = element.confidence
                    dimensions.append(angle_dim)
                
                tolerance_dim = self._extract_tolerance_dimension(text)
                if tolerance_dim:
                    tolerance_dim.bbox = element.bbox
                    tolerance_dim.confidence = element.confidence
                    dimensions.append(tolerance_dim)
            
            logger.debug(f"提取到 {len(dimensions)} 个尺寸标注")
            return dimensions
            
        except Exception as e:
            logger.error(f"尺寸标注提取失败: {e}")
            return []
    
    def _extract_length_dimension(self, text: str) -> Optional[DimensionAnnotation]:
        """提取长度尺寸"""
        patterns = self.dimension_config["value_extraction"]["number_patterns"]
        units = self.dimension_config["value_extraction"]["unit_patterns"]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                value = match.group()
                
                # 查找单位
                unit = "unknown"
                for u in units:
                    if u in text.lower():
                        unit = u
                        break
                
                return DimensionAnnotation(
                    dimension_value=value,
                    dimension_type="length",
                    unit=unit
                )
        
        return None
    
    def _extract_angle_dimension(self, text: str) -> Optional[DimensionAnnotation]:
        """提取角度尺寸"""
        angle_patterns = [
            r'(\d+\.?\d*)\s*(°|deg)',
            r'∠\s*(\d+\.?\d*)',
            r'⏤\s*(\d+\.?\d*)'
        ]
        
        for pattern in angle_patterns:
            match = re.search(pattern, text)
            if match:
                value = match.group(1)
                return DimensionAnnotation(
                    dimension_value=value,
                    dimension_type="angle",
                    unit="degree"
                )
        
        return None
    
    def _extract_tolerance_dimension(self, text: str) -> Optional[DimensionAnnotation]:
        """提取公差尺寸"""
        tolerance_patterns = self.dimension_config["value_extraction"]["tolerance_patterns"]
        
        for pattern in tolerance_patterns:
            match = re.search(pattern, text)
            if match:
                tolerance = match.group()
                return DimensionAnnotation(
                    dimension_value="0",  # 基础值
                    dimension_type="tolerance",
                    unit="unknown",
                    tolerance=tolerance
                )
        
        return None

class TextRecognitionSystem:
    """文本识别系统主类"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        
        # 初始化组件
        self.preprocessor = TextPreprocessor(self.config)
        self.layout_analyzer = LayoutAnalyzer(self.config)
        self.dimension_extractor = DimensionExtractor(self.config)
        
        logger.info("文本识别系统初始化完成")
    
    def recognize_text_and_layout(self, image: np.ndarray) -> Dict[str, Any]:
        """
        识别文本和布局
        
        Args:
            image: 输入图像
            
        Returns:
            Dict: 识别结果
        """
        try:
            logger.info("开始文本识别和布局分析")
            
            # 1. 图像预处理
            enhanced_image = self.preprocessor.enhance_image_for_ocr(image)
            
            # 2. 检测文本区域
            text_regions = self.preprocessor.detect_text_regions(enhanced_image)
            
            # 3. 使用多个OCR引擎提取文本
            all_text_elements = []
            
            # 这里应该调用实际的OCR引擎
            # 为了演示，我们使用模拟数据
            mock_text_elements = self._mock_text_extraction(image, text_regions)
            all_text_elements.extend(mock_text_elements)
            
            # 4. 布局分析
            layout_elements = self.layout_analyzer.analyze_layout(
                all_text_elements, image.shape
            )
            
            # 5. 尺寸标注提取
            dimensions = self.dimension_extractor.extract_dimensions(all_text_elements)
            
            # 6. 组合结果
            result = {
                "text_elements": [elem.to_dict() for elem in all_text_elements],
                "layout_elements": [elem.to_dict() for elem in layout_elements],
                "dimensions": [dim.to_dict() for dim in dimensions],
                "text_regions": [bbox.to_dict() for bbox in text_regions],
                "enhanced_image": enhanced_image.tolist() if isinstance(enhanced_image, np.ndarray) else enhanced_image
            }
            
            logger.info(f"文本识别完成：{len(all_text_elements)} 个文本元素，"
                       f"{len(layout_elements)} 个布局元素，{len(dimensions)} 个尺寸标注")
            
            return result
            
        except Exception as e:
            logger.error(f"文本识别失败: {e}")
            return {
                "text_elements": [],
                "layout_elements": [],
                "dimensions": [],
                "text_regions": [],
                "error": str(e)
            }
    
    def _mock_text_extraction(self, image: np.ndarray, 
                            text_regions: List[BoundingBox]) -> List[TextElement]:
        """模拟文本提取（实际应用中应该调用真实的OCR引擎）"""
        text_elements = []
        
        # 这里模拟一些文本提取结果
        mock_texts = [
            "Technical Drawing",
            "Section A-A",
            "Dimensions in mm",
            "R25",
            "±0.5",
            "100",
            "150",
            "200"
        ]
        
        for i, bbox in enumerate(text_regions[:len(mock_texts)]):
            text = mock_texts[i] if i < len(mock_texts) else f"Text_{i+1}"
            
            text_element = TextElement(
                text=text,
                bbox=bbox,
                confidence=0.9,
                font_size=12,
                font_name="Arial",
                ocr_engine="mock"
            )
            text_elements.append(text_element)
        
        return text_elements
    
    def recognize_text_from_regions(self, image: np.ndarray, 
                                  regions: List[BoundingBox]) -> List[TextElement]:
        """
        从指定区域识别文本
        
        Args:
            image: 输入图像
            regions: 文本区域列表
            
        Returns:
            List[TextElement]: 文本元素列表
        """
        text_elements = []
        
        for region in regions:
            try:
                # 裁剪区域
                x, y, w, h = int(region.x), int(region.y), int(region.width), int(region.height)
                cropped_image = image[y:y+h, x:x+w]
                
                # 预处理
                enhanced_image = self.preprocessor.enhance_image_for_ocr(cropped_image)
                
                # 模拟OCR结果
                mock_text = f"Region_{len(text_elements)+1}"
                
                text_element = TextElement(
                    text=mock_text,
                    bbox=region,
                    confidence=0.8,
                    font_size=12,
                    font_name="Arial",
                    ocr_engine="region_ocr"
                )
                text_elements.append(text_element)
                
            except Exception as e:
                logger.warning(f"区域文本识别失败: {e}")
                continue
        
        return text_elements

# 辅助函数
def calculate_text_density(text_elements: List[TextElement], 
                          image_shape: Tuple[int, int]) -> float:
    """计算文本密度"""
    if not text_elements or image_shape[0] == 0 or image_shape[1] == 0:
        return 0.0
    
    total_text_area = sum(elem.bbox.area() for elem in text_elements)
    image_area = image_shape[0] * image_shape[1]
    
    return total_text_area / image_area if image_area > 0 else 0.0

def filter_text_by_confidence(text_elements: List[TextElement], 
                            min_confidence: float = 0.5) -> List[TextElement]:
    """根据置信度过滤文本元素"""
    return [elem for elem in text_elements if elem.confidence >= min_confidence]

def sort_text_elements_by_position(text_elements: List[TextElement]) -> List[TextElement]:
    """按位置排序文本元素（从左到右，从上到下）"""
    return sorted(text_elements, key=lambda x: (x.bbox.y, x.bbox.x))

# 使用示例
if __name__ == "__main__":
    # 创建文本识别系统
    config = get_config()
    text_system = TextRecognitionSystem(config)
    
    # 创建测试图像
    test_image = np.ones((800, 600, 3), dtype=np.uint8) * 255
    
    # 模拟一些文本区域
    test_regions = [
        BoundingBox(50, 50, 200, 30),
        BoundingBox(50, 100, 300, 30),
        BoundingBox(50, 200, 100, 20),
        BoundingBox(200, 200, 100, 20)
    ]
    
    # 识别文本和布局
    result = text_system.recognize_text_and_layout(test_image)
    
    print("文本识别结果:")
    print(f"文本元素数量: {len(result['text_elements'])}")
    print(f"布局元素数量: {len(result['layout_elements'])}")
    print(f"尺寸标注数量: {len(result['dimensions'])}")
    print(f"文本区域数量: {len(result['text_regions'])}")
    
    # 保存结果
    with open("text_recognition_result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    print("结果已保存到 text_recognition_result.json")
