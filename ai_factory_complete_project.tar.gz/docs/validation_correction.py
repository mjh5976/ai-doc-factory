"""
识别结果验证和校正模块
负责验证识别结果的准确性并进行自动校正
"""

import os
import sys
import logging
import numpy as np
import cv2
import math
import re
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, asdict
from pathlib import Path
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
from scipy import stats
from sklearn.ensemble import IsolationForest
from sklearn.cluster import DBSCAN

# 导入配置
sys.path.append(str(Path(__file__).parent.parent))
from pdf_ocr_config import get_config

# 导入基础模块
from pdf_parser import BoundingBox, TextElement, VectorElement, ImageElement, PageData
from text_recognition import LayoutElement, DimensionAnnotation
from graphics_detection import GeometricElement, SymbolInstance
from multimodal_fusion import FusedElement, ContextualRelationship

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class ValidationResult:
    """验证结果数据类"""
    is_valid: bool
    error_type: str  # geometric, semantic, topological, layout
    error_message: str
    confidence_score: float
    severity: str  # low, medium, high, critical
    suggested_corrections: List[Dict[str, Any]]
    element_id: Optional[str] = None
    
    def to_dict(self):
        return {
            'is_valid': self.is_valid,
            'error_type': self.error_type,
            'error_message': self.error_message,
            'confidence_score': self.confidence_score,
            'severity': self.severity,
            'suggested_corrections': self.suggested_corrections,
            'element_id': self.element_id
        }

@dataclass
class CorrectionAction:
    """校正动作数据类"""
    action_type: str  # modify, remove, add, merge, split
    target_element_id: str
    parameters: Dict[str, Any]
    confidence: float
    description: str
    
    def to_dict(self):
        return {
            'action_type': self.action_type,
            'target_element_id': self.target_element_id,
            'parameters': self.parameters,
            'confidence': self.confidence,
            'description': self.description
        }

class GeometricValidator:
    """几何验证器"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        self.validation_config = self.config["validation"]
        self.geometric_config = self.validation_config["geometric_validation"]
    
    def validate_geometric_consistency(self, elements: List[Any]) -> List[ValidationResult]:
        """
        验证几何一致性
        
        Args:
            elements: 元素列表
            
        Returns:
            List[ValidationResult]: 验证结果列表
        """
        try:
            validation_results = []
            
            # 验证角度一致性
            angle_results = self._validate_angle_consistency(elements)
            validation_results.extend(angle_results)
            
            # 验证长度一致性
            length_results = self._validate_length_consistency(elements)
            validation_results.extend(length_results)
            
            # 验证平行垂直关系
            parallel_perp_results = self._validate_parallel_perpendicular(elements)
            validation_results.extend(parallel_perp_results)
            
            # 验证边界框重叠
            bbox_overlap_results = self._validate_bbox_overlap(elements)
            validation_results.extend(bbox_overlap_results)
            
            # 验证几何约束
            constraint_results = self._validate_geometric_constraints(elements)
            validation_results.extend(constraint_results)
            
            logger.debug(f"几何验证完成，发现 {len(validation_results)} 个问题")
            return validation_results
            
        except Exception as e:
            logger.error(f"几何验证失败: {e}")
            return []
    
    def _validate_angle_consistency(self, elements: List[Any]) -> List[ValidationResult]:
        """验证角度一致性"""
        results = []
        angle_tolerance = self.geometric_config["angle_tolerance"]
        
        # 提取线条元素
        lines = [elem for elem in elements if hasattr(elem, 'element_type') and elem.element_type == 'line']
        
        # 检查相似角度的线条是否应该平行
        angle_groups = {}
        for i, line in enumerate(lines):
            angle = line.properties.get('angle', 0)
            # 将角度归一化到0-180度
            normalized_angle = angle % 180
            
            # 按角度分组（容忍度范围内）
            group_key = round(normalized_angle / angle_tolerance) * angle_tolerance
            if group_key not in angle_groups:
                angle_groups[group_key] = []
            angle_groups[group_key].append((i, line))
        
        # 检查每组内的线条是否应该平行
        for group_angle, group_lines in angle_groups.items():
            if len(group_lines) > 1:
                # 检查线条是否真正平行
                for i in range(len(group_lines)):
                    for j in range(i + 1, len(group_lines)):
                        line1 = group_lines[i][1]
                        line2 = group_lines[j][1]
                        
                        angle1 = line1.properties.get('angle', 0) % 180
                        angle2 = line2.properties.get('angle', 0) % 180
                        
                        angle_diff = abs(angle1 - angle2)
                        angle_diff = min(angle_diff, 180 - angle_diff)
                        
                        if angle_diff > angle_tolerance:
                            result = ValidationResult(
                                is_valid=False,
                                error_type="geometric",
                                error_message=f"线条角度不一致: {angle_diff:.1f}° > {angle_tolerance}°",
                                confidence_score=0.8,
                                severity="medium",
                                suggested_corrections=[
                                    {
                                        "action": "adjust_angle",
                                        "target_line": str(id(line1)),
                                        "suggested_angle": group_angle
                                    }
                                ]
                            )
                            results.append(result)
        
        return results
    
    def _validate_length_consistency(self, elements: List[Any]) -> List[ValidationResult]:
        """验证长度一致性"""
        results = []
        length_tolerance = self.geometric_config["length_tolerance"]
        
        # 提取线条元素
        lines = [elem for elem in elements if hasattr(elem, 'element_type') and elem.element_type == 'line']
        
        # 使用聚类检测异常长度
        if len(lines) > 2:
            lengths = [line.properties.get('length', 0) for line in lines]
            
            # 使用IQR方法检测异常值
            Q1 = np.percentile(lengths, 25)
            Q3 = np.percentile(lengths, 75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            for i, line in enumerate(lines):
                length = line.properties.get('length', 0)
                
                if length < lower_bound or length > upper_bound:
                    result = ValidationResult(
                        is_valid=False,
                        error_type="geometric",
                        error_message=f"线条长度异常: {length:.1f} (正常范围: {lower_bound:.1f}-{upper_bound:.1f})",
                        confidence_score=0.7,
                        severity="medium",
                        suggested_corrections=[
                            {
                                "action": "review_length",
                                "target_line": str(id(line)),
                                "normal_range": [lower_bound, upper_bound]
                            }
                        ]
                    )
                    results.append(result)
        
        return results
    
    def _validate_parallel_perpendicular(self, elements: List[Any]) -> List[ValidationResult]:
        """验证平行垂直关系"""
        results = []
        tolerance = self.geometric_config["perpendicular_tolerance"]
        
        # 提取线条元素
        lines = [elem for elem in elements if hasattr(elem, 'element_type') and elem.element_type == 'line']
        
        for i, line1 in enumerate(lines):
            for j, line2 in enumerate(lines[i+1:], i+1):
                angle1 = line1.properties.get('angle', 0) % 180
                angle2 = line2.properties.get('angle', 0) % 180
                
                angle_diff = abs(angle1 - angle2)
                angle_diff = min(angle_diff, 180 - angle_diff)
                
                # 检查是否应该平行
                if angle_diff < tolerance:
                    # 检查中心点距离是否合理（平行线应该有一定距离）
                    center1 = self._get_line_center(line1)
                    center2 = self._get_line_center(line2)
                    
                    if center1 and center2:
                        distance = math.sqrt((center1[0] - center2[0])**2 + (center1[1] - center2[1])**2)
                        
                        if distance < 10:  # 平行线距离太近
                            result = ValidationResult(
                                is_valid=False,
                                error_type="geometric",
                                error_message=f"平行线距离过近: {distance:.1f}",
                                confidence_score=0.6,
                                severity="low",
                                suggested_corrections=[
                                    {
                                        "action": "adjust_position",
                                        "target_line": str(id(line2)),
                                        "suggested_offset": 10
                                    }
                                ]
                            )
                            results.append(result)
                
                # 检查是否应该垂直
                elif abs(angle_diff - 90) < tolerance:
                    # 检查交点是否合理
                    intersection = self._calculate_line_intersection(line1, line2)
                    
                    if intersection:
                        # 检查交点是否在线段范围内
                        if not self._is_point_on_line_segment(intersection, line1) or \
                           not self._is_point_on_line_segment(intersection, line2):
                            result = ValidationResult(
                                is_valid=False,
                                error_type="geometric",
                                error_message="垂直线条交点不在有效范围内",
                                confidence_score=0.7,
                                severity="medium",
                                suggested_corrections=[
                                    {
                                        "action": "extend_line",
                                        "target_line": str(id(line1)),
                                        "extension_length": 20
                                    }
                                ]
                            )
                            results.append(result)
        
        return results
    
    def _validate_bbox_overlap(self, elements: List[Any]) -> List[ValidationResult]:
        """验证边界框重叠"""
        results = []
        
        # 提取有边界框的元素
        bbox_elements = [elem for elem in elements if hasattr(elem, 'bbox')]
        
        for i, elem1 in enumerate(bbox_elements):
            for j, elem2 in enumerate(bbox_elements[i+1:], i+1):
                # 检查过度重叠
                overlap_ratio = self._calculate_overlap_ratio(elem1.bbox, elem2.bbox)
                
                if overlap_ratio > 0.8:  # 过度重叠
                    result = ValidationResult(
                        is_valid=False,
                        error_type="geometric",
                        error_message=f"元素过度重叠: {overlap_ratio:.2f}",
                        confidence_score=0.8,
                        severity="high",
                        suggested_corrections=[
                            {
                                "action": "separate_elements",
                                "target_element1": str(id(elem1)),
                                "target_element2": str(id(elem2)),
                                "separation_distance": 5
                            }
                        ]
                    )
                    results.append(result)
                
                # 检查边界框冲突
                elif overlap_ratio > 0.3:
                    # 检查是否可能合并
                    if self._should_merge_elements(elem1, elem2):
                        result = ValidationResult(
                            is_valid=True,
                            error_type="geometric",
                            error_message=f"元素可能应该合并: 重叠率 {overlap_ratio:.2f}",
                            confidence_score=0.6,
                            severity="low",
                            suggested_corrections=[
                                {
                                    "action": "merge_elements",
                                    "target_element1": str(id(elem1)),
                                    "target_element2": str(id(elem2))
                                }
                            ]
                        )
                        results.append(result)
        
        return results
    
    def _validate_geometric_constraints(self, elements: List[Any]) -> List[ValidationResult]:
        """验证几何约束"""
        results = []
        
        # 检查圆形和矩形的关系
        circles = [elem for elem in elements if hasattr(elem, 'element_type') and elem.element_type == 'circle']
        rectangles = [elem for elem in elements if hasattr(elem, 'element_type') and elem.element_type == 'rectangle']
        
        # 检查圆是否在矩形内
        for circle in circles:
            circle_center = circle.properties.get('center', (0, 0))
            circle_radius = circle.properties.get('radius', 0)
            
            for rectangle in rectangles:
                rect_bbox = rectangle.bbox
                
                # 检查圆心是否在矩形内
                if (rect_bbox.x <= circle_center[0] <= rect_bbox.x + rect_bbox.width and
                    rect_bbox.y <= circle_center[1] <= rect_bbox.y + rect_bbox.height):
                    
                    # 检查圆是否完全在矩形内
                    distances = [
                        circle_center[0] - rect_bbox.x,  # 到左边的距离
                        rect_bbox.x + rect_bbox.width - circle_center[0],  # 到右边的距离
                        circle_center[1] - rect_bbox.y,  # 到上边的距离
                        rect_bbox.y + rect_bbox.height - circle_center[1]  # 到下边的距离
                    ]
                    
                    min_distance = min(distances)
                    
                    if circle_radius > min_distance:
                        result = ValidationResult(
                            is_valid=False,
                            error_type="geometric",
                            error_message=f"圆形超出矩形边界: 半径 {circle_radius:.1f} > 最小距离 {min_distance:.1f}",
                            confidence_score=0.9,
                            severity="high",
                            suggested_corrections=[
                                {
                                    "action": "adjust_circle_radius",
                                    "target_circle": str(id(circle)),
                                    "max_radius": min_distance
                                }
                            ]
                        )
                        results.append(result)
        
        return results
    
    def _get_line_center(self, line: GeometricElement) -> Optional[Tuple[float, float]]:
        """获取线条中心点"""
        points = line.points
        if len(points) >= 2:
            return ((points[0][0] + points[1][0]) / 2, (points[0][1] + points[1][1]) / 2)
        return None
    
    def _calculate_line_intersection(self, line1: GeometricElement, line2: GeometricElement) -> Optional[Tuple[float, float]]:
        """计算两条线的交点"""
        try:
            x1, y1 = line1.points[0]
            x2, y2 = line1.points[1]
            x3, y3 = line2.points[0]
            x4, y4 = line2.points[1]
            
            # 使用行列式计算交点
            denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
            
            if abs(denom) < 1e-10:  # 平行线
                return None
            
            t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
            
            if 0 <= t <= 1:  # 交点在线段上
                x = x1 + t * (x2 - x1)
                y = y1 + t * (y2 - y1)
                return (x, y)
            
            return None
            
        except Exception:
            return None
    
    def _is_point_on_line_segment(self, point: Tuple[float, float], line: GeometricElement) -> bool:
        """检查点是否在线段上"""
        try:
            px, py = point
            x1, y1 = line.points[0]
            x2, y2 = line.points[1]
            
            # 检查点是否在线段范围内
            min_x = min(x1, x2) - 1e-6
            max_x = max(x1, x2) + 1e-6
            min_y = min(y1, y2) - 1e-6
            max_y = max(y1, y2) + 1e-6
            
            return min_x <= px <= max_x and min_y <= py <= max_y
            
        except Exception:
            return False
    
    def _calculate_overlap_ratio(self, bbox1: BoundingBox, bbox2: BoundingBox) -> float:
        """计算两个边界框的重叠比例"""
        if not bbox1.intersects(bbox2):
            return 0.0
        
        # 计算交集
        intersection_x = max(0, min(bbox1.x + bbox1.width, bbox2.x + bbox2.width) - max(bbox1.x, bbox2.x))
        intersection_y = max(0, min(bbox1.y + bbox1.height, bbox2.y + bbox2.height) - max(bbox1.y, bbox2.y))
        intersection_area = intersection_x * intersection_y
        
        # 计算并集
        union_area = bbox1.area() + bbox2.area() - intersection_area
        
        return intersection_area / union_area if union_area > 0 else 0.0
    
    def _should_merge_elements(self, elem1: Any, elem2: Any) -> bool:
        """判断两个元素是否应该合并"""
        # 简单的合并规则：相同类型且距离很近
        if (hasattr(elem1, 'element_type') and hasattr(elem2, 'element_type') and
            elem1.element_type == elem2.element_type):
            
            center1 = self._get_element_center(elem1)
            center2 = self._get_element_center(elem2)
            
            if center1 and center2:
                distance = math.sqrt((center1[0] - center2[0])**2 + (center1[1] - center2[1])**2)
                return distance < 20  # 距离阈值
        
        return False
    
    def _get_element_center(self, element: Any) -> Optional[Tuple[float, float]]:
        """获取元素中心点"""
        if hasattr(element, 'bbox'):
            bbox = element.bbox
            return (bbox.x + bbox.width / 2, bbox.y + bbox.height / 2)
        elif hasattr(element, 'points') and element.points:
            points = element.points
            if len(points) >= 2:
                return ((points[0][0] + points[1][0]) / 2, (points[0][1] + points[1][1]) / 2)
        return None

class SemanticValidator:
    """语义验证器"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        self.validation_config = self.config["validation"]
        self.semantic_config = self.validation_config["semantic_validation"]
    
    def validate_semantic_consistency(self, elements: List[Any]) -> List[ValidationResult]:
        """
        验证语义一致性
        
        Args:
            elements: 元素列表
            
        Returns:
            List[ValidationResult]: 验证结果列表
        """
        try:
            validation_results = []
            
            # 验证尺寸标注一致性
            dimension_results = self._validate_dimension_consistency(elements)
            validation_results.extend(dimension_results)
            
            # 验证文本语义
            text_results = self._validate_text_semantics(elements)
            validation_results.extend(text_results)
            
            # 验证符号语义
            symbol_results = self._validate_symbol_semantics(elements)
            validation_results.extend(symbol_results)
            
            # 验证上下文一致性
            context_results = self._validate_contextual_consistency(elements)
            validation_results.extend(context_results)
            
            logger.debug(f"语义验证完成，发现 {len(validation_results)} 个问题")
            return validation_results
            
        except Exception as e:
            logger.error(f"语义验证失败: {e}")
            return []
    
    def _validate_dimension_consistency(self, elements: List[Any]) -> List[ValidationResult]:
        """验证尺寸标注一致性"""
        results = []
        
        # 提取尺寸标注
        dimensions = [elem for elem in elements if hasattr(elem, 'dimension_value')]
        
        if not dimensions:
            return results
        
        # 检查尺寸范围
        dimension_range = self.semantic_config["dimension_range"]
        
        for dimension in dimensions:
            try:
                value = float(re.findall(r'\d+\.?\d*', dimension.dimension_value)[0])
                
                if value < dimension_range["min_value"] or value > dimension_range["max_value"]:
                    result = ValidationResult(
                        is_valid=False,
                        error_type="semantic",
                        error_message=f"尺寸值超出合理范围: {value} (正常范围: {dimension_range['min_value']}-{dimension_range['max_value']})",
                        confidence_score=0.9,
                        severity="high",
                        suggested_corrections=[
                            {
                                "action": "review_dimension_value",
                                "target_dimension": str(id(dimension)),
                                "suggested_range": dimension_range
                            }
                        ]
                    )
                    results.append(result)
                
            except (ValueError, IndexError):
                # 无法解析尺寸值
                result = ValidationResult(
                    is_valid=False,
                    error_type="semantic",
                    error_message=f"无法解析尺寸值: {dimension.dimension_value}",
                    confidence_score=0.8,
                    severity="medium",
                    suggested_corrections=[
                        {
                            "action": "correct_dimension_format",
                            "target_dimension": str(id(dimension)),
                            "expected_format": "数字+单位"
                        }
                    ]
                )
                results.append(result)
        
        # 检查尺寸类型一致性
        dimension_types = {}
        for dimension in dimensions:
            dim_type = dimension.dimension_type
            if dim_type not in dimension_types:
                dimension_types[dim_type] = []
            dimension_types[dim_type].append(dimension)
        
        # 检查相同类型尺寸的数值范围是否合理
        for dim_type, dims in dimension_types.items():
            if len(dims) > 1:
                values = []
                for dim in dims:
                    try:
                        value = float(re.findall(r'\d+\.?\d*', dim.dimension_value)[0])
                        values.append(value)
                    except (ValueError, IndexError):
                        continue
                
                if values:
                    # 使用统计方法检测异常值
                    Q1 = np.percentile(values, 25)
                    Q3 = np.percentile(values, 75)
                    IQR = Q3 - Q1
                    lower_bound = Q1 - 1.5 * IQR
                    upper_bound = Q3 + 1.5 * IQR
                    
                    for i, dim in enumerate(dims):
                        try:
                            value = float(re.findall(r'\d+\.?\d*', dim.dimension_value)[0])
                            if value < lower_bound or value > upper_bound:
                                result = ValidationResult(
                                    is_valid=False,
                                    error_type="semantic",
                                    error_message=f"{dim_type}类型尺寸异常: {value} (正常范围: {lower_bound:.1f}-{upper_bound:.1f})",
                                    confidence_score=0.7,
                                    severity="medium",
                                    suggested_corrections=[
                                        {
                                            "action": "review_dimension_value",
                                            "target_dimension": str(id(dim)),
                                            "normal_range": [lower_bound, upper_bound]
                                        }
                                    ]
                                )
                                results.append(result)
                        except (ValueError, IndexError):
                            continue
        
        return results
    
    def _validate_text_semantics(self, elements: List[Any]) -> List[ValidationResult]:
        """验证文本语义"""
        results = []
        
        # 提取文本元素
        text_elements = [elem for elem in elements if hasattr(elem, 'text')]
        
        # 检查文本长度
        for text_elem in text_elements:
            text = text_elem.text.strip()
            
            # 检查空文本
            if not text:
                result = ValidationResult(
                    is_valid=False,
                    error_type="semantic",
                    error_message="发现空文本元素",
                    confidence_score=0.9,
                    severity="medium",
                    suggested_corrections=[
                        {
                            "action": "remove_empty_text",
                            "target_text": str(id(text_elem))
                        }
                    ]
                )
                results.append(result)
            
            # 检查过长文本
            elif len(text) > 200:
                result = ValidationResult(
                    is_valid=True,
                    error_type="semantic",
                    error_message=f"文本过长: {len(text)} 字符",
                    confidence_score=0.6,
                    severity="low",
                    suggested_corrections=[
                        {
                            "action": "split_long_text",
                            "target_text": str(id(text_elem)),
                            "suggested_split_length": 100
                        }
                    ]
                )
                results.append(result)
            
            # 检查特殊字符
            elif re.search(r'[^\w\s\-.,;:!?()[\]{}]', text):
                result = ValidationResult(
                    is_valid=True,
                    error_type="semantic",
                    error_message="文本包含非标准字符",
                    confidence_score=0.5,
                    severity="low",
                    suggested_corrections=[
                        {
                            "action": "review_special_characters",
                            "target_text": str(id(text_elem))
                        }
                    ]
                )
                results.append(result)
        
        return results
    
    def _validate_symbol_semantics(self, elements: List[Any]) -> List[ValidationResult]:
        """验证符号语义"""
        results = []
        
        # 提取符号元素
        symbols = [elem for elem in elements if hasattr(elem, 'symbol_type')]
        
        # 检查符号置信度
        for symbol in symbols:
            if symbol.confidence < 0.5:
                result = ValidationResult(
                    is_valid=False,
                    error_type="semantic",
                    error_message=f"符号置信度过低: {symbol.confidence:.2f}",
                    confidence_score=0.8,
                    severity="medium",
                    suggested_corrections=[
                        {
                            "action": "review_low_confidence_symbol",
                            "target_symbol": str(id(symbol)),
                            "min_confidence": 0.5
                        }
                    ]
                )
                results.append(result)
        
        # 检查符号类型分布
        symbol_types = {}
        for symbol in symbols:
            sym_type = symbol.symbol_type
            if sym_type not in symbol_types:
                symbol_types[sym_type] = 0
            symbol_types[sym_type] += 1
        
        # 检查是否有不合理的符号分布
        total_symbols = len(symbols)
        for sym_type, count in symbol_types.items():
            if count / total_symbols > 0.8:  # 某种符号占比过高
                result = ValidationResult(
                    is_valid=True,
                    error_type="semantic",
                    error_message=f"符号类型分布不均: {sym_type} 占比 {count/total_symbols:.2f}",
                    confidence_score=0.6,
                    severity="low",
                    suggested_corrections=[
                        {
                            "action": "review_symbol_distribution",
                            "symbol_type": sym_type,
                            "expected_ratio": 0.5
                        }
                    ]
                )
                results.append(result)
        
        return results
    
    def _validate_contextual_consistency(self, elements: List[Any]) -> List[ValidationResult]:
        """验证上下文一致性"""
        results = []
        
        # 检查文本与尺寸标注的关联
        text_elements = [elem for elem in elements if hasattr(elem, 'text')]
        dimension_elements = [elem for elem in elements if hasattr(elem, 'dimension_value')]
        
        for text_elem in text_elements:
            for dim_elem in dimension_elements:
                # 检查是否应该有关联
                if self._should_be_associated(text_elem, dim_elem):
                    # 检查实际是否有关联
                    if not self._are_actually_associated(text_elem, dim_elem):
                        result = ValidationResult(
                            is_valid=True,
                            error_type="semantic",
                            error_message="文本与尺寸标注可能缺少关联",
                            confidence_score=0.6,
                            severity="low",
                            suggested_corrections=[
                                {
                                    "action": "associate_text_dimension",
                                    "target_text": str(id(text_elem)),
                                    "target_dimension": str(id(dim_elem))
                                }
                            ]
                        )
                        results.append(result)
        
        return results
    
    def _should_be_associated(self, text_elem: TextElement, dim_elem: DimensionAnnotation) -> bool:
        """判断文本和尺寸标注是否应该关联"""
        # 基于距离判断
        text_center = (text_elem.bbox.x + text_elem.bbox.width / 2, 
                      text_elem.bbox.y + text_elem.bbox.height / 2)
        dim_center = (dim_elem.bbox.x + dim_elem.bbox.width / 2,
                     dim_elem.bbox.y + dim_elem.bbox.height / 2)
        
        distance = math.sqrt((text_center[0] - dim_center[0])**2 + (text_center[1] - dim_center[1])**2)
        
        return distance < 100  # 距离阈值
    
    def _are_actually_associated(self, text_elem: TextElement, dim_elem: DimensionAnnotation) -> bool:
        """检查文本和尺寸标注是否实际关联"""
        # 这里可以实现更复杂的关联检测逻辑
        # 目前简化为检查距离
        return self._should_be_associated(text_elem, dim_elem)

class AutomaticCorrector:
    """自动校正器"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        self.validation_config = self.config["validation"]
        self.correction_config = self.validation_config["auto_correction"]
    
    def apply_corrections(self, elements: List[Any], 
                         validation_results: List[ValidationResult]) -> Tuple[List[Any], List[CorrectionAction]]:
        """
        应用自动校正
        
        Args:
            elements: 元素列表
            validation_results: 验证结果列表
            
        Returns:
            Tuple[List[Any], List[CorrectionAction]]: 校正后的元素和执行的校正动作
        """
        try:
            if not self.correction_config["enable_geometric_correction"] and \
               not self.correction_config["enable_semantic_correction"]:
                return elements, []
            
            corrected_elements = elements.copy()
            applied_actions = []
            
            # 按严重程度排序验证结果
            severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
            sorted_results = sorted(validation_results, 
                                  key=lambda x: severity_order.get(x.severity, 4))
            
            for result in sorted_results:
                if result.confidence_score < self.correction_config["correction_confidence_threshold"]:
                    continue
                
                # 应用几何校正
                if self.correction_config["enable_geometric_correction"] and result.error_type == "geometric":
                    corrected_elements, action = self._apply_geometric_correction(
                        corrected_elements, result
                    )
                    if action:
                        applied_actions.append(action)
                
                # 应用语义校正
                elif self.correction_config["enable_semantic_correction"] and result.error_type == "semantic":
                    corrected_elements, action = self._apply_semantic_correction(
                        corrected_elements, result
                    )
                    if action:
                        applied_actions.append(action)
            
            logger.info(f"自动校正完成，执行了 {len(applied_actions)} 个校正动作")
            return corrected_elements, applied_actions
            
        except Exception as e:
            logger.error(f"自动校正失败: {e}")
            return elements, []
    
    def _apply_geometric_correction(self, elements: List[Any], 
                                  validation_result: ValidationResult) -> Tuple[List[Any], Optional[CorrectionAction]]:
        """应用几何校正"""
        try:
            for correction in validation_result.suggested_corrections:
                action_type = correction.get("action")
                
                if action_type == "adjust_angle":
                    # 调整线条角度
                    target_line_id = correction.get("target_line")
                    suggested_angle = correction.get("suggested_angle")
                    
                    for element in elements:
                        if str(id(element)) == target_line_id and hasattr(element, 'element_type') and element.element_type == 'line':
                            element.properties['angle'] = suggested_angle
                            
                            action = CorrectionAction(
                                action_type="modify",
                                target_element_id=target_line_id,
                                parameters={"angle": suggested_angle},
                                confidence=validation_result.confidence_score,
                                description=f"调整线条角度到 {suggested_angle}°"
                            )
                            return elements, action
                
                elif action_type == "separate_elements":
                    # 分离重叠元素
                    target_elem1_id = correction.get("target_element1")
                    target_elem2_id = correction.get("target_element2")
                    separation_distance = correction.get("separation_distance", 5)
                    
                    # 简化实现：标记需要分离
                    for element in elements:
                        if str(id(element)) in [target_elem1_id, target_elem2_id]:
                            element.properties['needs_separation'] = True
                            element.properties['separation_distance'] = separation_distance
                    
                    action = CorrectionAction(
                        action_type="modify",
                        target_element_id=target_elem1_id,
                        parameters={"separation_distance": separation_distance},
                        confidence=validation_result.confidence_score,
                        description=f"分离重叠元素，距离: {separation_distance}"
                    )
                    return elements, action
                
                elif action_type == "merge_elements":
                    # 合并元素
                    target_elem1_id = correction.get("target_element1")
                    target_elem2_id = correction.get("target_element2")
                    
                    # 简化实现：标记需要合并
                    for element in elements:
                        if str(id(element)) in [target_elem1_id, target_elem2_id]:
                            element.properties['needs_merge'] = True
                    
                    action = CorrectionAction(
                        action_type="merge",
                        target_element_id=target_elem1_id,
                        parameters={"merge_with": target_elem2_id},
                        confidence=validation_result.confidence_score,
                        description=f"合并元素 {target_elem1_id} 和 {target_elem2_id}"
                    )
                    return elements, action
            
            return elements, None
            
        except Exception as e:
            logger.error(f"几何校正失败: {e}")
            return elements, None
    
    def _apply_semantic_correction(self, elements: List[Any], 
                                 validation_result: ValidationResult) -> Tuple[List[Any], Optional[CorrectionAction]]:
        """应用语义校正"""
        try:
            for correction in validation_result.suggested_corrections:
                action_type = correction.get("action")
                
                if action_type == "remove_empty_text":
                    # 移除空文本
                    target_text_id = correction.get("target_text")
                    
                    # 简化实现：标记需要移除
                    for element in elements:
                        if str(id(element)) == target_text_id and hasattr(element, 'text'):
                            element.properties['needs_removal'] = True
                    
                    action = CorrectionAction(
                        action_type="remove",
                        target_element_id=target_text_id,
                        parameters={},
                        confidence=validation_result.confidence_score,
                        description="移除空文本元素"
                    )
                    return elements, action
                
                elif action_type == "review_dimension_value":
                    # 标记尺寸值需要审查
                    target_dimension_id = correction.get("target_dimension")
                    
                    for element in elements:
                        if str(id(element)) == target_dimension_id and hasattr(element, 'dimension_value'):
                            element.properties['needs_review'] = True
                            element.properties['review_reason'] = "尺寸值超出正常范围"
                    
                    action = CorrectionAction(
                        action_type="modify",
                        target_element_id=target_dimension_id,
                        parameters={"needs_review": True},
                        confidence=validation_result.confidence_score,
                        description="标记尺寸值需要人工审查"
                    )
                    return elements, action
            
            return elements, None
            
        except Exception as e:
            logger.error(f"语义校正失败: {e}")
            return elements, None

class ValidationCorrectionSystem:
    """验证校正系统主类"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        
        # 初始化组件
        self.geometric_validator = GeometricValidator(self.config)
        self.semantic_validator = SemanticValidator(self.config)
        self.automatic_corrector = AutomaticCorrector(self.config)
        
        logger.info("验证校正系统初始化完成")
    
    def validate_and_correct(self, elements: List[Any]) -> Dict[str, Any]:
        """
        验证和校正元素
        
        Args:
            elements: 元素列表
            
        Returns:
            Dict: 验证和校正结果
        """
        try:
            logger.info("开始验证和校正")
            
            # 1. 几何验证
            geometric_results = self.geometric_validator.validate_geometric_consistency(elements)
            
            # 2. 语义验证
            semantic_results = self.semantic_validator.validate_semantic_consistency(elements)
            
            # 3. 合并验证结果
            all_validation_results = geometric_results + semantic_results
            
            # 4. 自动校正
            corrected_elements, correction_actions = self.automatic_corrector.apply_corrections(
                elements, all_validation_results
            )
            
            # 5. 质量评估
            quality_score = self._calculate_quality_score(corrected_elements, all_validation_results)
            
            # 6. 组合结果
            result = {
                "original_elements": [self._element_to_dict(elem) for elem in elements],
                "corrected_elements": [self._element_to_dict(elem) for elem in corrected_elements],
                "validation_results": [res.to_dict() for res in all_validation_results],
                "correction_actions": [action.to_dict() for action in correction_actions],
                "quality_metrics": {
                    "quality_score": quality_score,
                    "total_issues": len(all_validation_results),
                    "critical_issues": len([r for r in all_validation_results if r.severity == "critical"]),
                    "high_issues": len([r for r in all_validation_results if r.severity == "high"]),
                    "medium_issues": len([r for r in all_validation_results if r.severity == "medium"]),
                    "low_issues": len([r for r in all_validation_results if r.severity == "low"]),
                    "corrections_applied": len(correction_actions)
                }
            }
            
            logger.info(f"验证校正完成：{len(all_validation_results)} 个问题，{len(correction_actions)} 个校正")
            
            return result
            
        except Exception as e:
            logger.error(f"验证校正失败: {e}")
            return {
                "original_elements": [],
                "corrected_elements": [],
                "validation_results": [],
                "correction_actions": [],
                "error": str(e)
            }
    
    def _element_to_dict(self, element: Any) -> Dict[str, Any]:
        """将元素转换为字典"""
        if hasattr(element, 'to_dict'):
            return element.to_dict()
        elif hasattr(element, '__dict__'):
            return {
                'type': type(element).__name__,
                'attributes': element.__dict__
            }
        else:
            return {
                'type': type(element).__name__,
                'str': str(element)
            }
    
    def _calculate_quality_score(self, elements: List[Any], validation_results: List[ValidationResult]) -> float:
        """计算质量分数"""
        if not elements:
            return 0.0
        
        # 基础分数
        base_score = 1.0
        
        # 根据问题严重程度扣分
        severity_weights = {
            "critical": 0.3,
            "high": 0.2,
            "medium": 0.1,
            "low": 0.05
        }
        
        total_penalty = 0.0
        for result in validation_results:
            weight = severity_weights.get(result.severity, 0.05)
            penalty = weight * (1.0 - result.confidence_score)
            total_penalty += penalty
        
        # 根据元素数量调整（元素越多，质量要求越高）
        element_penalty = len(elements) * 0.001
        
        quality_score = max(0.0, base_score - total_penalty - element_penalty)
        
        return min(1.0, quality_score)
    
    def batch_validate_documents(self, document_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        批量验证文档结果
        
        Args:
            document_results: 文档结果列表
            
        Returns:
            Dict: 批量验证结果
        """
        try:
            logger.info(f"开始批量验证 {len(document_results)} 个文档")
            
            batch_results = []
            total_issues = 0
            total_corrections = 0
            total_quality_score = 0.0
            
            for doc_result in document_results:
                # 提取元素
                elements = []
                
                # 从文档结果中提取各种元素
                for page_data in doc_result.get("pages", []):
                    # 文本元素
                    for text_elem in page_data.get("text_elements", []):
                        elements.append(TextElement(**text_elem))
                    
                    # 图形元素
                    for graphic_elem in page_data.get("graphic_elements", []):
                        elements.append(GeometricElement(**graphic_elem))
                    
                    # 尺寸标注
                    for dimension in page_data.get("dimensions", []):
                        elements.append(DimensionAnnotation(**dimension))
                    
                    # 符号
                    for symbol in page_data.get("symbols", []):
                        elements.append(SymbolInstance(**symbol))
                
                # 验证和校正
                validation_result = self.validate_and_correct(elements)
                
                # 汇总结果
                batch_results.append({
                    "document_id": doc_result.get("document", {}).get("id"),
                    "filename": doc_result.get("document", {}).get("filename"),
                    "validation_result": validation_result
                })
                
                # 累计统计
                total_issues += validation_result["quality_metrics"]["total_issues"]
                total_corrections += validation_result["quality_metrics"]["corrections_applied"]
                total_quality_score += validation_result["quality_metrics"]["quality_score"]
            
            # 计算平均质量分数
            avg_quality_score = total_quality_score / len(document_results) if document_results else 0.0
            
            batch_summary = {
                "batch_results": batch_results,
                "summary": {
                    "total_documents": len(document_results),
                    "total_issues": total_issues,
                    "total_corrections": total_corrections,
                    "average_quality_score": avg_quality_score,
                    "documents_with_critical_issues": len([r for r in batch_results 
                                                          if r["validation_result"]["quality_metrics"]["critical_issues"] > 0])
                }
            }
            
            logger.info(f"批量验证完成：{total_issues} 个问题，{total_corrections} 个校正")
            
            return batch_summary
            
        except Exception as e:
            logger.error(f"批量验证失败: {e}")
            return {
                "batch_results": [],
                "error": str(e)
            }

# 辅助函数
def calculate_validation_statistics(validation_results: List[ValidationResult]) -> Dict[str, Any]:
    """计算验证统计信息"""
    if not validation_results:
        return {
            "total_issues": 0,
            "issues_by_type": {},
            "issues_by_severity": {},
            "average_confidence": 0.0,
            "high_confidence_issues": 0
        }
    
    # 按类型统计
    issues_by_type = {}
    for result in validation_results:
        error_type = result.error_type
        issues_by_type[error_type] = issues_by_type.get(error_type, 0) + 1
    
    # 按严重程度统计
    issues_by_severity = {}
    for result in validation_results:
        severity = result.severity
        issues_by_severity[severity] = issues_by_severity.get(severity, 0) + 1
    
    # 计算平均置信度
    confidences = [result.confidence_score for result in validation_results]
    average_confidence = sum(confidences) / len(confidences)
    
    # 高置信度问题数量
    high_confidence_issues = len([r for r in validation_results if r.confidence_score > 0.8])
    
    return {
        "total_issues": len(validation_results),
        "issues_by_type": issues_by_type,
        "issues_by_severity": issues_by_severity,
        "average_confidence": average_confidence,
        "high_confidence_issues": high_confidence_issues
    }

def filter_validation_results_by_severity(validation_results: List[ValidationResult], 
                                        min_severity: str = "low") -> List[ValidationResult]:
    """按严重程度过滤验证结果"""
    severity_levels = {"low": 0, "medium": 1, "high": 2, "critical": 3}
    min_level = severity_levels.get(min_severity, 0)
    
    return [result for result in validation_results 
            if severity_levels.get(result.severity, 0) >= min_level]

# 使用示例
if __name__ == "__main__":
    # 创建验证校正系统
    config = get_config()
    validation_system = ValidationCorrectionSystem(config)
    
    # 创建测试数据
    test_elements = [
        TextElement(
            text="100",
            bbox=BoundingBox(100, 100, 50, 20),
            confidence=0.9,
            font_size=12,
            font_name="Arial"
        ),
        GeometricElement(
            element_type="line",
            points=[(100, 110), (150, 110)],
            bbox=BoundingBox(100, 105, 50, 10),
            confidence=0.8,
            properties={"length": 50, "angle": 5}  # 故意设置一个角度误差
        ),
        DimensionAnnotation(
            dimension_value="1000",  # 故意设置一个异常大的尺寸
            dimension_type="length",
            unit="mm",
            bbox=BoundingBox(120, 95, 30, 15),
            confidence=0.85
        )
    ]
    
    # 执行验证和校正
    result = validation_system.validate_and_correct(test_elements)
    
    print("验证校正结果:")
    print(f"原始元素数量: {len(result['original_elements'])}")
    print(f"校正后元素数量: {len(result['corrected_elements'])}")
    print(f"发现问题数量: {result['quality_metrics']['total_issues']}")
    print(f"执行校正数量: {result['quality_metrics']['corrections_applied']}")
    print(f"质量分数: {result['quality_metrics']['quality_score']:.3f}")
    
    # 详细统计
    stats = calculate_validation_statistics([
        ValidationResult(**res) for res in result['validation_results']
    ])
    print(f"验证统计: {stats}")
    
    # 保存结果
    with open("validation_correction_result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    print("结果已保存到 validation_correction_result.json")
