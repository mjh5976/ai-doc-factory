"""
PDF OCR结构化识别系统主程序
整合所有模块，提供完整的PDF图纸OCR和结构化识别功能
"""

import os
import sys
import logging
import argparse
import json
import time
from typing import Dict, List, Tuple, Optional, Any, Union
from pathlib import Path
import traceback
from datetime import datetime

# 导入配置
sys.path.append(str(Path(__file__).parent.parent))
from pdf_ocr_config import get_config, validate_config

# 导入所有模块
from pdf_parser import PDFParser, parse_pdf
from text_recognition import TextRecognitionSystem
from graphics_detection import GraphicsDetectionSystem
from structured_data_manager import StructuredDataManager, DocumentRecord, ProcessingResult
from multimodal_fusion import MultimodalFusionEngine
from validation_correction import ValidationCorrectionSystem

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class PDFOCRStructuredRecognitionSystem:
    """PDF OCR结构化识别系统主类"""
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        初始化系统
        
        Args:
            config: 配置字典，如果为None则使用默认配置
        """
        self.config = config or get_config()
        
        # 验证配置
        errors = validate_config(self.config)
        if errors:
            logger.error("配置验证失败:")
            for error in errors:
                logger.error(f"  - {error}")
            raise ValueError("配置验证失败")
        
        # 初始化各个模块
        self.pdf_parser = PDFParser(self.config)
        self.text_recognition = TextRecognitionSystem(self.config)
        self.graphics_detection = GraphicsDetectionSystem(self.config)
        self.data_manager = StructuredDataManager(self.config)
        self.multimodal_fusion = MultimodalFusionEngine(self.config)
        self.validation_system = ValidationCorrectionSystem(self.config)
        
        logger.info("PDF OCR结构化识别系统初始化完成")
    
    def process_pdf(self, pdf_path: Union[str, Path], 
                   output_dir: Union[str, Path] = None,
                   export_formats: List[str] = None) -> Dict[str, Any]:
        """
        处理PDF文件
        
        Args:
            pdf_path: PDF文件路径
            output_dir: 输出目录
            export_formats: 导出格式列表
            
        Returns:
            Dict: 处理结果
        """
        start_time = time.time()
        pdf_path = Path(pdf_path)
        
        if not pdf_path.exists():
            raise FileNotFoundError(f"PDF文件不存在: {pdf_path}")
        
        logger.info(f"开始处理PDF文件: {pdf_path}")
        
        try:
            # 1. 创建文档记录
            doc_record = DocumentRecord(
                filename=pdf_path.name,
                file_path=str(pdf_path),
                file_size=pdf_path.stat().st_size,
                file_hash=self._calculate_file_hash(pdf_path),
                created_at=datetime.now().isoformat(),
                processing_status="processing"
            )
            
            # 2. 解析PDF
            logger.info("解析PDF文件...")
            pdf_result = parse_pdf(pdf_path, self.config)
            
            if not pdf_result:
                raise ValueError("PDF解析失败")
            
            doc_record.pages = pdf_result["total_pages"]
            
            # 3. 处理每一页
            page_data_list = []
            processing_results = []
            
            for page_num in range(pdf_result["total_pages"]):
                logger.info(f"处理第 {page_num + 1} 页...")
                
                page_result = self._process_page(pdf_result["pages"][page_num])
                page_data_list.append(page_result["page_data"])
                processing_results.append(page_result["processing_result"])
            
            # 4. 存储结果
            logger.info("存储处理结果...")
            self.data_manager.store_processing_result(doc_record, page_data_list, processing_results)
            
            # 5. 导出结果
            if output_dir:
                output_dir = Path(output_dir)
                output_dir.mkdir(parents=True, exist_ok=True)
                
                if export_formats is None:
                    export_formats = ["json", "csv", "excel"]
                
                self._export_results(doc_record, output_dir, export_formats)
            
            # 6. 计算处理时间
            processing_time = time.time() - start_time
            
            # 7. 更新文档状态
            self.data_manager.db_manager.update_document(
                doc_record.id, 
                processing_status="completed",
                processing_time=processing_time
            )
            
            result = {
                "success": True,
                "document_id": doc_record.id,
                "filename": pdf_path.name,
                "pages_processed": pdf_result["total_pages"],
                "processing_time": processing_time,
                "output_directory": str(output_dir) if output_dir else None,
                "export_formats": export_formats
            }
            
            logger.info(f"PDF处理完成: {pdf_path.name}, 用时: {processing_time:.2f}秒")
            return result
            
        except Exception as e:
            logger.error(f"PDF处理失败: {e}")
            logger.error(traceback.format_exc())
            
            # 更新文档状态为失败
            if 'doc_record' in locals() and doc_record.id:
                self.data_manager.db_manager.update_document(
                    doc_record.id,
                    processing_status="failed",
                    error_message=str(e)
                )
            
            return {
                "success": False,
                "error": str(e),
                "processing_time": time.time() - start_time
            }
    
    def _process_page(self, page_result: Dict[str, Any]) -> Dict[str, Any]:
        """处理单个页面"""
        try:
            # 1. 提取页面数据
            page_data = self._extract_page_data(page_result)
            
            # 2. 文本识别和布局分析
            logger.debug("执行文本识别和布局分析...")
            image = self._create_page_image(page_result)
            text_result = self.text_recognition.recognize_text_and_layout(image)
            
            # 3. 图形元素检测和分类
            logger.debug("执行图形元素检测和分类...")
            graphics_result = self.graphics_detection.detect_graphics(image)
            
            # 4. 多模态信息融合
            logger.debug("执行多模态信息融合...")
            text_elements = self._convert_text_elements(text_result["text_elements"])
            graphic_elements = self._convert_geometric_elements(graphics_result["geometric_elements"])
            layout_elements = self._convert_layout_elements(text_result["layout_elements"])
            dimensions = self._convert_dimensions(text_result["dimensions"])
            symbols = self._convert_symbols(graphics_result["symbols"])
            
            fusion_result = self.multimodal_fusion.fuse_multimodal_data(
                text_elements, graphic_elements, layout_elements, dimensions, symbols
            )
            
            # 5. 验证和校正
            logger.debug("执行验证和校正...")
            all_elements = text_elements + graphic_elements + layout_elements + dimensions + symbols
            validation_result = self.validation_system.validate_and_correct(all_elements)
            
            # 6. 创建处理结果
            processing_result = ProcessingResult(
                document_id=0,  # 将在存储时更新
                page_number=page_result["page_info"]["page_number"],
                text_elements=text_result["text_elements"],
                graphic_elements=graphics_result["geometric_elements"],
                layout_elements=text_result["layout_elements"],
                dimensions=text_result["dimensions"],
                symbols=graphics_result["symbols"],
                metadata={
                    "fusion_result": fusion_result,
                    "validation_result": validation_result,
                    "text_recognition_stats": self._calculate_text_stats(text_result),
                    "graphics_detection_stats": self._calculate_graphics_stats(graphics_result)
                },
                confidence_score=validation_result["quality_metrics"]["quality_score"],
                processing_time=0.0  # 将在调用时计算
            )
            
            return {
                "page_data": page_data,
                "processing_result": processing_result
            }
            
        except Exception as e:
            logger.error(f"页面处理失败: {e}")
            logger.error(traceback.format_exc())
            raise
    
    def _extract_page_data(self, page_result: Dict[str, Any]) -> Any:
        """提取页面数据"""
        # 转换PDF解析结果为PageData格式
        page_info = page_result["page_info"]
        
        # 转换文本元素
        text_elements = []
        for text_elem in page_result.get("text_elements", []):
            text_elements.append(self._convert_text_element(text_elem))
        
        # 转换矢量元素
        vector_elements = []
        for vector_elem in page_result.get("vector_elements", []):
            vector_elements.append(self._convert_vector_element(vector_elem))
        
        # 转换图像元素
        image_elements = []
        for image_elem in page_result.get("image_elements", []):
            image_elements.append(self._convert_image_element(image_elem))
        
        from pdf_parser import PageData
        return PageData(
            page_number=page_info["page_number"] - 1,  # 转换为0-based
            width=page_info["width"],
            height=page_info["height"],
            text_elements=text_elements,
            vector_elements=vector_elements,
            image_elements=image_elements,
            metadata=page_result.get("metadata", {})
        )
    
    def _create_page_image(self, page_result: Dict[str, Any]) -> Any:
        """创建页面图像（简化实现）"""
        # 这里应该实现实际的图像创建逻辑
        # 目前返回模拟图像
        import numpy as np
        width = int(page_result["page_info"]["width"])
        height = int(page_result["page_info"]["height"])
        return np.ones((height, width, 3), dtype=np.uint8) * 255
    
    def _convert_text_element(self, text_elem: Dict[str, Any]) -> Any:
        """转换文本元素"""
        from pdf_parser import TextElement, BoundingBox
        bbox_data = text_elem["bbox"]
        bbox = BoundingBox(
            bbox_data["x0"], bbox_data["y0"],
            bbox_data["x1"] - bbox_data["x0"],
            bbox_data["y1"] - bbox_data["y0"]
        )
        
        return TextElement(
            text=text_elem["text"],
            bbox=bbox,
            confidence=text_elem.get("confidence", 1.0),
            font_size=text_elem.get("size", 12),
            font_name=text_elem.get("font", "unknown"),
            color=(0, 0, 0),
            ocr_engine="pdf_native"
        )
    
    def _convert_vector_element(self, vector_elem: Dict[str, Any]) -> Any:
        """转换矢量元素"""
        from pdf_parser import VectorElement, BoundingBox
        bbox_data = vector_elem["bbox"]
        bbox = BoundingBox(
            bbox_data["x0"], bbox_data["y0"],
            bbox_data["x1"] - bbox_data["x0"],
            bbox_data["y1"] - bbox_data["y0"]
        )
        
        return VectorElement(
            element_type=vector_elem.get("element_type", "path"),
            points=vector_elem.get("points", []),
            bbox=bbox,
            stroke_color=vector_elem.get("stroke_color", (0, 0, 0)),
            fill_color=vector_elem.get("fill_color"),
            stroke_width=vector_elem.get("width", 1.0),
            layer=vector_elem.get("layer", "default")
        )
    
    def _convert_image_element(self, image_elem: Dict[str, Any]) -> Any:
        """转换图像元素"""
        from pdf_parser import ImageElement, BoundingBox
        bbox_data = image_elem["bbox"]
        bbox = BoundingBox(
            bbox_data["x0"], bbox_data["y0"],
            bbox_data["x1"] - bbox_data["x0"],
            bbox_data["y1"] - bbox_data["y0"]
        )
        
        return ImageElement(
            bbox=bbox,
            image_data=b"",  # 实际实现中应该包含图像数据
            image_format=image_elem.get("image_format", "PNG"),
            resolution=image_elem.get("resolution", (0, 0))
        )
    
    def _convert_text_elements(self, text_elements: List[Dict[str, Any]]) -> List[Any]:
        """转换文本元素列表"""
        return [self._convert_text_element(elem) for elem in text_elements]
    
    def _convert_geometric_elements(self, geometric_elements: List[Dict[str, Any]]) -> List[Any]:
        """转换几何元素列表"""
        from graphics_detection import GeometricElement, BoundingBox
        
        result = []
        for elem in geometric_elements:
            bbox_data = elem["bbox"]
            bbox = BoundingBox(
                bbox_data["x"], bbox_data["y"],
                bbox_data["width"], bbox_data["height"]
            )
            
            geometric_element = GeometricElement(
                element_type=elem["element_type"],
                points=elem["points"],
                bbox=bbox,
                confidence=elem["confidence"],
                properties=elem["properties"],
                layer=elem.get("layer", "default")
            )
            result.append(geometric_element)
        
        return result
    
    def _convert_layout_elements(self, layout_elements: List[Dict[str, Any]]) -> List[Any]:
        """转换布局元素列表"""
        from text_recognition import LayoutElement, BoundingBox
        
        result = []
        for elem in layout_elements:
            bbox_data = elem["bbox"]
            bbox = BoundingBox(
                bbox_data["x"], bbox_data["y"],
                bbox_data["width"], bbox_data["height"]
            )
            
            layout_element = LayoutElement(
                element_type=elem["element_type"],
                bbox=bbox,
                confidence=elem["confidence"],
                content=elem["content"],
                hierarchy_level=elem.get("hierarchy_level", 0)
            )
            result.append(layout_element)
        
        return result
    
    def _convert_dimensions(self, dimensions: List[Dict[str, Any]]) -> List[Any]:
        """转换尺寸标注列表"""
        from text_recognition import DimensionAnnotation, BoundingBox
        
        result = []
        for dim in dimensions:
            bbox = None
            if dim.get("bbox"):
                bbox_data = dim["bbox"]
                bbox = BoundingBox(
                    bbox_data["x"], bbox_data["y"],
                    bbox_data["width"], bbox_data["height"]
                )
            
            dimension_annotation = DimensionAnnotation(
                dimension_value=dim["dimension_value"],
                dimension_type=dim["dimension_type"],
                unit=dim["unit"],
                tolerance=dim.get("tolerance"),
                precision=dim.get("precision", 2),
                bbox=bbox,
                confidence=dim.get("confidence", 1.0)
            )
            result.append(dimension_annotation)
        
        return result
    
    def _convert_symbols(self, symbols: List[Dict[str, Any]]) -> List[Any]:
        """转换符号列表"""
        from graphics_detection import SymbolInstance, BoundingBox
        
        result = []
        for symbol in symbols:
            bbox_data = symbol["bbox"]
            bbox = BoundingBox(
                bbox_data["x"], bbox_data["y"],
                bbox_data["width"], bbox_data["height"]
            )
            
            symbol_instance = SymbolInstance(
                symbol_type=symbol["symbol_type"],
                bbox=bbox,
                confidence=symbol["confidence"],
                properties=symbol["properties"],
                template_id=symbol.get("template_id")
            )
            result.append(symbol_instance)
        
        return result
    
    def _calculate_text_stats(self, text_result: Dict[str, Any]) -> Dict[str, Any]:
        """计算文本识别统计信息"""
        return {
            "text_elements_count": len(text_result.get("text_elements", [])),
            "layout_elements_count": len(text_result.get("layout_elements", [])),
            "dimensions_count": len(text_result.get("dimensions", [])),
            "average_confidence": sum(
                elem.get("confidence", 0) for elem in text_result.get("text_elements", [])
            ) / max(1, len(text_result.get("text_elements", [])))
        }
    
    def _calculate_graphics_stats(self, graphics_result: Dict[str, Any]) -> Dict[str, Any]:
        """计算图形检测统计信息"""
        summary = graphics_result.get("summary", {})
        return {
            "geometric_elements_count": summary.get("total_geometric_elements", 0),
            "lines_count": summary.get("line_count", 0),
            "shapes_count": summary.get("shape_count", 0),
            "symbols_count": summary.get("symbol_count", 0),
            "average_confidence": sum(
                elem.get("confidence", 0) for elem in graphics_result.get("geometric_elements", [])
            ) / max(1, len(graphics_result.get("geometric_elements", [])))
        }
    
    def _export_results(self, doc_record: DocumentRecord, output_dir: Path, export_formats: List[str]):
        """导出结果"""
        try:
            # 获取文档数据
            document_data = self.data_manager.retrieve_document(doc_record.id)
            
            if not document_data:
                logger.warning(f"文档数据不存在: {doc_record.id}")
                return
            
            # 按格式导出
            for format_type in export_formats:
                try:
                    output_filename = f"{doc_record.filename}_ocr_result.{format_type}"
                    output_path = output_dir / output_filename
                    
                    success = self.data_manager.export_document(
                        doc_record.id, output_path, format_type
                    )
                    
                    if success:
                        logger.info(f"结果已导出: {output_path}")
                    else:
                        logger.error(f"导出失败: {output_path}")
                        
                except Exception as e:
                    logger.error(f"导出{format_type}格式失败: {e}")
            
        except Exception as e:
            logger.error(f"导出结果失败: {e}")
    
    def _calculate_file_hash(self, file_path: Path) -> str:
        """计算文件哈希值"""
        import hashlib
        
        hash_md5 = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        
        return hash_md5.hexdigest()
    
    def batch_process_pdfs(self, pdf_paths: List[Union[str, Path]], 
                          output_dir: Union[str, Path] = None,
                          export_formats: List[str] = None) -> Dict[str, Any]:
        """
        批量处理PDF文件
        
        Args:
            pdf_paths: PDF文件路径列表
            output_dir: 输出目录
            export_formats: 导出格式列表
            
        Returns:
            Dict: 批量处理结果
        """
        start_time = time.time()
        logger.info(f"开始批量处理 {len(pdf_paths)} 个PDF文件")
        
        results = []
        successful_count = 0
        failed_count = 0
        
        for pdf_path in pdf_paths:
            try:
                result = self.process_pdf(pdf_path, output_dir, export_formats)
                results.append(result)
                
                if result["success"]:
                    successful_count += 1
                else:
                    failed_count += 1
                    
            except Exception as e:
                logger.error(f"处理PDF失败 {pdf_path}: {e}")
                results.append({
                    "success": False,
                    "error": str(e),
                    "filename": Path(pdf_path).name
                })
                failed_count += 1
        
        total_time = time.time() - start_time
        
        batch_result = {
            "total_files": len(pdf_paths),
            "successful_count": successful_count,
            "failed_count": failed_count,
            "total_processing_time": total_time,
            "average_processing_time": total_time / len(pdf_paths) if pdf_paths else 0,
            "results": results
        }
        
        logger.info(f"批量处理完成: {successful_count}/{len(pdf_paths)} 成功, 用时: {total_time:.2f}秒")
        return batch_result
    
    def get_system_statistics(self) -> Dict[str, Any]:
        """获取系统统计信息"""
        try:
            # 数据库统计
            db_stats = self.data_manager.get_database_statistics()
            
            # 系统配置信息
            config_info = {
                "pdf_config": self.config["pdf"],
                "text_recognition_config": self.config["text_recognition"],
                "graphics_detection_config": self.config["graphics_detection"],
                "dimension_recognition_config": self.config["dimension_recognition"],
                "validation_config": self.config["validation"]
            }
            
            return {
                "database_statistics": db_stats,
                "system_configuration": config_info,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"获取系统统计信息失败: {e}")
            return {"error": str(e)}
    
    def cleanup_old_documents(self, days: int = 30) -> int:
        """清理旧文档"""
        try:
            deleted_count = self.data_manager.cleanup_old_documents(days)
            logger.info(f"清理了 {deleted_count} 个旧文档")
            return deleted_count
        except Exception as e:
            logger.error(f"清理旧文档失败: {e}")
            return 0

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="PDF OCR结构化识别系统")
    parser.add_argument("input", help="输入PDF文件路径或目录")
    parser.add_argument("-o", "--output", help="输出目录")
    parser.add_argument("-f", "--formats", nargs="+", default=["json", "csv", "excel"],
                       help="导出格式 (json, csv, xml, excel)")
    parser.add_argument("--batch", action="store_true", help="批量处理模式")
    parser.add_argument("--stats", action="store_true", help="显示系统统计信息")
    parser.add_argument("--cleanup", type=int, metavar="DAYS", help="清理指定天数前的旧文档")
    parser.add_argument("--config", help="配置文件路径")
    parser.add_argument("--verbose", "-v", action="store_true", help="详细输出")
    
    args = parser.parse_args()
    
    # 设置日志级别
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    try:
        # 加载配置
        if args.config:
            with open(args.config, 'r', encoding='utf-8') as f:
                config = json.load(f)
        else:
            config = get_config()
        
        # 创建系统实例
        system = PDFOCRStructuredRecognitionSystem(config)
        
        # 处理命令
        if args.stats:
            # 显示系统统计信息
            stats = system.get_system_statistics()
            print(json.dumps(stats, ensure_ascii=False, indent=2))
            
        elif args.cleanup:
            # 清理旧文档
            deleted_count = system.cleanup_old_documents(args.cleanup)
            print(f"清理了 {deleted_count} 个旧文档")
            
        else:
            # 处理PDF文件
            input_path = Path(args.input)
            
            if args.batch and input_path.is_dir():
                # 批量处理
                pdf_files = list(input_path.glob("*.pdf"))
                if not pdf_files:
                    print(f"目录中没有找到PDF文件: {input_path}")
                    return 1
                
                result = system.batch_process_pdfs(
                    pdf_files, args.output, args.formats
                )
                print(json.dumps(result, ensure_ascii=False, indent=2))
                
            elif input_path.is_file() and input_path.suffix.lower() == '.pdf':
                # 单文件处理
                result = system.process_pdf(input_path, args.output, args.formats)
                print(json.dumps(result, ensure_ascii=False, indent=2))
                
            else:
                print("错误: 请提供有效的PDF文件路径或包含PDF文件的目录")
                return 1
        
        return 0
        
    except Exception as e:
        logger.error(f"程序执行失败: {e}")
        logger.error(traceback.format_exc())
        return 1

if __name__ == "__main__":
    exit(main())
