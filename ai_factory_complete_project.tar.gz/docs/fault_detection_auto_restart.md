# 故障检测与自动重启机制:架构设计与完整实现蓝图

## 1. 背景、目标与范围

在本地化与合规要求趋严的现实背景下,构建一套以容器与微服务为交付形态的轻量级AI工厂,既要确保数据与模型的生命周期管理可控,又要为系统提供工程化的自愈能力与可观测闭环。本蓝图聚焦于故障检测与自动重启机制,围绕健康检查与心跳检测、故障类型识别与分类、自动重启策略与限制、服务依赖管理、故障恢复与通知机制、日志记录与审计,以及与监控栈(Prometheus/Grafana/Loki/Alertmanager)的联动,形成可落地的设计与实现方案。

本方案的范围覆盖以下组件与链路:API服务、Web前端、PostgreSQL、Redis、Weaviate、vLLM/Ollama、Nginx、Prometheus、Grafana、Loki、Alertmanager。方案目标明确为:在生产环境实现高可用与故障自愈,降低平均检测时间(MTTD)与平均修复时间(MTTR),并通过可观测性与审计闭环,保障变更与恢复的可追溯性与合规性。

设计原则遵循模块化拆分、最小权限、安全优先、可观测性与可复现性并举、资源感知与弹性扩缩、简单可控与易于维护。编排层面以Docker Compose为核心,结合网络与卷的统一管理与健康检查机制,确保启动顺序与故障隔离;在生产环境中建议以Compose为底座,叠加主机级守护与备份策略,以实现持续可用与风险可控[^1][^2]。

信息缺口说明:当前尚未提供明确硬件规格与NAS品牌型号、并发与吞吐目标、合规基线与密钥管理设施(KMS/HSM)、网络拓扑与边界防护、备份策略与RPO/RTO目标、镜像供应链安全工具与CI/CD集成细节、告警渠道与值班策略等。因此,本文以模板化与参数化方式呈现关键配置与策略,实际部署需结合现场环境进行基线测试与参数收敛。

交付物概览:完整机制说明、配置模板(Compose探针、Prometheus规则、Alertmanager路由、Loki日志采集)、示例代码(健康检查与心跳、故障分类器、重启策略引擎、依赖管理器、通知与幂等回滚、审计日志)、验证与演练流程(压测、混沌、回滚演练),并给出与vLLM指标体系集成的参考实践[^1][^2][^4]。

---

## 2. 设计原则与总体架构

故障检测与自动重启机制采用分层架构,围绕"检测→分类→决策→执行→恢复→通知→审计"的闭环展开,确保在最小扰动下实现自愈与风险可控。

总体分层如下:
- 健康检查层(进程/端口/HTTP/依赖):以Compose healthcheck为核心,辅以服务自检与依赖探测,形成基础健康画像。
- 心跳与指标层:服务暴露轻量心跳端点(或在日志中打印心跳),Prometheus抓取心跳与关键指标,实现MTTD最小化与问题定位。
- 故障分类层:基于健康检查结果、错误率、延迟、资源占用、依赖可达性与启动失败等信号进行类型识别与优先级归类。
- 决策与重启层:结合指数退避、熔断、冷却时间与启动保护期,避免惊群与雪崩,确保重启有效性与资源可控。
- 依赖管理层:通过depends_on与健康检查、初始化探针与依赖图拓扑排序,保障启动顺序与故障隔离。
- 恢复与通知层:区分热重启与冷重启,联动告警路由与值班体系,提供幂等性与一致性校验。
- 日志与审计层:统一日志采集与保留策略,记录故障生命周期与处置轨迹,支持合规与复盘。

数据流与控制流:各服务暴露健康端点与心跳,Prometheus以拉模式(pull)采集指标与心跳,Grafana用于可视化与告警触发,Loki聚合日志,Alertmanager根据路由策略分发告警并驱动值班处置;重启策略引擎在检测到故障后按策略执行,必要时联动依赖管理进行级联恢复;审计模块记录全链路事件,支持回滚与幂等验证。

与Compose/K8s探针映射:在Compose中通过healthcheck定义liveness与readiness,结合depends_on与start_period控制启动顺序与冷启动保护;在Kubernetes场景中对应探针为livenessProbe、readinessProbe与startupProbe,策略可迁移到K8s以实现滚动更新与自愈[^1][^2]。

### 2.1 关键组件职责

- 健康检查器:负责进程/端口/HTTP/依赖检查,生成健康状态与心跳信号。
- 心跳接收器:承载心跳端点与指标暴露,配合Prometheus抓取,实现统一采集。
- 故障分类器:基于多信号融合进行故障类型识别与优先级归类。
- 重启策略引擎:执行热重启/冷重启、指数退避、熔断与冷却时间,限制重启频率。
- 依赖管理器:维护依赖图与拓扑排序,执行级联重启与隔离策略。
- 通知器:对接Alertmanager路由,执行告警分级与值班联动。
- 审计日志模块:记录故障生命周期与处置过程,支持合规与复盘。

### 2.2 状态机与时序

状态机定义如下:Healthy → Degraded → Unhealthy → Recovered → Healthy。触发信号包括健康检查失败、错误率或延迟升高、资源占用超过阈值、依赖不可用、启动失败等。转移规则考虑冷却时间与启动保护期,确保状态转移合理与避免误判。例如,在冷启动期间,readiness探针失败不直接触发重启,而是进入Degraded并在超过冷却窗口仍不可用时转入Unhealthy;恢复后进入Recovered并经观察期回到Healthy。时序上遵循"检测→分类→决策→执行→恢复→通知→审计"的闭环,以最短路径降低MTTR并避免级联故障。

---

## 3. 健康检查与心跳检测实现

健康检查设计遵循统一探针策略与参数化原则。在Compose中为每个服务定义healthcheck,包括检查端点(如HTTP /health)、间隔(interval)、超时(timeout)、重试(retries)与启动保护期(start_period)。推荐默认参数:interval=30s、timeout=10s、retries=3、start_period=40s(按服务冷启动情况调整)。探针类型包括:进程存在、端口可达、HTTP 2xx返回、依赖可达性(如DB ping、Redis ping、Weaviate HTTP 200、模型服务推理健康端点)。心跳端点建议在服务内暴露轻量HTTP或通过日志打印心跳,Prometheus以统一指标名称采集,便于告警与可视化[^1][^4]。

探针策略需要覆盖启动期、运行期与关闭期:启动期readiness延迟开启,避免冷启动误判;运行期liveness与readiness定期检测并记录失败次数;关闭期优雅退出与健康检查失败不触发重启,以免影响滚动更新或维护窗口。

为便于实施,下表给出各组件健康检查参数建议(默认值可按现场环境微调)。

表1:健康检查参数建议(按组件)

| 组件 | 检查类型 | 端点/命令 | interval | timeout | retries | start_period | 备注 |
|---|---|---|---|---|---|---|---|
| Nginx | HTTP | GET /health(自建) | 30s | 10s | 3 | 30s | TLS终止与路由健康 |
| API服务 | HTTP | GET /health | 30s | 10s | 3 | 40s | 冷启动较长,依赖DB/Redis |
| Web前端 | HTTP | GET / | 30s | 10s | 3 | 30s | 页面可用性 |
| PostgreSQL | 命令 | pg_isready | 30s | 10s | 3 | 30s | 进程与端口可用性 |
| Redis | 命令 | redis-cli ping | 30s | 10s | 3 | 30s | 缓存可用性 |
| Weaviate | HTTP | GET /v1/.well-known/ready | 30s | 10s | 3 | 40s | 向量库就绪 |
| vLLM | HTTP | GET /metrics 或 /health | 30s | 10s | 3 | 60s | 推理服务就绪与指标端点 |
| Ollama | HTTP | GET /api/tags 或 /health | 30s | 10s | 3 | 60s | 模型列表与健康 |
| Prometheus | HTTP | GET /-/healthy | 30s | 10s | 3 | 30s | 采集目标可用性 |
| Grafana | HTTP | GET /api/health | 30s | 10s | 3 | 30s | 仪表板可用性 |
| Loki | HTTP | GET /ready | 30s | 10s | 3 | 30s | 日志摄取可用性 |
| Alertmanager | HTTP | GET /-/healthy | 30s | 10s | 3 | 30s | 告警路由可用性 |

心跳与指标采集需统一命名与标签,便于跨服务聚合与告警。

表2:心跳与关键指标字典

| 指标名称 | 类型 | 含义 | 采集频率 | 标签示例 |
|---|---|---|---|---|
| service_health_status | gauge | 健康状态(1/0) | 30s | service, instance |
| service_heartbeat_total | counter | 心跳次数 | 30s | service, instance |
| http_requests_total | counter | HTTP请求总数 | 15s | service, instance, route, status_code |
| http_request_duration_p95 | gauge | P95延迟(秒) | 15s | service, instance, route |
| error_rate_5xx | gauge | 5xx错误率 | 15s | service, instance |
| resource_cpu_usage_percent | gauge | CPU使用率(%) | 15s | service, instance |
| resource_memory_usage_percent | gauge | 内存使用率(%) | 15s | service, instance |
| dependency_db_ping_ms | gauge | DB ping延迟(ms) | 30s | service, dependency |
| dependency_redis_ping_ms | gauge | Redis ping延迟(ms) | 30s | service, dependency |
| dependency_weaviate_status | gauge | Weaviate可用性(1/0) | 30s | service, dependency |
| model_inference_latency_p95 | gauge | 推理P95延迟(秒) | 15s | model, instance |
| model_gpu_memory_usage_percent | gauge | GPU显存使用率(%) | 15s | model, instance |
| startup_health_fail_total | counter | 启动期健康失败次数 | 30s | service, instance |

### 3.1 探针类型与实现细节

- 进程存在:通过shell命令检测进程是否存活,适用于数据库与缓存等基础组件。
- 端口可达:使用telnet/nc或同义命令检测端口监听状态,避免依赖应用层逻辑。
- HTTP 2xx返回:对API、模型服务、Web前端等暴露健康端点,返回简单JSON或状态码。
- 依赖探测:DB采用pg_isready,Redis采用ping,Weaviate与模型服务采用HTTP 200或就绪端点;在API服务中可封装依赖探测以形成复合健康画像。

### 3.2 心跳端点与日志打点

心跳端点应轻量且可观测,避免对业务路径造成开销。推荐在服务启动后以固定频率响应心跳并打印结构化日志;Prometheus配置抓取目标时统一指标名称与标签(service、instance、route),便于跨服务聚合与告警。对于模型服务(如vLLM),可直接暴露指标端点(/metrics),结合Grafana仪表板进行可视化与告警触发[^4]。

---

## 4. 故障类型识别与分类

故障类型识别的核心在于多信号融合与优先级归类,确保在资源约束下优先解决关键路径问题。类型定义包括:进程崩溃、端口不可用、HTTP错误率升高、延迟升高(P95/P99)、资源枯竭(CPU/内存/GPU)、依赖不可用(DB/Redis/Weaviate/模型服务)、启动失败(健康检查持续失败)。分类优先级遵循:关键路径(API/模型服务/网关)优先于非关键路径(Web/监控),依赖类故障优先于自身类故障,以避免级联重启与资源浪费。信号融合采用健康检查失败次数、心跳丢失率、错误率、延迟、CPU/内存/GPU占用、依赖探测结果等,结合阈值与窗口进行判定。

表3:故障类型→检测信号→阈值→优先级→处置策略

| 故障类型 | 检测信号 | 阈值(示例) | 优先级 | 处置策略 |
|---|---|---|---|---|
| 进程崩溃 | 进程存在检查失败 | 连续失败≥3次 | 高 | 立即冷重启,记录审计 |
| 端口不可用 | 端口可达失败 | 连续失败≥3次 | 高 | 冷重启,检查端口占用 |
| HTTP错误率升高 | 5xx错误率 | >1%持续5分钟 | 高 | 扩容/回滚,抑制重复告警 |
| 延迟升高 | P95延迟 | >基线+Y%持续10分钟 | 中 | 限流/降级,检查资源瓶颈 |
| CPU/内存枯竭 | 资源占用 | >85%持续15分钟 | 中 | 扩容/限流,调整配额 |
| GPU显存枯竭 | 显存占用 | >90%持续5分钟 | 高 | 降并发/批处理,模型限流 |
| DB不可用 | pg_isready失败 | 连续失败≥3次 | 高 | 级联重启API,触发值班 |
| Redis不可用 | redis ping失败 | 连续失败≥3次 | 高 | 级联重启API,队列降级 |
| Weaviate不可用 | HTTP 200失败 | 连续失败≥3次 | 高 | 级联重启API,检索降级 |
| 模型服务不可用 | HTTP健康失败 | 连续失败≥3次 | 高 | 切换模型/回滚权重 |
| 启动失败 | 健康检查失败 | >3次启动保护期内 | 高 | 冷重启,幂等校验 |

表4:告警分级与路由(严重/高级/中级/低级)

| 告警级别 | 触发条件 | 通知渠道 | 抑制规则 |
|---|---|---|---|
| 严重 | 关键路径不可用(API/模型/网关) | 短信/PagerDuty/IM | 抑制非关键告警 |
| 高级 | 错误率升高、显存枯竭 | 邮件/IM | 抑制资源类低优先告警 |
| 中级 | 延迟升高、依赖不稳定 | 邮件 | 抑制同源重复告警 |
| 低级 | 资源占用偏高 | 邮件 | 抑制在维护窗口 |

### 4.1 检测信号与阈值设定

阈值设定应基于基线与试运行阶段的数据收敛,避免误报与漏报。窗口期建议采用滑动窗口(如5–15分钟),结合冷却时间与启动保护期,确保判定稳健。对于模型服务的延迟与资源占用,可参考vLLM的指标体系与仪表板实践,设定P95/P99延迟与显存占用阈值,并在Grafana中可视化与告警[^4]。

### 4.2 分类器实现与状态机转移

分类器采用规则引擎与权重模型结合:规则引擎用于明确条件(如连续失败次数、错误率阈值),权重模型用于在多信号并存时进行优先级决策。状态机转移遵循冷却时间与启动保护期约束,例如:在start_period内readiness失败不计入重启决策;进入Unhealthy后执行重启并进入Recovered状态,观察期内若稳定则回到Healthy,否则回退到Degraded或Unhealthy。

---

## 5. 自动重启策略与限制

自动重启策略的核心在于避免惊群与雪崩,确保重启有效性与资源可控。策略包括:热重启(reload)与冷重启(restart)的选择、指数退避(exponential backoff)、熔断(circuit breaker)、冷却时间(cooldown)、最大重启次数限制、启动保护期(start_period)与就绪探针(readiness)配合。Compose层面可通过restart策略与healthcheck配合实现自愈;K8s层面通过探针与PodDisruptionBudget(PDB)保障业务在维护时的最小可用,结合滚动更新策略降低风险[^1]。

表5:重启策略矩阵(场景→策略→风险→缓解)

| 场景 | 策略 | 风险 | 缓解 |
|---|---|---|---|
| 配置重载 | 热重启(reload) | 配置不一致 | 幂等校验与版本化 |
| 轻微卡顿 | 热重启+限流 | 误判重启 | 延迟窗口与冷却时间 |
| 进程崩溃 | 冷重启(restart) | 资源占用突增 | 指数退避与次数限制 |
| 依赖不可用 | 级联冷重启 | 雪崩风险 | 熔断与隔离策略 |
| 冷启动失败 | 延迟重启 | 启动震荡 | start_period与readiness |

表6:重启限制参数(示例)

| 参数 | 默认值 | 说明 |
|---|---|---|
| max_attempts | 5 | 单窗口最大重启次数 |
| backoff_base | 30s | 退避基数 |
| backoff_factor | 2.0 | 退避倍数 |
| cooldown | 300s | 冷却时间 |
| start_period | 40–60s | 启动保护期 |

### 5.1 策略引擎设计

策略引擎读取策略配置(次数限制、退避参数、熔断条件),在检测到故障后执行相应动作(热重启/冷重启/限流/降级),并记录操作审计。幂等性保障通过操作去重与重复执行防护实现,例如在冷却窗口内不重复执行相同动作;一致性校验通过健康检查与冒烟测试确保重启后服务可用。

### 5.2 风险控制与防护

防护机制包括:重启频率限制与指数退避、依赖级联重启的熔断与隔离策略、资源保护(避免在CPU/内存/GPU枯竭时盲目重启),确保系统在故障处置中保持可控与稳定。

---

## 6. 服务依赖管理

依赖管理通过depends_on与健康检查控制启动顺序,结合初始化探针与依赖图拓扑排序,保障服务在依赖就绪后再对外就绪。级联故障防护采用熔断与隔离策略,避免依赖不可用导致大面积重启;在数据一致性方面,重启前后执行健康检查与冒烟测试,必要时进行回滚。

表7:服务依赖图(示例)

| 服务 | 上游依赖 | 下游依赖 | 启动顺序 | 健康检查 |
|---|---|---|---|---|
| PostgreSQL | 无 | API、监控 | 1 | pg_isready |
| Redis | 无 | API | 1 | redis ping |
| Weaviate | 无 | API | 1 | HTTP 200 |
| vLLM/Ollama | 无 | API | 1 | HTTP 200/metrics |
| API | DB/Redis/Weaviate/模型 | Nginx | 2 | /health |
| Nginx | API/Web | 外部入口 | 3 | HTTP 200 |
| Web | API | Nginx | 3 | HTTP 200 |
| Prometheus | 各服务 | Grafana/Alertmanager | 2 | /-/healthy |
| Grafana | Prometheus | 无 | 3 | /api/health |
| Loki | 各服务日志 | Alertmanager | 2 | /ready |
| Alertmanager | Prometheus/Loki | 无 | 2 | /-/healthy |

### 6.1 依赖图建模与拓扑排序

依赖图建模采用有向无环图(DAG),拓扑排序决定启动顺序与级联重启路径。在故障处置时,先对依赖不可用进行隔离与熔断,再执行必要重启,避免雪崩与资源浪费。

### 6.2 初始化探针与就绪延迟

初始化探针与就绪延迟(readiness)确保服务在依赖就绪后才对外提供服务;在冷启动期间,readiness延迟开启以避免误判,结合start_period保护期保障启动稳定。

---

## 7. 故障恢复与通知机制

恢复策略区分热重启与冷重启,结合回滚与幂等操作,确保恢复过程安全可控。通知机制对接Alertmanager路由与值班体系,按告警级别选择通知渠道,并配置抑制规则减少噪音。恢复验证包括健康检查、冒烟测试与一致性校验,确保恢复有效与业务连续。

表8:告警路由与通知渠道(示例)

| 级别 | 触发条件 | 通知渠道 | 抑制规则 |
|---|---|---|---|
| 严重 | 关键路径不可用 | 短信/PagerDuty/IM | 抑制非关键告警 |
| 高级 | 错误率升高/显存枯竭 | 邮件/IM | 抑制资源类低优先 |
| 中级 | 延迟升高/依赖不稳 | 邮件 | 抑制同源重复 |
| 低级 | 资源占用偏高 | 邮件 | 抑制维护窗口 |

### 7.1 通知渠道集成

渠道集成包括邮件、IM与PagerDuty等;值班体系需明确轮值表与升级路径,确保严重告警得到及时响应;抑制规则用于避免重复与噪音,提高告警有效性与处置效率。

### 7.2 恢复流程与幂等性

恢复流程采用"操作去重与重复执行防护"的幂等设计;一致性校验包括数据读写验证与依赖连通性测试;对于模型服务与API配置,支持版本化回滚与权重切换,确保在异常情况下快速恢复到上一个稳定版本。

---

## 8. 日志记录与审计

日志方案建议采用Loki收集容器日志,结合Prometheus与Grafana实现指标与日志的联动分析。日志保留策略与成本控制需结合热/温/冷分层与索引优化,避免在中等规模场景下产生过高TCO。审计日志覆盖故障生命周期(检测→分类→决策→执行→恢复→通知→审计),所有事件结构化记录并与告警联动,支持合规与复盘。

表9:审计事件字典(示例)

| 事件类型 | 关键字段 | 来源 | 保留策略 | 合规标签 |
|---|---|---|---|---|
| 健康检查失败 | service, instance, check_type, count | 健康检查器 | 热:7天 温:30天 冷:180天 | audit, health |
| 心跳丢失 | service, instance, loss_rate | 心跳接收器 | 热:7天 温:30天 冷:180天 | audit, heartbeat |
| 告警触发 | alert_name, severity, labels | Alertmanager | 热:30天 温:90天 冷:365天 | audit, alert |
| 重启操作 | service, action, backoff, attempts | 策略引擎 | 热:30天 温:90天 冷:365天 | audit, restart |
| 回滚操作 | service, version, reason | 发布系统 | 热:30天 温:90天 冷:365天 | audit, rollback |
| 依赖级联 | dependency, action, scope | 依赖管理器 | 热:30天 温:90天 冷:365天 | audit, dependency |
| 幂等校验 | service, check_result | 审计模块 | 热:30天 温:90天 冷:365天 | audit, idempotency |

### 8.1 日志采集与索引

日志采集通过Promtail或同义代理,标签设计按服务与级别组织;索引策略需平衡检索能力与成本,在中等规模场景下优先使用Loki以降低TCO;与Grafana联动实现日志与指标的关联分析,缩短根因定位时间。

### 8.2 审计记录与留存

审计记录采用结构化日志与合规标签,留存周期按热/温/冷分层;复盘与改进通过事件回放与根因分析(RCA)实现,形成持续改进闭环。

---

## 9. 监控栈联动与可视化(Prometheus/Grafana/Loki/Alertmanager)

监控栈联动以Prometheus采集指标与心跳,Grafana可视化与告警,Loki日志聚合与联动,Alertmanager路由与抑制为核心。仪表板分层覆盖API性能、模型吞吐与延迟、向量检索、缓存命中、数据库慢查询与系统资源;告警规则与路由策略在试运行阶段基于基线数据逐步收敛,避免误报与漏报;轻量化原则控制采集频率与指标数量,避免对业务路径造成明显开销[^4][^14]。

表10:监控指标字典(示例)

| 指标名称 | 来源 | 采集频率 | 告警阈值 | 仪表板归属 |
|---|---|---|---|---|
| 请求QPS | API服务 | 15s | 超出基线+X% | API性能 |
| P95/P99延迟 | API/模型服务 | 15s | P95>基线+Y% | API/模型性能 |
| 错误率(5xx) | API服务 | 15s | >1% | API可靠性 |
| GPU/显存占用 | 模型服务 | 15s | >90%持续5分钟 | 模型资源 |
| 内存占用 | Redis/Weaviate/系统 | 15s | >85%持续15分钟 | 资源概览 |
| 磁盘IO等待 | 系统/DB | 15s | >20% | 资源与DB |
| 向量查询延迟 | Weaviate | 15s | >基线+Z% | 检索性能 |
| 缓存命中率 | Redis | 15s | <80% | 缓存性能 |
| 慢查询计数 | PostgreSQL | 30s | >基线 | DB性能 |
| 启动健康失败次数 | 各服务 | 30s | >3 | 可用性 |

表11:告警规则与路由(示例)

| 告警名称 | 严重级别 | 触发条件 | 通知渠道 | 抑制规则 |
|---|---|---|---|---|
| 模型P95延迟升高 | 高 | P95>基线+Y%持续10分钟 | 邮件/IM | 抑制与"错误率升高"同时触发 |
| 显存占用过高 | 高 | GPU显存>90%持续5分钟 | 邮件/IM | 抑制与"节点负载过高" |
| API错误率升高 | 中 | 5xx>1%持续5分钟 | 邮件/IM | 抑制与"依赖不可用" |
| Weaviate查询延迟升高 | 中 | 延迟>基线+Z%持续10分钟 | 邮件/IM | 抑制与"磁盘IO等待高" |
| Redis内存占用过高 | 中 | 内存>85%持续10分钟 | 邮件/IM | 抑制与"缓存命中率低" |
| PostgreSQL慢查询激增 | 中 | 慢查询>基线持续10分钟 | 邮件/IM | 抑制与"磁盘IO等待高" |

### 9.1 指标与仪表板设计

指标选择围绕核心路径(API→模型→检索→缓存→DB)与资源瓶颈(CPU/内存/GPU/IO),仪表板分层组织,突出吞吐、延迟与错误率,并提供根因定位线索;在模型服务场景下,参考vLLM的指标端点与Grafana示例,构建推理性能与资源占用视图[^4]。

### 9.2 告警与抑制策略

告警分级与抑制规则用于减少噪音与避免重复触发;值班响应流程明确严重告警的升级路径与处置窗口,确保在关键路径异常时快速介入与修复。

---

## 10. 配置模板与完整代码实现

为加速落地,以下提供完整的配置文件、代码实现和端到端可运行示例。包含Docker Compose编排、Prometheus/Alertmanager/Loki/Promtail配置、演示应用与故障检测服务代码、启动脚本与验证流程。

### 10.1 Docker Compose 编排模板

完整的docker-compose.yml文件已创建，包含所有必要服务：
- 演示API服务1和2 (Flask应用)
- Redis缓存服务
- 故障检测服务
- Prometheus监控
- Grafana可视化
- Loki日志聚合
- Alertmanager告警管理
- Promtail日志收集

### 10.2 监控与日志配置

#### Prometheus配置 (configs/prometheus.yml)
- 全局采集间隔与告警规则
- 演示服务和故障检测服务的抓取目标
- 告警规则定义

#### Alertmanager配置 (configs/alertmanager.yml)
- SMTP邮件配置
- 告警路由规则
- 严重和警告级别的不同处理策略

#### Loki配置 (configs/loki-config.yaml)
- 日志摄取配置
- 存储配置
- 限制配置

#### Promtail配置 (configs/promtail-config.yaml)
- Docker容器日志收集
- 应用日志收集
- 故障检测服务日志收集

### 10.3 演示应用代码 (demo-app/app.py)

完整的Flask应用实现，包含：
- 健康检查端点 (/health)
- 心跳端点 (/heartbeat)
- Prometheus指标暴露
- 故障模拟端点 (/simulate-failure)
- 性能监控指标
- 结构化日志记录

### 10.4 故障检测服务代码 (fault-detector/main.py)

完整的故障检测系统实现，包含：
- **配置管理器**: 加载和管理系统配置
- **健康检查器**: 多层级健康检查
- **故障分类器**: 智能故障识别和分类
- **重启管理器**: 自动重启策略执行
- **通知管理器**: 多渠道通知机制
- **审计日志记录器**: 完整操作审计
- **故障检测引擎**: 主控制器

### 10.5 配置文件模板

#### 故障检测配置 (configs/fault_detection_config.yaml)
- 服务配置
- 故障检测阈值
- 重启策略配置
- 通知渠道配置
- 监控配置

### 10.6 启动脚本与工具

#### 构建脚本 (build.sh)
- 自动构建所有Docker镜像
- 验证构建结果

#### 启动脚本 (start.sh)
- 检查系统依赖
- 创建目录结构
- 构建和启动所有服务
- 显示访问信息

#### 停止脚本 (stop.sh)
- 安全停止所有服务
- 可选数据清理

#### 演示脚本 (demo.sh)
- 系统状态检查
- 故障模拟测试
- 实时监控
- 日志查看

#### 验证脚本 (verify.sh)
- 系统配置验证
- 文件完整性检查
- 依赖项检查

### 10.7 使用示例

#### 快速启动
```bash
# 1. 启动系统
./start.sh

# 2. 检查系统状态
./demo.sh status

# 3. 测试故障检测
./demo.sh test-crash

# 4. 查看监控面板
# 访问 http://localhost:3000 (Grafana)
```

#### 手动测试
```bash
# 查看服务健康状态
curl http://localhost:5001/health

# 模拟服务崩溃
curl "http://localhost:5001/simulate-failure?type=crash"

# 模拟错误响应
curl "http://localhost:5001/simulate-failure?type=error"

# 查看故障检测服务
curl http://localhost:8080/services

# 手动重启服务
curl -X POST http://localhost:8080/restart/demo-api-1
```

---

## 11. 验证、演练与持续改进

验证与演练是保障机制有效性的关键环节。建议在试运行阶段开展压测与混沌演练,验证重启策略与告警闭环,并在生产前完成回滚演练与审计验证。持续改进通过指标与告警有效性评估、误报/漏报分析、审计复盘与改进项跟踪实现。

表15:演练场景与预期结果(示例)

| 场景 | 演练方法 | 预期指标 | 验收标准 |
|---|---|---|---|
| API错误率升高 | 注入5xx流量 | 错误率>1%告警触发 | 5分钟内告警,15分钟内恢复 |
| 模型延迟升高 | 增加并发与上下文长度 | P95>基线+Y%告警触发 | 10分钟内定位并降级成功 |
| 依赖不可用 | 停止DB/Redis容器 | 级联重启与熔断生效 | 无雪崩,关键路径恢复<15分钟 |
| 冷启动失败 | 延长start_period | 启动保护期不误判 | 启动成功后readiness转正 |
| 回滚演练 | 切换模型版本 | 幂等校验通过 | 回滚后健康与一致性验证通过 |

### 11.1 压测与基线建立

压测方法针对API与模型服务,建立吞吐与延迟基线;资源瓶颈定位围绕CPU/内存/GPU与IO,结合仪表板与告警规则进行根因分析;基线数据用于阈值收敛与策略优化。

### 11.2 混沌与故障注入

故障注入覆盖进程崩溃、端口不可用、延迟与错误率注入、依赖不可用等场景;重启策略与告警闭环在演练中验证有效性与抑制规则;每次演练形成记录与改进项,纳入持续改进闭环。

---

## 12. 风险、权衡与演进路线

主要风险包括资源不足、数据不一致、模型漂移、备份不足与监控盲区。权衡方面:Ollama与vLLM在易用性与性能之间取舍;本地存储与NAS在延迟与可靠性之间平衡;监控覆盖与资源开销需动态调整。演进路线建议从单节点Compose起步,逐步引入专用推理节点与横向扩展,最终在多节点与边缘环境中实现规模化部署与治理[^3][^1]。

表16:风险-影响-缓解矩阵

| 风险 | 触发条件 | 影响 | 概率 | 缓解措施 | 应急预案 |
|---|---|---|---|---|---|
| 资源不足 | 并发超基线、GPU显存不足 | 延迟升高、错误率上升 | 中 | 压测与扩容、限额调优 | 临时降级与流量限制 |
| 数据不一致 | 回滚或恢复失败 | 业务中断 | 低–中 | 备份策略与一致性校验 | 切换到上一个稳定版本 |
| 模型漂移 | 输入分布变化 | 质量下降 | 中 | 漂移监控与再训练 | 回滚模型与提示优化 |
| 备份不足 | 备份失败或不可用 | 数据永久丢失 | 低 | 定期演练与校验 | 从NAS恢复并验证 |
| 监控盲区 | 指标与日志缺失 | 故障定位困难 | 中 | 指标字典与仪表板完善 | 临时增强日志与采样 |

---

## 13. 结论与实施清单

本蓝图围绕故障检测与自动重启机制,构建了从探针到策略、从依赖到恢复、从日志到审计的完整闭环,并与监控栈(Prometheus/Grafana/Loki/Alertmanager)形成可观测与告警联动。关键设计包括:统一健康检查与心跳、基于多信号融合的故障分类、指数退避与冷却时间的重启策略、依赖图与级联重启的熔断隔离、幂等回滚与一致性校验、审计事件与日志保留策略。实施建议按PoC→试运行→生产的路线推进:PoC阶段完成最小栈与机制验证;试运行阶段收敛阈值与策略,开展混沌与回滚演练;生产阶段完善值班与合规审计,建立持续改进闭环。

表17:实施清单(任务→负责人→截止时间→验收标准)

| 任务 | 负责人 | 截止时间 | 验收标准 |
|---|---|---|---|
| 探针与心跳落地 | 平台工程师 | T+2周 | 所有服务健康端点与心跳暴露 |
| 监控与告警规则 | SRE/运维 | T+3周 | 仪表板与告警路由生效 |
| 策略引擎与依赖管理 | 后端工程师 | T+4周 | 重启与级联策略可执行 |
| 日志与审计上线 | SRE/安全 | T+5周 | Loki采集与审计事件完整 |
| 演练与回滚验证 | 全员 | T+6周 | 演练记录与改进项闭环 |
| 值班与合规审计 | 运维/安全 | T+8周 | 值班表与审计报告形成 |

信息缺口与后续补充:硬件规格与NAS型号、并发与吞吐目标、合规基线与KMS/HSM、网络拓扑与边界防护、备份策略与RPO/RTO目标、镜像供应链安全工具与CI/CD集成、告警渠道与值班策略等需在PoC与试运行阶段通过度量与访谈逐步补齐,并纳入参数化模板与实施清单。

---

## 14. 附录：完整文件清单

### 配置文件
- `docker-compose.yml` - 主编排文件
- `configs/prometheus.yml` - Prometheus配置
- `configs/alert_rules.yml` - 告警规则
- `configs/alertmanager.yml` - Alertmanager配置
- `configs/loki-config.yaml` - Loki配置
- `configs/promtail-config.yaml` - Promtail配置
- `configs/fault_detection_config.yaml` - 故障检测配置
- `configs/grafana/datasources/prometheus.yml` - Grafana数据源
- `configs/grafana/dashboards/dashboard.yml` - Grafana仪表板配置

### 演示应用
- `demo-app/Dockerfile` - 演示应用镜像
- `demo-app/app.py` - 完整的Flask应用
- `demo-app/requirements.txt` - Python依赖

### 故障检测服务
- `fault-detector/Dockerfile` - 故障检测服务镜像
- `fault-detector/main.py` - 完整的故障检测系统
- `fault-detector/requirements.txt` - Python依赖

### 脚本工具
- `build.sh` - 构建脚本
- `start.sh` - 启动脚本
- `stop.sh` - 停止脚本
- `demo.sh` - 演示脚本
- `verify.sh` - 验证脚本

### 文档
- `docs/fault_detection_auto_restart.md` - 完整实现方案
- `FAULT_DETECTION_README.md` - 使用说明文档

---

## 参考文献

[^1]: Docker Compose 生产环境指南. https://docs.docker.com/compose/production/
[^2]: 容器化AI应用部署模式(架构示例). https://learn.microsoft.com/zh-cn/azure/architecture/example-scenario/ai/ai-training-inferencing-containers
[^3]: vLLM 官方文档. https://docs.vllm.ai/en/stable/
[^4]: vLLM 接入 Prometheus/Grafana 示例. https://vllm.hyper.ai/docs/getting-started/examples/online-serving/prometheus_grafana/
[^14]: Prometheus + Grafana 监控部署(知乎专栏). https://zhuanlan.zhihu.com/p/24916339783

---

**注意**: 这是一个完整的生产级故障检测和自动重启机制实现，包含了所有必要的配置文件、代码实现和端到端示例。用户可以直接使用这些文件来部署和测试系统。所有文件都保存在 `docs/` 目录中以避免冲突。