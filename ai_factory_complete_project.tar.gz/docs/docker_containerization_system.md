# 轻量级AI工厂容器化系统(Docker Compose生产级)集成与部署蓝图

## 执行摘要与读者指南

本蓝图面向架构师、平台工程师、后端与机器学习工程师、SRE/运维以及信息安全负责人,提供一套在本地数据中心或边缘环境可落地的容器化系统方案。目标是以Docker与Docker Compose为核心交付形态,构建一个安全、可观测、可维护且具备版本化与回滚能力的轻量级AI工厂,覆盖数据接入与清洗、向量检索、模型推理、API与前端、监控与日志,以及以NAS为中枢的数据持久化与备份。

本方案的产出物包括:生产级docker-compose.yml与配套模板、统一网络与卷的编排策略、服务间通信与端到端数据流设计、基于RBAC与MFA的最小权限安全策略、面向RPO/RTO的备份与恢复流程、环境变量与配置分层管理、监控与日志的轻量化落地,以及从PoC到生产的实施路线与验收标准。

读者路径建议:若关注系统全貌与演进逻辑,请通读第2至第9章;若聚焦落地细节与操作步骤,请重点阅读第3至第6章,并结合第10章的模板与清单执行;若负责安全与合规,请重点关注第5章与第9章的风险与缓解措施,并结合第10章的检查清单组织验收。

在方法论上,本蓝图以生产级Compose实践为基线,结合容器化AI应用的网络与卷管理原则、模型服务的指标暴露规范以及Prometheus/Grafana的部署与告警闭环经验,确保“轻量但完备”的落地路径[^1][^2][^4][^5]。同时,针对本地AI安全与合规,引用面向本地部署的信息安全框架综述,以指导认证授权、网络隔离、加密与审计等控制项的设计[^5]。

信息缺口说明:由于目标硬件与NAS品牌型号、并发与吞吐目标、合规基线与密钥管理设施(KMS/HSM)等信息尚未提供,本文在资源配额、索引策略、监控阈值与安全加固细节上以可调参数与模板化方式呈现,实际部署需结合现场环境进行基线测试与参数收敛。

---

## 整体系统架构与组件集成

轻量级AI工厂的总体蓝图由以下组件构成:数据接入与预处理服务、关系型数据库(PostgreSQL)、缓存(Redis)、向量数据库(Weaviate)、模型推理服务(优先vLLM,备选Ollama)、API服务、应用前端(Web UI)、反向代理与网关(Nginx)、监控与日志(Prometheus/Grafana/Loki/Alertmanager),以及统一挂载的NAS共享存储。组件之间通过内部bridge网络通信,外部访问经由Nginx反向代理与端口映射统一收敛,数据持久化通过本地数据卷与NAS挂载协同实现[^2]。

设计原则遵循:模块化拆分与边界清晰、最小权限与安全优先、可观测性与可复现性并举、资源感知与弹性扩缩、简单可控与易于维护。容器编排以Docker Compose为核心,网络与卷统一管理,健康检查与依赖声明保障启动顺序与故障隔离;生产环境建议在Compose之上结合主机级守护与备份策略,以实现持续可用[^1][^2]。模型推理服务优先采用vLLM以获得高吞吐与批处理优化,在低资源或开发验证场景可切换至Ollama以简化部署与提升易用性[^3]。

为便于角色与权限设计,下表给出核心组件与责任矩阵,明确谁提供API、被谁调用、是否对互联网暴露,以及持久化与监控要求。

表1 核心组件与责任矩阵

| 组件 | 职责 | 对外暴露 | 依赖 | 数据持久化 | 监控要求 |
|---|---|---|---|---|---|
| Nginx(网关) | 统一入口、TLS终止、路由与限流 | 是(80/443) | API、Web | 无(配置可挂载) | 进程与端口可用性、证书有效期 |
| API服务 | 业务编排、鉴权、任务提交与状态查询 | 否(仅通过Nginx) | DB、Redis、向量库、模型服务 | 无(配置挂载) | QPS、P95/P99延迟、错误率 |
| Web前端 | 用户界面、对话与知识库操作 | 是(经Nginx) | API | 无 | 页面加载时间、JS错误率 |
| PostgreSQL | 结构化数据存储(应用元数据、审计等) | 否 | 磁盘IO | 是(数据卷+NAS备份) | 连接数、慢查询、磁盘使用 |
| Redis | 缓存与队列 | 否 | 内存与磁盘 | 是(AOF持久化可选) | 命中率、内存占用、延迟 |
| Weaviate | 向量索引与相似度检索 | 否(仅API服务访问) | 磁盘与内存 | 是(数据路径挂载) | 索引大小、查询延迟、插入速率 |
| vLLM/Ollama | 模型推理服务(LLM/Embedding) | 否(仅API服务访问) | GPU/CPU、显存/内存 | 模型权重可挂载至NAS | 吞吐、请求延迟、显存/内存占用 |
| Prometheus | 指标采集 | 否(本地) | 各服务exporter | 无 | 目标可用性、采集延迟 |
| Grafana | 指标可视化与告警 | 可选(内网) | Prometheus | 无 | 仪表板可用性、告警有效性 |
| Loki/Alertmanager | 日志聚合与告警路由 | 否(本地) | 各服务日志 | 无 | 日志摄取延迟、告警误报/漏报 |

上述矩阵体现了“外部入口唯一、内部服务互信”的安全边界设计:所有面向互联网的访问统一通过Nginx,内部服务之间通过容器网络隔离,数据库与缓存不对外暴露,模型服务与向量库仅由API服务调用,监控与日志系统以本地内网为主,避免将敏感指标与日志直接暴露在公网[^1][^2]。

### 逻辑架构与数据流

从用户访问到模型推理与响应的路径如下:用户通过Web前端或API客户端发起请求,经Nginx反向代理进入API服务;API服务根据业务逻辑读取或写入PostgreSQL与Redis,并在需要时调用Weaviate进行向量检索;若请求涉及生成式任务,API服务将提示词与上下文发送给vLLM或Ollama进行推理,生成结果返回给API服务,再由API服务统一组织响应经Nginx返回给用户。该路径中的数据流包括结构化数据(元数据、审计记录)、非结构化数据(原始文档与清洗产物)、向量索引数据(嵌入向量与元数据)以及模型权重与配置。

模型生命周期数据流贯穿始终:数据经DVC(Data Version Control)进行版本化与远程存储,实验由MLflow记录与追踪,模型注册与审批通过后由部署服务拉取权重并发布到推理服务;运行期指标与日志由Prometheus与Loki采集,Grafana可视化并通过Alertmanager路由告警;回滚时从模型注册表或镜像仓库/对象存储拉取历史版本,切换流量并验证,形成闭环[^12][^13][^4][^14]。

### 资源与容量假设(可调参数)

在缺少明确并发与吞吐目标的前提下,容量规划以可调参数为原则,通过基线测试逐步收敛。资源预算以CPU/GPU/内存/磁盘IO与网络带宽为主要维度,优先保障模型推理与向量检索的吞吐与延迟;缓存与数据库的内存与IOPS需与数据规模匹配;监控与日志的开销控制在整体资源的10%以内,以确保业务路径的资源占用为主。

表2 资源预算与基线参数(示例)

| 服务 | CPU限额 | 内存限额 | GPU/显存 | 磁盘IO | 网络带宽 | 健康检查参数 |
|---|---|---|---|---|---|---|
| Nginx | 0.5–1 vCPU | 512M–1G | 无 | 低 | 中 | interval=30s, retries=3 |
| API服务 | 1–2 vCPU | 1–2G | 无 | 中 | 中 | interval=30s, retries=3, start_period=40s |
| Web前端 | 0.5–1 vCPU | 512M–1G | 无 | 低 | 中 | interval=30s, retries=3 |
| PostgreSQL | 1–2 vCPU | 1–4G | 无 | 高 | 中 | 进程与端口可用性 |
| Redis | 0.5–1 vCPU | 512M–2G | 无 | 中 | 中 | 进程与端口可用性 |
| Weaviate | 1–2 vCPU | 2–4G | 无 | 中–高 | 中 | interval=30s, retries=3 |
| vLLM | 2–4 vCPU | 4–8G | 视GPU而定 | 中 | 中–高 | interval=30s, retries=3 |
| Ollama | 1–2 vCPU | 2–4G | 可用GPU/CPU | 中 | 中 | interval=30s, retries=3 |
| Prometheus | 0.5–1 vCPU | 1–2G | 无 | 中 | 低 | 目标采集可用性 |
| Grafana | 0.5–1 vCPU | 512M–1G | 无 | 低 | 低 | 进程与端口可用性 |
| Loki/Alertmanager | 0.5–1 vCPU | 512M–1G | 无 | 中 | 低 | 进程与端口可用性 |

上述参数来自容器化AI应用与Compose编排的通用实践,实际值需结合硬件与负载进行压测与调优[^2][^1]。健康检查建议统一采用间隔30秒、超时10秒、重试3次、启动保护期40秒的设置,以避免冷启动期间的误判;API与模型服务的启动保护期可适当延长,确保依赖服务就绪后再进行健康探测。

---

## Docker Compose编排配置(生产级)

镜像策略遵循多阶段构建与最小基镜像原则,固定版本与镜像摘要(digest)以保障可复现与安全;Dockerfile遵循官方最佳实践,减少层数、清理缓存与非必要包,构建时进行安全扫描与依赖锁定[^11][^10]。Compose文件组织采用“单文件多服务、依赖与健康检查、网络与卷统一管理”的策略;生产环境建议启用日志驱动限额与资源限额,配置重启策略与回滚流程;镜像仓库与配置管理采用环境变量与只读挂载结合的方式,避免明文密钥落在镜像与配置文件中[^1][^2][^10]。

表3 Compose服务配置摘要(示例)

| 服务 | 镜像版本/摘要 | 端口映射 | 环境变量 | 卷挂载 | 资源限额 | 健康检查 |
|---|---|---|---|---|---|---|
| Nginx | latest(固定digest) | 80,443 | TZ、证书路径 | conf与证书挂载 | CPU/内存限额 | HTTP 200 |
| API | 自定义:v1.x | 5001 | DB/Redis/Weaviate地址 | 无 | CPU/内存限额 | /health |
| Web | 前端:v1.x | 3000 | API_BASE_URL | 无 | CPU/内存限额 | HTTP 200 |
| DB | postgres:15-alpine | 5432 | POSTGRES_* | postgres_data | CPU/内存限额 | pg_isready |
| Redis | redis:6-alpine | 6379 | AOF等 | redis_data | CPU/内存限额 | Redis ping |
| Weaviate | semitechnologies/weaviate:1.19.0 | 8080 | QUERY_DEFAULTS等 | weaviate_data | CPU/内存限额 | HTTP 200 |
| vLLM | vllm官方镜像 | 8000 | 模型与并发参数 | 模型权重可挂载 | GPU/显存与CPU/内存限额 | HTTP 200 |
| Ollama | ollama官方镜像 | 11434 | 模型与参数 | 模型权重可挂载 | CPU/内存限额 | HTTP 200 |
| Prometheus | prom/prometheus | 9090 | 配置文件 | prometheus数据 | CPU/内存限额 | HTTP 200 |
| Grafana | grafana/grafana | 3000 | 数据源与插件 | grafana数据 | CPU/内存限额 | HTTP 200 |
| Loki | grafana/loki | 3100 | 配置文件 | loki数据 | CPU/内存限额 | HTTP 200 |
| Alertmanager | alertmanager | 9093 | 路由与接收器 | alertmanager数据 | CPU/内存限额 | HTTP 200 |

表4 镜像供应链安全清单

| 控制项 | 实施要点 |
|---|---|
| 基础镜像来源 | 使用官方或受信任仓库,固定digest |
| 扫描 | 构建流程集成漏洞扫描,阻断高危镜像 |
| SBOM | 生成软件物料清单,纳入审计 |
| 签名 | 对镜像进行签名,部署前验证 |
| 最小权限运行 | 非root用户运行,只读文件系统 |
| 机密管理 | 使用环境变量与密钥管理服务,避免明文泄露 |

#### 3.1 完整Docker Compose配置

以下为完整的docker-compose.yml配置，包含所有必要的服务、卷、网络和健康检查：

```yaml
# docker-compose.yml - AI工厂容器化系统完整配置
version: '3.8'

networks:
  ai_factory:
    driver: bridge
    ipam:
      config:
        - subnet: 172.21.0.0/16
  monitoring:
    driver: bridge
    ipam:
      config:
        - subnet: 172.22.0.0/16

volumes:
  # 数据持久化卷
  postgres_data:
    driver: local
  redis_data:
    driver: local
  weaviate_data:
    driver: local
  prometheus_data:
    driver: local
  grafana_data:
    driver: local
  alertmanager_data:
    driver: local
  node_exporter_data:
    driver: local
  cadvisor_data:
    driver: local
  loki_data:
    driver: local

services:
  # ==================== 核心业务服务 ====================
  
  # PostgreSQL 数据库服务
  postgres:
    image: postgres:15-alpine
    container_name: postgres
    restart: unless-stopped
    environment:
      - POSTGRES_DB=ai_factory
      - POSTGRES_USER=ai_user
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD:-ai_password_123}
      - PGDATA=/var/lib/postgresql/data/pgdata
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./backups:/backups
      - ./scripts/init-db.sql:/docker-entrypoint-initdb.d/init-db.sql:ro
    networks:
      - ai_factory
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ai_user -d ai_factory"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
    deploy:
      resources:
        limits:
          cpus: "1.0"
          memory: "2G"
        reservations:
          cpus: "0.5"
          memory: "1G"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # Redis 缓存服务
  redis:
    image: redis:7-alpine
    container_name: redis
    restart: unless-stopped
    command: >
      redis-server 
      --appendonly yes 
      --appendfsync everysec
      --maxmemory 512mb
      --maxmemory-policy allkeys-lru
    volumes:
      - redis_data:/data
      - ./config/redis/redis.conf:/usr/local/etc/redis/redis.conf:ro
    networks:
      - ai_factory
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      resources:
        limits:
          cpus: "0.5"
          memory: "512M"
        reservations:
          cpus: "0.25"
          memory: "256M"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # Weaviate 向量数据库
  weaviate:
    image: semitechnologies/weaviate:1.20.0
    container_name: weaviate
    restart: unless-stopped
    environment:
      - QUERY_DEFAULTS_LIMIT=25
      - AUTHENTICATION_ANONYMOUS_ACCESS_ENABLED=true
      - PERSISTENCE_DATA_PATH=/var/lib/weaviate
      - DEFAULT_VECTORIZER_MODULE=none
      - CLUSTER_HOSTNAME=node1
    volumes:
      - weaviate_data:/var/lib/weaviate
    networks:
      - ai_factory
    ports:
      - "8080:8080"
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/v1/schema"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s
    deploy:
      resources:
        limits:
          cpus: "1.0"
          memory: "2G"
        reservations:
          cpus: "0.5"
          memory: "1G"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # API 服务
  api_service:
    image: your-org/api-service:latest
    container_name: api_service
    restart: unless-stopped
    environment:
      - DATABASE_URL=postgresql://ai_user:${POSTGRES_PASSWORD:-ai_password_123}@postgres:5432/ai_factory
      - REDIS_URL=redis://redis:6379
      - WEAVIATE_URL=http://weaviate:8080
      - VLLM_URL=http://vllm_service:8000
      - OLLAMA_URL=http://ollama:11434
      - JWT_SECRET=${JWT_SECRET:-your-jwt-secret-key}
      - API_RATE_LIMIT=1000
      - LOG_LEVEL=INFO
    volumes:
      - ./config/api:/app/config:ro
      - ./logs:/app/logs
    networks:
      - ai_factory
      - monitoring
    ports:
      - "8000:8000"
      - "8001:8001"  # 监控指标端口
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
      weaviate:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s
    deploy:
      resources:
        limits:
          cpus: "1.0"
          memory: "1G"
        reservations:
          cpus: "0.5"
          memory: "512M"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "5"

  # Web 前端服务
  web_frontend:
    image: your-org/web-frontend:latest
    container_name: web_frontend
    restart: unless-stopped
    environment:
      - VITE_API_BASE_URL=http://localhost/api
      - VITE_WS_BASE_URL=ws://localhost/ws
      - NODE_ENV=production
    networks:
      - ai_factory
      - monitoring
    ports:
      - "3000:3000"
    depends_on:
      - api_service
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      resources:
        limits:
          cpus: "0.5"
          memory: "512M"
        reservations:
          cpus: "0.25"
          memory: "256M"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # vLLM 模型推理服务
  vllm_service:
    image: vllm/vllm-openai:latest
    container_name: vllm_service
    restart: unless-stopped
    volumes:
      - ./models:/models
    environment:
      - CUDA_VISIBLE_DEVICES=0
      - MODEL_PATH=/models/llama-2-7b-chat
      - HOST=0.0.0.0
      - PORT=8000
      - SERVED_MODEL_NAME=llama-2-7b-chat
      - MAX_MODEL_LEN=4096
      - TENSOR_PARALLEL_SIZE=1
      - GPU_MEMORY_UTILIZATION=0.9
    networks:
      - ai_factory
      - monitoring
    ports:
      - "8002:8000"
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/v1/models"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 120s
    deploy:
      resources:
        limits:
          cpus: "2.0"
          memory: "4G"
          devices:
            - driver: nvidia
              device_ids: ['0']
              capabilities: [gpu]
        reservations:
          cpus: "1.0"
          memory: "2G"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # Ollama 备选推理服务
  ollama:
    image: ollama/ollama:latest
    container_name: ollama
    restart: unless-stopped
    volumes:
      - ./models:/root/.ollama
      - /var/run/docker.sock:/var/run/docker.sock
    environment:
      - OLLAMA_HOST=0.0.0.0
      - OLLAMA_MODELS=/root/.ollama
    networks:
      - ai_factory
      - monitoring
    ports:
      - "11434:11434"
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:11434/api/tags"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s
    deploy:
      resources:
        limits:
          cpus: "1.0"
          memory: "2G"
        reservations:
          cpus: "0.5"
          memory: "1G"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # ==================== 监控与日志服务 ====================
  
  # Prometheus 监控服务
  prometheus:
    image: prom/prometheus:v2.45.0
    container_name: prometheus
    restart: unless-stopped
    volumes:
      - ./config/prometheus/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - ./config/prometheus/alert_rules.yml:/etc/prometheus/alert_rules.yml:ro
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--storage.tsdb.retention.time=30d'
      - '--storage.tsdb.retention.size=20GB'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
      - '--storage.tsdb.wal-compression'
      - '--web.enable-lifecycle'
      - '--web.enable-admin-api'
    networks:
      - monitoring
    ports:
      - "9090:9090"
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:9090/-/healthy"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
    deploy:
      resources:
        limits:
          cpus: "0.5"
          memory: "1G"
        reservations:
          cpus: "0.25"
          memory: "512M"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # Grafana 可视化服务
  grafana:
    image: grafana/grafana:10.0.0
    container_name: grafana
    restart: unless-stopped
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=${GRAFANA_PASSWORD:-admin123}
      - GF_USERS_ALLOW_SIGN_UP=false
      - GF_INSTALL_PLUGINS=grafana-piechart-panel,grafana-worldmap-panel
      - GF_SECURITY_DISABLE_GRAVATAR=true
      - GF_ANALYTICS_REPORTING_ENABLED=false
      - GF_ANALYTICS_CHECK_FOR_UPDATES=false
    volumes:
      - grafana_data:/var/lib/grafana
      - ./config/grafana/provisioning:/etc/grafana/provisioning:ro
      - ./config/grafana/dashboards:/var/lib/grafana/dashboards:ro
    networks:
      - monitoring
    ports:
      - "3001:3000"
    depends_on:
      - prometheus
    healthcheck:
      test: ["CMD-SHELL", "curl -f http://localhost:3000/api/health || exit 1"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
    deploy:
      resources:
        limits:
          cpus: "0.5"
          memory: "512M"
        reservations:
          cpus: "0.25"
          memory: "256M"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # AlertManager 告警管理
  alertmanager:
    image: prom/alertmanager:v0.25.0
    container_name: alertmanager
    restart: unless-stopped
    volumes:
      - ./config/alertmanager/alertmanager.yml:/etc/alertmanager/alertmanager.yml:ro
      - alertmanager_data:/alertmanager
    command:
      - '--config.file=/etc/alertmanager/alertmanager.yml'
      - '--storage.path=/alertmanager'
      - '--web.external-url=http://localhost:9093'
      - '--cluster.advertise-address=0.0.0.0:9093'
    networks:
      - monitoring
    ports:
      - "9093:9093"
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:9093/-/healthy"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      resources:
        limits:
          cpus: "0.2"
          memory: "256M"
        reservations:
          cpus: "0.1"
          memory: "128M"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # Node Exporter 系统监控
  node_exporter:
    image: prom/node-exporter:v1.6.0
    container_name: node_exporter
    restart: unless-stopped
    volumes:
      - /proc:/host/proc:ro
      - /sys:/host/sys:ro
      - /:/rootfs:ro
    command:
      - '--path.procfs=/host/proc'
      - '--path.rootfs=/rootfs'
      - '--path.sysfs=/host/sys'
      - '--collector.filesystem.mount-points-exclude=^/(sys|proc|dev|host|etc)($$|/)'
      - '--web.listen-address=0.0.0.0:9100'
    networks:
      - monitoring
    ports:
      - "9100:9100"
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:9100/metrics"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      resources:
        limits:
          cpus: "0.1"
          memory: "128M"
        reservations:
          cpus: "0.05"
          memory: "64M"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # cAdvisor 容器监控
  cadvisor:
    image: gcr.io/cadvisor/cadvisor:v0.47.0
    container_name: cadvisor
    restart: unless-stopped
    ports:
      - "8080:8080"
    volumes:
      - /:/rootfs:ro
      - /var/run:/var/run:rw
      - /sys:/sys:ro
      - /var/lib/docker/:/var/lib/docker:ro
      - /dev/disk/:/dev/disk:ro
    privileged: true
    devices:
      - /dev/kmsg
    networks:
      - monitoring
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:8080/healthz"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      resources:
        limits:
          cpus: "0.2"
          memory: "256M"
        reservations:
          cpus: "0.1"
          memory: "128M"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # Loki 日志聚合
  loki:
    image: grafana/loki:2.8.0
    container_name: loki
    restart: unless-stopped
    volumes:
      - ./config/loki/loki.yml:/etc/loki/loki.yml:ro
      - loki_data:/loki
    command: -config.file=/etc/loki/loki.yml
    networks:
      - monitoring
    ports:
      - "3100:3100"
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:3100/ready"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      resources:
        limits:
          cpus: "0.5"
          memory: "512M"
        reservations:
          cpus: "0.25"
          memory: "256M"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # ==================== 反向代理与网关 ====================
  
  # Nginx 反向代理
  nginx:
    image: nginx:alpine
    container_name: nginx
    restart: unless-stopped
    volumes:
      - ./config/nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./config/nginx/conf.d:/etc/nginx/conf.d:ro
      - ./config/ssl:/etc/nginx/ssl:ro
    networks:
      - ai_factory
      - monitoring
    ports:
      - "80:80"
      - "443:443"
    depends_on:
      - web_frontend
      - api_service
      - grafana
      - prometheus
      - alertmanager
      - node_exporter
      - cadvisor
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      resources:
        limits:
          cpus: "0.5"
          memory: "256M"
        reservations:
          cpus: "0.25"
          memory: "128M"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "5"

  # ==================== 导出器服务 (可选) ====================
  
  # Redis Exporter
  redis_exporter:
    image: oliver006/redis_exporter:v1.51.0
    container_name: redis_exporter
    restart: unless-stopped
    environment:
      - REDIS_ADDR=redis://redis:6379
      - REDIS_PASSWORD=${POSTGRES_PASSWORD:-ai_password_123}
    networks:
      - monitoring
    ports:
      - "9121:9121"
    depends_on:
      - redis
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:9121/metrics"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      resources:
        limits:
          cpus: "0.1"
          memory: "128M"
        reservations:
          cpus: "0.05"
          memory: "64M"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  # PostgreSQL Exporter
  postgres_exporter:
    image: prometheuscommunity/postgres-exporter:v0.13.2
    container_name: postgres_exporter
    restart: unless-stopped
    environment:
      - DATA_SOURCE_NAME=postgresql://ai_user:${POSTGRES_PASSWORD:-ai_password_123}@postgres:5432/ai_factory?sslmode=disable
      - PG_EXPORTER_EXTEND_QUERY_PATH=/etc/postgres_exporter/queries.yaml
    volumes:
      - ./config/postgres_exporter/queries.yaml:/etc/postgres_exporter/queries.yaml:ro
    networks:
      - monitoring
    ports:
      - "9187:9187"
    depends_on:
      - postgres
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:9187/metrics"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      resources:
        limits:
          cpus: "0.1"
          memory: "128M"
        reservations:
          cpus: "0.05"
          memory: "64M"
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
```

#### 3.2 关键配置文件

以下为Prometheus、AlertManager和Nginx的完整配置文件：

##### 3.2.1 Prometheus配置

```yaml
# config/prometheus/prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s
  external_labels:
    cluster: 'ai-factory'
    environment: 'production'

rule_files:
  - "alert_rules.yml"

alerting:
  alertmanagers:
    - static_configs:
        - targets:
          - alertmanager:9093

scrape_configs:
  # Prometheus 自身监控
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']
    scrape_interval: 5s
    metrics_path: /metrics

  # Node Exporter 系统监控
  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node_exporter:9100']
    scrape_interval: 15s
    metrics_path: /metrics

  # cAdvisor 容器监控
  - job_name: 'cadvisor'
    static_configs:
      - targets: ['cadvisor:8080']
    scrape_interval: 15s
    metrics_path: /metrics

  # AlertManager 监控
  - job_name: 'alertmanager'
    static_configs:
      - targets: ['alertmanager:9093']
    scrape_interval: 15s
    metrics_path: /metrics

  # API 服务监控
  - job_name: 'api-service'
    static_configs:
      - targets: ['api_service:8001']
    scrape_interval: 15s
    metrics_path: /metrics
    scrape_timeout: 10s

  # vLLM 模型服务监控
  - job_name: 'vllm-service'
    static_configs:
      - targets: ['vllm_service:8000']
    scrape_interval: 15s
    metrics_path: /metrics
    scrape_timeout: 10s

  # Redis 监控
  - job_name: 'redis'
    static_configs:
      - targets: ['redis_exporter:9121']
    scrape_interval: 15s
    metrics_path: /metrics

  # PostgreSQL 监控
  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres_exporter:9187']
    scrape_interval: 15s
    metrics_path: /metrics

  # Weaviate 监控
  - job_name: 'weaviate'
    static_configs:
      - targets: ['weaviate:8080']
    scrape_interval: 15s
    metrics_path: /metrics

  # Nginx 监控
  - job_name: 'nginx'
    static_configs:
      - targets: ['nginx:80']
    scrape_interval: 15s
    metrics_path: /nginx_status

# 远程写入配置 (可选)
remote_write:
  - url: "http://your-remote-storage:8086/api/v1/prom/write?db=prometheus"
    queue_config:
      max_samples_per_send: 1000
      max_shards: 200
      capacity: 2500

# 远程读取配置 (可选)
remote_read:
  - url: "http://your-remote-storage:8086/api/v1/prom/read?db=prometheus"
```

##### 3.2.2 AlertManager配置

```yaml
# config/alertmanager/alertmanager.yml
global:
  smtp_smarthost: 'smtp.gmail.com:587'
  smtp_from: 'alerts@yourcompany.com'
  smtp_auth_username: 'alerts@yourcompany.com'
  smtp_auth_password: 'your-app-password'
  smtp_require_tls: true

route:
  group_by: ['alertname', 'cluster', 'service']
  group_wait: 10s
  group_interval: 10s
  repeat_interval: 1h
  receiver: 'default'
  routes:
    # 高优先级告警
    - match:
        severity: critical
      receiver: 'critical-alerts'
      group_wait: 5s
      repeat_interval: 15m
    
    # 中优先级告警
    - match:
        severity: warning
      receiver: 'warning-alerts'
      group_wait: 30s
      repeat_interval: 2h
    
    # 服务特定告警
    - match:
        service: 'api-service'
      receiver: 'api-team'
      group_wait: 10s
      repeat_interval: 30m
    
    - match:
        service: 'vllm-service'
      receiver: 'ml-team'
      group_wait: 10s
      repeat_interval: 30m

receivers:
  - name: 'default'
    email_configs:
      - to: 'admin@yourcompany.com'
        subject: '[监控告警] {{ .GroupLabels.alertname }}'
        body: |
          {{ range .Alerts }}
          告警: {{ .Annotations.summary }}
          描述: {{ .Annotations.description }}
          时间: {{ .StartsAt }}
          严重程度: {{ .Labels.severity }}
          服务: {{ .Labels.service }}
          实例: {{ .Labels.instance }}
          {{ end }}

  - name: 'critical-alerts'
    email_configs:
      - to: 'oncall@yourcompany.com'
        subject: '[P0 紧急告警] {{ .GroupLabels.alertname }}'
        body: |
          🚨 紧急告警 🚨
          
          {{ range .Alerts }}
          告警: {{ .Annotations.summary }}
          描述: {{ .Annotations.description }}
          时间: {{ .StartsAt }}
          严重程度: {{ .Labels.severity }}
          服务: {{ .Labels.service }}
          实例: {{ .Labels.instance }}
          {{ end }}
          
          请立即响应并处理此告警！
    webhook_configs:
      - url: 'http://slack-webhook:5000/alerts'
        send_resolved: true

  - name: 'warning-alerts'
    email_configs:
      - to: 'team@yourcompany.com'
        subject: '[P1 警告] {{ .GroupLabels.alertname }}'
        body: |
          ⚠️ 警告告警 ⚠️
          
          {{ range .Alerts }}
          告警: {{ .Annotations.summary }}
          描述: {{ .Annotations.description }}
          时间: {{ .StartsAt }}
          严重程度: {{ .Labels.severity }}
          服务: {{ .Labels.service }}
          实例: {{ .Labels.instance }}
          {{ end }}

  - name: 'api-team'
    email_configs:
      - to: 'api-team@yourcompany.com'
        subject: '[API服务告警] {{ .GroupLabels.alertname }}'
        body: |
          API团队告警通知
          
          {{ range .Alerts }}
          告警: {{ .Annotations.summary }}
          描述: {{ .Annotations.description }}
          时间: {{ .StartsAt }}
          严重程度: {{ .Labels.severity }}
          服务: {{ .Labels.service }}
          实例: {{ .Labels.instance }}
          {{ end }}

  - name: 'ml-team'
    email_configs:
      - to: 'ml-team@yourcompany.com'
        subject: '[ML模型服务告警] {{ .GroupLabels.alertname }}'
        body: |
          ML团队告警通知
          
          {{ range .Alerts }}
          告警: {{ .Annotations.summary }}
          描述: {{ .Annotations.description }}
          时间: {{ .StartsAt }}
          严重程度: {{ .Labels.severity }}
          服务: {{ .Labels.service }}
          实例: {{ .Labels.instance }}
          {{ end }}

inhibit_rules:
  # 如果服务不可用，抑制其他相关告警
  - source_match:
      alertname: 'ServiceDown'
    target_match:
      service: '{{ .source.service }}'
    equal: ['instance']
  
  # 如果主机不可用，抑制该主机上的服务告警
  - source_match:
      alertname: 'HostDown'
    target_match:
      instance: '{{ .source.instance }}'
    equal: ['instance']
```

##### 3.2.3 Nginx配置

```nginx
# config/nginx/nginx.conf
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';
    
    access_log /var/log/nginx/access.log main;
    
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    
    # Gzip 压缩
    gzip on;
    gzip_vary on;
    gzip_min_length 10240;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
    
    # 包含站点配置
    include /etc/nginx/conf.d/*.conf;
}
```

```nginx
# config/nginx/conf.d/ai-factory.conf
server {
    listen 80;
    server_name localhost;
    
    # 健康检查
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
    
    # Web前端
    location / {
        proxy_pass http://web_frontend:3000/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
    
    # API服务
    location /api/ {
        proxy_pass http://api_service:8000/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
        
        # API限流
        limit_req zone=api burst=20 nodelay;
    }
    
    # vLLM服务
    location /vllm/ {
        proxy_pass http://vllm_service:8000/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 300s;
    }
    
    # Ollama服务
    location /ollama/ {
        proxy_pass http://ollama:11434/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 60s;
    }
    
    # Grafana 监控面板
    location /grafana/ {
        proxy_pass http://grafana:3000/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Prometheus 监控数据
    location /prometheus/ {
        proxy_pass http://prometheus:9090/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # AlertManager 告警管理
    location /alertmanager/ {
        proxy_pass http://alertmanager:9093/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Node Exporter 系统指标
    location /node-exporter/ {
        proxy_pass http://node_exporter:9100/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # cAdvisor 容器指标
    location /cadvisor/ {
        proxy_pass http://cadvisor:8080/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Weaviate 向量数据库
    location /weaviate/ {
        proxy_pass http://weaviate:8080/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
}

# 限流配置
http {
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
}
```
| 最小权限运行 | 非root用户运行,只读文件系统 |
| 机密管理 | 使用环境变量与密钥管理服务,避免明文泄露 |

### 参考服务栈与配置映射

以常见AI应用栈为例:API服务通过DB_HOST/DB_PORT/DB_USER/DB_PASSWORD连接PostgreSQL,通过REDIS_HOST/REDIS_PORT连接Redis,通过Weaviate端点进行向量检索;Nginx对外暴露80/443并路由到API与Web;Web前端设置API_BASE_URL指向内部API服务;向量库Weaviate配置数据路径与默认向量器模块;数据库与缓存采用本地数据卷持久化,权重与归档日志挂载到NAS共享路径。该参考栈体现了“外部入口唯一、内部服务解耦”的组织方式,便于在Compose中统一管理依赖与健康检查[^2][^8][^9]。

---

## 服务间通信与端到端数据流

服务间通信采用REST或OpenAI兼容API,避免共享数据库的跨服务直接访问;所有外部访问统一通过Nginx反向代理收敛。端到端数据流贯穿用户请求→API编排→检索(Weaviate)→推理(vLLM/Ollama)→响应;模型生命周期闭环涵盖数据版本化(DVC)、实验追踪(MLflow)、注册与审批、部署与监控、回滚与审计[^12][^13][^4]。

表5 服务通信矩阵(示例)

| 调用方 | 被调用方 | 协议 | 端口 | 鉴权方式 | 超时/重试 |
|---|---|---|---|---|---|
| Nginx | API服务 | HTTP | 5001 | JWT/OAuth2(可选经Nginx) | 30s/重试3次 |
| Nginx | Web前端 | HTTP | 3000 | 无(内网) | 10s/重试3次 |
| API服务 | PostgreSQL | TCP | 5432 | DB用户/密码 | 10s/重试3次 |
| API服务 | Redis | TCP | 6379 | 无(内网) | 5s/重试3次 |
| API服务 | Weaviate | HTTP | 8080 | 无(内网) | 10s/重试3次 |
| API服务 | vLLM/Ollama | HTTP | 8000/11434 | 无(内网) | 60s/重试3次 |
| Prometheus | 各服务指标端点 | HTTP | 各自端口 | 无(内网) | 5s/重试3次 |
| Grafana | Prometheus | HTTP | 9090 | 无(内网) | 10s/重试3次 |
| Alertmanager | 通知渠道 | HTTP/SMTP等 | 各自协议 | 凭据 | 10s/重试3次 |

该通信矩阵体现了“内部互信、边界收敛”的设计:内部服务间以最小权限与内网访问为主,外部访问统一通过Nginx进行TLS终止与路由控制;鉴权可在API层或反向代理层实现,避免数据库与缓存对外暴露;超时与重试策略结合健康检查与启动保护期,避免冷启动期间的误判与级联故障[^1][^2][^4]。

---

## 网络配置与安全策略

网络拓扑采用bridge与子网规划,外部入口唯一(仅Nginx暴露80/443),内部服务互信与微分段。身份认证与授权采用基于角色的访问控制(RBAC)与多因素认证(MFA),遵循最小权限原则;镜像供应链安全涵盖来源控制、漏洞扫描、SBOM与签名;数据安全与合规包括静态与传输加密、备份与隔离、脱敏与审计日志;安全运营建立监测预警、应急响应与复盘改进的闭环[^5][^10][^1]。

表6 网络端口与暴露策略(示例)

| 服务 | 内部端口 | 外部端口 | 协议 | 暴露策略 |
|---|---|---|---|---|
| Nginx | 80,443 | 80,443 | HTTP/HTTPS | 对外暴露,统一入口 |
| API | 5001 | 无(经Nginx) | HTTP | 仅内部访问 |
| Web | 3000 | 无(经Nginx) | HTTP | 仅内部访问 |
| PostgreSQL | 5432 | 无 | TCP | 仅内部访问 |
| Redis | 6379 | 无 | TCP | 仅内部访问 |
| Weaviate | 8080 | 无 | HTTP | 仅内部访问 |
| vLLM | 8000 | 无 | HTTP | 仅内部访问 |
| Ollama | 11434 | 无 | HTTP | 仅内部访问 |
| Prometheus | 9090 | 无 | HTTP | 仅内部访问 |
| Grafana | 3000 | 可选内网 | HTTP | 按需暴露 |
| Loki | 3100 | 无 | HTTP | 仅内部访问 |
| Alertmanager | 9093 | 无 | HTTP | 仅内部访问 |

表7 角色-权限矩阵(示例)

| 角色 | 资源 | 操作 | 审批流程 | 审计要求 |
|---|---|---|---|---|
| 管理员 | 全局配置、用户与角色 | 创建/修改/删除 | 双人审批 | 全量审计与告警 |
| 开发者 | 模型与数据管道 | 提交/回滚/发布 | 单人审批+代码审查 | 操作留痕与产物签名 |
| 运维 | 监控与日志、备份 | 配置/告警/恢复 | 变更审批 | 变更记录与验证 |
| 分析师 | 数据与仪表板 | 查询/可视化 | 数据访问审批 | 查询审计与脱敏 |
| 访客 | Web前端 | 只读访问 | 临时授权 | 访问日志与限流 |

表8 安全控制清单(示例)

| 控制项 | 实施措施 | 验证方法 | 频次 |
|---|---|---|---|
| 身份认证 | 本地用户+MFA | 登录审计与失败告警 | 持续 |
| 授权管理 | RBAC与最小权限 | 权限审计与越权告警 | 每周 |
| 网络隔离 | 内外网分离与微分段 | 端口扫描与路由审计 | 每周 |
| 加密 | 静态与传输加密 | 配置核查与证书检查 | 每月 |
| 镜像安全 | 扫描、SBOM与签名 | 构建与部署校验 | 每次发布 |
| 备份与恢复 | 全量/增量与隔离 | 恢复演练与校验 | 每月 |
| 审计日志 | 全量记录与脱敏 | 日志审计与留存检查 | 每周 |
| 应急响应 | 预案与演练 | 复盘与改进记录 | 每季度 |

---

## 存储卷与数据持久化(NAS集成)

NAS作为统一数据中枢承载原始数据、清洗数据、向量索引、模型权重与备份。容器侧通过数据卷与bind mount将NAS共享路径挂载到服务容器,实现跨服务的统一读写与权限控制;数据库与向量库的持久化目录建议采用本地卷以保障IO性能,同时将备份与归档任务指向NAS以降低主存储压力[^6]。

数据库选型建议:PostgreSQL用于结构化数据(应用元数据、审计日志、权限与任务记录等),Redis用于缓存与会话、队列与限流,Weaviate用于向量索引与相似度检索。性能优化围绕IOPS与内存命中率展开:PostgreSQL需关注连接池与慢查询优化、适当增加shared_buffers与checkpoint参数;Redis需设置合理的最大内存与淘汰策略,确保热点数据的命中率;Weaviate需根据数据规模与查询特征调整索引参数与批处理策略,控制段大小与合并策略以平衡写入与查询性能[^8][^9][^7][^6]。

表9 数据分类与存储映射(示例)

| 数据类型 | 存储位置 | 保留策略 | 备份频率 | 加密要求 |
|---|---|---|---|---|
| 原始数据(文档/日志) | NAS共享路径/raw | 长期保留,按项目归档 | 每周全量+每日增量 | 静态加密(磁盘/文件级) |
| 清洗数据(结构化/半结构化) | NAS共享路径/clean + DB | 中期保留,版本化 | 每周全量+每日增量 | 静态加密(磁盘/文件级) |
| 向量索引 | Weaviate数据路径 + NAS备份 | 中期保留,重建成本高 | 每周全量+每日增量 | 静态加密(磁盘/文件级) |
| 模型权重 | NAS共享路径/models + 镜像仓库 | 长期保留,版本化 | 每次发布归档 | 静态加密(磁盘/文件级) |
| 审计日志 | DB与Loki + NAS归档 | 合规要求长期保留 | 每周全量+每日增量 | 静态加密与访问审计 |

表10 数据库/缓存/向量库选型对比(示例)

| 组件 | 优势 | 局限 | 典型场景 | 资源画像 |
|---|---|---|---|---|
| PostgreSQL | 成熟稳定、SQL能力强、插件丰富 | 需要调优与维护 | 应用元数据、审计与权限 | 1–2 vCPU,1–4G内存,高IO |
| Redis | 低延迟、缓存/队列/限流 | 持久化与内存管理需谨慎 | 会话、队列、热点数据 | 0.5–1 vCPU,512M–2G内存 |
| Weaviate | 向量检索与索引、易集成 | 大规模索引需资源与调优 | 语义检索、RAG | 1–2 vCPU,2–4G内存,中高IO |

表11 目录挂载与权限(示例)

| 容器路径 | 主机路径/NAS | 读写权限 | 属主/属组 | 备份策略 |
|---|---|---|---|---|
| /var/lib/postgresql/data | 本地数据卷 | rw | postgres | 每周全量+每日增量 |
| /data | 本地数据卷(Redis) | rw | redis | 每周全量 |
| /var/lib/weaviate | 本地数据卷 | rw | weaviate | 每周全量+每日增量 |
| /etc/nginx/conf.d | 主机配置目录 | ro | root | 配置版本化 |
| /var/log | Loki/日志目录 | rw | adm | 每周归档到NAS |
| /models | NAS共享路径 | rw | appuser | 每次发布归档 |

NAS集成要点:在容器侧使用统一命名卷与bind mount组合;NAS路径权限与属主需与应用容器用户匹配,避免权限不足或越权访问;定期对数据库与向量索引执行快照备份并将权重与归档日志同步到NAS;灾难恢复时从NAS恢复数据到本地卷,启动服务并进行一致性校验与读写验证[^6][^7][^8][^9]。

---

## 环境变量与配置管理

环境变量分层包括全局(时区、证书路径)、服务级(DB/Redis/Weaviate地址、模型参数)、机密(密码、API密钥)。注入方式避免明文出现在镜像与配置,结合外部密钥管理或受管机密;配置挂载采用只读策略,降低误操作风险;回滚与版本化通过镜像标签与配置模板版本管理实现[^1][^10]。

表12 环境变量清单(示例)

| 变量名 | 作用域 | 默认值 | 是否机密 | 更新策略 |
|---|---|---|---|---|
| TZ | 全局 | UTC | 否 | 版本化(配置模板) |
| CERT_PATH | Nginx | /etc/nginx/certs | 否 | 版本化(证书轮换) |
| DB_HOST | API/DB | db | 否 | 环境文件(多环境) |
| DB_PORT | API/DB | 5432 | 否 | 环境文件 |
| DB_USER | API/DB | app | 是 | KMS/HSM注入 |
| DB_PASSWORD | API/DB | - | 是 | KMS/HSM注入 |
| REDIS_HOST | API/Redis | redis | 否 | 环境文件 |
| REDIS_PORT | API/Redis | 6379 | 否 | 环境文件 |
| WEAVIATE_HOST | API/Weaviate | weaviate | 否 | 环境文件 |
| WEAVIATE_PORT | API/Weaviate | 8080 | 否 | 环境文件 |
| MODEL_PATH | vLLM/Ollama | /models | 否 | 只读挂载 |
| GRAFANA_PASSWORD | Grafana | - | 是 | KMS/HSM注入 |
| PROMETHEUS_CONFIG | Prometheus | /etc/prometheus/prometheus.yml | 否 | 只读挂载 |
| LOKI_CONFIG | Loki | /etc/loki/loki.yml | 否 | 只读挂载 |
| ALERTMANAGER_CONFIG | Alertmanager | /etc/alertmanager/alertmanager.yml | 否 | 只读挂载 |

---

## 监控与日志(轻量化落地)

监控目标是以最低开销实现对服务健康、推理性能、数据管道与资源利用的可见性。指标采集采用Prometheus,统一拉取模型服务、API服务、数据库与缓存、向量库与系统主机的指标;可视化与告警采用Grafana与Alertmanager,仪表板按服务与场景分层,告警路由与抑制策略确保有效通知与减少噪音。日志方案采用Loki收集容器日志,结合Prometheus对模型服务(如vLLM)的指标进行展示与告警,形成指标与日志的联动分析[^4][^14]。

表13 监控指标字典(示例)

| 指标名称 | 来源 | 采集频率 | 告警阈值 | 仪表板归属 |
|---|---|---|---|---|
| 请求QPS | API服务 | 15s | 超出基线+X% | API性能 |
| P95/P99延迟 | API服务/模型服务 | 15s | P95>基线+Y% | API/模型性能 |
| 错误率(5xx) | API服务 | 15s | >1% | API可靠性 |
| GPU/显存占用 | 模型服务 | 15s | >90%持续N分钟 | 模型资源 |
| 内存占用 | Redis/Weaviate/系统 | 15s | >85%持续N分钟 | 资源概览 |
| 磁盘IO等待 | 系统/DB | 15s | >20% | 资源与DB |
| 向量查询延迟 | Weaviate | 15s | >基线+Z% | 检索性能 |
| 缓存命中率 | Redis | 15s | <80% | 缓存性能 |
| 慢查询计数 | PostgreSQL | 30s | >基线 | DB性能 |
| 启动健康失败次数 | 各服务 | 30s | >3 | 可用性 |

表14 告警路由与阈值(示例)

| 告警名称 | 严重级别 | 触发条件 | 通知渠道 | 抑制规则 |
|---|---|---|---|---|
| 模型P95延迟升高 | 高 | P95>基线+Y%持续10分钟 | 邮件/IM | 抑制与“错误率升高”同时触发 |
| 显存占用过高 | 高 | GPU显存>90%持续5分钟 | 邮件/IM | 抑制与“节点负载过高” |
| API错误率升高 | 中 | 5xx>1%持续5分钟 | 邮件/IM | 抑制与“依赖不可用” |
| Weaviate查询延迟升高 | 中 | 延迟>基线+Z%持续10分钟 | 邮件/IM | 抑制与“磁盘IO等待高” |
| Redis内存占用过高 | 中 | 内存>85%持续10分钟 | 邮件/IM | 抑制与“缓存命中率低” |
| PostgreSQL慢查询激增 | 中 | 慢查询>基线持续10分钟 | 邮件/IM | 抑制与“磁盘IO等待高” |

轻量化原则:控制采集频率与指标数量,避免对业务路径造成明显开销;日志级别默认INFO,必要时调整为DEBUG并限时启用;告警阈值基于基线设定,避免误报与漏报;仪表板分层组织,突出核心路径与瓶颈定位[^4][^14]。

---

## 备份与灾难恢复(BCDR)

备份策略采用全量+增量+快照+版本化组合,工具选型建议Restic/Borg/rsync,结合GFS与“3-2-1”原则(3份副本、2种介质、1份异地),并确保备份加密与完整性校验。RPO/RTO目标需在试运行阶段通过演练与度量形成可验证指标。恢复流程包括准备→执行→验证→记录,形成审计与复盘机制;演练计划覆盖单文件、整卷、数据库、向量索引与模型回滚等场景[^11][^12][^13][^14]。

表15 备份策略矩阵(示例)

| 数据类型 | 频率 | 保留期 | 工具 | 加密 | 验证 |
|---|---|---|---|---|---|
| 数据库 | 每日增量+每周全量 | 30–90天 | Restic/Borg | AES-256 | 校验和与恢复演练 |
| 向量索引 | 每日增量+每周全量 | 30–90天 | Restic/Borg | AES-256 | 索引一致性校验 |
| 模型权重 | 每次发布归档 | 长期 | Borg/Restic | AES-256 | 版本校验与回滚演练 |
| 文件共享 | 每日增量+每周全量 | 30–90天 | Rsync+Borg | AES-256 | 随机抽样恢复验证 |
| 审计日志 | 每周全量+每日增量 | 90–180天 | Restic | AES-256 | 哈希与保留策略检查 |

表16 RPO/RTO矩阵(示例)

| 系统/数据 | RPO | RTO | 恢复策略 | 优先级 |
|---|---|---|---|---|
| 核心数据库 | ≤15分钟 | ≤1小时 | 增量+日志重放 | 高 |
| 向量索引 | ≤1小时 | ≤2小时 | 快照+增量重建 | 高 |
| 模型权重 | ≤1版本 | ≤30分钟 | 版本回滚 | 中高 |
| 文件共享 | ≤1小时 | ≤1小时 | 增量+异地副本 | 中 |
| 审计日志 | ≤24小时 | ≤24小时 | 归档与WORM | 中 |

---

## 风险、权衡与演进路线

主要风险包括:硬件资源不足导致延迟与吞吐不达标;数据一致性风险在回滚与恢复时引发业务中断;模型漂移导致质量下降;备份恢复不充分导致数据永久丢失。权衡方面:Ollama与vLLM在易用性与性能之间取舍;本地存储与NAS在延迟与可靠性之间平衡;监控覆盖与资源开销需动态调整。演进路线建议从单节点Compose起步,逐步引入专用推理节点与横向扩展,最终在多节点与边缘环境中实现规模化部署与治理[^3][^1]。

表17 风险-影响-缓解矩阵(示例)

| 风险 | 触发条件 | 影响 | 概率 | 缓解措施 | 应急预案 |
|---|---|---|---|---|---|
| 资源不足 | 并发超基线、GPU显存不足 | 延迟升高、错误率上升 | 中 | 压测与扩容、限额调优 | 临时降级与流量限制 |
| 数据不一致 | 回滚或恢复失败 | 业务中断 | 低–中 | 备份策略与一致性校验 | 切换到上一个稳定版本 |
| 模型漂移 | 输入分布变化 | 质量下降 | 中 | 漂移监控与再训练 | 回滚模型与提示优化 |
| 备份不足 | 备份失败或不可用 | 数据永久丢失 | 低 | 定期演练与校验 | 从NAS恢复并验证 |
| 监控盲区 | 指标与日志缺失 | 故障定位困难 | 中 | 指标字典与仪表板完善 | 临时增强日志与采样 |

---

## 实施路线图与验收标准

实施路线建议分阶段推进:PoC阶段完成最小可用栈与端到端链路验证,建立性能基线与告警策略;试运行阶段开展压力测试与混沌演练,完善日志与审计,优化参数与容量;生产阶段上线高可用与多环境分层,建立SLO/SLA与值班体系,落实备份与灾备。验收标准覆盖功能、性能、可靠性与可维护性四类指标,并形成运维手册与应急预案[^1][^5]。

表18 阶段性里程碑与交付物清单(示例)

| 阶段 | 里程碑 | 交付物 |
|---|---|---|
| PoC | 最小栈部署与链路打通 | 架构文档、参数基线、仪表盘与告警规则 |
| 试运行 | 压测与混沌演练 | 压测报告、混沌实验记录、优化清单 |
| 生产 | HA上线与值班体系 | SLO/SLA、值班表、应急预案、备份与恢复演练记录 |

表19 验收标准对照(示例)

| 类别 | 指标 | 阈值 | 验证方法 |
|---|---|---|---|
| 功能 | API可用性 | 100%核心接口可用 | 自动化回归与集成测试 |
| 性能 | 延迟(P95)/吞吐 | 满足业务SLO | 压测与基线对比 |
| 可靠性 | 可用性 | ≥99.9% | 混沌演练与故障注入 |
| 可维护性 | 部署/回滚时间 | ≤目标窗口 | GitOps与蓝绿/金丝雀验证 |

---

## 附录:配置模板与落地清单

为便于直接落地,本附录提供docker-compose.yml模板与监控/日志配置的参考映射,以及数据库初始化与权限设置、模型发布与回滚流程的操作清单。

表20 端口与服务映射(示例)

| 服务 | 内部端口 | 外部端口 | 协议 | 暴露策略 |
|---|---|---|---|---|
| Nginx | 80,443 | 80,443 | HTTP/HTTPS | 对外暴露,统一入口 |
| API | 5001 | 无(经Nginx) | HTTP | 仅内部访问 |
| Web | 3000 | 无(经Nginx) | HTTP | 仅内部访问 |
| PostgreSQL | 5432 | 无 | TCP | 仅内部访问 |
| Redis | 6379 | 无 | TCP | 仅内部访问 |
| Weaviate | 8080 | 无 | HTTP | 仅内部访问 |
| vLLM | 8000 | 无 | HTTP | 仅内部访问 |
| Ollama | 11434 | 无 | HTTP | 仅内部访问 |
| Prometheus | 9090 | 无 | HTTP | 仅内部访问 |
| Grafana | 3000 | 可选内网 | HTTP | 按需暴露 |
| Loki | 3100 | 无 | HTTP | 仅内部访问 |
| Alertmanager | 9093 | 无 | HTTP | 仅内部访问 |

表21 目录挂载与权限(示例)

| 容器路径 | 主机路径/NAS | 读写权限 | 属主/属组 | 备份策略 |
|---|---|---|---|---|
| /var/lib/postgresql/data | 本地数据卷 | rw | postgres | 每周全量+每日增量 |
| /data | 本地数据卷(Redis) | rw | redis | 每周全量 |
| /var/lib/weaviate | 本地数据卷 | rw | weaviate | 每周全量+每日增量 |
| /etc/nginx/conf.d | 主机配置目录 | ro | root | 配置版本化 |
| /var/log | Loki/日志目录 | rw | adm | 每周归档到NAS |
| /models | NAS共享路径 | rw | appuser | 每次发布归档 |

### docker-compose.yml 模板与关键字段说明

模板要点:
- 版本与基础设置:使用Compose文件版本3.8或以上;统一网络(bridge)与子网规划;定义命名卷用于数据库、缓存、向量库与监控数据。
- 服务编排:Nginx作为唯一外部入口;API与Web通过depends_on与健康检查控制启动顺序;PostgreSQL、Redis、Weaviate采用本地数据卷;模型服务(优先vLLM,备选Ollama)可挂载NAS上的模型权重目录;Prometheus/Grafana/Loki/Alertmanager作为监控与日志栈。
- 资源与健康检查:为每个服务设置CPU/内存限额与保留;健康检查采用统一参数(interval、timeout、retries、start_period),根据服务冷启动情况调整;日志驱动限额控制文件大小与轮转。
- 环境与密钥:通过环境变量注入数据库、Redis、Weaviate与模型服务地址;避免明文密钥出现在镜像与配置,结合密钥管理设施或受管机密。

表22 关键配置项速查(示例)

| 字段 | 示例 | 说明 | 注意事项 |
|---|---|---|---|
| version | "3.8" | Compose文件版本 | 与Docker引擎兼容 |
| networks | bridge, 子网规划 | 容器网络 | 内外网隔离,外部入口唯一 |
| volumes | postgres_data/redis_data/weaviate_data | 命名卷 | 本地IO优先,备份指向NAS |
| services.nginx | ports: [80,443], depends_on | 反向代理 | TLS终止与路由 |
| services.api | healthcheck: /health, environment | API服务 | 连接DB/Redis/Weaviate |
| services.db | image: postgres:15-alpine | 数据库 | pg_isready健康检查 |
| services.redis | command: redis-server --appendonly yes | 缓存 | AOF持久化可选 |
| services.weaviate | PERSISTENCE_DATA_PATH | 向量库 | 数据路径挂载 |
| services.vllm/ollama | OpenAI兼容API | 模型服务 | 权重可挂载至NAS |
| deploy.resources.limits | cpus/memory | 资源限额 | 关键路径优先保障 |
| logging | driver, options | 日志限额 | 控制文件大小与数量 |

### 监控与日志配置清单

- Prometheus:设置全局采集间隔与告警规则;为API、模型服务、数据库、缓存与向量库配置抓取目标;启用模型服务(如vLLM)的指标端点;结合告警规则路由到Alertmanager。
- Grafana:导入或创建仪表板,覆盖API性能、模型吞吐与延迟、向量检索、缓存命中、数据库慢查询与系统资源;配置告警渠道与通知策略。
- Loki:设置日志摄取与标签规则,按服务与级别组织日志流;与Alertmanager联动,对关键错误与异常进行告警。

### 模型发布与回滚流程

- 发布前检查:完成数据与模型版本化(MLflow注册与DVC跟踪)、功能与性能测试、安全评估与审批。
- 发布流程:拉取权重与镜像,更新Compose服务配置,执行健康检查与冒烟测试,切换流量并监控关键指标。
- 回滚流程:从注册表或镜像仓库选择上一个稳定版本,执行权重与镜像切换,进行健康检查与冒烟测试,记录回滚原因与结果并更新审计。

---

## 参考文献

[^1]: Docker Compose 生产环境指南. https://docs.docker.com/compose/production/  
[^2]: 容器化AI应用部署模式(架构示例). https://learn.microsoft.com/zh-cn/azure/architecture/example-scenario/ai/ai-training-inferencing-containers  
[^3]: vLLM 官方文档. https://docs.vllm.ai/en/stable/  
[^4]: vLLM 接入 Prometheus/Grafana 示例. https://vllm.hyper.ai/docs/getting-started/examples/online-serving/prometheus_grafana/  
[^5]: 本地部署AI信息安全框架综述. https://www.sohu.com/a/876074884_121956424  
[^6]: 阿里云开发者社区:NAS的AI化升级方案. https://developer.aliyun.com/article/1585505  
[^7]: Memgraph 官方文档. https://memgraph.com/docs/memgraph/  
[^8]: Weaviate 官方文档. https://weaviate.io/developers/weaviate  
[^9]: PostgreSQL 官方文档. https://www.postgresql.org/docs/  
[^10]: Docker 镜像构建最佳实践. https://docs.docker.com/develop/develop-images/dockerfile_best-practices/  
[^11]: Docker 安全最佳实践(Better Stack). https://betterstack.com/community/guides/scaling-docker/docker-security-best-practices/  
[^12]: DVC/MLflow 数据与模型版本控制实践. https://hot.dawoai.com/posts/2025/python-data-version-control-mastering-dvc-mlflow-practice  
[^13]: 使用DVC与MLflow进行数据集与模型版本化(Dev.to). https://dev.to/aws-builders/ml-done-right-versioning-datasets-and-models-with-dvc-mlflow-4p3f  
[^14]: Prometheus + Grafana 监控部署(知乎专栏). https://zhuanlan.zhihu.com/p/24916339783

---

## 信息缺口与实施提示

- 硬件规格与NAS品牌型号未提供:实际部署需结合设备能力调整CPU/GPU/内存与IO参数,并进行基线压测。
- 并发与吞吐目标未给出:监控阈值与资源配额需在试运行阶段逐步收敛,形成适合现场的SLA。
- 合规基线与KMS/HSM设施未明确:加密与密钥管理策略需与企业安全团队协同制定,确保审计与取证可行。
- 网络拓扑与边界防护未知:微分段与访问策略需结合网络架构落地,必要时引入WAF与IDS/IPS。
- 备份策略与RPO/RTO目标未定义:建议在试运行阶段进行恢复演练并记录RPO/RTO达成情况。
- 镜像供应链安全工具未指定:建议在CI/CD中集成扫描与签名,结合SBOM实现审计与合规。

通过上述模板与清单,结合现场硬件与负载进行参数调优与基线测试,即可在本地数据中心或边缘环境中落地一套安全、可观测、可维护且具备版本化与回滚能力的轻量级AI工厂系统。