"""
图形元素检测和分类模块
负责检测和分类线条、形状、符号等图形元素
"""

import os
import sys
import logging
import numpy as np
import cv2
import math
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, asdict
from pathlib import Path
import json
import pickle
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# 导入配置
sys.path.append(str(Path(__file__).parent.parent))
from pdf_ocr_config import get_config

# 导入基础模块
from pdf_parser import BoundingBox, VectorElement

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class GeometricElement:
    """几何元素数据类"""
    element_type: str  # line, circle, rectangle, polygon, arc, curve
    points: List[Tuple[float, float]]
    bbox: BoundingBox
    confidence: float
    properties: Dict[str, Any]
    layer: str = "default"
    
    def to_dict(self):
        return {
            'element_type': self.element_type,
            'points': self.points,
            'bbox': self.bbox.to_dict(),
            'confidence': self.confidence,
            'properties': self.properties,
            'layer': self.layer
        }

@dataclass
class SymbolInstance:
    """符号实例数据类"""
    symbol_type: str
    bbox: BoundingBox
    confidence: float
    properties: Dict[str, Any]
    template_id: Optional[str] = None
    
    def to_dict(self):
        return {
            'symbol_type': self.symbol_type,
            'bbox': self.bbox.to_dict(),
            'confidence': self.confidence,
            'properties': self.properties,
            'template_id': self.template_id
        }

class LineDetector:
    """线条检测器"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        self.line_config = self.config["graphics_detection"]["line_detection"]
    
    def detect_lines(self, image: np.ndarray) -> List[GeometricElement]:
        """
        检测线条
        
        Args:
            image: 输入图像
            
        Returns:
            List[GeometricElement]: 检测到的线条列表
        """
        try:
            lines = []
            
            # 方法1: 霍夫直线检测
            hough_lines = self._hough_line_detection(image)
            lines.extend(hough_lines)
            
            # 方法2: 形态学检测
            morphology_lines = self._morphology_line_detection(image)
            lines.extend(morphology_lines)
            
            # 去重和合并
            lines = self._merge_similar_lines(lines)
            
            logger.debug(f"检测到 {len(lines)} 条线条")
            return lines
            
        except Exception as e:
            logger.error(f"线条检测失败: {e}")
            return []
    
    def _hough_line_detection(self, image: np.ndarray) -> List[GeometricElement]:
        """霍夫直线检测"""
        lines = []
        
        try:
            # 预处理
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
            edges = cv2.Canny(gray, 50, 150, apertureSize=3)
            
            # 霍夫直线检测
            hough_config = self.line_config["hough_lines"]
            detected_lines = cv2.HoughLinesP(
                edges,
                rho=hough_config["rho"],
                theta=eval(hough_config["theta"]),  # 转换为弧度
                threshold=hough_config["threshold"],
                minLineLength=hough_config["min_line_length"],
                maxLineGap=hough_config["max_line_gap"]
            )
            
            if detected_lines is not None:
                for line in detected_lines:
                    x1, y1, x2, y2 = line[0]
                    
                    # 计算边界框
                    x = min(x1, x2)
                    y = min(y1, y2)
                    width = abs(x2 - x1)
                    height = abs(y2 - y1)
                    
                    bbox = BoundingBox(x, y, width, height)
                    
                    # 计算线条属性
                    length = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
                    angle = math.atan2(y2 - y1, x2 - x1) * 180 / math.pi
                    
                    geometric_element = GeometricElement(
                        element_type="line",
                        points=[(x1, y1), (x2, y2)],
                        bbox=bbox,
                        confidence=0.8,
                        properties={
                            "length": length,
                            "angle": angle,
                            "method": "hough"
                        }
                    )
                    lines.append(geometric_element)
            
        except Exception as e:
            logger.warning(f"霍夫直线检测失败: {e}")
        
        return lines
    
    def _morphology_line_detection(self, image: np.ndarray) -> List[GeometricElement]:
        """形态学线条检测"""
        lines = []
        
        try:
            # 预处理
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
            
            # 二值化
            _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # 形态学操作
            morph_config = self.line_config["morphology"]
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, morph_config["kernel_size"])
            
            # 闭运算，连接断开的线条
            closed = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=morph_config["iterations"])
            
            # 开运算，去除噪声
            opened = cv2.morphologyEx(closed, cv2.MORPH_OPEN, kernel)
            
            # 查找轮廓
            contours, _ = cv2.findContours(opened, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            for contour in contours:
                # 过滤太小的轮廓
                area = cv2.contourArea(contour)
                if area < 100:  # 最小面积阈值
                    continue
                
                # 近似为多边形
                epsilon = 0.02 * cv2.arcLength(contour, True)
                approx = cv2.approxPolyDP(contour, epsilon, True)
                
                # 如果近似为直线（2个点）
                if len(approx) == 2:
                    x1, y1 = approx[0][0]
                    x2, y2 = approx[1][0]
                    
                    # 计算边界框
                    x = min(x1, x2)
                    y = min(y1, y2)
                    width = abs(x2 - x1)
                    height = abs(y2 - y1)
                    
                    bbox = BoundingBox(x, y, width, height)
                    
                    # 计算线条属性
                    length = math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
                    angle = math.atan2(y2 - y1, x2 - x1) * 180 / math.pi
                    
                    geometric_element = GeometricElement(
                        element_type="line",
                        points=[(x1, y1), (x2, y2)],
                        bbox=bbox,
                        confidence=0.7,
                        properties={
                            "length": length,
                            "angle": angle,
                            "method": "morphology",
                            "area": area
                        }
                    )
                    lines.append(geometric_element)
            
        except Exception as e:
            logger.warning(f"形态学线条检测失败: {e}")
        
        return lines
    
    def _merge_similar_lines(self, lines: List[GeometricElement]) -> List[GeometricElement]:
        """合并相似的线条"""
        if not lines:
            return []
        
        merged = []
        
        for line in lines:
            is_merged = False
            
            for existing in merged:
                # 检查是否相似（角度相近，位置相近）
                if (self._are_lines_similar(line, existing) and
                    self._are_lines_close(line, existing)):
                    
                    # 合并线条
                    merged_line = self._merge_two_lines(line, existing)
                    merged.remove(existing)
                    merged.append(merged_line)
                    is_merged = True
                    break
            
            if not is_merged:
                merged.append(line)
        
        return merged
    
    def _are_lines_similar(self, line1: GeometricElement, line2: GeometricElement) -> bool:
        """检查两条线是否相似"""
        angle1 = line1.properties.get("angle", 0)
        angle2 = line2.properties.get("angle", 0)
        
        # 角度差小于10度认为相似
        angle_diff = abs(angle1 - angle2)
        angle_diff = min(angle_diff, 180 - angle_diff)  # 处理角度的周期性
        
        return angle_diff < 10
    
    def _are_lines_close(self, line1: GeometricElement, line2: GeometricElement) -> bool:
        """检查两条线是否接近"""
        # 计算中点距离
        mid1 = ((line1.points[0][0] + line1.points[1][0]) / 2,
                (line1.points[0][1] + line1.points[1][1]) / 2)
        mid2 = ((line2.points[0][0] + line2.points[1][0]) / 2,
                (line2.points[0][1] + line2.points[1][1]) / 2)
        
        distance = math.sqrt((mid1[0] - mid2[0])**2 + (mid1[1] - mid2[1])**2)
        return distance < 50  # 距离阈值
    
    def _merge_two_lines(self, line1: GeometricElement, line2: GeometricElement) -> GeometricElement:
        """合并两条线"""
        # 合并点
        all_points = line1.points + line2.points
        
        # 找到最远的两个点作为合并后的线段
        max_distance = 0
        best_points = None
        
        for i in range(len(all_points)):
            for j in range(i + 1, len(all_points)):
                p1, p2 = all_points[i], all_points[j]
                distance = math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)
                
                if distance > max_distance:
                    max_distance = distance
                    best_points = [p1, p2]
        
        # 计算合并后的属性
        x_coords = [p[0] for p in all_points]
        y_coords = [p[1] for p in all_points]
        x = min(x_coords)
        y = min(y_coords)
        width = max(x_coords) - x
        height = max(y_coords) - y
        
        bbox = BoundingBox(x, y, width, height)
        
        # 平均角度和长度
        avg_angle = (line1.properties.get("angle", 0) + line2.properties.get("angle", 0)) / 2
        avg_length = (line1.properties.get("length", 0) + line2.properties.get("length", 0)) / 2
        
        return GeometricElement(
            element_type="line",
            points=best_points,
            bbox=bbox,
            confidence=(line1.confidence + line2.confidence) / 2,
            properties={
                "length": avg_length,
                "angle": avg_angle,
                "method": "merged",
                "merged_from": [line1.properties.get("method", ""), line2.properties.get("method", "")]
            }
        )

class ShapeDetector:
    """形状检测器"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        self.shape_config = self.config["graphics_detection"]["shape_detection"]
    
    def detect_shapes(self, image: np.ndarray) -> List[GeometricElement]:
        """
        检测形状
        
        Args:
            image: 输入图像
            
        Returns:
            List[GeometricElement]: 检测到的形状列表
        """
        try:
            shapes = []
            
            # 检测圆形
            circles = self._detect_circles(image)
            shapes.extend(circles)
            
            # 检测矩形
            rectangles = self._detect_rectangles(image)
            shapes.extend(rectangles)
            
            # 检测多边形
            polygons = self._detect_polygons(image)
            shapes.extend(polygons)
            
            logger.debug(f"检测到 {len(shapes)} 个形状")
            return shapes
            
        except Exception as e:
            logger.error(f"形状检测失败: {e}")
            return []
    
    def _detect_circles(self, image: np.ndarray) -> List[GeometricElement]:
        """检测圆形"""
        circles = []
        
        try:
            # 预处理
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
            gray = cv2.medianBlur(gray, 5)
            
            # 霍夫圆检测
            circle_config = self.shape_config["circle_detection"]
            detected_circles = cv2.HoughCircles(
                gray,
                cv2.HOUGH_GRADIENT,
                dp=1,
                minDist=20,
                param1=circle_config["param1"],
                param2=circle_config["param2"],
                minRadius=circle_config["min_radius"],
                maxRadius=circle_config["max_radius"]
            )
            
            if detected_circles is not None:
                detected_circles = np.round(detected_circles[0, :]).astype("int")
                
                for (x, y, r) in detected_circles:
                    bbox = BoundingBox(x - r, y - r, 2 * r, 2 * r)
                    
                    geometric_element = GeometricElement(
                        element_type="circle",
                        points=[(x, y), (r, 0)],  # 圆心，半径
                        bbox=bbox,
                        confidence=0.8,
                        properties={
                            "center": (x, y),
                            "radius": r,
                            "area": math.pi * r * r
                        }
                    )
                    circles.append(geometric_element)
            
        except Exception as e:
            logger.warning(f"圆形检测失败: {e}")
        
        return circles
    
    def _detect_rectangles(self, image: np.ndarray) -> List[GeometricElement]:
        """检测矩形"""
        rectangles = []
        
        try:
            # 预处理
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
            
            # 二值化
            _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # 查找轮廓
            contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            rect_config = self.shape_config["rectangle_detection"]
            
            for contour in contours:
                area = cv2.contourArea(contour)
                
                # 过滤面积
                if area < rect_config["min_area"] or area > rect_config["max_area"]:
                    continue
                
                # 近似为多边形
                epsilon = 0.02 * cv2.arcLength(contour, True)
                approx = cv2.approxPolyDP(contour, epsilon, True)
                
                # 如果是矩形（4个顶点）
                if len(approx) == 4:
                    # 计算边界框
                    x, y, w, h = cv2.boundingRect(approx)
                    bbox = BoundingBox(x, y, w, h)
                    
                    # 计算纵横比
                    aspect_ratio = w / h if h > 0 else 0
                    
                    # 检查纵横比是否合理
                    if (rect_config["aspect_ratio_range"][0] <= aspect_ratio <= rect_config["aspect_ratio_range"][1]):
                        geometric_element = GeometricElement(
                            element_type="rectangle",
                            points=[(x, y), (x + w, y + h)],  # 对角点
                            bbox=bbox,
                            confidence=0.7,
                            properties={
                                "width": w,
                                "height": h,
                                "aspect_ratio": aspect_ratio,
                                "area": area
                            }
                        )
                        rectangles.append(geometric_element)
            
        except Exception as e:
            logger.warning(f"矩形检测失败: {e}")
        
        return rectangles
    
    def _detect_polygons(self, image: np.ndarray) -> List[GeometricElement]:
        """检测多边形"""
        polygons = []
        
        try:
            # 预处理
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
            
            # 二值化
            _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # 查找轮廓
            contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            for contour in contours:
                area = cv2.contourArea(contour)
                
                # 过滤太小的轮廓
                if area < 500:
                    continue
                
                # 近似为多边形
                epsilon = 0.02 * cv2.arcLength(contour, True)
                approx = cv2.approxPolyDP(contour, epsilon, True)
                
                # 如果是复杂多边形（5个或更多顶点）
                if len(approx) >= 5:
                    # 计算边界框
                    x, y, w, h = cv2.boundingRect(approx)
                    bbox = BoundingBox(x, y, w, h)
                    
                    # 提取顶点
                    vertices = [(point[0][0], point[0][1]) for point in approx]
                    
                    geometric_element = GeometricElement(
                        element_type="polygon",
                        points=vertices,
                        bbox=bbox,
                        confidence=0.6,
                        properties={
                            "vertices": vertices,
                            "vertex_count": len(vertices),
                            "area": area
                        }
                    )
                    polygons.append(geometric_element)
            
        except Exception as e:
            logger.warning(f"多边形检测失败: {e}")
        
        return polygons

class SymbolDetector:
    """符号检测器"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        self.symbol_config = self.config["graphics_detection"]["symbol_detection"]
        
        # 加载符号模板
        self.symbol_templates = self._load_symbol_templates()
    
    def _load_symbol_templates(self) -> Dict[str, Any]:
        """加载符号模板"""
        # 这里应该从文件或数据库加载符号模板
        # 为了演示，我们使用一些基本的模板
        templates = {
            "arrow": {
                "type": "arrow",
                "description": "箭头",
                "min_size": 20,
                "max_size": 200,
                "features": ["pointed", "linear"]
            },
            "dimension_line": {
                "type": "dimension_line",
                "description": "尺寸线",
                "min_size": 30,
                "max_size": 500,
                "features": ["linear", "parallel"]
            },
            "center_line": {
                "type": "center_line",
                "description": "中心线",
                "min_size": 20,
                "max_size": 300,
                "features": ["dashed", "linear"]
            },
            "hidden_line": {
                "type": "hidden_line",
                "description": "隐藏线",
                "min_size": 10,
                "max_size": 400,
                "features": ["dashed", "linear"]
            },
            "break_line": {
                "type": "break_line",
                "description": "折断线",
                "min_size": 20,
                "max_size": 100,
                "features": ["zigzag", "linear"]
            }
        }
        
        return templates
    
    def detect_symbols(self, image: np.ndarray, 
                      geometric_elements: List[GeometricElement]) -> List[SymbolInstance]:
        """
        检测符号
        
        Args:
            image: 输入图像
            geometric_elements: 几何元素列表
            
        Returns:
            List[SymbolInstance]: 检测到的符号列表
        """
        try:
            symbols = []
            
            # 基于几何元素检测符号
            for element in geometric_elements:
                symbol = self._detect_symbol_from_element(element)
                if symbol:
                    symbols.append(symbol)
            
            # 基于模板匹配检测符号
            template_symbols = self._template_matching_detection(image)
            symbols.extend(template_symbols)
            
            logger.debug(f"检测到 {len(symbols)} 个符号")
            return symbols
            
        except Exception as e:
            logger.error(f"符号检测失败: {e}")
            return []
    
    def _detect_symbol_from_element(self, element: GeometricElement) -> Optional[SymbolInstance]:
        """从几何元素检测符号"""
        try:
            element_type = element.element_type
            properties = element.properties
            
            # 基于元素类型和属性判断符号类型
            if element_type == "line":
                return self._detect_line_symbol(element, properties)
            elif element_type == "circle":
                return self._detect_circle_symbol(element, properties)
            elif element_type == "polygon":
                return self._detect_polygon_symbol(element, properties)
            
            return None
            
        except Exception as e:
            logger.warning(f"几何元素符号检测失败: {e}")
            return None
    
    def _detect_line_symbol(self, element: GeometricElement, properties: Dict[str, Any]) -> Optional[SymbolInstance]:
        """检测线条符号"""
        length = properties.get("length", 0)
        angle = properties.get("angle", 0)
        
        # 检测箭头
        if self._is_arrow(element):
            return SymbolInstance(
                symbol_type="arrow",
                bbox=element.bbox,
                confidence=0.8,
                properties={
                    "direction": "right" if angle > 0 else "left",
                    "length": length
                }
            )
        
        # 检测尺寸线
        if self._is_dimension_line(element):
            return SymbolInstance(
                symbol_type="dimension_line",
                bbox=element.bbox,
                confidence=0.7,
                properties={
                    "length": length,
                    "angle": angle
                }
            )
        
        # 检测中心线
        if self._is_center_line(element):
            return SymbolInstance(
                symbol_type="center_line",
                bbox=element.bbox,
                confidence=0.7,
                properties={
                    "length": length,
                    "angle": angle
                }
            )
        
        # 检测隐藏线
        if self._is_hidden_line(element):
            return SymbolInstance(
                symbol_type="hidden_line",
                bbox=element.bbox,
                confidence=0.6,
                properties={
                    "length": length,
                    "angle": angle
                }
            )
        
        return None
    
    def _detect_circle_symbol(self, element: GeometricElement, properties: Dict[str, Any]) -> Optional[SymbolInstance]:
        """检测圆形符号"""
        center = properties.get("center", (0, 0))
        radius = properties.get("radius", 0)
        
        # 检测孔
        if 5 <= radius <= 50:
            return SymbolInstance(
                symbol_type="hole",
                bbox=element.bbox,
                confidence=0.8,
                properties={
                    "center": center,
                    "radius": radius
                }
            )
        
        # 检测圆
        if radius > 50:
            return SymbolInstance(
                symbol_type="circle",
                bbox=element.bbox,
                confidence=0.7,
                properties={
                    "center": center,
                    "radius": radius
                }
            )
        
        return None
    
    def _detect_polygon_symbol(self, element: GeometricElement, properties: Dict[str, Any]) -> Optional[SymbolInstance]:
        """检测多边形符号"""
        vertex_count = properties.get("vertex_count", 0)
        
        # 检测三角形
        if vertex_count == 3:
            return SymbolInstance(
                symbol_type="triangle",
                bbox=element.bbox,
                confidence=0.6,
                properties=properties
            )
        
        # 检测五边形
        if vertex_count == 5:
            return SymbolInstance(
                symbol_type="pentagon",
                bbox=element.bbox,
                confidence=0.6,
                properties=properties
            )
        
        # 检测六边形
        if vertex_count == 6:
            return SymbolInstance(
                symbol_type="hexagon",
                bbox=element.bbox,
                confidence=0.6,
                properties=properties
            )
        
        return None
    
    def _is_arrow(self, element: GeometricElement) -> bool:
        """判断是否为箭头"""
        # 箭头特征：短线条，一端有尖端
        length = element.properties.get("length", 0)
        return 10 <= length <= 100
    
    def _is_dimension_line(self, element: GeometricElement) -> bool:
        """判断是否为尺寸线"""
        # 尺寸线特征：中等长度，通常与其他尺寸元素成组出现
        length = element.properties.get("length", 0)
        return 30 <= length <= 500
    
    def _is_center_line(self, element: GeometricElement) -> bool:
        """判断是否为中心线"""
        # 中心线特征：虚线，长度中等
        length = element.properties.get("length", 0)
        return 20 <= length <= 300
    
    def _is_hidden_line(self, element: GeometricElement) -> bool:
        """判断是否为隐藏线"""
        # 隐藏线特征：虚线，可能较短
        length = element.properties.get("length", 0)
        return 10 <= length <= 400
    
    def _template_matching_detection(self, image: np.ndarray) -> List[SymbolInstance]:
        """模板匹配检测"""
        symbols = []
        
        try:
            # 这里应该实现基于模板的符号检测
            # 由于模板匹配比较复杂，这里只做简单的演示
            
            # 检测常见的工程符号
            engineering_symbols = self._detect_engineering_symbols(image)
            symbols.extend(engineering_symbols)
            
        except Exception as e:
            logger.warning(f"模板匹配检测失败: {e}")
        
        return symbols
    
    def _detect_engineering_symbols(self, image: np.ndarray) -> List[SymbolInstance]:
        """检测工程符号"""
        symbols = []
        
        # 这里应该实现具体的工程符号检测逻辑
        # 由于实现复杂，这里返回空列表
        return symbols

class GraphicsDetectionSystem:
    """图形检测系统主类"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or get_config()
        
        # 初始化检测器
        self.line_detector = LineDetector(self.config)
        self.shape_detector = ShapeDetector(self.config)
        self.symbol_detector = SymbolDetector(self.config)
        
        logger.info("图形检测系统初始化完成")
    
    def detect_graphics(self, image: np.ndarray) -> Dict[str, Any]:
        """
        检测图形元素
        
        Args:
            image: 输入图像
            
        Returns:
            Dict: 检测结果
        """
        try:
            logger.info("开始图形检测")
            
            # 1. 检测线条
            lines = self.line_detector.detect_lines(image)
            
            # 2. 检测形状
            shapes = self.shape_detector.detect_shapes(image)
            
            # 3. 合并几何元素
            geometric_elements = lines + shapes
            
            # 4. 检测符号
            symbols = self.symbol_detector.detect_symbols(image, geometric_elements)
            
            # 5. 组合结果
            result = {
                "geometric_elements": [elem.to_dict() for elem in geometric_elements],
                "lines": [elem.to_dict() for elem in lines],
                "shapes": [elem.to_dict() for elem in shapes],
                "symbols": [symbol.to_dict() for symbol in symbols],
                "summary": {
                    "total_geometric_elements": len(geometric_elements),
                    "line_count": len(lines),
                    "shape_count": len(shapes),
                    "symbol_count": len(symbols)
                }
            }
            
            logger.info(f"图形检测完成：{len(geometric_elements)} 个几何元素，{len(symbols)} 个符号")
            
            return result
            
        except Exception as e:
            logger.error(f"图形检测失败: {e}")
            return {
                "geometric_elements": [],
                "lines": [],
                "shapes": [],
                "symbols": [],
                "error": str(e)
            }
    
    def classify_elements(self, geometric_elements: List[GeometricElement]) -> Dict[str, List[GeometricElement]]:
        """
        对几何元素进行分类
        
        Args:
            geometric_elements: 几何元素列表
            
        Returns:
            Dict: 按类型分类的元素
        """
        classification = {
            "lines": [],
            "circles": [],
            "rectangles": [],
            "polygons": [],
            "curves": [],
            "other": []
        }
        
        for element in geometric_elements:
            element_type = element.element_type
            
            if element_type == "line":
                classification["lines"].append(element)
            elif element_type == "circle":
                classification["circles"].append(element)
            elif element_type == "rectangle":
                classification["rectangles"].append(element)
            elif element_type == "polygon":
                classification["polygons"].append(element)
            elif element_type in ["curve", "arc"]:
                classification["curves"].append(element)
            else:
                classification["other"].append(element)
        
        return classification
    
    def analyze_geometric_relationships(self, geometric_elements: List[GeometricElement]) -> Dict[str, Any]:
        """
        分析几何元素之间的关系
        
        Args:
            geometric_elements: 几何元素列表
            
        Returns:
            Dict: 关系分析结果
        """
        relationships = {
            "parallel_lines": [],
            "perpendicular_lines": [],
            "intersections": [],
            "enclosed_shapes": [],
            "nested_shapes": []
        }
        
        try:
            # 分析平行线
            relationships["parallel_lines"] = self._find_parallel_lines(geometric_elements)
            
            # 分析垂直线
            relationships["perpendicular_lines"] = self._find_perpendicular_lines(geometric_elements)
            
            # 分析交点
            relationships["intersections"] = self._find_intersections(geometric_elements)
            
            # 分析包含关系
            relationships["enclosed_shapes"] = self._find_enclosed_shapes(geometric_elements)
            
        except Exception as e:
            logger.warning(f"几何关系分析失败: {e}")
        
        return relationships
    
    def _find_parallel_lines(self, geometric_elements: List[GeometricElement]) -> List[Tuple[GeometricElement, GeometricElement]]:
        """查找平行线"""
        parallel_pairs = []
        lines = [elem for elem in geometric_elements if elem.element_type == "line"]
        
        for i in range(len(lines)):
            for j in range(i + 1, len(lines)):
                line1, line2 = lines[i], lines[j]
                
                angle1 = line1.properties.get("angle", 0)
                angle2 = line2.properties.get("angle", 0)
                
                angle_diff = abs(angle1 - angle2)
                angle_diff = min(angle_diff, 180 - angle_diff)
                
                if angle_diff < 5:  # 角度差小于5度认为平行
                    parallel_pairs.append((line1, line2))
        
        return parallel_pairs
    
    def _find_perpendicular_lines(self, geometric_elements: List[GeometricElement]) -> List[Tuple[GeometricElement, GeometricElement]]:
        """查找垂直线"""
        perpendicular_pairs = []
        lines = [elem for elem in geometric_elements if elem.element_type == "line"]
        
        for i in range(len(lines)):
            for j in range(i + 1, len(lines)):
                line1, line2 = lines[i], lines[j]
                
                angle1 = line1.properties.get("angle", 0)
                angle2 = line2.properties.get("angle", 0)
                
                angle_diff = abs(angle1 - angle2)
                
                # 垂直线角度差接近90度
                if abs(angle_diff - 90) < 5 or abs(angle_diff - 270) < 5:
                    perpendicular_pairs.append((line1, line2))
        
        return perpendicular_pairs
    
    def _find_intersections(self, geometric_elements: List[GeometricElement]) -> List[Dict[str, Any]]:
        """查找交点"""
        intersections = []
        lines = [elem for elem in geometric_elements if elem.element_type == "line"]
        
        for i in range(len(lines)):
            for j in range(i + 1, len(lines)):
                line1, line2 = lines[i], lines[j]
                
                # 计算两条直线的交点
                intersection = self._calculate_line_intersection(line1, line2)
                
                if intersection:
                    intersections.append({
                        "line1": line1.to_dict(),
                        "line2": line2.to_dict(),
                        "intersection_point": intersection
                    })
        
        return intersections
    
    def _calculate_line_intersection(self, line1: GeometricElement, line2: GeometricElement) -> Optional[Tuple[float, float]]:
        """计算两条直线的交点"""
        try:
            x1, y1 = line1.points[0]
            x2, y2 = line1.points[1]
            x3, y3 = line2.points[0]
            x4, y4 = line2.points[1]
            
            # 使用行列式计算交点
            denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
            
            if abs(denom) < 1e-10:  # 平行线
                return None
            
            t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
            
            if 0 <= t <= 1:  # 交点在线段上
                x = x1 + t * (x2 - x1)
                y = y1 + t * (y2 - y1)
                return (x, y)
            
            return None
            
        except Exception:
            return None
    
    def _find_enclosed_shapes(self, geometric_elements: List[GeometricElement]) -> List[Dict[str, Any]]:
        """查找包含关系"""
        enclosed = []
        
        for i, elem1 in enumerate(geometric_elements):
            for j, elem2 in enumerate(geometric_elements):
                if i != j and self._is_enclosed(elem1, elem2):
                    enclosed.append({
                        "outer_shape": elem1.to_dict(),
                        "inner_shape": elem2.to_dict()
                    })
        
        return enclosed
    
    def _is_enclosed(self, outer: GeometricElement, inner: GeometricElement) -> bool:
        """检查一个形状是否被另一个形状包含"""
        # 简化实现：检查边界框是否包含
        outer_bbox = outer.bbox
        inner_bbox = inner.bbox
        
        return (outer_bbox.x <= inner_bbox.x and
                outer_bbox.y <= inner_bbox.y and
                outer_bbox.x + outer_bbox.width >= inner_bbox.x + inner_bbox.width and
                outer_bbox.y + outer_bbox.height >= inner_bbox.y + inner_bbox.height)

# 辅助函数
def filter_elements_by_confidence(elements: List, min_confidence: float = 0.5) -> List:
    """根据置信度过滤元素"""
    return [elem for elem in elements if elem.confidence >= min_confidence]

def sort_elements_by_area(elements: List[GeometricElement]) -> List[GeometricElement]:
    """按面积排序元素"""
    return sorted(elements, key=lambda x: x.bbox.area(), reverse=True)

def calculate_element_statistics(geometric_elements: List[GeometricElement]) -> Dict[str, Any]:
    """计算几何元素统计信息"""
    if not geometric_elements:
        return {}
    
    stats = {
        "total_count": len(geometric_elements),
        "type_distribution": {},
        "total_area": 0,
        "average_area": 0,
        "confidence_stats": {
            "min": float('inf'),
            "max": 0,
            "mean": 0,
            "std": 0
        }
    }
    
    # 类型分布
    for element in geometric_elements:
        element_type = element.element_type
        stats["type_distribution"][element_type] = stats["type_distribution"].get(element_type, 0) + 1
    
    # 面积统计
    areas = [elem.bbox.area() for elem in geometric_elements]
    stats["total_area"] = sum(areas)
    stats["average_area"] = stats["total_area"] / len(areas)
    
    # 置信度统计
    confidences = [elem.confidence for elem in geometric_elements]
    stats["confidence_stats"]["min"] = min(confidences)
    stats["confidence_stats"]["max"] = max(confidences)
    stats["confidence_stats"]["mean"] = sum(confidences) / len(confidences)
    
    if len(confidences) > 1:
        variance = sum((c - stats["confidence_stats"]["mean"]) ** 2 for c in confidences) / len(confidences)
        stats["confidence_stats"]["std"] = math.sqrt(variance)
    
    return stats

# 使用示例
if __name__ == "__main__":
    # 创建图形检测系统
    config = get_config()
    graphics_system = GraphicsDetectionSystem(config)
    
    # 创建测试图像
    test_image = np.ones((800, 600, 3), dtype=np.uint8) * 255
    
    # 绘制一些测试图形
    cv2.line(test_image, (100, 100), (500, 100), (0, 0, 0), 2)
    cv2.rectangle(test_image, (150, 200), (350, 350), (0, 0, 0), 2)
    cv2.circle(test_image, (400, 150), 50, (0, 0, 0), 2)
    
    # 检测图形
    result = graphics_system.detect_graphics(test_image)
    
    print("图形检测结果:")
    print(f"几何元素数量: {result['summary']['total_geometric_elements']}")
    print(f"线条数量: {result['summary']['line_count']}")
    print(f"形状数量: {result['summary']['shape_count']}")
    print(f"符号数量: {result['summary']['symbol_count']}")
    
    # 分析几何关系
    if result["geometric_elements"]:
        geometric_elements = [GeometricElement(**elem) for elem in result["geometric_elements"]]
        relationships = graphics_system.analyze_geometric_relationships(geometric_elements)
        
        print(f"平行线对数: {len(relationships['parallel_lines'])}")
        print(f"垂直线对数: {len(relationships['perpendicular_lines'])}")
        print(f"交点数量: {len(relationships['intersections'])}")
    
    # 保存结果
    with open("graphics_detection_result.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    print("结果已保存到 graphics_detection_result.json")
