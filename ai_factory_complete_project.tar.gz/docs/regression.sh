#!/bin/bash

# regression.sh - 回归测试脚本
# 用于检测系统更新后的性能回退和质量下降

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 默认配置
BASELINE_DIR="./baseline_results"
CURRENT_DIR="./regression_results"
REPORT_FILE="regression_report.json"
VERBOSE=false
THRESHOLD_PERCENTAGE=5
TEST_DURATION=180
CONCURRENT_USERS=8

# 回归测试结果存储
declare -A REGRESSION_DATA=(
    ["api_health"]="{}"
    ["api_performance"]="{}"
    ["model_performance"]="{}"
    ["database_performance"]="{}"
    ["cache_performance"]="{}"
    ["system_resources"]="{}"
)

# 创建输出目录
mkdir -p "$CURRENT_DIR"

# 清理函数
cleanup() {
    log_info "清理回归测试环境..."
    # 终止所有后台进程
    jobs -p | xargs -r kill 2>/dev/null || true
    wait
}

trap cleanup EXIT

# 加载基准数据
load_baseline_data() {
    local baseline_file="$BASELINE_DIR/baseline_data.json"
    
    if [ ! -f "$baseline_file" ]; then
        log_error "基准数据文件不存在: $baseline_file"
        log_info "请先运行 baseline.sh 创建基准数据"
        return 1
    fi
    
    log_info "加载基准数据: $baseline_file"
    
    # 提取基准数据
    BASELINE_API_HEALTH=$(jq -r '.test_results.api_health_check' "$baseline_file" 2>/dev/null || echo "{}")
    BASELINE_API_PERF=$(jq -r '.test_results.api_basic_request' "$baseline_file" 2>/dev/null || echo "{}")
    BASELINE_MODEL_PERF=$(jq -r '.test_results.model_chat_completion' "$baseline_file" 2>/dev/null || echo "{}")
    BASELINE_DB_PERF=$(jq -r '.test_results.database_query' "$baseline_file" 2>/dev/null || echo "{}")
    BASELINE_CACHE_PERF=$(jq -r '.test_results.cache_operations' "$baseline_file" 2>/dev/null || echo "{}")
    BASELINE_SYS_RES=$(jq -r '.test_results.system_resources' "$baseline_file" 2>/dev/null || echo "{}")
    
    log_success "基准数据加载完成"
    return 0
}

# API健康检查回归测试
regression_api_health() {
    log_info "执行API健康检查回归测试..."
    
    local test_name="api_health"
    local results_file="$CURRENT_DIR/${test_name}_results.json"
    
    # 执行健康检查测试
    local total_time=0
    local success_count=0
    local failure_count=0
    local min_time=999999
    local max_time=0
    local times=()
    
    for i in {1..50}; do
        local req_start=$(date +%s%3N)
        local response=$(curl -w "%{http_code}" -s -o /dev/null http://localhost:8000/health 2>/dev/null)
        local req_end=$(date +%s%3N)
        local req_time=$((req_end - req_start))
        
        times+=($req_time)
        total_time=$((total_time + req_time))
        
        if [ "$response" = "200" ]; then
            success_count=$((success_count + 1))
        else
            failure_count=$((failure_count + 1))
        fi
        
        if [ $req_time -lt $min_time ]; then
            min_time=$req_time
        fi
        
        if [ $req_time -gt $max_time ]; then
            max_time=$req_time
        fi
        
        sleep 0.1
    done
    
    local avg_time=$(echo "scale=2; $total_time / 50" | bc)
    local success_rate=$(echo "scale=2; $success_count * 100 / 50" | bc)
    
    # 计算百分位数
    times=($(printf '%s\n' "${times[@]}" | sort -n))
    local p50_time=${times[24]}
    local p95_time=${times[47]}
    local p99_time=${times[49]}
    
    # 保存当前结果
    cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "total_requests": 50,
  "successful_requests": $success_count,
  "failed_requests": $failure_count,
  "success_rate": "$success_rate%",
  "avg_response_time": "${avg_time}ms",
  "min_response_time": "${min_time}ms",
  "max_response_time": "${max_time}ms",
  "p50_response_time": "${p50_time}ms",
  "p95_response_time": "${p95_time}ms",
  "p99_response_time": "${p99_time}ms"
}
EOF
    
    # 比较与基准数据
    local baseline_avg=$(echo "$BASELINE_API_HEALTH" | jq -r '.avg_response_time' | sed 's/ms//')
    local current_avg=$avg_time
    
    if [ -n "$baseline_avg" ] && [ "$baseline_avg" != "null" ]; then
        local degradation=$(echo "scale=2; ($current_avg - $baseline_avg) * 100 / $baseline_avg" | bc)
        local status="stable"
        
        if (( $(echo "$degradation > $THRESHOLD_PERCENTAGE" | bc -l) )); then
            status="degraded"
            log_warning "API健康检查性能下降: ${degradation}%"
        elif (( $(echo "$degradation < -$THRESHOLD_PERCENTAGE" | bc -l) )); then
            status="improved"
            log_success "API健康检查性能提升: ${degradation}%"
        else
            log_info "API健康检查性能稳定: ${degradation}%"
        fi
        
        jq ".regression_analysis = {
            \"baseline_avg_response_time\": \"${baseline_avg}ms\",
            \"current_avg_response_time\": \"${current_avg}ms\",
            \"degradation_percentage\": \"${degradation}%\",
            \"status\": \"$status\"
        }" "$results_file" > "${results_file}.tmp" && mv "${results_file}.tmp" "$results_file"
    fi
    
    REGRESSION_DATA[$test_name]=$(cat "$results_file")
    log_success "API健康检查回归测试完成"
    echo "$results_file"
}

# API性能回归测试
regression_api_performance() {
    log_info "执行API性能回归测试..."
    
    local test_name="api_performance"
    local results_file="$CURRENT_DIR/${test_name}_results.json"
    
    # 使用loadtest-api.sh进行性能测试
    ./loadtest-api.sh -c $CONCURRENT_USERS -d 120 -o "$CURRENT_DIR" -f "${test_name}_loadtest" api_basic > /dev/null 2>&1
    
    # 解析loadtest结果
    local loadtest_file="$CURRENT_DIR/${test_name}_loadtest_report_$(ls -t $CURRENT_DIR/*loadtest* | head -1 | xargs basename)"
    
    if [ -f "$loadtest_file" ]; then
        local total_requests=$(grep -o '"total_requests": [0-9]*' "$loadtest_file" | awk '{print $2}')
        local successful_requests=$(grep -o '"successful_requests": [0-9]*' "$loadtest_file" | awk '{print $2}')
        local avg_response_time=$(grep -o '"avg_response_time": [0-9.]*' "$loadtest_file" | awk '{print $2}')
        local throughput=$(grep -o '"throughput": [0-9.]*' "$loadtest_file" | awk '{print $2}')
        
        cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "concurrent_users": $CONCURRENT_USERS,
  "test_duration": 120,
  "total_requests": $total_requests,
  "successful_requests": $successful_requests,
  "avg_response_time": "${avg_response_time}ms",
  "throughput": "${throughput} req/s"
}
EOF
        
        # 比较与基准数据
        local baseline_avg=$(echo "$BASELINE_API_PERF" | jq -r '.avg_response_time' | sed 's/ms//')
        local baseline_throughput=$(echo "$BASELINE_API_PERF" | jq -r '.throughput' | sed 's/ req\/s//')
        local current_avg=$avg_response_time
        local current_throughput=$throughput
        
        if [ -n "$baseline_avg" ] && [ "$baseline_avg" != "null" ]; then
            local response_degradation=$(echo "scale=2; ($current_avg - $baseline_avg) * 100 / $baseline_avg" | bc)
            local throughput_degradation=$(echo "scale=2; ($baseline_throughput - $current_throughput) * 100 / $baseline_throughput" | bc)
            
            local status="stable"
            if (( $(echo "$response_degradation > $THRESHOLD_PERCENTAGE" | bc -l) )) || 
               (( $(echo "$throughput_degradation > $THRESHOLD_PERCENTAGE" | bc -l) )); then
                status="degraded"
                log_warning "API性能回归: 响应时间下降${response_degradation}%, 吞吐量下降${throughput_degradation}%"
            else
                log_info "API性能稳定"
            fi
            
            jq ".regression_analysis = {
                \"baseline_avg_response_time\": \"${baseline_avg}ms\",
                \"current_avg_response_time\": \"${current_avg}ms\",
                \"response_degradation_percentage\": \"${response_degradation}%\",
                \"baseline_throughput\": \"${baseline_throughput} req/s\",
                \"current_throughput\": \"${current_throughput} req/s\",
                \"throughput_degradation_percentage\": \"${throughput_degradation}%\",
                \"status\": \"$status\"
            }" "$results_file" > "${results_file}.tmp" && mv "${results_file}.tmp" "$results_file"
        fi
    else
        log_warning "未找到loadtest结果文件"
        cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "error": "Loadtest results not found"
}
EOF
    fi
    
    REGRESSION_DATA[$test_name]=$(cat "$results_file")
    log_success "API性能回归测试完成"
    echo "$results_file"
}

# 模型性能回归测试
regression_model_performance() {
    log_info "执行模型性能回归测试..."
    
    local test_name="model_performance"
    local results_file="$CURRENT_DIR/${test_name}_results.json"
    
    # 使用loadtest-model.sh进行模型测试
    ./loadtest-model.sh -c 4 -d 180 -o "$CURRENT_DIR" -f "${test_name}_loadtest" chat_completion simple > /dev/null 2>&1
    
    # 解析loadtest结果
    local loadtest_file="$CURRENT_DIR/${test_name}_loadtest_report_$(ls -t $CURRENT_DIR/*loadtest* | head -1 | xargs basename)"
    
    if [ -f "$loadtest_file" ]; then
        local total_requests=$(grep -o '"total_requests": [0-9]*' "$loadtest_file" | awk '{print $2}')
        local successful_requests=$(grep -o '"successful_requests": [0-9]*' "$loadtest_file" | awk '{print $2}')
        local avg_response_time=$(grep -o '"avg_response_time": [0-9.]*' "$loadtest_file" | awk '{print $2}')
        local throughput=$(grep -o '"throughput": [0-9.]*' "$loadtest_file" | awk '{print $2}')
        local tokens_per_second=$(grep -o '"tokens_per_second": [0-9.]*' "$loadtest_file" | awk '{print $2}')
        
        cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "concurrent_requests": 4,
  "test_duration": 180,
  "total_requests": $total_requests,
  "successful_requests": $successful_requests,
  "avg_response_time": "${avg_response_time}ms",
  "throughput": "${throughput} req/s",
  "tokens_per_second": "${tokens_per_second} tokens/s"
}
EOF
        
        # 比较与基准数据
        local baseline_avg=$(echo "$BASELINE_MODEL_PERF" | jq -r '.avg_response_time' | sed 's/ms//')
        local baseline_throughput=$(echo "$BASELINE_MODEL_PERF" | jq -r '.throughput' | sed 's/ req\/s//')
        local baseline_tokens=$(echo "$BASELINE_MODEL_PERF" | jq -r '.tokens_per_second' | sed 's/ tokens\/s//')
        local current_avg=$avg_response_time
        local current_throughput=$throughput
        local current_tokens=$tokens_per_second
        
        if [ -n "$baseline_avg" ] && [ "$baseline_avg" != "null" ]; then
            local response_degradation=$(echo "scale=2; ($current_avg - $baseline_avg) * 100 / $baseline_avg" | bc)
            local throughput_degradation=$(echo "scale=2; ($baseline_throughput - $current_throughput) * 100 / $baseline_throughput" | bc)
            local tokens_degradation=$(echo "scale=2; ($baseline_tokens - $current_tokens) * 100 / $baseline_tokens" | bc)
            
            local status="stable"
            if (( $(echo "$response_degradation > $THRESHOLD_PERCENTAGE" | bc -l) )) || 
               (( $(echo "$throughput_degradation > $THRESHOLD_PERCENTAGE" | bc -l) )) ||
               (( $(echo "$tokens_degradation > $THRESHOLD_PERCENTAGE" | bc -l) )); then
                status="degraded"
                log_warning "模型性能回归: 响应时间下降${response_degradation}%, 吞吐量下降${throughput_degradation}%, Token生成下降${tokens_degradation}%"
            else
                log_info "模型性能稳定"
            fi
            
            jq ".regression_analysis = {
                \"baseline_avg_response_time\": \"${baseline_avg}ms\",
                \"current_avg_response_time\": \"${current_avg}ms\",
                \"response_degradation_percentage\": \"${response_degradation}%\",
                \"baseline_throughput\": \"${baseline_throughput} req/s\",
                \"current_throughput\": \"${current_throughput} req/s\",
                \"throughput_degradation_percentage\": \"${throughput_degradation}%\",
                \"baseline_tokens_per_second\": \"${baseline_tokens} tokens/s\",
                \"current_tokens_per_second\": \"${current_tokens} tokens/s\",
                \"tokens_degradation_percentage\": \"${tokens_degradation}%\",
                \"status\": \"$status\"
            }" "$results_file" > "${results_file}.tmp" && mv "${results_file}.tmp" "$results_file"
        fi
    else
        log_warning "未找到model loadtest结果文件"
        cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "error": "Model loadtest results not found"
}
EOF
    fi
    
    REGRESSION_DATA[$test_name]=$(cat "$results_file")
    log_success "模型性能回归测试完成"
    echo "$results_file"
}

# 数据库性能回归测试
regression_database_performance() {
    log_info "执行数据库性能回归测试..."
    
    local test_name="database_performance"
    local results_file="$CURRENT_DIR/${test_name}_results.json"
    
    # 测试PostgreSQL连接和基本查询
    local connection_time=0
    local query_time=0
    local success_count=0
    local failure_count=0
    
    for i in {1..30}; do
        # 测试连接时间
        local conn_start=$(date +%s%3N)
        if psql -h localhost -U postgres -d postgres -c "SELECT 1;" > /dev/null 2>&1; then
            local conn_end=$(date +%s%3N)
            local conn_time=$((conn_end - conn_start))
            connection_time=$((connection_time + conn_time))
            
            # 测试查询时间
            local query_start=$(date +%s%3N)
            if psql -h localhost -U postgres -d postgres -c "SELECT COUNT(*) FROM pg_stat_activity;" > /dev/null 2>&1; then
                local query_end=$(date +%s%3N)
                local q_time=$((query_end - query_start))
                query_time=$((query_time + q_time))
                success_count=$((success_count + 1))
            else
                failure_count=$((failure_count + 1))
            fi
        else
            failure_count=$((failure_count + 1))
        fi
        
        sleep 0.2
    done
    
    local avg_connection_time=$(echo "scale=2; $connection_time / $success_count" | bc)
    local avg_query_time=$(echo "scale=2; $query_time / $success_count" | bc)
    local success_rate=$(echo "scale=2; $success_count * 100 / 30" | bc)
    
    cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "total_tests": 30,
  "successful_tests": $success_count,
  "failed_tests": $failure_count,
  "success_rate": "$success_rate%",
  "avg_connection_time": "${avg_connection_time}ms",
  "avg_query_time": "${avg_query_time}ms"
}
EOF
    
    # 比较与基准数据
    local baseline_conn=$(echo "$BASELINE_DB_PERF" | jq -r '.avg_connection_time' | sed 's/ms//')
    local baseline_query=$(echo "$BASELINE_DB_PERF" | jq -r '.avg_query_time' | sed 's/ms//')
    
    if [ -n "$baseline_conn" ] && [ "$baseline_conn" != "null" ]; then
        local conn_degradation=$(echo "scale=2; ($avg_connection_time - $baseline_conn) * 100 / $baseline_conn" | bc)
        local query_degradation=$(echo "scale=2; ($avg_query_time - $baseline_query) * 100 / $baseline_query" | bc)
        
        local status="stable"
        if (( $(echo "$conn_degradation > $THRESHOLD_PERCENTAGE" | bc -l) )) || 
           (( $(echo "$query_degradation > $THRESHOLD_PERCENTAGE" | bc -l) )); then
            status="degraded"
            log_warning "数据库性能回归: 连接时间下降${conn_degradation}%, 查询时间下降${query_degradation}%"
        else
            log_info "数据库性能稳定"
        fi
        
        jq ".regression_analysis = {
            \"baseline_avg_connection_time\": \"${baseline_conn}ms\",
            \"current_avg_connection_time\": \"${avg_connection_time}ms\",
            \"connection_degradation_percentage\": \"${conn_degradation}%\",
            \"baseline_avg_query_time\": \"${baseline_query}ms\",
            \"current_avg_query_time\": \"${avg_query_time}ms\",
            \"query_degradation_percentage\": \"${query_degradation}%\",
            \"status\": \"$status\"
        }" "$results_file" > "${results_file}.tmp" && mv "${results_file}.tmp" "$results_file"
    fi
    
    REGRESSION_DATA[$test_name]=$(cat "$results_file")
    log_success "数据库性能回归测试完成"
    echo "$results_file"
}

# 缓存性能回归测试
regression_cache_performance() {
    log_info "执行缓存性能回归测试..."
    
    local test_name="cache_performance"
    local results_file="$CURRENT_DIR/${test_name}_results.json"
    
    # 测试Redis连接和基本操作
    local set_time=0
    local get_time=0
    local success_count=0
    local failure_count=0
    
    for i in {1..50}; do
        local key="regression_key_$i"
        local value="regression_value_$(date +%s)"
        
        # 测试SET操作
        local set_start=$(date +%s%3N)
        if redis-cli SET "$key" "$value" > /dev/null 2>&1; then
            local set_end=$(date +%s%3N)
            local s_time=$((set_end - set_start))
            set_time=$((set_time + s_time))
            
            # 测试GET操作
            local get_start=$(date +%s%3N)
            if redis-cli GET "$key" > /dev/null 2>&1; then
                local get_end=$(date +%s%3N)
                local g_time=$((get_end - get_start))
                get_time=$((get_time + g_time))
                success_count=$((success_count + 1))
            else
                failure_count=$((failure_count + 1))
            fi
        else
            failure_count=$((failure_count + 1))
        fi
        
        # 清理测试数据
        redis-cli DEL "$key" > /dev/null 2>&1
        
        sleep 0.1
    done
    
    local avg_set_time=$(echo "scale=2; $set_time / $success_count" | bc)
    local avg_get_time=$(echo "scale=2; $get_time / $success_count" | bc)
    local success_rate=$(echo "scale=2; $success_count * 100 / 50" | bc)
    
    cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "total_operations": 50,
  "successful_operations": $success_count,
  "failed_operations": $failure_count,
  "success_rate": "$success_rate%",
  "avg_set_time": "${avg_set_time}ms",
  "avg_get_time": "${avg_get_time}ms"
}
EOF
    
    # 比较与基准数据
    local baseline_set=$(echo "$BASELINE_CACHE_PERF" | jq -r '.avg_set_time' | sed 's/ms//')
    local baseline_get=$(echo "$BASELINE_CACHE_PERF" | jq -r '.avg_get_time' | sed 's/ms//')
    
    if [ -n "$baseline_set" ] && [ "$baseline_set" != "null" ]; then
        local set_degradation=$(echo "scale=2; ($avg_set_time - $baseline_set) * 100 / $baseline_set" | bc)
        local get_degradation=$(echo "scale=2; ($avg_get_time - $baseline_get) * 100 / $baseline_get" | bc)
        
        local status="stable"
        if (( $(echo "$set_degradation > $THRESHOLD_PERCENTAGE" | bc -l) )) || 
           (( $(echo "$get_degradation > $THRESHOLD_PERCENTAGE" | bc -l) )); then
            status="degraded"
            log_warning "缓存性能回归: SET时间下降${set_degradation}%, GET时间下降${get_degradation}%"
        else
            log_info "缓存性能稳定"
        fi
        
        jq ".regression_analysis = {
            \"baseline_avg_set_time\": \"${baseline_set}ms\",
            \"current_avg_set_time\": \"${avg_set_time}ms\",
            \"set_degradation_percentage\": \"${set_degradation}%\",
            \"baseline_avg_get_time\": \"${baseline_get}ms\",
            \"current_avg_get_time\": \"${avg_get_time}ms\",
            \"get_degradation_percentage\": \"${get_degradation}%\",
            \"status\": \"$status\"
        }" "$results_file" > "${results_file}.tmp" && mv "${results_file}.tmp" "$results_file"
    fi
    
    REGRESSION_DATA[$test_name]=$(cat "$results_file")
    log_success "缓存性能回归测试完成"
    echo "$results_file"
}

# 系统资源回归测试
regression_system_resources() {
    log_info "执行系统资源回归测试..."
    
    local test_name="system_resources"
    local results_file="$CURRENT_DIR/${test_name}_results.json"
    local monitor_file="$CURRENT_DIR/${test_name}_monitor.csv"
    
    # 创建监控CSV文件
    echo "timestamp,cpu_usage,memory_usage,disk_usage,load_avg" > "$monitor_file"
    
    # 监控系统资源2分钟
    local start_time=$(date +%s)
    local end_time=$((start_time + 120))
    
    while [ $(date +%s) -lt $end_time ]; do
        local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
        local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | awk -F'%' '{print $1}')
        local mem_info=$(free | grep Mem)
        local total_mem=$(echo $mem_info | awk '{print $2}')
        local used_mem=$(echo $mem_info | awk '{print $3}')
        local mem_usage=$(echo "scale=2; $used_mem * 100 / $total_mem" | bc)
        local disk_usage=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
        local load_avg=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
        
        echo "$timestamp,$cpu_usage,$mem_usage,$disk_usage,$load_avg" >> "$monitor_file"
        
        sleep 10
    done
    
    # 计算平均值
    local avg_cpu=$(awk -F',' 'NR>1 {sum+=$2; count++} END {printf "%.2f", sum/count}' "$monitor_file")
    local avg_memory=$(awk -F',' 'NR>1 {sum+=$3; count++} END {printf "%.2f", sum/count}' "$monitor_file")
    local avg_disk=$(awk -F',' 'NR>1 {sum+=$4; count++} END {printf "%.2f", sum/count}' "$monitor_file")
    local avg_load=$(awk -F',' 'NR>1 {sum+=$5; count++} END {printf "%.2f", sum/count}' "$monitor_file")
    
    cat > "$results_file" << EOF
{
  "test_name": "$test_name",
  "timestamp": "$(date -Iseconds)",
  "monitor_duration": 120,
  "monitor_file": "$monitor_file",
  "avg_cpu_usage": "${avg_cpu}%",
  "avg_memory_usage": "${avg_memory}%",
  "avg_disk_usage": "${avg_disk}%",
  "avg_load_average": "$avg_load"
}
EOF
    
    # 比较与基准数据
    local baseline_cpu=$(echo "$BASELINE_SYS_RES" | jq -r '.avg_cpu_usage' | sed 's/%//')
    local baseline_memory=$(echo "$BASELINE_SYS_RES" | jq -r '.avg_memory_usage' | sed 's/%//')
    
    if [ -n "$baseline_cpu" ] && [ "$baseline_cpu" != "null" ]; then
        local cpu_increase=$(echo "scale=2; ($avg_cpu - $baseline_cpu) * 100 / $baseline_cpu" | bc)
        local memory_increase=$(echo "scale=2; ($avg_memory - $baseline_memory) * 100 / $baseline_memory" | bc)
        
        local status="stable"
        if (( $(echo "$cpu_increase > $THRESHOLD_PERCENTAGE" | bc -l) )) || 
           (( $(echo "$memory_increase > $THRESHOLD_PERCENTAGE" | bc -l) )); then
            status="degraded"
            log_warning "系统资源回归: CPU使用增加${cpu_increase}%, 内存使用增加${memory_increase}%"
        else
            log_info "系统资源稳定"
        fi
        
        jq ".regression_analysis = {
            \"baseline_avg_cpu_usage\": \"${baseline_cpu}%\",
            \"current_avg_cpu_usage\": \"${avg_cpu}%\",
            \"cpu_increase_percentage\": \"${cpu_increase}%\",
            \"baseline_avg_memory_usage\": \"${baseline_memory}%\",
            \"current_avg_memory_usage\": \"${avg_memory}%\",
            \"memory_increase_percentage\": \"${memory_increase}%\",
            \"status\": \"$status\"
        }" "$results_file" > "${results_file}.tmp" && mv "${results_file}.tmp" "$results_file"
    fi
    
    REGRESSION_DATA[$test_name]=$(cat "$results_file")
    log_success "系统资源回归测试完成"
    echo "$results_file"
}

# 生成回归报告
generate_regression_report() {
    log_info "生成回归测试报告..."
    
    local report_file="$CURRENT_DIR/$REPORT_FILE"
    
    # 统计回归结果
    local total_tests=0
    local degraded_tests=0
    local stable_tests=0
    local improved_tests=0
    
    for test_name in "${!REGRESSION_DATA[@]}"; do
        total_tests=$((total_tests + 1))
        local status=$(echo "${REGRESSION_DATA[$test_name]}" | jq -r '.regression_analysis.status // "unknown"')
        
        case $status in
            "degraded")
                degraded_tests=$((degraded_tests + 1))
                ;;
            "stable")
                stable_tests=$((stable_tests + 1))
                ;;
            "improved")
                improved_tests=$((improved_tests + 1))
                ;;
        esac
    done
    
    # 创建报告JSON
    cat > "$report_file" << EOF
{
  "regression_test_summary": {
    "timestamp": "$(date -Iseconds)",
    "total_tests": $total_tests,
    "degraded_tests": $degraded_tests,
    "stable_tests": $stable_tests,
    "improved_tests": $improved_tests,
    "threshold_percentage": $THRESHOLD_PERCENTAGE
  },
  "test_results": {
EOF
    
    local first=true
    for test_name in "${!REGRESSION_DATA[@]}"; do
        if [ "$first" = true ]; then
            first=false
        else
            echo "," >> "$report_file"
        fi
        
        echo "    \"$test_name\": ${REGRESSION_DATA[$test_name]}" >> "$report_file"
    done
    
    cat >> "$report_file" << EOF

  },
  "recommendations": [
    "如果发现性能回退，请检查最近的系统更新和配置变更",
    "对于性能下降超过阈值的组件，建议进行详细分析",
    "定期更新基准数据以反映系统的最佳性能状态",
    "建立自动化的回归测试流程以快速发现性能问题"
  ]
}
EOF
    
    # 生成Markdown报告
    local md_report_file="$CURRENT_DIR/regression_report_$(date +%Y%m%d_%H%M%S).md"
    
    cat > "$md_report_file" << EOF
# AI工厂系统回归测试报告

## 测试概述

- **测试时间**: $(date '+%Y-%m-%d %H:%M:%S')
- **回归阈值**: ${THRESHOLD_PERCENTAGE}%
- **基准数据目录**: $BASELINE_DIR
- **当前测试目录**: $CURRENT_DIR

## 测试结果摘要

| 测试项目 | 状态 | 详情 |
|---------|------|------|
| 总测试数 | $total_tests | - |
| 性能下降 | $degraded_tests | 需要关注 |
| 性能稳定 | $stable_tests | 正常 |
| 性能提升 | $improved_tests | 良好 |

## 详细测试结果

EOF
    
    # 添加各测试详细结果
    for test_name in "${!REGRESSION_DATA[@]}"; do
        local result="${REGRESSION_DATA[$test_name]}"
        local status=$(echo "$result" | jq -r '.regression_analysis.status // "unknown"')
        local test_title=$(echo "$result" | jq -r '.test_name // "'$test_name'"')
        
        case $status in
            "degraded")
                status_icon="❌"
                ;;
            "stable")
                status_icon="✅"
                ;;
            "improved")
                status_icon="📈"
                ;;
            *)
                status_icon="❓"
                ;;
        esac
        
        cat >> "$md_report_file" << EOF

### $test_title $status_icon

EOF
        
        if [ "$status" != "unknown" ]; then
            local baseline=$(echo "$result" | jq -r '.regression_analysis | to_entries | .[] | select(.key | contains("baseline")) | .key + ": " + .value')
            local current=$(echo "$result" | jq -r '.regression_analysis | to_entries | .[] | select(.key | contains("current")) | .key + ": " + .value')
            local degradation=$(echo "$result" | jq -r '.regression_analysis.degradation_percentage // .regression_analysis.increase_percentage // "N/A"')
            
            cat >> "$md_report_file" << EOF

**基准值**: $baseline  
**当前值**: $current  
**变化幅度**: $degradation  

EOF
        fi
        
        # 添加原始结果
        cat >> "$md_report_file" << EOF

**原始结果**: \`$test_name\_results.json\`

EOF
    done
    
    cat >> "$md_report_file" << EOF

## 建议措施

1. **性能下降处理**: 对于标记为性能下降的测试项目，建议：
   - 检查最近的系统更新和配置变更
   - 分析日志文件查找异常信息
   - 考虑回滚到上一个稳定版本

2. **持续监控**: 建议建立自动化的回归测试流程：
   - 定期运行回归测试
   - 设置性能阈值告警
   - 跟踪性能趋势变化

3. **基准数据更新**: 当系统性能确实得到提升时，更新基准数据以反映新的最佳性能状态。

---

*报告生成时间: $(date '+%Y-%m-%d %H:%M:%S')*
EOF
    
    log_success "回归测试报告生成完成"
    log_info "JSON报告: $report_file"
    log_info "Markdown报告: $md_report_file"
    
    echo "$report_file"
}

# 显示帮助信息
show_help() {
    echo "回归测试脚本"
    echo ""
    echo "使用方法:"
    echo "  $0 [选项]"
    echo ""
    echo "选项:"
    echo "  -h, --help              显示此帮助信息"
    echo "  -b, --baseline DIR      基准数据目录 (默认: $BASELINE_DIR)"
    echo "  -c, --current DIR       当前测试目录 (默认: $CURRENT_DIR)"
    echo "  -t, --threshold NUM     回归阈值百分比 (默认: $THRESHOLD_PERCENTAGE)"
    echo "  -d, --duration SEC      测试持续时间 (默认: $TEST_DURATION)"
    echo "  -u, --users NUM         并发用户数 (默认: $CONCURRENT_USERS)"
    echo "  -v, --verbose           详细输出"
    echo ""
    echo "示例:"
    echo "  $0                      # 运行完整回归测试"
    echo "  $0 -t 10                # 设置10%回归阈值"
    echo "  $0 -b /path/to/baseline # 指定基准数据目录"
}

# 主函数
main() {
    # 解析命令行参数
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -b|--baseline)
                BASELINE_DIR="$2"
                shift 2
                ;;
            -c|--current)
                CURRENT_DIR="$2"
                mkdir -p "$CURRENT_DIR"
                shift 2
                ;;
            -t|--threshold)
                THRESHOLD_PERCENTAGE="$2"
                shift 2
                ;;
            -d|--duration)
                TEST_DURATION="$2"
                shift 2
                ;;
            -u|--users)
                CONCURRENT_USERS="$2"
                shift 2
                ;;
            -v|--verbose)
                VERBOSE=true
                shift
                ;;
            *)
                log_error "未知参数: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    log_info "开始回归测试"
    log_info "基准数据目录: $BASELINE_DIR"
    log_info "当前测试目录: $CURRENT_DIR"
    log_info "回归阈值: ${THRESHOLD_PERCENTAGE}%"
    echo ""
    
    # 加载基准数据
    if ! load_baseline_data; then
        log_error "无法加载基准数据，退出测试"
        exit 1
    fi
    echo ""
    
    # 执行回归测试
    regression_api_health
    regression_api_performance
    regression_model_performance
    regression_database_performance
    regression_cache_performance
    regression_system_resources
    
    echo ""
    
    # 生成报告
    generate_regression_report
    
    echo ""
    log_success "回归测试完成"
    log_info "结果目录: $CURRENT_DIR"
}

# 执行主函数
main "$@"