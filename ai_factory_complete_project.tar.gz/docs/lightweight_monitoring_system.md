# 本地部署轻量级系统监控方案(Prometheus + Grafana)设计蓝图

## 执行摘要与范围界定

在本地数据中心或边缘环境中,如何以最小资源开销建立一套可观测、可审计、可回滚的监控体系,是平台工程与SRE团队面临的现实课题。本蓝图提出一套以 Prometheus 与 Grafana 为核心的轻量级监控方案,围绕“拉取为主、最小化暴露、模板化部署、分层可视化、基于基线的告警闭环”五项原则,面向架构师、平台工程师、后端与机器学习工程师、SRE/运维以及信息安全负责人,给出可直接落地的架构、配置与操作指南。方案覆盖范围包括:

- 架构与组件选型:明确监控边界、端到端数据流与组件职责。
- 本地部署配置优化:基于 Docker Compose 的网络、卷、权限、密钥与健康检查策略。
- 监控指标定义与采集策略:服务级、模型级、数据库/缓存/向量库、系统与业务指标字典与采集频率。
- 仪表板设计与可视化方案:分层仪表板与面板设计原则。
- 告警规则与通知机制:阈值策略、抑制与路由、值班与升级。
- 性能优化与资源控制:采集频率、保留策略、日志级别与索引优化、成本杠杆。
- 完整部署配置与使用指南:配置文件模板、部署与验证、运维手册与回滚策略。
- 安全与合规:最小权限、网络隔离、供应链安全、审计与合规。
- 风险与权衡、实施路线图与验收标准:从PoC到生产的推进与验收。
- 附录:配置模板与速查清单。

在方法论上,本方案以生产级 Compose 实践为基线,结合容器化AI应用的网络与卷管理原则、模型服务的指标暴露规范以及Prometheus+Grafana的部署与告警闭环经验,确保“轻量但不失完备”的落地路径[^1][^2][^3][^4][^5]。同时,方案充分考虑本地AI系统的安全与合规要求,将供应链安全与审计追踪纳入设计范畴[^6]。

信息缺口与实施假设:由于目标硬件规格(CPU/GPU、内存、磁盘IOPS与网络)、并发与吞吐目标、合规基线(跨境、审计、保留策略与灾备等级)、NAS品牌型号与协议(SMB/NFS/对象存储)、密钥管理设施(KMS/HSM)等信息尚未提供,方案中的资源配额、采集频率、保留周期与告警阈值以“基线可调参数”形式呈现;实际部署需在试运行阶段通过压测与度量逐步收敛。

---

## 监控架构设计与组件选型

监控边界的确定遵循“外部入口唯一、内部服务互信”的原则:所有面向互联网的访问统一通过反向代理(例如 Nginx),内部服务之间通过容器网络隔离,数据库、缓存、向量库与模型服务均不对外暴露,监控与日志系统以本地内网为主,避免将敏感指标与日志直接暴露在公网[^1][^2]。端到端数据流为:服务与模型指标暴露→Prometheus拉取→Grafana可视化→Alertmanager路由与通知→日志联动(Loki可选)→处置与回滚。

组件职责清晰分工:Prometheus负责指标拉取与告警规则执行;Grafana负责可视化与告警配置;Alertmanager负责告警路由与抑制;Exporter或服务内置指标端点提供采集目标;日志系统(Loki或既有方案)与指标系统联动,支持跨维度分析与根因定位;反向代理统一入口与TLS终止,保障外部访问安全边界[^1][^2][^4][^5][^6]。

为帮助读者把握职责边界与暴露策略,以下矩阵给出核心组件的监控职责与暴露范围。

表1 核心组件与监控职责矩阵

| 组件 | 监控职责 | 对外暴露 | 依赖 | 数据持久化 | 监控要求 |
|---|---|---|---|---|---|
| 反向代理(Nginx) | 进程与端口可用性、证书有效期、路由错误率 | 是(80/443) | API、Web | 无(配置可挂载) | 可用性与证书有效期 |
| API服务 | QPS、P95/P99延迟、错误率(5xx)、依赖调用耗时 | 否(仅通过反向代理) | DB、Redis、向量库、模型服务 | 无 | 延迟分位数、错误率 |
| Web前端 | 页面加载时间、JS错误率、资源加载失败率 | 是(经反向代理) | API | 无 | 前端性能与错误 |
| PostgreSQL | 连接数、慢查询、锁等待、磁盘使用 | 否 | 磁盘IO | 是(数据卷+NAS备份) | 慢查询与IO等待 |
| Redis | 命中率、内存占用、延迟、淘汰次数 | 否 | 内存与磁盘 | 是(AOF可选) | 命中率与内存 |
| 向量库(Weaviate) | 索引大小、查询延迟、插入速率 | 否 | 磁盘与内存 | 是(数据路径挂载) | 检索延迟与吞吐 |
| 模型服务(vLLM/Ollama) | 吞吐、请求延迟、并发队列、显存/内存占用 | 否 | GPU/CPU、权重 | 模型权重可挂载 | 延迟与资源利用 |
| Prometheus | 采集目标可用性、采集延迟、告警触发 | 否(本地) | 各服务exporter | 无 | 目标可用性 |
| Grafana | 仪表板可用性、告警有效性 | 可选(内网) | Prometheus | 无 | 告警有效性 |
| Loki/Alertmanager | 日志摄取延迟、告警路由与抑制 | 否(本地) | 各服务日志 | 无 | 误报/漏报率 |

上述矩阵体现了“内部互信、外部收敛”的安全边界设计,确保监控与日志系统在不暴露敏感服务的前提下,实现端到端可见性与告警闭环[^1][^2][^4][^5][^6]。

### 逻辑架构与数据流

从用户请求到模型推理与响应的路径中,监控数据流贯穿始终:API服务在处理请求时暴露延迟、吞吐与错误率等指标;模型服务暴露推理延迟、并发队列与资源利用指标;数据库与缓存暴露连接、慢查询与命中率指标;系统主机暴露CPU、内存、磁盘与网络指标。Prometheus以固定采集周期拉取上述指标,并在告警规则满足时触发事件,由Alertmanager路由到邮件或IM等通知渠道;Grafana从Prometheus读取数据,按服务与场景分层组织仪表板,并在必要时通过日志联动(如Loki)进行跨维度分析,形成“指标—日志—追踪”的闭环[^4][^5]。

### 组件选型原则

在选型与取舍上遵循四项原则:轻量化优先(控制监控栈资源占比)、易维护(模板化与声明式配置)、与现有栈兼容(与API框架、模型服务、数据库与缓存、向量库与日志系统兼容)、安全与合规(最小权限与审计追踪)。在模型服务层面,优先启用服务内置指标端点(例如 vLLM 的 Prometheus 指标),减少额外Exporter维护成本,同时保证指标语义与模型行为一致[^3][^4][^5][^6]。

---

## 本地部署配置优化(Docker Compose)

在本地部署场景,Docker Compose 是最直接且可控的编排方式。最佳实践包括:镜像策略(多阶段构建、固定digest、最小基础镜像)、网络与卷(bridge网络、命名卷与bind mount组合)、资源限额(requests/limits)、健康检查(统一 interval/timeout/retries/start_period)、日志驱动限额(控制文件大小与轮转)、密钥与配置管理(环境变量注入、避免明文)、重启与回滚策略(版本化与灰度)[^1][^7][^6]。

表2 Compose服务配置摘要(示例)

| 服务 | 镜像版本/摘要 | 端口映射 | 环境变量 | 卷挂载 | 资源限额 | 健康检查 |
|---|---|---|---|---|---|---|
| Nginx | latest(固定digest) | 80,443 | TZ、证书路径 | conf与证书挂载 | CPU/内存限额 | HTTP 200 |
| API | 自定义:v1.x | 5001 | DB/Redis/Weaviate地址 | 无 | CPU/内存限额 | /health |
| Web | 前端:v1.x | 3000 | API_BASE_URL | 无 | CPU/内存限额 | HTTP 200 |
| DB(PostgreSQL) | postgres:15-alpine | 5432 | POSTGRES_* | postgres_data | CPU/内存限额 | pg_isready |
| Redis | redis:6-alpine | 6379 | AOF等 | redis_data | CPU/内存限额 | Redis ping |
| Weaviate | semitechnologies/weaviate:1.19.0 | 8080 | QUERY_DEFAULTS等 | weaviate_data | CPU/内存限额 | HTTP 200 |
| vLLM | vllm官方镜像 | 8000 | 模型与并发参数 | 模型权重可挂载 | GPU/显存与CPU/内存限额 | HTTP 200 |
| Ollama | ollama官方镜像 | 11434 | 模型与参数 | 模型权重可挂载 | CPU/内存限额 | HTTP 200 |
| Prometheus | prom/prometheus | 9090 | 配置文件 | prometheus数据 | CPU/内存限额 | HTTP 200 |
| Grafana | grafana/grafana | 3000 | 数据源与插件 | grafana数据 | CPU/内存限额 | HTTP 200 |
| Loki | grafana/loki | 3100 | 配置文件 | loki数据 | CPU/内存限额 | HTTP 200 |
| Alertmanager | alertmanager | 9093 | 路由与接收器 | alertmanager数据 | CPU/内存限额 | HTTP 200 |

表3 镜像供应链安全清单

| 控制项 | 实施要点 |
|---|---|
| 基础镜像来源 | 使用官方或受信任仓库,固定digest |
| 漏洞扫描 | 构建流程集成扫描,阻断高危镜像 |
| SBOM | 生成软件物料清单,纳入审计 |
| 签名 | 对镜像进行签名,部署前验证 |
| 最小权限运行 | 非root用户运行,只读文件系统 |
| 机密管理 | 使用环境变量与密钥管理服务,避免明文泄露 |

表4 端口与服务映射(示例)

| 服务 | 内部端口 | 外部端口 | 协议 | 暴露策略 |
|---|---|---|---|---|
| Nginx | 80,443 | 80,443 | HTTP/HTTPS | 对外暴露,统一入口 |
| API | 5001 | 无(经Nginx) | HTTP | 仅内部访问 |
| Web | 3000 | 无(经Nginx) | HTTP | 仅内部访问 |
| PostgreSQL | 5432 | 无 | TCP | 仅内部访问 |
| Redis | 6379 | 无 | TCP | 仅内部访问 |
| Weaviate | 8080 | 无 | HTTP | 仅内部访问 |
| vLLM | 8000 | 无 | HTTP | 仅内部访问 |
| Ollama | 11434 | 无 | HTTP | 仅内部访问 |
| Prometheus | 9090 | 无 | HTTP | 仅内部访问 |
| Grafana | 3000 | 可选内网 | HTTP | 按需暴露 |
| Loki | 3100 | 无 | HTTP | 仅内部访问 |
| Alertmanager | 9093 | 无 | HTTP | 仅内部访问 |

表5 目录挂载与权限(示例)

| 容器路径 | 主机路径/NAS | 读写权限 | 属主/属组 | 备份策略 |
|---|---|---|---|---|
| /var/lib/postgresql/data | 本地数据卷 | rw | postgres | 每周全量+每日增量 |
| /data | 本地数据卷(Redis) | rw | redis | 每周全量 |
| /var/lib/weaviate | 本地数据卷 | rw | weaviate | 每周全量+每日增量 |
| /etc/nginx/conf.d | 主机配置目录 | ro | root | 配置版本化 |
| /var/log | Loki/日志目录 | rw | adm | 每周归档到NAS |
| /models | NAS共享路径 | rw | appuser | 每次发布归档 |

### 网络与卷策略

网络采用 bridge 与子网规划,确保容器间通信可控、外部入口唯一;卷策略优先使用命名卷承载数据库与缓存等IO敏感数据,以保障性能;NAS用于权重、归档与备份,降低主存储压力并提升可迁移性。权限与属主需与应用容器用户匹配,避免权限不足或越权访问[^1][^2]。

### 健康检查与启动顺序

健康检查统一参数:interval=30s、timeout=10s、retries=3、start_period=40s。depends_on 与条件依赖结合,确保依赖服务就绪后再进行健康探测,避免冷启动期间的误判与级联故障[^1]。

---

## 监控指标定义与采集策略

指标字典覆盖服务级、模型级、数据库/缓存/向量库、系统与业务五大类。采集频率以15–30秒为基线,日志级别默认INFO,必要时限时启用DEBUG;告警阈值基于基线设定,避免误报与漏报;日志与指标通过请求ID/页ID等上下文进行关联分析,形成从异常发现到根因定位的闭环[^4][^5][^8][^9][^10][^11]。

表6 监控指标字典(示例)

| 指标名称 | 来源 | 采集频率 | 告警阈值 | 仪表板归属 |
|---|---|---|---|---|
| 请求QPS | API服务 | 15s | 超出基线+X% | API性能 |
| P95/P99延迟 | API服务/模型服务 | 15s | P95>基线+Y% | API/模型性能 |
| 错误率(5xx) | API服务 | 15s | >1% | API可靠性 |
| GPU/显存占用 | 模型服务 | 15s | >90%持续N分钟 | 模型资源 |
| 内存占用 | Redis/Weaviate/系统 | 15s | >85%持续N分钟 | 资源概览 |
| 磁盘IO等待 | 系统/DB | 15s | >20% | 资源与DB |
| 向量查询延迟 | Weaviate | 15s | >基线+Z% | 检索性能 |
| 缓存命中率 | Redis | 15s | <80% | 缓存性能 |
| 慢查询计数 | PostgreSQL | 30s | >基线 | DB性能 |
| 启动健康失败次数 | 各服务 | 30s | >3 | 可用性 |

表7 采集目标与抓取配置摘要(示例)

| 目标服务 | 指标端点 | 抓取间隔 | 命名空间/标签 |
|---|---|---|---|
| API服务 | /metrics 或自定义端点 | 15s | service=api, env=prod |
| 模型服务(vLLM) | /metrics(Prometheus) | 15s | service=model, model=... |
| Ollama | /metrics 或Exporter | 15s | service=model, model=... |
| PostgreSQL | postgres_exporter | 30s | service=db |
| Redis | redis_exporter | 30s | service=cache |
| Weaviate | 内置指标 | 30s | service=vector |
| 系统主机 | node_exporter | 30s | service=node |

### 服务级指标

服务级关注吞吐、延迟分位数、错误率、超时率、并发度与队列长度;依赖调用耗时(数据库、缓存、向量库与模型服务)需单独记录,以便在瓶颈定位时快速识别上下游影响。延迟建议以P50/P95/P99分位数呈现,避免平均值掩盖长尾[^5]。

### 模型级指标(vLLM/Ollama)

模型级关注吞吐(tokens/s或requests/s)、请求延迟、并发队列、显存/内存占用与批处理效率;启用模型服务内置指标端点(例如 vLLM 的 Prometheus 指标),减少维护成本并保证指标语义一致;在生产场景下优先vLLM以获得更好的批处理与吞吐表现[^3][^4]。

### 数据库/缓存/向量库指标

数据库(PostgreSQL)关注连接数、慢查询、锁等待与磁盘使用;缓存(Redis)关注命中率、内存占用、延迟与淘汰次数;向量库(Weaviate)关注索引大小、查询延迟与插入速率。上述指标与采集频率建议基于官方文档与实践指南设定,并在试运行阶段结合负载特征进行微调[^8][^9][^10]。

### 系统与业务指标

系统指标包括CPU、内存、磁盘IO与网络;业务指标与场景相关,例如PDF图纸识别的结构保真度、文本精度(CER/WER)、符号检测F1、拓扑一致性与尺寸链闭合差等,需结合业务目标设定采集与评估策略(可参考既有评估体系中的指标定义与阈值建议)[^11]。

---

## 仪表板设计与可视化方案

仪表板分层组织,建议分为总览、服务性能、模型吞吐与延迟、检索与缓存、数据库性能、资源与容量六大类。面板设计遵循“少而精、突出趋势与分位数、避免噪音”的原则:总览展示核心SLO与健康度;服务性能面板聚焦QPS、延迟分位数与错误率;模型面板突出吞吐与资源利用;检索与缓存面板呈现向量查询延迟与命中率;数据库面板关注慢查询与锁等待;资源与容量面板用于容量规划与成本监控。数据源统一配置Prometheus,变量与模板按服务与环境分层,支持快速切换与过滤[^5][^4]。

表8 仪表板面板清单(示例)

| 面板名称 | 指标 | 可视化类型 | 用途 | 告警关联 |
|---|---|---|---|---|
| 总览-SLO健康度 | 可用性、错误率、P95延迟 | 指标卡+时间序列 | 快速掌握整体健康 | 高 |
| API性能-QPS与延迟 | QPS、P95/P99 | 时间序列+分位图 | 观察性能趋势与长尾 | 中 |
| 模型吞吐与资源 | tokens/s、显存占用 | 时间序列+热力图 | 评估并发与资源瓶颈 | 高 |
| 检索与缓存 | 向量查询延迟、命中率 | 时间序列+条形图 | 识别检索与缓存问题 | 中 |
| DB慢查询与锁 | 慢查询计数、锁等待 | 条形图+时间序列 | 定位数据库瓶颈 | 中 |
| 资源与容量 | CPU/内存/磁盘/网络 | 时间序列+仪表 | 容量规划与成本监控 | 低 |

### 总览仪表板

总览仪表板以服务等级目标(Service Level Objective,SLO)为核心,展示可用性、错误率与关键延迟(P95/P99),并提供健康度评分与异常热点入口,帮助值班人员快速识别是否需要进一步调查或处置[^5]。

### 服务与模型性能仪表板

该层聚焦API与模型服务的QPS、延迟分位数、错误率与并发队列,以及模型吞吐(tokens/s)与资源利用(显存/内存),用于判断性能瓶颈在应用层还是模型层,从而指导扩容、降级或回滚等动作[^4]。

---

## 告警规则与通知机制

告警策略采用“静态阈值+动态基线”的组合:静态阈值用于明确红线(例如错误率≥1%),动态基线用于识别缓慢下滑或周期性异常(例如P95延迟相对基线上升X%并持续N分钟)。抑制与合并策略用于减少抖动与告警风暴,例如在维护窗口静默非关键告警、在依赖不可用时抑制下游告警。通知渠道与值班SLA明确升级路径与复盘机制,确保告警闭环[^5][^4][^12]。

表9 告警路由与阈值(示例)

| 告警名称 | 严重级别 | 触发条件 | 通知渠道 | 抑制规则 |
|---|---|---|---|---|
| 模型P95延迟升高 | 高 | P95>基线+Y%持续10分钟 | 邮件/IM | 抑制与“错误率升高”同时触发 |
| 显存占用过高 | 高 | GPU显存>90%持续5分钟 | 邮件/IM | 抑制与“节点负载过高” |
| API错误率升高 | 中 | 5xx>1%持续5分钟 | 邮件/IM | 抑制与“依赖不可用” |
| 向量查询延迟升高 | 中 | 延迟>基线+Z%持续10分钟 | 邮件/IM | 抑制与“磁盘IO等待高” |
| Redis内存占用过高 | 中 | 内存>85%持续10分钟 | 邮件/IM | 抑制与“缓存命中率低” |
| PostgreSQL慢查询激增 | 中 | 慢查询>基线持续10分钟 | 邮件/IM | 抑制与“磁盘IO等待高” |

表10 通知渠道与升级路径(示例)

| 等级 | 渠道 | 接收人 | SLA | 升级条件 |
|---|---|---|---|---|
| P1 | 电话+IM+邮件 | 值班工程师/技术委员会 | 15分钟 | 30分钟未恢复 |
| P2 | IM+邮件 | 模块负责人 | 2小时 | 当日未恢复 |
| P3 | IM | 模块成员 | 次日 | 每周回顾 |

### 阈值策略

绝对阈值用于明确红线,相对阈值用于基于基线的变化检测;滑动窗口用于平滑短期抖动并捕捉持续异常;在负载异常时可临时调整阈值并记录审计,以避免过度告警或漏报[^5]。

### 告警联动与自动化

在P1/P2告警触发时,进入回滚候选或冻结上线;在A/B框架下可快速切换流量;与日志系统的联动用于根因定位与审计记录,形成“检测—抑制—处置—审计”的闭环[^5]。

---

## 性能优化与资源控制

轻量化的关键在于“控制采集与日志开销、保留策略分层、成本杠杆可调”。采集频率与指标数量需与业务负载匹配,避免对业务路径造成明显开销;日志级别默认INFO,必要时限时启用DEBUG;保留策略与下采样在热/温/冷数据上分层,平衡成本与可观测性;容量规划基于基线与弹性扩缩策略,避免资源抢占与过载[^1][^13][^14][^6]。

表11 资源预算与基线参数(示例)

| 服务 | CPU限额/保留 | 内存限额/保留 | GPU/显存 | 磁盘IO | 网络带宽 | 健康检查参数 |
|---|---|---|---|---|---|---|
| Nginx | 0.5–1 / 0.3 | 512M–1G / 256M | 无 | 低 | 中 | interval=30s, retries=3 |
| API服务 | 1–2 / 0.5 | 1–2G / 512M | 无 | 中 | 中 | interval=30s, retries=3, start_period=40s |
| Web前端 | 0.5–1 / 0.3 | 512M–1G / 256M | 无 | 低 | 中 | interval=30s, retries=3 |
| PostgreSQL | 1–2 / 0.5 | 1–4G / 1G | 无 | 高 | 中 | 进程与端口可用性 |
| Redis | 0.5–1 / 0.3 | 512M–2G / 512M | 无 | 中 | 中 | 进程与端口可用性 |
| Weaviate | 1–2 / 0.5 | 2–4G / 1G | 无 | 中–高 | 中 | interval=30s, retries=3 |
| vLLM | 2–4 / 1.0 | 4–8G / 2G | 视GPU而定 | 中 | 中–高 | interval=30s, retries=3 |
| Ollama | 1–2 / 0.5 | 2–4G / 1G | 可用GPU/CPU | 中 | 中 | interval=30s, retries=3 |
| Prometheus | 0.5–1 / 0.3 | 1–2G / 512M | 无 | 中 | 低 | 目标采集可用性 |
| Grafana | 0.5–1 / 0.3 | 512M–1G / 256M | 无 | 低 | 低 | 进程与端口可用性 |
| Loki/Alertmanager | 0.5–1 / 0.3 | 512M–1G / 256M | 无 | 中 | 低 | 进程与端口可用性 |

表12 成本优化杠杆(示例)

| 杠杆 | 影响 | 风险 | 适用场景 |
|---|---|---|---|
| 采集频率下调 | 降低监控开销 | 告警响应变慢 | 稳定期与低波动服务 |
| 指标精简 | 降低存储与计算 | 观测盲区 | 非核心路径或短期调试 |
| 日志级别控制 | 降低摄取与索引开销 | 调试能力下降 | 日常运行与问题复盘 |
| 保留策略分层 | 降低成本 | 冷数据取回延迟 | 历史趋势与合规归档 |
| HPA与限额 | 避免过载与闲置 | 限流过严影响峰值 | 负载波动明显服务 |

### 采集与存储优化

抓取间隔与保留策略需在“观测有效性”与“成本”之间平衡;对高频指标进行下采样并保留分位数,避免存储压力过大;日志索引与字段规范需按服务与级别组织,减少冗余与提高检索效率[^13][^14]。

### 容量规划与弹性

基于基线压测设定副本数与资源配额;在负载波动时采用弹性扩缩(HPA或脚本化扩容),避免资源抢占与过载;容量规划需定期回顾,结合趋势与业务增长调整[^1]。

---

## 安全与合规

安全策略贯穿身份认证与授权(RBAC与MFA)、网络隔离(内外网分离与微分段、反向代理统一入口与TLS终止)、镜像供应链安全(来源控制、漏洞扫描、SBOM与签名、最小权限运行)、数据安全与合规(静态与传输加密、备份与隔离、脱敏与审计)、安全运营(监测预警、应急响应与复盘改进)[^6][^7][^1]。

表13 角色-权限矩阵(示例)

| 角色 | 资源 | 操作 | 审批流程 | 审计要求 |
|---|---|---|---|---|
| 管理员 | 全局配置、用户与角色 | 创建/修改/删除 | 双人审批 | 全量审计与告警 |
| 开发者 | 模型与数据管道 | 提交/回滚/发布 | 单人审批+代码审查 | 操作留痕与产物签名 |
| 运维 | 监控与日志、备份 | 配置/告警/恢复 | 变更审批 | 变更记录与验证 |
| 分析师 | 数据与仪表板 | 查询/可视化 | 数据访问审批 | 查询审计与脱敏 |
| 访客 | Web前端 | 只读访问 | 临时授权 | 访问日志与限流 |

表14 安全控制清单(示例)

| 控制项 | 实施措施 | 验证方法 | 频次 |
|---|---|---|---|
| 身份认证 | 本地用户+MFA | 登录审计与失败告警 | 持续 |
| 授权管理 | RBAC与最小权限 | 权限审计与越权告警 | 每周 |
| 网络隔离 | 内外网分离与微分段 | 端口扫描与路由审计 | 每周 |
| 加密 | 静态与传输加密 | 配置核查与证书检查 | 每月 |
| 镜像安全 | 扫描、SBOM与签名 | 构建与部署校验 | 每次发布 |
| 备份与恢复 | 全量/增量与隔离 | 恢复演练与校验 | 每月 |
| 审计日志 | 全量记录与脱敏 | 日志审计与留存检查 | 每周 |
| 应急响应 | 预案与演练 | 复盘与改进记录 | 每季度 |

### 供应链安全

在CI/CD中集成镜像扫描与签名,生成SBOM并纳入审计;部署前验证签名与供应链完整性,阻断高危镜像进入生产环境[^7][^6]。

### 审计与合规

访问日志与操作留痕纳入审计;日志留存与脱敏策略满足合规要求;在报告与仪表板中体现审计点与告警闭环,支持事后复盘与持续改进[^6]。

---

## 风险、权衡与演进路线

主要风险包括:硬件资源不足导致延迟与吞吐不达标;数据一致性风险在回滚与恢复时引发业务中断;模型漂移导致质量下降;备份恢复不充分导致数据永久丢失;监控盲区导致故障定位困难。权衡方面:Ollama与vLLM在易用性与性能之间取舍;本地存储与NAS在延迟与可靠性之间平衡;监控覆盖与资源开销需动态调整。演进路线建议从单节点Compose起步,逐步引入专用推理节点与横向扩展,最终在多节点与边缘环境中实现规模化部署与治理[^3][^1]。

表15 风险-影响-缓解矩阵(示例)

| 风险 | 触发条件 | 影响 | 概率 | 缓解措施 | 应急预案 |
|---|---|---|---|---|---|
| 资源不足 | 并发超基线、GPU显存不足 | 延迟升高、错误率上升 | 中 | 压测与扩容、限额调优 | 临时降级与流量限制 |
| 数据不一致 | 回滚或恢复失败 | 业务中断 | 低–中 | 备份策略与一致性校验 | 切换到上一个稳定版本 |
| 模型漂移 | 输入分布变化 | 质量下降 | 中 | 漂移监控与再训练 | 回滚模型与提示优化 |
| 备份不足 | 备份失败或不可用 | 数据永久丢失 | 低 | 定期演练与校验 | 从NAS恢复并验证 |
| 监控盲区 | 指标与日志缺失 | 故障定位困难 | 中 | 指标字典与仪表板完善 | 临时增强日志与采样 |

---

## 实施路线图与验收标准

实施路线图建议分阶段推进:PoC阶段完成最小可用栈与端到端链路验证,建立性能基线与告警策略;试运行阶段开展压力测试与混沌演练,完善日志与审计,优化参数与容量;生产阶段上线高可用与多环境分层,建立SLO/SLA与值班体系,落实备份与灾备。验收标准覆盖功能、性能、可靠性与可维护性四类指标,并明确运维手册与应急预案[^1][^5]。

表16 阶段性里程碑与交付物清单(示例)

| 阶段 | 里程碑 | 交付物 |
|---|---|---|
| PoC | 最小栈部署与链路打通 | 架构文档、参数基线、仪表盘与告警规则 |
| 试运行 | 压测与混沌演练 | 压测报告、混沌实验记录、优化清单 |
| 生产 | HA上线与值班体系 | SLO/SLA、值班表、应急预案、备份与恢复演练记录 |

表17 验收标准对照(示例)

| 类别 | 指标 | 阈值 | 验证方法 |
|---|---|---|---|
| 功能 | API可用性 | 100%核心接口可用 | 自动化回归与集成测试 |
| 性能 | 延迟(P95)/吞吐 | 满足业务SLO | 压测与基线对比 |
| 可靠性 | 可用性 | ≥99.9% | 混沌演练与故障注入 |
| 可维护性 | 部署/回滚时间 | ≤目标窗口 | GitOps与蓝绿/金丝雀验证 |

---

## 附录:配置模板与落地清单

为便于直接落地,附录提供关键配置模板与速查清单。实际部署时应按环境差异进行参数化与版本管理,确保可重复与可回滚。

表18 关键配置项速查(示例)

| 字段 | 示例 | 说明 | 注意事项 |
|---|---|---|---|
| version | "3.8" | Compose文件版本 | 与Docker引擎兼容 |
| networks | bridge, 子网规划 | 容器网络 | 内外网隔离,外部入口唯一 |
| volumes | postgres_data/redis_data/weaviate_data | 命名卷 | 本地IO优先,备份指向NAS |
| services.nginx | ports: [80,443], depends_on | 反向代理 | TLS终止与路由 |
| services.api | healthcheck: /health, environment | API服务 | 连接DB/Redis/Weaviate |
| services.db | image: postgres:15-alpine | 数据库 | pg_isready健康检查 |
| services.redis | command: redis-server --appendonly yes | 缓存 | AOF持久化可选 |
| services.weaviate | PERSISTENCE_DATA_PATH | 向量库 | 数据路径挂载 |
| services.vllm/ollama | OpenAI兼容API | 模型服务 | 权重可挂载至NAS |
| deploy.resources.limits | cpus/memory | 资源限额 | 关键路径优先保障 |
| logging | driver, options | 日志限额 | 控制文件大小与数量 |

### 配置文件模板与字段说明

- Prometheus:设置全局采集间隔与告警规则;为API、模型服务、数据库、缓存与向量库配置抓取目标;启用模型服务的指标端点;结合告警规则路由到Alertmanager[^4][^5]。
- Grafana:导入或创建仪表板,覆盖API性能、模型吞吐与延迟、向量检索、缓存命中、数据库慢查询与系统资源;配置告警渠道与通知策略[^5]。
- Loki:设置日志摄取与标签规则,按服务与级别组织日志流;与Alertmanager联动,对关键错误与异常进行告警[^14]。

### 部署与验证

部署顺序建议为:网络与卷→数据库与缓存→向量库与模型服务→API与Web→监控与日志→反向代理。健康检查与冒烟测试在每阶段完成后进行,确保依赖就绪与链路通畅;验证清单包括:指标采集有效性、仪表板加载与变量过滤、告警触发与路由、通知渠道可达、备份与恢复演练记录。运维手册需明确值班与升级策略、监控与告警闭环、备份与恢复演练流程[^1][^5]。

---

## 参考文献

[^1]: Docker Compose 生产环境指南. https://docs.docker.com/compose/production/
[^2]: 容器化AI应用部署模式(架构示例). https://learn.microsoft.com/zh-cn/azure/architecture/example-scenario/ai/ai-training-inferencing-containers
[^3]: vLLM 官方文档. https://docs.vllm.ai/en/stable/
[^4]: vLLM 接入 Prometheus/Grafana 示例. https://vllm.hyper.ai/docs/getting-started/examples/online-serving/prometheus_grafana/
[^5]: Prometheus + Grafana 监控部署(知乎专栏). https://zhuanlan.zhihu.com/p/24916339783
[^6]: 本地部署AI信息安全框架综述. https://www.sohu.com/a/876074884_121956424
[^7]: Docker 镜像构建最佳实践. https://docs.docker.com/develop/develop-images/dockerfile_best-practices/
[^8]: PostgreSQL 官方文档. https://www.postgresql.org/docs/
[^9]: Weaviate 官方文档. https://weaviate.io/developers/weaviate
[^10]: Memgraph 官方文档. https://memgraph.com/docs/memgraph/
[^11]: PDF图纸识别性能监控与评估体系蓝图(本报告配套评估框架)
[^12]: 云原生监控实战:Prometheus+Grafana快速搭建指南. https://developer.aliyun.com/article/1669439
[^13]: 基于Grafana+Prometheus搭建可视化监控系统. https://cloud.tencent.com/developer/article/2384051
[^14]: Loki vs ELK:谁是日志收集的终极选择? https://cloud.tencent.com/developer/article/2457079

---

## 信息缺口与实施提示

- 硬件规格与NAS品牌型号未提供:实际部署需结合设备能力调整CPU/GPU/内存与IO参数,并进行基线压测。
- 并发与吞吐目标未给出:监控阈值与资源配额需在试运行阶段逐步收敛,形成适合现场的SLA。
- 合规基线与KMS/HSM设施未明确:加密与密钥管理策略需与企业安全团队协同制定,确保审计与取证可行。
- 网络拓扑与边界防护未知:微分段与访问策略需结合网络架构落地,必要时引入WAF与IDS/IPS。
- 备份策略与RPO/RTO目标未定义:建议在试运行阶段进行恢复演练并记录RPO/RTO达成情况。
- 镜像供应链安全工具未指定:建议在CI/CD中集成扫描与签名,结合SBOM实现审计与合规。

通过上述模板与清单,结合现场硬件与负载进行参数调优与基线测试,即可在本地数据中心或边缘环境中落地一套安全、可观测、可维护且具备版本化与回滚能力的轻量级监控系统。---

## 完整部署配置与使用指南

本章提供完整的部署配置文件和自动化部署脚本，确保用户能够直接按照文档完成监控系统的部署。

### 1. Docker Compose 完整配置

```yaml
# docker-compose.yml
version: '3.8'

networks:
  monitoring:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16

volumes:
  prometheus_data:
    driver: local
  grafana_data:
    driver: local
  alertmanager_data:
    driver: local
  node_exporter_data:
    driver: local
  cAdvisor_data:
    driver: local

services:
  # Prometheus 监控服务
  prometheus:
    image: prom/prometheus:v2.45.0
    container_name: prometheus
    restart: unless-stopped
    ports:
      - "9090:9090"
    volumes:
      - ./config/prometheus.yml:/etc/prometheus/prometheus.yml
      - ./config/alert_rules.yml:/etc/prometheus/alert_rules.yml
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--storage.tsdb.retention.time=30d'
      - '--storage.tsdb.retention.size=10GB'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
      - '--storage.tsdb.wal-compression'
      - '--web.enable-lifecycle'
      - '--web.enable-admin-api'
    networks:
      - monitoring
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:9090/-/healthy"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

  # Grafana 可视化服务
  grafana:
    image: grafana/grafana:10.0.0
    container_name: grafana
    restart: unless-stopped
    ports:
      - "3000:3000"
    volumes:
      - grafana_data:/var/lib/grafana
      - ./config/grafana:/etc/grafana/provisioning
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin123
      - GF_USERS_ALLOW_SIGN_UP=false
      - GF_INSTALL_PLUGINS=grafana-piechart-panel
    networks:
      - monitoring
    depends_on:
      - prometheus
    healthcheck:
      test: ["CMD-SHELL", "curl -f http://localhost:3000/api/health || exit 1"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

  # AlertManager 告警管理
  alertmanager:
    image: prom/alertmanager:v0.25.0
    container_name: alertmanager
    restart: unless-stopped
    ports:
      - "9093:9093"
    volumes:
      - ./config/alertmanager.yml:/etc/alertmanager/alertmanager.yml
      - alertmanager_data:/alertmanager
    command:
      - '--config.file=/etc/alertmanager/alertmanager.yml'
      - '--storage.path=/alertmanager'
      - '--web.external-url=http://localhost:9093'
    networks:
      - monitoring
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:9093/-/healthy"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Node Exporter 系统监控
  node_exporter:
    image: prom/node-exporter:v1.6.0
    container_name: node_exporter
    restart: unless-stopped
    ports:
      - "9100:9100"
    volumes:
      - /proc:/host/proc:ro
      - /sys:/host/sys:ro
      - /:/rootfs:ro
    command:
      - '--path.procfs=/host/proc'
      - '--path.rootfs=/rootfs'
      - '--path.sysfs=/host/sys'
      - '--collector.filesystem.mount-points-exclude=^/(sys|proc|dev|host|etc)($$|/)'
    networks:
      - monitoring
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:9100/metrics"]
      interval: 30s
      timeout: 10s
      retries: 3

  # cAdvisor 容器监控
  cadvisor:
    image: gcr.io/cadvisor/cadvisor:v0.47.0
    container_name: cadvisor
    restart: unless-stopped
    ports:
      - "8080:8080"
    volumes:
      - /:/rootfs:ro
      - /var/run:/var/run:rw
      - /sys:/sys:ro
      - /var/lib/docker/:/var/lib/docker:ro
      - /dev/disk/:/dev/disk:ro
    privileged: true
    devices:
      - /dev/kmsg
    networks:
      - monitoring
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:8080/healthz"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Redis Exporter (可选)
  redis_exporter:
    image: oliver006/redis_exporter:v1.51.0
    container_name: redis_exporter
    restart: unless-stopped
    ports:
      - "9121:9121"
    environment:
      - REDIS_ADDR=redis://redis:6379
    networks:
      - monitoring
    depends_on:
      - redis
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:9121/metrics"]
      interval: 30s
      timeout: 10s
      retries: 3

  # PostgreSQL Exporter (可选)
  postgres_exporter:
    image: prometheuscommunity/postgres-exporter:v0.13.2
    container_name: postgres_exporter
    restart: unless-stopped
    ports:
      - "9187:9187"
    environment:
      - DATA_SOURCE_NAME=postgresql://postgres:password@postgres:5432/postgres?sslmode=disable
    networks:
      - monitoring
    depends_on:
      - postgres
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:9187/metrics"]
      interval: 30s
      timeout: 10s
      retries: 3

  # 示例应用服务 (可根据实际需要调整)
  api_service:
    image: your-api-image:latest
    container_name: api_service
    restart: unless-stopped
    ports:
      - "8000:8000"
    environment:
      - PROMETHEUS_METRICS=true
      - METRICS_PORT=8001
    networks:
      - monitoring
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

  # vLLM 模型服务 (可选)
  vllm_service:
    image: vllm/vllm-openai:latest
    container_name: vllm_service
    restart: unless-stopped
    ports:
      - "8001:8000"
    volumes:
      - ./models:/models
    environment:
      - CUDA_VISIBLE_DEVICES=0
    command: >
      --model /models/llama-2-7b-chat
      --host 0.0.0.0
      --port 8000
      --served-model-name llama-2-7b-chat
      --max-model-len 4096
      --tensor-parallel-size 1
    networks:
      - monitoring
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/v1/models"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s

  # Nginx 反向代理
  nginx:
    image: nginx:alpine
    container_name: nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./config/nginx/nginx.conf:/etc/nginx/nginx.conf
      - ./config/nginx/conf.d:/etc/nginx/conf.d
      - ./config/ssl:/etc/nginx/ssl
    networks:
      - monitoring
    depends_on:
      - grafana
      - prometheus
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost/health"]
      interval: 30s
      timeout: 10s
      retries: 3
```

### 2. Prometheus 配置文件

```yaml
# config/prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s
  external_labels:
    cluster: 'local-ai-factory'
    environment: 'production'

rule_files:
  - "alert_rules.yml"

alerting:
  alertmanagers:
    - static_configs:
        - targets:
          - alertmanager:9093

scrape_configs:
  # Prometheus 自身监控
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']
    scrape_interval: 5s
    metrics_path: /metrics

  # Node Exporter 系统监控
  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node_exporter:9100']
    scrape_interval: 15s
    metrics_path: /metrics

  # cAdvisor 容器监控
  - job_name: 'cadvisor'
    static_configs:
      - targets: ['cadvisor:8080']
    scrape_interval: 15s
    metrics_path: /metrics

  # AlertManager 监控
  - job_name: 'alertmanager'
    static_configs:
      - targets: ['alertmanager:9093']
    scrape_interval: 15s
    metrics_path: /metrics

  # API 服务监控
  - job_name: 'api-service'
    static_configs:
      - targets: ['api_service:8001']
    scrape_interval: 15s
    metrics_path: /metrics
    scrape_timeout: 10s

  # vLLM 模型服务监控
  - job_name: 'vllm-service'
    static_configs:
      - targets: ['vllm_service:8000']
    scrape_interval: 15s
    metrics_path: /metrics
    scrape_timeout: 10s

  # Redis 监控 (如果使用)
  - job_name: 'redis'
    static_configs:
      - targets: ['redis_exporter:9121']
    scrape_interval: 15s
    metrics_path: /metrics

  # PostgreSQL 监控 (如果使用)
  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres_exporter:9187']
    scrape_interval: 15s
    metrics_path: /metrics

  # 自定义应用监控
  - job_name: 'custom-applications'
    static_configs:
      - targets: 
        - 'api_service:8001'
        - 'vllm_service:8000'
    scrape_interval: 15s
    metrics_path: /metrics
    scrape_timeout: 10s
    relabel_configs:
      - source_labels: [__address__]
        target_label: __param_target
      - source_labels: [__param_target]
        target_label: instance
      - target_label: __address__
        replacement: 'prometheus:9090'

# 远程写入配置 (可选)
remote_write:
  - url: "http://your-remote-storage:8086/api/v1/prom/write?db=prometheus"
    queue_config:
      max_samples_per_send: 1000
      max_shards: 200
      capacity: 2500

# 远程读取配置 (可选)
remote_read:
  - url: "http://your-remote-storage:8086/api/v1/prom/read?db=prometheus"
```

### 3. AlertManager 配置文件

```yaml
# config/alertmanager.yml
global:
  smtp_smarthost: 'smtp.gmail.com:587'
  smtp_from: 'alerts@yourcompany.com'
  smtp_auth_username: 'alerts@yourcompany.com'
  smtp_auth_password: 'your-app-password'
  smtp_require_tls: true

route:
  group_by: ['alertname', 'cluster', 'service']
  group_wait: 10s
  group_interval: 10s
  repeat_interval: 1h
  receiver: 'default'
  routes:
    # 高优先级告警
    - match:
        severity: critical
      receiver: 'critical-alerts'
      group_wait: 5s
      repeat_interval: 15m
    
    # 中优先级告警
    - match:
        severity: warning
      receiver: 'warning-alerts'
      group_wait: 30s
      repeat_interval: 2h
    
    # 服务特定告警
    - match:
        service: 'api-service'
      receiver: 'api-team'
      group_wait: 10s
      repeat_interval: 30m
    
    - match:
        service: 'vllm-service'
      receiver: 'ml-team'
      group_wait: 10s
      repeat_interval: 30m

receivers:
  - name: 'default'
    email_configs:
      - to: 'admin@yourcompany.com'
        subject: '[监控告警] {{ .GroupLabels.alertname }}'
        body: |
          {{ range .Alerts }}
          告警: {{ .Annotations.summary }}
          描述: {{ .Annotations.description }}
          时间: {{ .StartsAt }}
          严重程度: {{ .Labels.severity }}
          服务: {{ .Labels.service }}
          实例: {{ .Labels.instance }}
          {{ end }}

  - name: 'critical-alerts'
    email_configs:
      - to: 'oncall@yourcompany.com'
        subject: '[P0 紧急告警] {{ .GroupLabels.alertname }}'
        body: |
          🚨 紧急告警 🚨
          
          {{ range .Alerts }}
          告警: {{ .Annotations.summary }}
          描述: {{ .Annotations.description }}
          时间: {{ .StartsAt }}
          严重程度: {{ .Labels.severity }}
          服务: {{ .Labels.service }}
          实例: {{ .Labels.instance }}
          {{ end }}
          
          请立即响应并处理此告警！
    webhook_configs:
      - url: 'http://slack-webhook:5000/alerts'
        send_resolved: true

  - name: 'warning-alerts'
    email_configs:
      - to: 'team@yourcompany.com'
        subject: '[P1 警告] {{ .GroupLabels.alertname }}'
        body: |
          ⚠️ 警告告警 ⚠️
          
          {{ range .Alerts }}
          告警: {{ .Annotations.summary }}
          描述: {{ .Annotations.description }}
          时间: {{ .StartsAt }}
          严重程度: {{ .Labels.severity }}
          服务: {{ .Labels.service }}
          实例: {{ .Labels.instance }}
          {{ end }}

  - name: 'api-team'
    email_configs:
      - to: 'api-team@yourcompany.com'
        subject: '[API服务告警] {{ .GroupLabels.alertname }}'
        body: |
          API团队告警通知
          
          {{ range .Alerts }}
          告警: {{ .Annotations.summary }}
          描述: {{ .Annotations.description }}
          时间: {{ .StartsAt }}
          严重程度: {{ .Labels.severity }}
          服务: {{ .Labels.service }}
          实例: {{ .Labels.instance }}
          {{ end }}

  - name: 'ml-team'
    email_configs:
      - to: 'ml-team@yourcompany.com'
        subject: '[ML模型服务告警] {{ .GroupLabels.alertname }}'
        body: |
          ML团队告警通知
          
          {{ range .Alerts }}
          告警: {{ .Annotations.summary }}
          描述: {{ .Annotations.description }}
          时间: {{ .StartsAt }}
          严重程度: {{ .Labels.severity }}
          服务: {{ .Labels.service }}
          实例: {{ .Labels.instance }}
          {{ end }}

inhibit_rules:
  # 如果服务不可用，抑制其他相关告警
  - source_match:
      alertname: 'ServiceDown'
    target_match:
      service: '{{ .source.service }}'
    equal: ['instance']
  
  # 如果主机不可用，抑制该主机上的服务告警
  - source_match:
      alertname: 'HostDown'
    target_match:
      instance: '{{ .source.instance }}'
    equal: ['instance']
```

### 4. Prometheus 告警规则

```yaml
# config/alert_rules.yml
groups:
  - name: infrastructure
    rules:
      # 主机CPU使用率过高
      - alert: HighCPUUsage
        expr: 100 - (avg by(instance) (irate(node_cpu_seconds_total{mode="idle"}[5m])) * 100) > 80
        for: 5m
        labels:
          severity: warning
          service: infrastructure
        annotations:
          summary: "CPU使用率过高"
          description: "实例 {{ $labels.instance }} CPU使用率已超过80%，当前值: {{ $value }}%"

      # 主机内存使用率过高
      - alert: HighMemoryUsage
        expr: (1 - (node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes)) * 100 > 85
        for: 5m
        labels:
          severity: warning
          service: infrastructure
        annotations:
          summary: "内存使用率过高"
          description: "实例 {{ $labels.instance }} 内存使用率已超过85%，当前值: {{ $value }}%"

      # 磁盘空间不足
      - alert: LowDiskSpace
        expr: (1 - (node_filesystem_avail_bytes / node_filesystem_size_bytes)) * 100 > 90
        for: 5m
        labels:
          severity: critical
          service: infrastructure
        annotations:
          summary: "磁盘空间不足"
          description: "实例 {{ $labels.instance }} 挂载点 {{ $labels.mountpoint }} 磁盘使用率已超过90%，当前值: {{ $value }}%"

      # 主机不可达
      - alert: HostDown
        expr: up{job="node-exporter"} == 0
        for: 1m
        labels:
          severity: critical
          service: infrastructure
        annotations:
          summary: "主机不可达"
          description: "实例 {{ $labels.instance }} 已离线超过1分钟"

  - name: containers
    rules:
      # 容器CPU使用率过高
      - alert: ContainerHighCPUUsage
        expr: rate(container_cpu_usage_seconds_total{name!=""}[5m]) * 100 > 80
        for: 5m
        labels:
          severity: warning
          service: containers
        annotations:
          summary: "容器CPU使用率过高"
          description: "容器 {{ $labels.name }} CPU使用率已超过80%，当前值: {{ $value }}%"

      # 容器内存使用率过高
      - alert: ContainerHighMemoryUsage
        expr: container_memory_usage_bytes{name!=""} / container_spec_memory_limit_bytes * 100 > 85
        for: 5m
        labels:
          severity: warning
          service: containers
        annotations:
          summary: "容器内存使用率过高"
          description: "容器 {{ $labels.name }} 内存使用率已超过85%，当前值: {{ $value }}%"

      # 容器重启频繁
      - alert: ContainerRestartFrequent
        expr: increase(container_start_time_seconds{name!=""}[1h]) > 3
        for: 0m
        labels:
          severity: warning
          service: containers
        annotations:
          summary: "容器重启频繁"
          description: "容器 {{ $labels.name }} 在过去1小时内重启了 {{ $value }} 次"

  - name: api-service
    rules:
      # API服务响应时间过长
      - alert: HighAPIResponseTime
        expr: histogram_quantile(0.95, rate(http_request_duration_seconds_bucket{job="api-service"}[5m])) > 2
        for: 5m
        labels:
          severity: warning
          service: api-service
        annotations:
          summary: "API响应时间过长"
          description: "API服务 95%请求响应时间超过2秒，当前值: {{ $value }}s"

      # API服务错误率过高
      - alert: HighAPIErrorRate
        expr: rate(http_requests_total{job="api-service",status=~"5.."}[5m]) / rate(http_requests_total{job="api-service"}[5m]) * 100 > 5
        for: 5m
        labels:
          severity: critical
          service: api-service
        annotations:
          summary: "API服务错误率过高"
          description: "API服务错误率已超过5%，当前值: {{ $value }}%"

      # API服务不可用
      - alert: APIServiceDown
        expr: up{job="api-service"} == 0
        for: 1m
        labels:
          severity: critical
          service: api-service
        annotations:
          summary: "API服务不可用"
          description: "API服务 {{ $labels.instance }} 已离线超过1分钟"

      # API请求量异常
      - alert: HighAPIRequestRate
        expr: rate(http_requests_total{job="api-service"}[5m]) > 100
        for: 10m
        labels:
          severity: warning
          service: api-service
        annotations:
          summary: "API请求量异常"
          description: "API服务请求量异常高，当前值: {{ $value }} req/s"

  - name: vllm-service
    rules:
      # vLLM模型服务响应时间过长
      - alert: HighVLLMResponseTime
        expr: histogram_quantile(0.95, rate(vllm_request_latency_seconds_bucket[5m])) > 10
        for: 5m
        labels:
          severity: warning
          service: vllm-service
        annotations:
          summary: "vLLM模型服务响应时间过长"
          description: "vLLM服务 95%请求响应时间超过10秒，当前值: {{ $value }}s"

      # vLLM模型服务错误率过高
      - alert: HighVLLMErrorRate
        expr: rate(vllm_requests_total{status="error"}[5m]) / rate(vllm_requests_total[5m]) * 100 > 2
        for: 5m
        labels:
          severity: critical
          service: vllm-service
        annotations:
          summary: "vLLM模型服务错误率过高"
          description: "vLLM服务错误率已超过2%，当前值: {{ $value }}%"

      # vLLM模型服务不可用
      - alert: VLLMServiceDown
        expr: up{job="vllm-service"} == 0
        for: 1m
        labels:
          severity: critical
          service: vllm-service
        annotations:
          summary: "vLLM模型服务不可用"
          description: "vLLM服务 {{ $labels.instance }} 已离线超过1分钟"

      # vLLM GPU利用率过高
      - alert: HighVLLMGPUUsage
        expr: rate(nvidia_gpu_utilization_percent[5m]) > 90
        for: 5m
        labels:
          severity: warning
          service: vllm-service
        annotations:
          summary: "vLLM GPU利用率过高"
          description: "vLLM服务 GPU利用率已超过90%，当前值: {{ $value }}%"

      # vLLM显存使用率过高
      - alert: HighVLLMGPUMemoryUsage
        expr: nvidia_gpu_memory_used_bytes / nvidia_gpu_memory_total_bytes * 100 > 90
        for: 5m
        labels:
          severity: warning
          service: vllm-service
        annotations:
          summary: "vLLM显存使用率过高"
          description: "vLLM服务显存使用率已超过90%，当前值: {{ $value }}%"

  - name: database
    rules:
      # Redis连接数过多
      - alert: RedisHighConnections
        expr: redis_connected_clients > 100
        for: 5m
        labels:
          severity: warning
          service: redis
        annotations:
          summary: "Redis连接数过多"
          description: "Redis实例连接数已超过100，当前值: {{ $value }}"

      # Redis内存使用率过高
      - alert: RedisHighMemoryUsage
        expr: redis_memory_used_bytes / redis_memory_max_bytes * 100 > 85
        for: 5m
        labels:
          severity: warning
          service: redis
        annotations:
          summary: "Redis内存使用率过高"
          description: "Redis内存使用率已超过85%，当前值: {{ $value }}%"

      # PostgreSQL连接数过多
      - alert: PostgreSQLHighConnections
        expr: pg_stat_database_numbackends / pg_settings_max_connections * 100 > 80
        for: 5m
        labels:
          severity: warning
          service: postgres
        annotations:
          summary: "PostgreSQL连接数过多"
          description: "PostgreSQL连接数使用率已超过80%，当前值: {{ $value }}%"

  - name: business
    rules:
      # 用户请求量异常
      - alert: HighUserRequestRate
        expr: rate(user_requests_total[5m]) > 50
        for: 10m
        labels:
          severity: info
          service: business
        annotations:
          summary: "用户请求量异常"
          description: "用户请求量异常高，当前值: {{ $value }} req/s"

      # 业务错误率过高
      - alert: HighBusinessErrorRate
        expr: rate(business_errors_total[5m]) / rate(business_requests_total[5m]) * 100 > 1
        for: 5m
        labels:
          severity: warning
          service: business
        annotations:
          summary: "业务错误率过高"
          description: "业务错误率已超过1%，当前值: {{ $value }}%"
```

### 5. Grafana 仪表板配置

```json
{
  "dashboard": {
    "id": null,
    "title": "AI工厂监控总览",
    "tags": ["ai-factory", "monitoring"],
    "timezone": "browser",
    "panels": [
      {
        "id": 1,
        "title": "系统概览",
        "type": "stat",
        "targets": [
          {
            "expr": "up{job=~\"node-exporter|cadvisor\"}",
            "legendFormat": "服务状态"
          }
        ],
        "gridPos": {
          "h": 8,
          "w": 12,
          "x": 0,
          "y": 0
        }
      },
      {
        "id": 2,
        "title": "API服务性能",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(http_requests_total{job=\"api-service\"}[5m])",
            "legendFormat": "{{method}} {{status}}"
          },
          {
            "expr": "histogram_quantile(0.95, rate(http_request_duration_seconds_bucket{job=\"api-service\"}[5m]))",
            "legendFormat": "P95响应时间"
          }
        ],
        "gridPos": {
          "h": 8,
          "w": 12,
          "x": 12,
          "y": 0
        }
      },
      {
        "id": 3,
        "title": "vLLM模型服务",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(vllm_requests_total[5m])",
            "legendFormat": "请求速率"
          },
          {
            "expr": "histogram_quantile(0.95, rate(vllm_request_latency_seconds_bucket[5m]))",
            "legendFormat": "P95延迟"
          }
        ],
        "gridPos": {
          "h": 8,
          "w": 12,
          "x": 0,
          "y": 8
        }
      },
      {
        "id": 4,
        "title": "资源使用情况",
        "type": "graph",
        "targets": [
          {
            "expr": "100 - (avg by(instance) (irate(node_cpu_seconds_total{mode=\"idle\"}[5m])) * 100)",
            "legendFormat": "CPU使用率"
          },
          {
            "expr": "(1 - (node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes)) * 100",
            "legendFormat": "内存使用率"
          }
        ],
        "gridPos": {
          "h": 8,
          "w": 12,
          "x": 12,
          "y": 8
        }
      }
    ],
    "time": {
      "from": "now-1h",
      "to": "now"
    },
    "refresh": "30s"
  }
}
```

### 6. 自动化部署脚本

```bash
#!/bin/bash

# deploy.sh - 轻量级监控系统自动化部署脚本
# 使用方法: ./deploy.sh [start|stop|restart|status|logs|clean]

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查依赖
check_dependencies() {
    log_info "检查系统依赖..."
    
    # 检查 Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker 未安装，请先安装 Docker"
        exit 1
    fi
    
    # 检查 Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose 未安装，请先安装 Docker Compose"
        exit 1
    fi
    
    # 检查端口占用
    local ports=(80 443 3000 8080 9090 9093 9100 9121 9187)
    for port in "${ports[@]}"; do
        if netstat -tuln 2>/dev/null | grep -q ":$port "; then
            log_warning "端口 $port 已被占用"
        fi
    done
    
    log_success "依赖检查完成"
}

# 创建目录结构
create_directories() {
    log_info "创建目录结构..."
    
    mkdir -p config
    mkdir -p config/grafana/provisioning/datasources
    mkdir -p config/grafana/provisioning/dashboards
    mkdir -p config/nginx/conf.d
    mkdir -p config/ssl
    mkdir -p logs
    mkdir -p models
    
    log_success "目录结构创建完成"
}

# 生成配置文件
generate_configs() {
    log_info "生成配置文件..."
    
    # Grafana 数据源配置
    cat > config/grafana/provisioning/datasources/prometheus.yml << EOF
apiVersion: 1
datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
    editable: true
EOF

    # Grafana 仪表板配置
    cat > config/grafana/provisioning/dashboards/dashboard.yml << EOF
apiVersion: 1
providers:
  - name: 'default'
    orgId: 1
    folder: ''
    type: file
    disableDeletion: false
    updateIntervalSeconds: 10
    allowUiUpdates: true
    options:
      path: /etc/grafana/provisioning/dashboards
EOF

    # Nginx 配置
    cat > config/nginx/nginx.conf << 'EOF'
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';
    
    access_log /var/log/nginx/access.log main;
    
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    
    # Gzip 压缩
    gzip on;
    gzip_vary on;
    gzip_min_length 10240;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
    
    # 包含站点配置
    include /etc/nginx/conf.d/*.conf;
}
EOF

    # Nginx 站点配置
    cat > config/nginx/conf.d/monitoring.conf << EOF
server {
    listen 80;
    server_name localhost;
    
    # 健康检查
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
    
    # Grafana
    location /grafana/ {
        proxy_pass http://grafana:3000/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Prometheus
    location /prometheus/ {
        proxy_pass http://prometheus:9090/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # AlertManager
    location /alertmanager/ {
        proxy_pass http://alertmanager:9093/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Node Exporter
    location /node-exporter/ {
        proxy_pass http://node_exporter:9100/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # cAdvisor
    location /cadvisor/ {
        proxy_pass http://cadvisor:8080/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # API 服务
    location /api/ {
        proxy_pass http://api_service:8000/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
    
    # vLLM 服务
    location /vllm/ {
        proxy_pass http://vllm_service:8000/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # 默认页面
    location / {
        return 200 '
        <html>
        <head><title>AI工厂监控系统</title></head>
        <body>
        <h1>AI工厂监控系统</h1>
        <ul>
        <li><a href="/grafana/">Grafana 监控面板</a></li>
        <li><a href="/prometheus/">Prometheus 监控数据</a></li>
        <li><a href="/alertmanager/">AlertManager 告警管理</a></li>
        <li><a href="/node-exporter/">Node Exporter 系统指标</a></li>
        <li><a href="/cadvisor/">cAdvisor 容器指标</a></li>
        </ul>
        </body>
        </html>';
        add_header Content-Type text/html;
    }
}
EOF

    log_success "配置文件生成完成"
}

# 启动服务
start_services() {
    log_info "启动监控服务..."
    
    # 检查 docker-compose.yml 是否存在
    if [ ! -f "docker-compose.yml" ]; then
        log_error "docker-compose.yml 文件不存在"
        exit 1
    fi
    
    # 启动服务
    docker-compose up -d
    
    # 等待服务启动
    log_info "等待服务启动..."
    sleep 30
    
    # 检查服务状态
    check_services_status
    
    log_success "监控服务启动完成"
}

# 停止服务
stop_services() {
    log_info "停止监控服务..."
    docker-compose down
    log_success "监控服务已停止"
}

# 重启服务
restart_services() {
    log_info "重启监控服务..."
    docker-compose restart
    sleep 30
    check_services_status
    log_success "监控服务重启完成"
}

# 检查服务状态
check_services_status() {
    log_info "检查服务状态..."
    
    local services=("prometheus" "grafana" "alertmanager" "node_exporter" "cadvisor")
    
    for service in "${services[@]}"; do
        if docker-compose ps $service | grep -q "Up"; then
            log_success "$service: 运行中"
        else
            log_error "$service: 未运行"
        fi
    done
    
    # 检查端口
    local ports=(3000 8080 9090 9093 9100)
    for port in "${ports[@]}"; do
        if netstat -tuln 2>/dev/null | grep -q ":$port "; then
            log_success "端口 $port: 监听中"
        else
            log_warning "端口 $port: 未监听"
        fi
    done
}

# 查看日志
show_logs() {
    local service=${1:-""}
    if [ -z "$service" ]; then
        docker-compose logs -f
    else
        docker-compose logs -f $service
    fi
}

# 清理数据
clean_data() {
    log_warning "这将删除所有监控数据，确定要继续吗? (y/N)"
    read -r response
    if [[ "$response" =~ ^([yY][eE][sS]|[yY])$ ]]; then
        log_info "清理监控数据..."
        docker-compose down -v
        docker system prune -f
        log_success "监控数据清理完成"
    else
        log_info "取消清理操作"
    fi
}

# 验证部署
verify_deployment() {
    log_info "验证部署..."
    
    # 检查服务健康状态
    local health_checks=(
        "http://localhost:9090/-/healthy:Prometheus"
        "http://localhost:3000/api/health:Grafana"
        "http://localhost:9093/-/healthy:AlertManager"
        "http://localhost:9100/metrics:Node Exporter"
        "http://localhost:8080/healthz:cAdvisor"
    )
    
    for check in "${health_checks[@]}"; do
        local url=$(echo $check | cut -d: -f1)
        local name=$(echo $check | cut -d: -f2)
        
        if curl -sf "$url" > /dev/null 2>&1; then
            log_success "$name: 健康"
        else
            log_error "$name: 不健康"
        fi
    done
    
    # 检查数据收集
    log_info "检查数据收集..."
    sleep 10
    
    local metrics_checks=(
        "up:Prometheus目标"
        "node_cpu_seconds_total:系统CPU指标"
        "container_cpu_usage_seconds_total:容器CPU指标"
        "http_requests_total:API请求指标"
    )
    
    for check in "${metrics_checks[@]}"; do
        local metric=$(echo $check | cut -d: -f1)
        local name=$(echo $check | cut -d: -f2)
        
        if curl -sf "http://localhost:9090/api/v1/query?query=$metric" | grep -q '"status":"success"'; then
            log_success "$name: 收集正常"
        else
            log_warning "$name: 收集异常"
        fi
    done
    
    log_success "部署验证完成"
}

# 显示帮助信息
show_help() {
    echo "轻量级监控系统部署脚本"
    echo ""
    echo "使用方法:"
    echo "  $0 start          启动监控系统"
    echo "  $0 stop           停止监控系统"
    echo "  $0 restart        重启监控系统"
    echo "  $0 status         查看服务状态"
    echo "  $0 logs [service] 查看日志 (可选指定服务)"
    echo "  $0 verify         验证部署"
    echo "  $0 clean          清理数据和容器"
    echo "  $0 help           显示此帮助信息"
    echo ""
    echo "访问地址:"
    echo "  Grafana:     http://localhost/grafana (admin/admin123)"
    echo "  Prometheus:  http://localhost/prometheus"
    echo "  AlertManager: http://localhost/alertmanager"
    echo "  Node Exporter: http://localhost/node-exporter"
    echo "  cAdvisor:    http://localhost/cadvisor"
}

# 主函数
main() {
    case "${1:-help}" in
        "start")
            check_dependencies
            create_directories
            generate_configs
            start_services
            verify_deployment
            ;;
        "stop")
            stop_services
            ;;
        "restart")
            restart_services
            ;;
        "status")
            check_services_status
            ;;
        "logs")
            show_logs "$2"
            ;;
        "verify")
            verify_deployment
            ;;
        "clean")
            clean_data
            ;;
        "help"|*)
            show_help
            ;;
    esac
}

# 执行主函数
main "$@"
```

### 7. PromQL 查询示例

#### 7.1 系统监控查询

```promql
# CPU 使用率
100 - (avg by(instance) (irate(node_cpu_seconds_total{mode="idle"}[5m])) * 100)

# 内存使用率
(1 - (node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes)) * 100

# 磁盘使用率
(1 - (node_filesystem_avail_bytes / node_filesystem_size_bytes)) * 100

# 网络IO
rate(node_network_receive_bytes_total[5m])
rate(node_network_transmit_bytes_total[5m])

# 负载平均值
node_load1
node_load5
node_load15
```

#### 7.2 容器监控查询

```promql
# 容器CPU使用率
rate(container_cpu_usage_seconds_total{name!=""}[5m]) * 100

# 容器内存使用率
container_memory_usage_bytes{name!=""} / container_spec_memory_limit_bytes * 100

# 容器网络IO
rate(container_network_receive_bytes_total{name!=""}[5m])
rate(container_network_transmit_bytes_total{name!=""}[5m])

# 容器数量
count(container_last_seen{name!=""})
```

#### 7.3 API服务监控查询

```promql
# 请求速率
rate(http_requests_total{job="api-service"}[5m])

# 错误率
rate(http_requests_total{job="api-service",status=~"5.."}[5m]) / rate(http_requests_total{job="api-service"}[5m]) * 100

# 响应时间分位数
histogram_quantile(0.50, rate(http_request_duration_seconds_bucket{job="api-service"}[5m]))
histogram_quantile(0.90, rate(http_request_duration_seconds_bucket{job="api-service"}[5m]))
histogram_quantile(0.95, rate(http_request_duration_seconds_bucket{job="api-service"}[5m]))
histogram_quantile(0.99, rate(http_request_duration_seconds_bucket{job="api-service"}[5m]))

# 活跃连接数
sum(http_requests_in_flight{job="api-service"})
```

#### 7.4 vLLM模型服务查询

```promql
# 请求速率
rate(vllm_requests_total[5m])

# 错误率
rate(vllm_requests_total{status="error"}[5m]) / rate(vllm_requests_total[5m]) * 100

# 响应时间分位数
histogram_quantile(0.50, rate(vllm_request_latency_seconds_bucket[5m]))
histogram_quantile(0.90, rate(vllm_request_latency_seconds_bucket[5m]))
histogram_quantile(0.95, rate(vllm_request_latency_seconds_bucket[5m]))

# 并发请求数
sum(vllm_requests_in_flight)

# 令牌生成速率
rate(vllm_generated_tokens_total[5m])

# GPU利用率 (需要nvidia_gpu_exporter)
rate(nvidia_gpu_utilization_percent[5m])

# GPU显存使用率
nvidia_gpu_memory_used_bytes / nvidia_gpu_memory_total_bytes * 100
```

#### 7.5 数据库监控查询

```promql
# Redis连接数
redis_connected_clients

# Redis内存使用率
redis_memory_used_bytes / redis_memory_max_bytes * 100

# Redis操作速率
rate(redis_commands_processed_total[5m])

# PostgreSQL连接数
pg_stat_database_numbackends / pg_settings_max_connections * 100

# PostgreSQL查询速率
rate(pg_stat_database_tup_returned[5m])
rate(pg_stat_database_tup_fetched[5m])
```

#### 7.6 业务指标查询

```promql
# 用户请求量
rate(user_requests_total[5m])

# 业务成功率
(rate(business_requests_total{status="success"}[5m]) / rate(business_requests_total[5m])) * 100

# 业务错误率
rate(business_errors_total[5m]) / rate(business_requests_total[5m]) * 100

# 特定业务指标
rate(business_custom_metric_total[5m])
```

#### 7.7 告警相关查询

```promql
# 告警总数
ALERTS{alertstate="firing"}

# 服务可用性
up == 1

# 响应时间异常
histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) > 2

# 错误率异常
rate(http_requests_total{status=~"5.."}[5m]) / rate(http_requests_total[5m]) * 100 > 5
```

### 8. 使用说明

#### 8.1 快速开始

1. **下载配置文件**
   ```bash
   # 确保所有配置文件都在相应目录中
   ls -la config/
   ls -la docker-compose.yml
   ```

2. **运行部署脚本**
   ```bash
   chmod +x deploy.sh
   ./deploy.sh start
   ```

3. **访问监控面板**
   - Grafana: http://localhost/grafana (admin/admin123)
   - Prometheus: http://localhost/prometheus
   - AlertManager: http://localhost/alertmanager

#### 8.2 常用操作

```bash
# 查看服务状态
./deploy.sh status

# 查看日志
./deploy.sh logs
./deploy.sh logs prometheus
./deploy.sh logs grafana

# 重启服务
./deploy.sh restart

# 停止服务
./deploy.sh stop

# 验证部署
./deploy.sh verify

# 清理数据
./deploy.sh clean
```

#### 8.3 自定义配置

1. **修改告警规则**: 编辑 `config/alert_rules.yml`
2. **调整告警通知**: 编辑 `config/alertmanager.yml`
3. **添加监控目标**: 编辑 `config/prometheus.yml`
4. **自定义仪表板**: 通过Grafana界面导入或创建

#### 8.4 性能调优

1. **调整采集频率**: 修改 `prometheus.yml` 中的 `scrape_interval`
2. **优化存储**: 调整 `storage.tsdb.retention.time` 和 `storage.tsdb.retention.size`
3. **资源限制**: 在 `docker-compose.yml` 中设置 `deploy.resources.limits`

这套完整的部署配置提供了从架构设计到实际部署的全套解决方案，用户可以直接按照文档完成监控系统的部署和配置。