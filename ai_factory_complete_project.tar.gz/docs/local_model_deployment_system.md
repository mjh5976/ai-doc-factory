# 本地模型部署与版本管理集成系统蓝图(MLflow + Docker Compose + vLLM/Ollama)

## 1. 执行摘要与范围界定

在本地化与数据合规成为主流诉求的背景下,中小型团队亟需一套“轻量但可治理”的模型部署与版本管理方案。本蓝图提出以开源组件为核心、在本地数据中心落地的集成系统:以 MLflow 负责实验追踪与模型注册,以 Docker Compose 编排推理服务与网关,以 vLLM/Ollama 提供推理引擎,以 Nginx 实现反向代理与灰度分流,以 Prometheus/Grafana/Loki/Alertmanager 构建监控与告警闭环。系统以 MLflow 的模型注册表为事实来源,通过别名(如 @champion)与阶段(Staging/Production)稳定指向生产版本,结合准入阈值与审批工作流实现受控推广与快速回滚[^1][^2][^3][^4][^5][^6]。

范围覆盖:端到端部署流水线、版本治理与标签策略、蓝绿与灰度发布、负载均衡与流量管理、监控与健康检查、自动回滚与恢复机制、CI/CD 集成。交付物包括 docker-compose.yml、推理服务配置、Nginx 路由与限流、Prometheus/Grafana/Loki/Alertmanager 规则与仪表板、CI/CD 流水线模板(GitHub Actions/Jenkins),以及脚本化操作清单。成功标准以“最小可行治理”为基线:可复现、可审计、可回滚、可观测、低成本、易维护;并在关键路径上提供明确准入阈值与回滚触发条件,确保生产风险可控[^1][^2][^3][^4][^5][^6]。

信息缺口与假设:操作系统与文件系统类型、数据库类型与版本、生产流量规模与 SLO、合规与安全基线、CI/CD 平台与镜像仓库、磁盘配额与限额、漂移监控阈值等未明确。本文在相关章节以参数化模板与“需现场验证”的方式提示,确保方案可落地且可调优[^1][^2][^3][^4][^5][^6]。

---

## 2. 总体架构与设计原则

总体架构由以下组件构成:MLflow Tracking/Registry(Backend Store + Artifact Store)、推理服务(vLLM 优先,Ollama 备选)、API 服务(编排与鉴权)、Nginx(反向代理与灰度分流)、PostgreSQL/Redis/Weaviate(数据与检索)、监控与日志(Prometheus/Grafana/Loki/Alertmanager)、NAS/本地卷(统一数据中枢)。设计原则:模块化拆分、最小权限、可观测性与可复现性并举、资源感知与弹性扩缩、简单可控与易于维护。容器编排以 Docker Compose 为核心,网络与卷统一管理,健康检查与依赖声明保障启动顺序与故障隔离;生产环境建议在 Compose 之上结合主机级守护与备份策略[^7][^8][^4][^3][^9]。

为便于职责划分与接口清晰,下表给出组件与责任映射。

表 1 组件与责任映射表
| 组件 | 核心职责 | 对外暴露 | 依赖 | 数据持久化 | 监控要求 |
|---|---|---|---|---|---|
| MLflow Tracking/Registry | 实验追踪、模型注册与治理 | 否(本地内网) | Backend Store、Artifact Store | 是(数据库 + 本地卷/NAS) | 注册操作失败、评估失败、磁盘占用 |
| vLLM/Ollama | 模型推理(LLM/Embedding) | 否(仅 API 访问) | GPU/CPU、权重挂载 | 权重可挂载至 NAS | 吞吐、P95/P99 延迟、显存/内存占用 |
| API 服务 | 业务编排、鉴权、路由与限流 | 否(经 Nginx) | DB、Redis、向量库、模型服务 | 无(配置挂载) | QPS、错误率、延迟 |
| Nginx | 反向代理、TLS 终止、灰度分流 | 是(80/443) | API、Web | 无(配置挂载) | 路由失败率、证书有效期 |
| PostgreSQL | 结构化数据存储 | 否 | 磁盘 IO | 是(数据卷 + NAS 备份) | 连接数、慢查询、磁盘使用 |
| Redis | 缓存与队列 | 否 | 内存与磁盘 | 是(AOF 可选) | 命中率、内存占用、延迟 |
| Weaviate | 向量索引与检索 | 否(仅 API 访问) | 磁盘与内存 | 是(数据路径挂载) | 索引大小、查询延迟 |
| Prometheus/Grafana/Loki/Alertmanager | 指标采集、可视化、日志聚合与告警 | 可选(内网) | 各服务 exporter/日志 | 无 | 采集延迟、告警有效性 |

上述矩阵强调“外部入口唯一、内部服务互信”的安全边界:所有面向互联网的访问统一通过 Nginx,内部服务之间通过容器网络隔离,数据库与缓存不对外暴露,模型服务与向量库仅由 API 服务调用,监控与日志系统以本地内网为主[^7][^8][^4][^3][^9]。

### 2.1 逻辑架构与数据流

从用户请求到模型推理与响应的路径:用户通过 Web 前端或 API 客户端发起请求,经 Nginx 反向代理进入 API 服务;API 服务根据业务逻辑读取或写入 PostgreSQL 与 Redis,并在需要时调用 Weaviate 进行向量检索;若请求涉及生成式任务,API 服务将提示词与上下文发送给 vLLM 或 Ollama 进行推理,生成结果返回给 API 服务,再由 API 服务统一组织响应经 Nginx 返回给用户。模型生命周期数据流贯穿始终:数据版本化与实验追踪由 MLflow 记录,模型注册与审批通过后由部署服务拉取权重并发布到推理服务;运行期指标与日志由 Prometheus 与 Loki 采集,Grafana 可视化并通过 Alertmanager 路由告警;回滚时从注册表或镜像仓库/对象存储拉取历史版本,切换流量并验证[^1][^3][^9]。

---

## 3. 模型部署流水线设计(端到端)

端到端流水线以 MLflow 为事实来源:训练与评估记录 → 模型注册(满足阈值与审批)→ 打包与容器化(推理镜像)→ 部署(Compose)→ 健康检查与冒烟测试 → 监控与告警接入 → 灰度与别名切换。每一阶段都设定准入条件与审计记录,确保可追溯与可回滚[^1][^10][^11][^7][^8]。

表 2 流水线阶段与准入条件(示例)
| 阶段 | 目标 | 准入条件 | 失败处理 |
|---|---|---|---|
| 训练与记录 | 生成可复现运行与工件 | 参数、指标、依赖与数据摘要完整 | 中止并通知,保留现场 |
| 评估与比较 | 与基线对比,判定候选 | 主指标与业务指标达标;诊断图表无异常 | 回退至上次稳定版本 |
| 注册模型 | 入库与标注(版本、标签、别名) | 审批工作流通过;审计记录完整 | 记录拒绝原因 |
| 容器化与部署 | 生成推理镜像并发布到预生产 | 镜像签名与扫描通过;健康检查通过 | 自动回滚 |
| 灰度与别名切换 | 低风险推广至生产 | 灰度窗口健康指标稳定;审批通过 | 立即回滚并告警 |
| 监控与告警 | 接入指标与日志,闭环告警 | 仪表板与告警规则验证通过 | 临时增强日志与采样 |

上述模板强调“评估先行、审批受控、回滚可达”的治理原则,确保每次发布都可度量、可审计、可回退[^1][^10][^11][^7][^8]。

### 3.1 容器化与推理服务选型

在推理框架选型上,Ollama以“开箱即用、多平台兼容”为优势,适合开发验证与低并发场景;vLLM以“高吞吐、批处理优化”为优势,适合生产环境与高并发场景。两者均提供 OpenAI 兼容的 REST API,便于与现有 API 服务集成[^3][^4]。

表 3 Ollama vs vLLM 对比(性能、并发、硬件、API、适用场景)
| 维度 | Ollama | vLLM |
|---|---|---|
| 部署复杂度 | 低,安装即用,多平台支持 | 中,需 Linux 与 CUDA 环境 |
| 性能与吞吐 | 中,适合低并发与快速验证 | 高,连续批处理与 PagedAttention 显著提升吞吐 |
| 并发能力 | 中,32 并发后提升有限 | 高,128 并发下吞吐显著优于 Ollama(示例比值约 3.23x) |
| 硬件支持 | GPU 与 CPU 均可,Apple/AMD/NVIDIA 兼容 | 以 NVIDIA GPU 为主,Linux 环境 |
| API 兼容性 | OpenAI 兼容 REST | OpenAI 兼容 REST |
| 模型格式 | GGUF 等 | safetensors/BF16 等 |
| 适用场景 | 开发/验证/轻量生产 | 生产级高并发与性能优先 |

选型建议:开发验证与低并发场景优先 Ollama;生产环境与高并发场景优先 vLLM;如需在多节点横向扩展,可结合 Ray 与 vLLM 的分布式能力实现规模化部署[^3][^4]。

### 3.2 打包与镜像供应链安全

镜像策略遵循多阶段构建与最小基镜像原则,固定版本与镜像摘要(digest)以保障可复现与安全;Dockerfile 遵循官方最佳实践,减少层数、清理缓存与非必要包,构建时进行安全扫描与依赖锁定;供应链安全控制包括 SBOM(软件物料清单)、镜像签名与最小权限运行(非 root、只读文件系统),机密管理通过环境变量与受管机密,避免明文密钥落在镜像与配置文件中[^12][^13]。

表 4 镜像供应链安全清单
| 控制项 | 实施要点 |
|---|---|
| 基础镜像来源 | 使用官方或受信任仓库,固定 digest |
| 扫描 | 构建流程集成漏洞扫描,阻断高危镜像 |
| SBOM | 生成软件物料清单,纳入审计 |
| 签名 | 对镜像进行签名,部署前验证 |
| 最小权限运行 | 非 root 用户运行,只读文件系统 |
| 机密管理 | 使用环境变量与密钥管理服务,避免明文泄露 |

---

## 4. 版本管理与标签策略(基于 MLflow Registry)

模型注册表是本方案的中枢。命名规范采用“业务域/模型名”,版本号由注册表自动递增;别名(如 @champion、@challenger)用于稳定指向生产或候选版本;标签用于业务维度分类(如 dataset:v2025.09、risk:low)。阶段转换(Staging/Production)需满足准入阈值并形成审计轨迹;评估与比较在 Staging 阶段完成,推广至生产前通过别名稳定指向当前生产版本,避免“版本漂移”[^14][^15][^16][^10][^17]。

表 5 模型阶段与准入条件模板
| 阶段 | 准入条件 | 审批人 | 审计记录 |
|---|---|---|---|
| Development | 训练完成并记录必要元数据 | 开发者 | 运行记录、依赖列表 |
| Staging | 评估指标达标;诊断图表无异常;资源占用评估 | 评审委员会 | 评估结果、比较报告 |
| Production | 灰度或 A/B 验证通过;回滚预案已确认 | 变更委员会 | 阶段转换记录、别名设定 |

### 4.1 评估与比较机制

通过 mlflow.evaluate 对候选模型与生产基线进行对比,关注主指标(如 AUC、RMSE)与关键业务指标(如转化率、召回率),并结合可视化诊断(校准、残差、SHAP)识别潜在问题。对于生成式场景,使用专门的评估接口与指标集,并注意与传统评估框架的兼容性边界。推广时通过别名稳定指向新版本,确保服务配置与注册表一致[^10][^18]。

表 6 模型比较报告模板
| 模型版本 | 主指标 | 业务指标 | 诊断结论 | 风险评估 | 决策 |
|---|---|---|---|---|---|
| v003 | AUC=0.87 | 转化率+2.1% | 校准良好;SHAP 无异常 | 低 | 推广至 Production |
| v002(基线) | AUC=0.85 | 转化率基准 | 稳定 | 低 | 保持 @champion |

---

## 5. 蓝绿部署与灰度发布策略

蓝绿发布通过准备全套新版本环境(绿)并在新旧环境之间一次性切换流量,适合结构变化较大或需要完整验证的场景;灰度发布通过按百分比或用户群体逐步放量,结合 Nginx 路由与权重控制,实现低风险验证与快速回滚。两者均需设定观察窗口与健康阈值,失败即回滚并保留审计记录[^7][^8][^4]。

表 7 灰度参数与阈值模板
| 参数 | 建议值/范围 | 说明 |
|---|---|---|
| 初始流量比例 | 5%–10% | 小流量验证,观察窗口 30–60 分钟 |
| 步进幅度 | 10%–20% | 每次放量需健康检查通过 |
| 观察窗口 | 30–60 分钟 | 结合 P95/P99 延迟与错误率 |
| 回滚条件 | 错误率≥1%;P95≥基线+30% | 触发自动回滚与告警 |
| 审批门槛 | 连续两个窗口稳定 | 变更委员会审批后全量切换 |

### 5.1 流量切换与验证步骤

流量切换前进行预检:健康检查通过、依赖服务就绪、监控与告警验证;切换后进行冒烟测试与指标复核,包括 P95/P99 延迟、错误率与业务指标;如出现异常,按预案回滚并记录审计。Nginx 作为统一入口,结合权重路由实现灰度分流;vLLM 的指标端点与 Prometheus 联动,提供推理性能的实时观测与告警触发[^4][^9]。

---

## 6. 负载均衡与流量管理(Nginx + 推理服务)

Nginx 作为统一入口与反向代理,承担 TLS 终止、路由与限流;内部路由将请求分发至 API 服务与推理服务(vLLM/Ollama),并按权重实现灰度分流。限流策略包括基于并发与 QPS 的速率限制、基于用户或客户端的访问控制、熔断与降级(如减少最大并发、降低精度或切换至轻量模型),在异常时保护后端服务与保障用户体验[^7][^8][^4]。

表 8 端口与服务映射(示例)
| 服务 | 内部端口 | 外部端口 | 协议 | 暴露策略 |
|---|---|---|---|---|
| Nginx | 80,443 | 80,443 | HTTP/HTTPS | 对外暴露,统一入口 |
| API | 5001 | 无(经 Nginx) | HTTP | 仅内部访问 |
| vLLM | 8000 | 无 | HTTP | 仅内部访问 |
| Ollama | 11434 | 无 | HTTP | 仅内部访问 |
| PostgreSQL | 5432 | 无 | TCP | 仅内部访问 |
| Redis | 6379 | 无 | TCP | 仅内部访问 |
| Weaviate | 8080 | 无 | HTTP | 仅内部访问 |
| Prometheus | 9090 | 无 | HTTP | 仅内部访问 |
| Grafana | 3000 | 可选内网 | HTTP | 按需暴露 |
| Loki | 3100 | 无 | HTTP | 仅内部访问 |
| Alertmanager | 9093 | 无 | HTTP | 仅内部访问 |

---

## 7. 部署监控与健康检查(指标、日志、告警)

监控目标是以最低开销实现对服务健康、推理性能、数据管道与资源利用的可见性。指标采集采用 Prometheus,统一拉取模型服务、API 服务、数据库与缓存、向量库与系统主机的指标;可视化与告警采用 Grafana 与 Alertmanager,仪表板按服务与场景分层,告警路由与抑制策略确保有效通知与减少噪音。日志方案采用 Loki 收集容器日志,结合 Prometheus 对模型服务的指标进行展示与告警,形成指标与日志的联动分析[^9][^19][^20][^21]。

表 9 监控指标字典(示例)
| 指标名称 | 来源 | 采集频率 | 告警阈值 | 仪表板归属 |
|---|---|---|---|---|
| 请求 QPS | API 服务 | 15s | 超出基线+X% | API 性能 |
| P95/P99 延迟 | API/模型服务 | 15s | P95>基线+Y% | API/模型性能 |
| 错误率(5xx) | API 服务 | 15s | >1% | API 可靠性 |
| GPU/显存占用 | 模型服务 | 15s | >90%持续 N 分钟 | 模型资源 |
| 内存占用 | Redis/Weaviate/系统 | 15s | >85%持续 N 分钟 | 资源概览 |
| 磁盘 IO 等待 | 系统/DB | 15s | >20% | 资源与 DB |
| 向量查询延迟 | Weaviate | 15s | >基线+Z% | 检索性能 |
| 缓存命中率 | Redis | 15s | <80% | 缓存性能 |
| 慢查询计数 | PostgreSQL | 30s | >基线 | DB 性能 |
| 启动健康失败次数 | 各服务 | 30s | >3 | 可用性 |

表 10 告警路由与阈值(示例)
| 告警名称 | 严重级别 | 触发条件 | 通知渠道 | 抑制规则 |
|---|---|---|---|---|
| 模型 P95 延迟升高 | 高 | P95>基线+Y%持续 10 分钟 | 邮件/IM | 抑制与“错误率升高”同时触发 |
| 显存占用过高 | 高 | GPU 显存>90%持续 5 分钟 | 邮件/IM | 抑制与“节点负载过高” |
| API 错误率升高 | 中 | 5xx>1%持续 5 分钟 | 邮件/IM | 抑制与“依赖不可用” |
| Weaviate 查询延迟升高 | 中 | 延迟>基线+Z%持续 10 分钟 | 邮件/IM | 抑制与“磁盘 IO 等待高” |
| Redis 内存占用过高 | 中 | 内存>85%持续 10 分钟 | 邮件/IM | 抑制与“缓存命中率低” |
| PostgreSQL 慢查询激增 | 中 | 慢查询>基线持续 10 分钟 | 邮件/IM | 抑制与“磁盘 IO 等待高” |

健康检查建议统一采用间隔 30 秒、超时 10 秒、重试 3 次、启动保护期 40 秒的设置;日志级别默认 INFO,必要时调整为 DEBUG 并限时启用;告警阈值基于基线设定,避免误报与漏报[^9][^19][^20][^21]。

### 7.1 日志与指标关联分析

日志与指标的联动可显著缩短故障定位时间。建议在 Grafana 中通过看板将关键错误日志与指标变化并排展示;在 Alertmanager 中配置抑制规则,避免同一故障触发多个告警;建立“告警—处置—复盘”闭环,记录根因与改进措施,持续优化阈值与路由策略[^9][^19][^20][^21]。

---

## 8. 自动回滚与恢复机制

回滚策略以“触发条件—动作—验证—审计”为核心。触发条件包括指标退化(如 AUC 下降≥Δ)、错误率或延迟显著上升、数据分布漂移检测触发、线上业务指标异常。回滚动作将别名(如 @champion)重新指向稳定版本,并在服务层执行版本切换;恢复后进行验证与观察,确保系统稳定。最佳实践强调“先稳定、后分析”的原则:快速恢复服务,再进行根因分析与流程改进[^22][^23][^24][^10]。

表 11 回滚触发条件与动作清单
| 触发条件 | 阈值示例 | 回滚动作 | 验证步骤 | 审计记录 |
|---|---|---|---|---|
| 主指标退化 | AUC 下降≥0.03 | 将 @champion 指回 v002 | 重跑评估;比对诊断图 | 记录触发、回滚与验证日志 |
| 错误率上升 | 5xx 比例≥1% | 切换至稳定版本 | 检查服务健康与日志 | 事件时间线与影响范围 |
| 延迟上升 | P95 延迟≥+30% | 降级或回滚 | 压测与监控确认 | 性能指标与变更记录 |
| 漂移触发 | PSI≥0.25 | 回滚并触发再训练 | 数据分布复核 | 漂移报告与处置动作 |

---

## 9. 与 CI/CD 系统的集成(GitHub Actions/Jenkins)

在持续集成/持续交付中纳入模型训练、评估、注册与部署环节,可以将模型治理与软件工程流程统一起来。轻量级形态下,推荐在预生产环境进行自动评估与注册,再由人工审批推广至生产;如需更高弹性与可扩展性,可将部署迁移至 Kubernetes。关键在于将评估阈值与准入条件参数化,并在 UI 与日志中保留完整审计轨迹[^25][^26][^11]。

表 12 CI/CD 阶段与准入条件模板
| 阶段 | 目标 | 准入条件 | 失败处理 |
|---|---|---|---|
| 训练与记录 | 生成可复现运行 | 参数与依赖完整记录 | 中止并通知 |
| 评估与比较 | 与基线比较 | 主指标与业务指标达标 | 回退至上次稳定版本 |
| 注册模型 | 入库与标注 | 审批工作流通过 | 记录拒绝原因 |
| 预生产部署 | 灰度验证 | 健康检查通过 | 自动回滚 |
| 生产发布 | 切换别名与流量 | 审批通过;监控稳定 | 立即回滚并告警 |

### 9.1 审批与审计工作流

审批节点设置在“注册模型”与“生产发布”两处,审批人角色与通知渠道明确;审计日志记录触发条件、阈值、动作与结果,确保每次变更可追溯与可复盘。MLflow 的模型注册表工作流与评估框架为审批与审计提供事实来源与可视化依据[^15][^10]。

---

## 10. 完整部署脚本与配置文件清单(本地落地)

本节汇总 docker-compose.yml、推理服务配置、Nginx 路由与限流、Prometheus/Grafana/Loki/Alertmanager 规则与仪表板、CI/CD 流水线模板,以及脚本化操作清单(部署、灰度、回滚、清理)。在生产环境建议启用日志驱动限额与资源限额,配置重启策略与回滚流程;镜像仓库与配置管理采用环境变量与只读挂载结合的方式,避免明文密钥落在镜像与配置文件中[^7][^8][^12][^13]。

表 13 目录挂载与权限(示例)
| 容器路径 | 主机路径/NAS | 读写权限 | 属主/属组 | 备份策略 |
|---|---|---|---|---|
| /var/lib/postgresql/data | 本地数据卷 | rw | postgres | 每周全量+每日增量 |
| /data | 本地数据卷(Redis) | rw | redis | 每周全量 |
| /var/lib/weaviate | 本地数据卷 | rw | weaviate | 每周全量+每日增量 |
| /etc/nginx/conf.d | 主机配置目录 | ro | root | 配置版本化 |
| /var/log | Loki/日志目录 | rw | adm | 每周归档到 NAS |
| /models | NAS 共享路径 | rw | appuser | 每次发布归档 |

### 10.1 脚本化操作清单

- 部署:拉取权重与镜像,更新 Compose 服务配置,执行健康检查与冒烟测试,接入监控与告警。
- 灰度:设定初始比例与步进幅度,按窗口观察健康指标,满足条件后逐步放量。
- 回滚:从注册表或镜像仓库选择上一个稳定版本,执行权重与镜像切换,进行健康检查与冒烟测试,记录回滚原因与结果并更新审计。
- 清理:按保留策略清理未注册运行工件与历史评估结果,确保 Registry 指向版本不被误删。

---

## 11. 运维、故障排除与备份恢复

运维重点在于保持系统稳定、数据完整与治理有效。建议建立例行任务与监控指标,形成闭环维护。故障场景包括工件写入失败、数据库不可用、模型加载失败、评估失败与回滚异常;排查步骤与解决方案需标准化,确保快速恢复与审计留痕[^27][^28][^9]。

表 14 运维检查清单
| 检查项 | 频率 | 工具/方法 | 阈值/告警条件 |
|---|---|---|---|
| 磁盘占用与增长 | 每日 | df/du + 脚本 | 连续 3 天增长≥10% |
| 数据库连接与慢查询 | 每周 | 数据库监控 | 慢查询≥100 次/周 |
| 工件读写错误率 | 每日 | 日志分析 | 错误率≥0.5% |
| 注册表操作失败 | 每日 | 应用日志 | 失败≥5 次/日 |
| 评估失败与阈值触发 | 每日 | 评估日志 | 连续触发≥2 次/日 |

表 15 故障场景-症状-排查-解决方案
| 场景 | 症状 | 排查步骤 | 解决方案 |
|---|---|---|---|
| 工件写入失败 | 训练中断 | 检查目录权限与磁盘空间 | 修复权限、清理空间、续写 |
| 数据库不可用 | UI 与 API 异常 | 检查连接与驱动 | 恢复服务、更新驱动与重试 |
| 模型加载失败 | 推理报错 | 检查 URI 与依赖 | 修正 URI、补齐依赖与验证 |
| 评估失败 | 指标缺失 | 检查数据与评估器 | 修复数据或更新评估器 |
| 回滚异常 | 别名未更新 | 检查服务配置与别名指向 | 手动修正并记录审计 |

清理与保留策略在运维中至关重要,应结合组织的安全与合规要求执行;建议以“最新 N 个版本保留”为默认策略,并对未注册运行工件设定较短保留期。归档命名应包含模型名、版本与时间戳,便于检索与清理;Registry 保护与删除前校验别名指向,避免误删生产版本[^27][^28]。

---

## 12. 风险、权衡与演进路线

主要风险包括:硬件资源不足导致延迟与吞吐不达标;数据一致性风险在回滚与恢复时引发业务中断;模型漂移导致质量下降;备份恢复不充分导致数据永久丢失。权衡方面:Ollama 与 vLLM 在易用性与性能之间取舍;本地存储与 NAS 在延迟与可靠性之间平衡;监控覆盖与资源开销需动态调整。演进路线建议从单节点 Compose 起步,逐步引入专用推理节点与横向扩展,最终在多节点与边缘环境中实现规模化部署与治理[^3][^7]。

表 16 风险-影响-缓解矩阵
| 风险 | 触发条件 | 影响 | 概率 | 缓解措施 | 应急预案 |
|---|---|---|---|---|---|
| 资源不足 | 并发超基线、GPU 显存不足 | 延迟升高、错误率上升 | 中 | 压测与扩容、限额调优 | 临时降级与流量限制 |
| 数据不一致 | 回滚或恢复失败 | 业务中断 | 低–中 | 备份策略与一致性校验 | 切换到上一个稳定版本 |
| 模型漂移 | 输入分布变化 | 质量下降 | 中 | 漂移监控与再训练 | 回滚模型与提示优化 |
| 备份不足 | 备份失败或不可用 | 数据永久丢失 | 低 | 定期演练与校验 | 从 NAS 恢复并验证 |
| 监控盲区 | 指标与日志缺失 | 故障定位困难 | 中 | 指标字典与仪表板完善 | 临时增强日志与采样 |

---

## 13. 附录:术语、API 与参考

术语简释:
- Experiment(实验):运行的集合,用于组织与查询。
- Run(运行):一次训练或评估过程的记录单元。
- Artifact(工件):运行过程中产生的大文件或目录,如模型权重与图表。
- Stage(阶段):模型版本所处的治理阶段,如 Staging、Production。
- Alias(别名):对模型版本的稳定引用,如 @champion。
- Flavor(风味):模型保存与加载的框架特定接口或自定义封装。
- PyFunc(Python Function 模型):MLflow 的通用 Python 模型封装机制。

常用 API 与示例:
- 记录与注册:mlflow.start_run、mlflow.log_param、mlflow.log_metric、mlflow.log_artifact、mlflow.log_model、mlflow.register_model。
- 加载与评估:mlflow.load_model、mlflow.evaluate、mlflow.genai.evaluate(用于 LLM)。
- 模型 URI:models://<model_name>/<version> 与 models://<model_name>@<alias>。

信息缺口说明:
- 操作系统与文件系统类型、数据库类型与版本、生产流量规模、合规要求、CI/CD 平台与镜像仓库、磁盘配额与限额、漂移监控阈值等未在本文中明确,需结合本地环境与组织策略补充与验证。

---

## 参考文献

[^1]: MLflow:管理机器学习生命周期的工具 | MLflow 平台. https://mlflow.org.cn/docs/latest/ml/  
[^2]: MLflow Model Registry: Guide to Managing the ML Lifecycle. https://mljourney.com/mlflow-model-registry-guide-to-managing-the-ml-lifecycle/  
[^3]: vLLM 官方文档. https://docs.vllm.ai/en/stable/  
[^4]: vLLM 接入 Prometheus/Grafana 示例. https://vllm.hyper.ai/docs/getting-started/examples/online-serving/prometheus_grafana/  
[^5]: 本地部署AI信息安全框架综述. https://www.sohu.com/a/876074884_121956424  
[^6]: 阿里云开发者社区:NAS的AI化升级方案. https://developer.aliyun.com/article/1585505  
[^7]: Docker Compose 生产环境指南. https://docs.docker.com/compose/production/  
[^8]: 容器化AI应用部署模式(架构示例). https://learn.microsoft.com/zh-cn/azure/architecture/example-scenario/ai/ai-training-inferencing-containers  
[^9]: Prometheus + Grafana 监控部署(知乎专栏). https://zhuanlan.zhihu.com/p/24916339783  
[^10]: MLflow 评估 | MLflow 平台. https://mlflow.org.cn/docs/latest/ml/evaluation/  
[^11]: 将 MLflow 模型部署到 Kubernetes | MLflow 平台. https://mlflow.org.cn/docs/latest/ml/deployment/deploy-model-to-kubernetes/  
[^12]: Docker 镜像构建最佳实践. https://docs.docker.com/develop/develop-images/dockerfile_best-practices/  
[^13]: Docker 安全最佳实践(Better Stack). https://betterstack.com/community/guides/scaling-docker/docker-security-best-practices/  
[^14]: MLflow 模型注册表 | MLflow 平台. https://mlflow.org.cn/docs/latest/ml/model-registry/  
[^15]: 模型注册表工作流 | MLflow 平台. https://mlflow.org.cn/docs/latest/ml/model-registry/workflow/  
[^16]: 模型注册表教程 | MLflow 平台. https://mlflow.org.cn/docs/latest/ml/model-registry/tutorial/  
[^17]: How to Evaluate Models Using MLflow - The Databricks Blog. https://www.databricks.com/blog/2022/04/19/model-evaluation-in-mlflow.html  
[^18]: Model Evaluation | MLflow. https://mlflow.org/docs/latest/ml/evaluation/model-eval  
[^19]: 云原生监控实战:Prometheus+Grafana快速搭建指南. https://developer.aliyun.com/article/1669439  
[^20]: Prometheus + Grafana监控方案详解:从入门到实战. https://juejin.cn/post/7503407890322374692  
[^21]: 基于Grafana+Prometheus搭建可视化监控系统. https://cloud.tencent.com/developer/article/2384051  
[^22]: Automated Rollback for ML Models - apxml.com. https://apxml.com/courses/monitoring-managing-ml-models-production/chapter-4-automated-retraining-updates/automated-rollback  
[^23]: SE-ML | Enable Automatic Roll Backs for Production Models. https://se-ml.github.io/best_practices/04-rollback_models_prod/  
[^24]: ML Model Rollback Strategies After Failed Deployment. https://mljourney.com/ml-model-rollback-strategies-after-failed-deployment/  
[^25]: Streamlining CI/CD Pipelines for ML Models Using GitHub Actions and Jenkins (2025). https://johal.in/streamlining-ci-cd-pipelines-for-ml-models-using-github-actions-and-jenkins-2025/  
[^26]: CI/CD for ML Models: Automate Deployment with Jenkins and MLflow. https://codezup.com/ci-cd-for-ml-models-jenkins-mlflow/  
[^27]: 清理 MLflow 资源 - 亚马逊 SageMaker AI. https://docs.amazonaws.cn/sagemaker/latest/dg/mlflow-cleanup.html  
[^28]: Artifact Stores - MLflow. https://mlflow.org/docs/latest/self-hosting/architecture/artifact-store/