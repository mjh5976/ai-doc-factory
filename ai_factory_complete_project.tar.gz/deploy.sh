#!/bin/bash

# PDF图纸识别性能监控系统部署脚本
# 作者: MiniMax Agent
# 日期: 2025-11-06

set -e  # 遇到错误立即退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# 检查依赖
check_dependencies() {
    log_step "检查系统依赖..."
    
    # 检查Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker未安装，请先安装Docker"
        exit 1
    fi
    
    # 检查Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose未安装，请先安装Docker Compose"
        exit 1
    fi
    
    # 检查Python
    if ! command -v python3 &> /dev/null; then
        log_error "Python3未安装，请先安装Python3"
        exit 1
    fi
    
    log_info "依赖检查完成"
}

# 创建目录结构
create_directories() {
    log_step "创建目录结构..."
    
    mkdir -p data/prometheus
    mkdir -p data/grafana
    mkdir -p data/alertmanager
    mkdir -p logs
    mkdir -p reports
    mkdir -p config
    
    # 设置权限
    chmod 755 data/prometheus
    chmod 755 data/grafana
    chmod 755 data/alertmanager
    chmod 755 logs
    chmod 755 reports
    chmod 755 config
    
    log_info "目录结构创建完成"
}

# 复制配置文件
copy_config_files() {
    log_step "复制配置文件..."
    
    # 复制Prometheus配置
    if [ -f "config/prometheus.yml" ]; then
        cp config/prometheus.yml data/prometheus/prometheus.yml
        log_info "Prometheus配置已复制"
    else
        log_warn "Prometheus配置文件不存在，跳过复制"
    fi
    
    # 复制AlertManager配置
    if [ -f "config/alertmanager.yml" ]; then
        cp config/alertmanager.yml data/alertmanager/alertmanager.yml
        log_info "AlertManager配置已复制"
    else
        log_warn "AlertManager配置文件不存在，跳过复制"
    fi
    
    # 复制Grafana仪表板配置
    if [ -f "config/grafana_dashboard.json" ]; then
        cp config/grafana_dashboard.json data/grafana/dashboard.json
        log_info "Grafana仪表板配置已复制"
    else
        log_warn "Grafana仪表板配置文件不存在，跳过复制"
    fi
}

# 创建Docker Compose文件
create_docker_compose() {
    log_step "创建Docker Compose配置..."
    
    cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  # Prometheus监控服务
  prometheus:
    image: prom/prometheus:latest
    container_name: pdf-prometheus
    restart: unless-stopped
    ports:
      - "9090:9090"
    volumes:
      - ./data/prometheus:/etc/prometheus
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
      - '--storage.tsdb.retention.time=200h'
      - '--web.enable-lifecycle'
    networks:
      - monitoring

  # Grafana可视化服务
  grafana:
    image: grafana/grafana:latest
    container_name: pdf-grafana
    restart: unless-stopped
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin123
      - GF_USERS_ALLOW_SIGN_UP=false
    volumes:
      - grafana_data:/var/lib/grafana
      - ./data/grafana/provisioning:/etc/grafana/provisioning
      - ./data/grafana/dashboard.json:/var/lib/grafana/dashboards/dashboard.json
    networks:
      - monitoring

  # AlertManager告警服务
  alertmanager:
    image: prom/alertmanager:latest
    container_name: pdf-alertmanager
    restart: unless-stopped
    ports:
      - "9093:9093"
    volumes:
      - ./data/alertmanager:/etc/alertmanager
    command:
      - '--config.file=/etc/alertmanager/alertmanager.yml'
      - '--storage.path=/alertmanager'
    networks:
      - monitoring

  # Node Exporter系统监控
  node-exporter:
    image: prom/node-exporter:latest
    container_name: pdf-node-exporter
    restart: unless-stopped
    ports:
      - "9100:9100"
    volumes:
      - /proc:/host/proc:ro
      - /sys:/host/sys:ro
      - /:/rootfs:ro
    command:
      - '--path.procfs=/host/proc'
      - '--path.rootfs=/rootfs'
      - '--path.sysfs=/host/sys'
      - '--collector.filesystem.mount-points-exclude=^/(sys|proc|dev|host|etc)($$|/)'
    networks:
      - monitoring

  # PDF识别应用服务
  pdf-recognition-service:
    image: python:3.9-slim
    container_name: pdf-recognition-service
    restart: unless-stopped
    ports:
      - "8080:8080"
    working_dir: /app
    volumes:
      - ./code:/app/code
      - ./reports:/app/reports
    command: >
      bash -c "
        pip install -r code/requirements.txt &&
        python code/monitoring_sdk.py
      "
    networks:
      - monitoring

  # 性能评估服务
  evaluation-service:
    image: python:3.9-slim
    container_name: evaluation-service
    restart: unless-stopped
    ports:
      - "8082:8082"
    working_dir: /app
    volumes:
      - ./code:/app/code
      - ./reports:/app/reports
    command: >
      bash -c "
        pip install -r code/requirements.txt &&
        python code/performance_evaluator.py
      "
    networks:
      - monitoring

volumes:
  prometheus_data:
  grafana_data:

networks:
  monitoring:
    driver: bridge
EOF

    log_info "Docker Compose配置已创建"
}

# 创建Grafana配置
setup_grafana() {
    log_step "配置Grafana..."
    
    mkdir -p data/grafana/provisioning/datasources
    mkdir -p data/grafana/provisioning/dashboards
    
    # 创建数据源配置
    cat > data/grafana/provisioning/datasources/prometheus.yml << 'EOF'
apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
    editable: true
EOF

    # 创建仪表板配置
    cat > data/grafana/provisioning/dashboards/dashboard.yml << 'EOF'
apiVersion: 1

providers:
  - name: 'PDF Blueprint Performance'
    orgId: 1
    folder: ''
    type: file
    disableDeletion: false
    updateIntervalSeconds: 10
    allowUiUpdates: true
    options:
      path: /var/lib/grafana/dashboards
EOF

    log_info "Grafana配置完成"
}

# 安装Python依赖
install_python_dependencies() {
    log_step "安装Python依赖..."
    
    cat > code/requirements.txt << 'EOF'
prometheus-client==0.17.1
scikit-learn==1.3.0
matplotlib==3.7.2
seaborn==0.12.2
pandas==2.0.3
numpy==1.24.3
scipy==1.11.1
jinja2==3.1.2
requests==2.31.0
psutil==5.9.5
EOF

    # 创建虚拟环境并安装依赖
    if [ ! -d "venv" ]; then
        python3 -m venv venv
    fi
    
    source venv/bin/activate
    pip install --upgrade pip
    pip install -r code/requirements.txt
    
    log_info "Python依赖安装完成"
}

# 启动服务
start_services() {
    log_step "启动监控服务..."
    
    # 启动所有服务
    docker-compose up -d
    
    log_info "服务启动中，等待服务就绪..."
    
    # 等待服务启动
    sleep 30
    
    # 检查服务状态
    check_service_status
    
    log_info "服务启动完成"
}

# 检查服务状态
check_service_status() {
    log_step "检查服务状态..."
    
    services=("pdf-prometheus" "pdf-grafana" "pdf-alertmanager" "pdf-node-exporter")
    
    for service in "${services[@]}"; do
        if docker ps --filter "name=$service" --filter "status=running" | grep -q "$service"; then
            log_info "$service 运行正常"
        else
            log_error "$service 启动失败"
        fi
    done
}

# 导入Grafana仪表板
import_grafana_dashboard() {
    log_step "导入Grafana仪表板..."
    
    # 等待Grafana启动
    sleep 10
    
    # 导入仪表板
    if [ -f "data/grafana/dashboard.json" ]; then
        curl -X POST \
          -H "Content-Type: application/json" \
          -d @data/grafana/dashboard.json \
          http://admin:admin123@localhost:3000/api/dashboards/db || log_warn "仪表板导入失败，请手动导入"
        
        log_info "Grafana仪表板导入完成"
    else
        log_warn "仪表板配置文件不存在"
    fi
}

# 创建测试脚本
create_test_script() {
    log_step "创建测试脚本..."
    
    cat > test_monitoring.sh << 'EOF'
#!/bin/bash

# 测试监控系统的功能

echo "开始测试PDF图纸识别监控系统..."

# 测试Prometheus
echo "测试Prometheus服务..."
if curl -s http://localhost:9090/api/v1/query?query=up > /dev/null; then
    echo "✓ Prometheus服务正常"
else
    echo "✗ Prometheus服务异常"
fi

# 测试Grafana
echo "测试Grafana服务..."
if curl -s http://localhost:3000/api/health > /dev/null; then
    echo "✓ Grafana服务正常"
else
    echo "✗ Grafana服务异常"
fi

# 测试AlertManager
echo "测试AlertManager服务..."
if curl -s http://localhost:9093/api/v1/status > /dev/null; then
    echo "✓ AlertManager服务正常"
else
    echo "✗ AlertManager服务异常"
fi

# 测试Node Exporter
echo "测试Node Exporter服务..."
if curl -s http://localhost:9100/metrics > /dev/null; then
    echo "✓ Node Exporter服务正常"
else
    echo "✗ Node Exporter服务异常"
fi

echo "监控系统测试完成"
EOF

    chmod +x test_monitoring.sh
    log_info "测试脚本已创建"
}

# 显示访问信息
show_access_info() {
    echo ""
    echo "=========================================="
    echo "PDF图纸识别监控系统部署完成！"
    echo "=========================================="
    echo ""
    echo "服务访问地址:"
    echo "  • Prometheus:  http://localhost:9090"
    echo "  • Grafana:     http://localhost:3000"
    echo "  • AlertManager: http://localhost:9093"
    echo "  • Node Exporter: http://localhost:9100"
    echo ""
    echo "Grafana登录信息:"
    echo "  • 用户名: admin"
    echo "  • 密码: admin123"
    echo ""
    echo "测试命令:"
    echo "  ./test_monitoring.sh"
    echo ""
    echo "停止服务:"
    echo "  docker-compose down"
    echo ""
    echo "查看日志:"
    echo "  docker-compose logs -f [service_name]"
    echo ""
}

# 主函数
main() {
    echo "=========================================="
    echo "PDF图纸识别性能监控系统部署"
    echo "=========================================="
    echo ""
    
    # 检查是否以root权限运行
    if [ "$EUID" -eq 0 ]; then
        log_warn "建议不要以root权限运行此脚本"
    fi
    
    # 执行部署步骤
    check_dependencies
    create_directories
    copy_config_files
    create_docker_compose
    setup_grafana
    install_python_dependencies
    start_services
    import_grafana_dashboard
    create_test_script
    
    show_access_info
}

# 执行主函数
main "$@"