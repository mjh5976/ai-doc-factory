# NAS-Bench-201 README 详细分析报告

## 项目概述

**项目名称**: NAS-Bench-201  
**GitHub仓库**: https://github.com/D-X-Y/NAS-Bench-201  
**作者**: Xuanyi Dong, Yi Yang  
**发表会议**: ICLR 2020  
**许可证**: MIT License  
**当前状态**: ⚠️ **已废弃** - 项目已被扩展为 NATS-Bench  

### ⚠️ 重要声明
该项目已被废弃，作者明确建议用户使用 **NATS-Bench** (https://github.com/D-X-Y/NATS-Bench) 作为替代方案。NATS-Bench 提供了：
- 5倍更多的架构信息
- 更快的API性能
- 更好的维护和支持

## 基准数据集特性

### 1. 搜索空间设计
- **架构类型**: 基于单元(cell)的神经架构搜索
- **搜索空间大小**: 15,625 个神经单元候选
- **网络结构**: 有向无环图(DAG)
- **节点配置**: 4个节点
- **操作选项**: 每条边5个操作选项

### 2. 支持的数据集
- **CIFAR-10**: 10类图像分类数据集
- **CIFAR-100**: 100类图像分类数据集  
- **ImageNet16-120**: ImageNet的子集，120类图像

### 3. 性能指标
- **准确率**: 训练和验证准确率
- **计算成本**: FLOPs、参数量、延迟
- **训练信息**: 完整的训练历史记录
- **评估结果**: 不同训练轮次的性能表现

## 安装指南

### 系统要求
- **Python**: >= 3.6.0
- **PyTorch**: >= 1.2.0

### 安装步骤

#### 1. 安装API包
```bash
pip install nas-bench-201
```

#### 2. 下载基准数据集文件
**推荐文件**: `NAS-Bench-201-v1_1-096897.pth` (4.7GB)  
**下载链接**: https://drive.google.com/file/d/16Y0UwGisiouVRxW-W5hEtbxmcHw_0hF_/view?usp=sharing

**旧版本文件**: `NAS-Bench-201-v1_0-e59899.pth`  
**下载链接**: https://drive.google.com/file/d/1SKW0Cu0u8-gb18zDpaAGi0f74UdXeGKs/view?usp=sharing

#### 3. 文件放置
将下载的 `.pth` 文件放置在以下位置之一：
- `~/.torch/` 目录
- 当前工作目录
- 自定义路径(需要在API中指定)

#### 4. 完整训练权重(可选)
如需完整训练权重，可下载226GB的完整存档文件。

## API使用方法

### 核心类

#### 1. NASBench201API - 主要API类
```python
from nas_201_api import NASBench201API as API

# 初始化API
api = API('NAS-Bench-201-v1_1-096897.pth', verbose=False)
api = API(None)  # 使用默认路径
```

#### 2. ArchResults - 架构结果类
```python
# 获取架构元信息
info = api.query_meta_info_by_index(1)
```

#### 3. ResultsCount - 结果计数类
```python
# 获取详细结果
res_metrics = info.get_metrics('cifar10', 'train')
```

### 常用API方法

#### 1. 创建API实例
```python
from nas_201_api import NASBench201API as API

# 使用指定路径
api = API('$path_to_meta_nas_bench_file')

# 使用默认文件名
api = API('NAS-Bench-201-v1_1-096897.pth', verbose=False)

# 使用默认路径
api = API(None)
```

#### 2. 展示架构信息
```python
# 遍历所有架构
num = len(api)
for i, arch_str in enumerate(api):
    print('{:5d}/{:5d} : {:}'.format(i, len(api), arch_str))

# 显示特定架构
api.show(1)
```

#### 3. 查询架构结果
```python
# 通过索引查询
info = api.query_meta_info_by_index(1)
res_metrics = info.get_metrics('cifar10', 'train')
cost_metrics = info.get_comput_costs('cifar100')

# 通过架构字符串查询
arch_str = '|nor_conv_3x3~0|+|nor_conv_3x3~0|avg_pool_3x3~1|+|skip_connect~0|nor_conv_3x3~1|skip_connect~2|'
index = api.query_index_by_arch(arch_str)
api.show(index)
```

#### 4. 获取网络配置和权重
```python
# 获取网络配置
config = api.get_net_config(123, 'cifar10')

# 创建网络
from models import get_cell_based_tiny_net
network = get_cell_based_tiny_net(config)

# 获取训练权重
param = api.get_net_param(123, 'cifar10')
network.load_state_dict(param)
```

### 详细API方法说明

#### NASBench201API 类方法
- `API()` - API实例构造函数
- `show(index)` - 显示指定索引的架构信息
- `query_meta_info_by_index(index)` - 获取架构元数据
- `query_by_index(index)` - 获取详细试验结果
- `query_index_by_arch(arch_str)` - 通过架构字符串查找索引
- `get_net_config(index, dataset)` - 获取网络配置
- `get_net_param(index, dataset)` - 获取训练权重
- `get_more_info(index, dataset, hp)` - 获取训练/评估指标

#### ArchResults 类方法
- `create_from_state_dict(state_dict)` - 从状态字典创建
- `arch_idx_str()` - 获取架构索引字符串
- `get_dataset_names()` - 获取支持的数据集列表
- `get_compute_costs(dataset)` - 获取计算成本指标
- `get_metrics(dataset, metric_type)` - 获取性能指标

#### ResultsCount 类方法
- `create_from_state_dict(state_dict)` - 从试验数据创建
- `get_train()` - 获取训练信息
- `get_eval()` - 获取评估信息
- `get_latency()` - 获取模型延迟
- `get_net_param()` - 获取训练参数

## 核心功能

### 1. 架构搜索空间
- 统一的15,625个神经架构候选
- 基于单元的搜索策略
- 支持多种操作类型(卷积、池化、跳跃连接等)

### 2. 性能评估
- 跨多个数据集的统一评估
- 完整的训练历史记录
- 计算成本分析(FLOPs、参数量、延迟)

### 3. 研究工具
- 算法无关的基准测试
- 快速原型验证
- 与AutoDL-Projects集成

### 4. 数据访问
- 高效的API接口
- 内存优化的数据存储
- 支持批量查询

## 相关资源

### 学术论文
- **论文链接**: https://openreview.net/forum?id=HJxyZkBKDr
- **发表会议**: ICLR 2020

### 相关项目
- **NATS-Bench**: https://github.com/D-X-Y/NATS-Bench (推荐使用)
- **AutoDL-Projects**: https://github.com/D-X-Y/AutoDL-Projects

### 测试代码
- **API测试示例**: https://github.com/D-X-Y/AutoDL-Projects/blob/master/exps/NAS-Bench-201/test-nas-api.py

### 数据下载链接
1. **最新基准文件**: https://drive.google.com/file/d/16Y0UwGisiouVRxW-W5hEtbxmcHw_0hF_/view?usp=sharing
2. **旧版本基准文件**: https://drive.google.com/file/d/1SKW0Cu0u8-gb18zDpaAGi0f74UdXeGKs/view?usp=sharing
3. **百度网盘备份**: https://pan.baidu.com/s/1CiaNH6C12zuZf7q-Ilm09w
4. **完整训练权重**: https://drive.google.com/open?id=1X2i-JXaElsnVLuGgM4tP-yNwtsspXgdQ

## 使用建议

### 对于新用户
1. **强烈推荐使用 NATS-Bench** 替代 NAS-Bench-201
2. NATS-Bench 提供更好的性能和更多功能
3. 更好的文档和维护支持

### 对于现有用户
1. 考虑迁移到 NATS-Bench
2. 当前API仍然可用但不推荐新项目使用
3. 关注项目迁移指南

### 技术要求
- 确保Python >= 3.6.0和PyTorch >= 1.2.0
- 准备足够的磁盘空间(至少5GB用于基准文件)
- 建议使用GPU进行深度学习实验

## 总结

NAS-Bench-201作为早期重要的神经架构搜索基准，为NAS研究提供了宝贵的标准化评估平台。虽然项目已被废弃，但其设计理念和API接口仍具有参考价值。建议新用户直接使用NATS-Bench，现有用户考虑逐步迁移到新平台。

---
*报告生成时间: 2025-11-06*  
*数据来源: GitHub官方仓库 README文档*